"""Client-safe source route (EQ-A-0106): for every Inputs indicator whose cells cite the IMF, an ordered list of sources.
IMF comes last and is used in internal mode only.

Why: IMF data is for internal research use only (EXC-003, Sam 2026-10-24 12:38Z), and licence enforcement withholds every
cell that cites it. On the 2026-10-23 data that is 465 Inputs cells in 29 indicators, out of the 492 Team B's
client-safe comparison withholds (validation.client_safe, EQ-B-0096). Team B fills 18 of them (5.14) from the World Bank. It puts the
rulebook midpoint in 198 and leaves 249 blank. This module supplies the cleared non-IMF value where one exists.
Every other cell gets a label that says why there is no free substitute.

Policy (one rule, already used by Team B in HO-20261024-A-B-011 item 3 for 'IMF IFS via WDI'): a World Bank series
whose WDI metadata names the IMF as its source (IFS, BOP, FSI, GFS) is IMF data republished, so its step is
client 'conditional': computed here, with the upstream named in its series text (which audit.client_output_reason
restricts), and never used for a client cell until Sam / AGENT-09 rule that the World Bank's CC BY 4.0 covers it
(docs/runbooks/A-client-safe-sources.md, team/when-sam-is-ready.md). The upstream attributions are from the WDI
metadata as recalled. They stay UNVERIFIED until the indicator metadata (sourceOrganization) is read on a Mac pull.

Steps carry:
    client     'yes' (cleared: World Bank own data, BIS, OECD, ECB, Eurostat, national), 'conditional' (IMF-compiled data
               in a World Bank dataset), 'no' (IMF; internal mode only)
    verified   'yes' when the code and values are in recorded data in the shared folder (data/live, Sam's
               team/inbox/pull-20261025T013150Z/raw_worldbank.csv sha256 d700f70f...), else 'UNVERIFIED' (probe list)
    built      a transform here computes it from recorded files (no network, ever)

Internal mode is untouched: nothing here is called by feeds.fetch_all or the quality gate. The client-safe build calls
`client_safe_values` and `apply_route` (Team B wiring, HO to B/AGENT-08).

CLI (offline):
    python -m econquest.ingestion.official.client_safe_route --as-of 2026-10-23
    python -m econquest.ingestion.official.client_safe_route --as-of 2026-10-23 --wb team/inbox/pull-20261025T013150Z/raw_worldbank.csv
    python -m econquest.ingestion.official.client_safe_route --route-table
"""
from __future__ import annotations

import argparse
import datetime as dt
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

import numpy as np
import pandas as pd

TICKET = "EQ-A-0106"
YES, COND, NO = "yes", "conditional", "no"
VERIFIED, UNVERIFIED = "yes", "UNVERIFIED"
WB_SOURCE = "wbgapi World Bank API v2"          # matches the worldbank_wdi register row (client_output allowed)
WB_REL = "live/raw_worldbank.csv"
BIS_REL = "live/raw_bis.csv"
ROUTE_FALLBACK = "non-IMF route (EQ-A-0106)"
ROUTE_PREFIX = "client-safe route (EQ-A-0106): "
NO_SUB_PREFIX = "no free non-IMF substitute (EQ-A-0106): "
# D3 (team/first-mac-pass.md): are IMF-compiled World Bank WDI series client-safe? ONE switch, the licence register row
# D3_ROW (data/licences.csv): client_output restricted = "no" (the default), allowed = "yes". It changes only through
# `econquest change` once Sam has baselined the register. Every conditional value this module writes carries D3_TAG
# in its series text (and names the International Monetary Fund in full), so that row alone decides it.
D3_ROW = "imf_via_wdi"
D3_TAG = "[imf_via_wdi]"
# The register row matches only D3_TAG while D3 is undecided (client output as before the row). Sam's "no" widens it to
# D3_STRICT_SERIES, the IMF-compiled WDI codes (a tightening); Sam's "yes" sets client_output allowed. d3_patch gives
# each as one `econquest change` patch; d3_report always computes "no" with the strict match.
D3_CODES = (r"FP\.CPI\.TOTL\.ZG|BN\.CAB\.XOKA\.(GD\.ZS|CD)|FI\.RES\.TOTL\.(CD|MO)|FM\.LBL\.BMNY\.GD\.ZS|FB\.AST\.NPER\.ZS|"
            r"GC\.(DOD|XPN|NLD|REV)\.[A-Z.]+|PX\.REX\.REER|FS\.AST\.PRVT\.GD\.ZS")
D3_TAG_SERIES = r"\[imf_via_wdi\]"
D3_STRICT_SERIES = rf"{D3_TAG_SERIES}|\b({D3_CODES})\b"


def d3_patch(answer: str) -> dict:
    """The `econquest change propose licences.csv --patch-file` document for Sam's D3 answer ("yes" or "no")."""
    if answer == "yes":
        return {f"/{D3_ROW}/client_output": "allowed"}
    if answer == "no":
        return {f"/{D3_ROW}/match_series": D3_STRICT_SERIES}
    raise ValueError(f"D3 answer must be yes or no, not {answer!r}")


def d3_text(kind: str) -> str:
    return f"{D3_TAG} International Monetary Fund {kind} data republished in WDI"


def d3_row(register: list[dict] | None = None) -> dict | None:
    from ..licences import safe_register
    reg = safe_register() if register is None else register
    return next((r for r in reg if r.get("source_id") == D3_ROW), None)


def d3_yes(register: list[dict] | None = None) -> bool:
    """Sam's D3 answer as the register records it: True only when the D3 row exists and says client_output allowed.
    A missing row, an unreadable register or any other value is the conservative "no"."""
    row = d3_row(register)
    return bool(row) and row.get("client_output") == "allowed"


GROWTH = "NY.GDP.MKTP.KD.ZG"
# 5.12 window: feeds.growth_sd_years / GROWTH_SD_* (ARCH-A-PI10 N5: one rule, shared with feeds.weo_transforms)


@dataclass(frozen=True)
class Step:
    source_id: str          # licence register row (data/licences.csv)
    series: str
    client: str             # YES | COND | NO
    verified: str           # VERIFIED | UNVERIFIED
    built: bool = False
    note: str = ""


def _imf(series: str, note: str = "") -> Step:
    return Step("imf_weo" if "WEO" in series else "imf_derived", series, NO, VERIFIED, False,
                note or "current internal source; internal mode only (EXC-003)")


# Ordered: first client 'yes' step that has a value wins in client mode; IMF last, internal only.
ROUTE: dict[str, tuple[Step, ...]] = {
    "1.1": (Step("worldbank_wdi", "GC.XPN.INTP.RV.ZS interest % revenue (IMF GFS via WDI)", COND, UNVERIFIED,
                 note="interest only, central government; 1.1 also needs principal"),
            _imf("econquest dsa: WEO interest + debt / avg maturity, % of GGR_NGDP")),
    "1.2": (Step("worldbank_ids", "IDS DT.TDS.DPPG.CD next two complete projection years / WDI FI.RES.TOTL.CD "
                 "(IMF IFS via WDI)", COND, VERIFIED, True,
                 note="engine.dsa 1.2 rule (ppg_debt_service_detail); IDS covers low- and middle-income economies only, "
                      "so MYS SGP JPN KOR VEN have none"),
            _imf("IMF IRFCL predetermined drains / analyst seed")),
    "1.3": (Step("cb_registry", "national debt stock (BCB SGS 13762 for BRA)", YES, UNVERIFIED,
                 note="cb_series_verified.csv verified=no; one country"),
            Step("oecd", "OECD general government debt (JPN, KOR, COL)", YES, UNVERIFIED, note="no adapter for this series"),
            Step("worldbank_wdi", "GC.DOD.TOTL.GD.ZS (IMF GFS via WDI)", COND, UNVERIFIED,
                 note="central government only (crosscheck.py excludes it on purpose)"),
            _imf("WEO GGXWDG_NGDP")),
    "1.4": (_imf("IMF Fiscal Monitor / Article IV GFN (analyst seed)"),),
    "1.6": (_imf("WEO GGXONLB_NGDP, GGXCNL_NGDP, GGXWDG_NGDP, NGDP"),),
    "1.7": (Step("oecd", "OECD general government debt, t minus t-5 (JPN, KOR, COL)", YES, UNVERIFIED),
            Step("worldbank_wdi", "GC.DOD.TOTL.GD.ZS t minus t-5 (IMF GFS via WDI)", COND, UNVERIFIED),
            _imf("WEO GGXWDG_NGDP (t minus t-5)")),
    "2.1": (Step("worldbank_wdi", "indicator-rules 17 (validation.nonimf_ara): ARA on WDI FI.RES.TOTL.CD, "
                 "NY.GDP.MKTP.CD, NE.EXP.GNFS.ZS, FM.LBL.BMNY.GD.ZS (IMF IFS via WDI), IDS DT.DOD.DSTC.CD and national "
                 "IIP portfolio liabilities", COND, UNVERIFIED,
                 note="reserves and broad money are IMF-compiled in WDI; FM.LBL.BMNY.GD.ZS never pulled; national IIP "
                      "has no adapter (HO-20261025-B-A-002)"),
            Step("worldbank_wdi", "FI.RES.TOTL.MO reserves in months of imports (IMF IFS via WDI)", COND, VERIFIED,
                 note="in worldbank_history.csv; a different metric from the IMF ARA ratio (Team B definition, Tier 1)"),
            _imf("usable reserves / IMF ARA metric (dsa_inputs.csv)")),
    "2.2": (Step("worldbank_ids", "(-WDI BN.CAB.XOKA.GD.ZS x NY.GDP.MKTP.CD + IDS DT.DOD.DSTC.CD + DT.AMT.DPPG.CD + "
                 "DT.AMT.PNGB.CD) / FI.RES.TOTL.CD (IMF BOP and IFS via WDI)", COND, VERIFIED, True,
                 note="official.worldbank 2.2 with the WEO current account replaced by WDI"),
            _imf("WEO BCA_NGDPD x NGDPD in official.worldbank 2.2")),
    "2.3": (Step("bis", "BIS international debt securities (non-resident holdings not split)", YES, UNVERIFIED,
                 note="not the same concept; no adapter"),
            _imf("IMF IIP / sovereign investor base (analyst seed)")),
    "2.4": (Step("cb_registry", "national FX deposit statistics", YES, UNVERIFIED, note="no adapter"),
            _imf("IMF FSI FX deposits (analyst seed)")),
    "2.5": (Step("third_party_unverified", "Ilzetzki-Reinhart-Rogoff de facto regime classification", YES, UNVERIFIED,
                 note="research dataset, licence unknown; not in the register"),
            _imf("IMF AREAER (analyst seed)")),
    "2.6": (_imf("IMF lending arrangements (analyst seed)"),),
    "2.7": (Step("third_party_unverified", "FATF public statements (grey and black lists), manual", YES, UNVERIFIED,
                 note="manual re-entry citing FATF only would clear the cell"),
            _imf("World Bank / IMF correspondent banking reports (analyst seed)")),
    "2.8": (Step("oecd", "OECD balance of payments, CA % GDP (JPN, KOR, COL)", YES, UNVERIFIED, note="no adapter"),
            Step("worldbank_wdi", "BN.CAB.XOKA.GD.ZS (IMF BOP via WDI)", COND, VERIFIED, True,
                 note="last actual year, WEO uses year t (a projection)"),
            _imf("WEO BCA_NGDPD")),
    "2.11": (Step("worldbank_wdi", "rule 2.11 WDI v1: TX.VAL.{FUEL,MMTL,FOOD,AGRI,MANF}.ZS.UN (UN Comtrade via WITS)",
                  YES, VERIFIED, True, note="indicator-rules 15, Sam approved 2026-10-25 13:19Z (EQ-A-0102)"),
             _imf("IMF BoP / UN Comtrade (analyst seed)")),
    "2.12": (Step("bis", "BIS EER_REAL_BROAD", YES, VERIFIED, note="already used; the 8 withheld names have no BIS series"),
             Step("third_party_unverified", "Bruegel REER database", YES, UNVERIFIED, note="licence unknown"),
             Step("worldbank_wdi", "PX.REX.REER (IMF IFS via WDI)", COND, UNVERIFIED, note="official.wdi_extra"),
             _imf("IMF REER (analyst seed)")),
    "3.8": (Step("third_party_unverified", "Open Budget Survey (IBP) / PEFA scores", YES, UNVERIFIED,
                 note="research datasets, licences unknown"),
            _imf("IMF data standards / Article IV (analyst seed)")),
    "5.1": (Step("cb_registry", "national monetary survey", YES, UNVERIFIED, note="no adapter"),
            _imf("IMF MFS (analyst seed)")),
    "5.2": (Step("cb_registry", "national FX loan statistics", YES, UNVERIFIED, note="no adapter"),
            _imf("IMF FSI (analyst seed)")),
    "5.4": (Step("worldbank_wdi", "WB Pink Sheet price + FS.AST.PRVT.GD.ZS (IMF IFS via WDI)", COND, UNVERIFIED),
            _imf("IMF credit data (analyst seed)")),
    "5.5": (Step("cb_registry", "national CPI (BCB 13522, BCRA 28, BoK 901Y009)", YES, UNVERIFIED,
                 note="cb_series_verified.csv verified=no"),
            Step("oecd", "OECD CPI (JPN, KOR, COL)", YES, UNVERIFIED, note="no adapter"),
            Step("worldbank_wdi", "FP.CPI.TOTL.ZG (IMF IFS via WDI)", COND, VERIFIED, True,
                 note="last actual year, WEO uses year t"),
            _imf("WEO PCPIPCH")),
    "5.6": (Step("worldbank_gep", "World Bank Global Economic Prospects real GDP forecast t+1", YES, UNVERIFIED,
                 note="World Bank's own forecast (EMDEs); not in WDI, no adapter, no register row yet"),
            Step("oecd", "OECD Economic Outlook real GDP projection (JPN, KOR, COL)", YES, UNVERIFIED),
            _imf("WEO NGDP_RPCH (t+1)")),
    "5.8": (Step("third_party_unverified", "FSB global monitoring report on NBFI", YES, UNVERIFIED),
            _imf("IMF FSAP (analyst seed)")),
    "5.9": (Step("bis", "BIS CREDIT_GAP", YES, VERIFIED, note="already used; the 9 withheld names have no BIS gap"),
            Step("worldbank_wdi", "FS.AST.PRVT.GD.ZS one-sided HP gap (IMF IFS via WDI)", COND, UNVERIFIED,
                 note="official.wdi_extra, method not approved (Tier 1)"),
            _imf("computed from IMF data (analyst seed)")),
    "5.10": (Step("worldbank_wdi", "FB.AST.NPER.ZS (IMF FSI via WDI)", COND, VERIFIED,
                  note="no value for VEN, SEN, ZWE in the recorded pulls"),
             _imf("IMF FSI (analyst seed)")),
    "5.12": (Step("worldbank_wdi", "NY.GDP.MKTP.KD.ZG (World Bank national accounts) 15y SD ex 2020-21", YES, VERIFIED,
                  True, note="needs 8 years in the window; mrnev 6 gave 4 (feeds.WB_HISTORY_MRNEV asks 20 next pull)"),
             _imf("WEO NGDP_RPCH (15y SD ex 2020-21)")),
    "5.13": (Step("bis", "BIS POLICY_RATE minus BIS consumer prices (WS_LONG_CPI)", YES, UNVERIFIED,
                  note="BIS CPI dataflow and codes not in recorded data; no adapter"),
             Step("cb_registry", "BIS POLICY_RATE minus national CPI", YES, UNVERIFIED),
             Step("worldbank_wdi", "BIS POLICY_RATE minus FP.CPI.TOTL.ZG (IMF IFS via WDI)", COND, VERIFIED, True),
             _imf("WS_CBPOL minus WEO PCPIPCH")),
    "5.14": (Step("worldbank_wdi", "NY.GDP.MKTP.CD / SP.POP.TOTL (World Bank national accounts, UN WPP)", YES, VERIFIED,
                  True, note="Team B's client-safe fallback already uses it"),
             _imf("WEO NGDPDPC")),
    "7.13": (Step("worldbank_wdi", "NY.GDP.MKTP.KD path after an EM-DAT disaster date", YES, UNVERIFIED,
                  note="EM-DAT is licensed; analyst method"),
             _imf("IMF post-disaster reviews / WEO (analyst seed)")),
}


# HO-20261025-B-A-002 (3): the ARA-applicability flag, out of the restricted dsa_inputs.csv. A desk judgement (reserve-
# currency issuers, for which the emerging-market ARA metric is not used), not IMF data; a test keeps it equal to the
# dsa_inputs.csv column the internal engine reads.
ARA_NOT_APPLICABLE = frozenset({"Singapore", "Japan"})


def ara_applicable(country: str) -> bool:
    return country not in ARA_NOT_APPLICABLE


def route_table() -> pd.DataFrame:
    """One row per (indicator, step) in route order."""
    rows = [{"key": k, "order": i + 1, "source_id": s.source_id, "series": s.series, "client": s.client,
             "verified": s.verified, "built": s.built, "note": s.note} for k, steps in ROUTE.items()
            for i, s in enumerate(steps)]
    return pd.DataFrame(rows)


def client_step(key: str) -> Step | None:
    """The first cleared (client 'yes'), verified, built step of `key`, or None."""
    return next((s for s in ROUTE.get(key, ()) if s.client == YES and s.verified == VERIFIED and s.built), None)


def no_substitute_reason(key: str) -> str:
    """Why `key` has no free substitute today (empty when a built cleared step exists)."""
    if client_step(key):
        return ""
    steps = ROUTE.get(key, ())
    cleared = [s for s in steps if s.client == YES]
    cond = [s for s in steps if s.client == COND]
    bits = []
    if cleared:
        bits.append("cleared candidates UNVERIFIED or not built: " + "; ".join(s.series for s in cleared))
    if cond:
        bits.append("IMF-compiled World Bank series only: " + "; ".join(s.series for s in cond))
    return "; ".join(bits) or "the only source is the IMF"


# ---------------------------------------------------------------------------------------------- recorded inputs

def last_usable_year(as_of) -> int:
    """WDI year y is published by 30 June y+1 (the rule official.worldbank uses for 2.11)."""
    d = pd.Timestamp(as_of).date()
    return d.year - 1 if d >= dt.date(d.year, 6, 30) else d.year - 2


def _read_long(p: Path, source_prefix: str | None = None) -> pd.DataFrame | None:
    """A recorded long file (iso, series, period, value[, source]). With `source_prefix`, only rows whose `source`
    starts with it are kept (SEC-A-012 L2: the register clears a file by its name, so a row another source wrote into
    a file of that name must not ride on that clearance); no `source` column keeps nothing (fail closed)."""
    if not p.is_file():
        return None
    df = pd.read_csv(p, dtype={"iso": str, "series": str, "period": str}, keep_default_na=False, na_values=[""])
    df["value"] = pd.to_numeric(df["value"], errors="coerce")
    if source_prefix is not None:
        src = df["source"].fillna("").astype(str) if "source" in df.columns else pd.Series("", index=df.index)
        df = df[src.str.startswith(source_prefix)].reset_index(drop=True)
    return df


def _annual(df: pd.DataFrame | None, iso: str, series: str, last: int | None = None) -> pd.Series:
    if df is None:
        return pd.Series(dtype=float)
    x = df[(df["iso"] == iso) & (df["series"] == series)].dropna(subset=["value"])
    s = pd.Series(x["value"].to_numpy(dtype=float), index=pd.to_numeric(x["period"], errors="coerce").to_numpy())
    s = s[np.isfinite(s.index.to_numpy(dtype=float))]
    s.index = s.index.astype(int)
    s = s[~s.index.duplicated(keep="last")].sort_index()
    return s[s.index <= last] if last is not None else s


def _file_cleared(name: str) -> str:
    """'' when the register lets this recorded file out to clients, else the reason (fail closed)."""
    from ..licences import file_licence, invalid_reason
    bad = invalid_reason()
    if bad:
        return bad
    row = file_licence(name)
    if row is None:
        return f"{name}: no licence register row"
    return "" if row.get("client_output") == "allowed" else f"{name}: register row {row['source_id']} is not client-allowed"


# ---------------------------------------------------------------------------------------------- transforms
# Each: (wb, bis, iso, as_of) -> (value or None, series text, reason)

def t_export_concentration(wb, bis, iso, as_of):
    from .worldbank import export_concentration
    v, text, why = export_concentration(wb, iso, as_of)
    return v, text, why


def t_growth_sd(wb, bis, iso, as_of):
    last = last_usable_year(as_of)
    g = _annual(wb, iso, GROWTH, last)
    from ..feeds import GROWTH_SD_MIN, GROWTH_SD_WINDOW, growth_sd_years
    h = growth_sd_years(g, last)
    if len(h) < GROWTH_SD_MIN:
        return None, "", (f"5.12: {len(h)} usable years of {GROWTH} in {last - GROWTH_SD_WINDOW + 1}-{last} ex 2020-21, "
                          f"need {GROWTH_SD_MIN} (recorded pull too short)")
    return (float(h.std(ddof=1)), f"rule 5.12 WDI: SD of {GROWTH} (World Bank national accounts) "
            f"{int(h.index[0])}-{int(h.index[-1])} ex 2020-21, {len(h)} years (window ends at the last actual year; "
            "WEO's included year t)", "")


def t_gdp_per_head(wb, bis, iso, as_of):
    last = last_usable_year(as_of)
    g, n = _annual(wb, iso, "NY.GDP.MKTP.CD", last), _annual(wb, iso, "SP.POP.TOTL", last)
    yrs = sorted(set(g.index) & set(n.index))
    if not yrs or n[yrs[-1]] <= 0:
        return None, "", "5.14: no common year of NY.GDP.MKTP.CD and SP.POP.TOTL"
    y = yrs[-1]
    return float(g[y] / n[y]), f"NY.GDP.MKTP.CD / SP.POP.TOTL {y} (World Bank national accounts, UN WPP)", ""


def _recent(wb, iso, series, as_of) -> tuple[float | None, int | None]:
    s = _annual(wb, iso, series, pd.Timestamp(as_of).year)
    if not len(s) or s.index[-1] < last_usable_year(as_of):
        return None, (int(s.index[-1]) if len(s) else None)
    return float(s.iloc[-1]), int(s.index[-1])


def t_ca_wdi(wb, bis, iso, as_of):
    v, y = _recent(wb, iso, "BN.CAB.XOKA.GD.ZS", as_of)
    if v is None:
        return None, "", f"2.8: BN.CAB.XOKA.GD.ZS latest year {y} older than {last_usable_year(as_of)}"
    return v, f"WDI BN.CAB.XOKA.GD.ZS {y} {d3_text('BOP')}", ""


def t_cpi_wdi(wb, bis, iso, as_of):
    v, y = _recent(wb, iso, "FP.CPI.TOTL.ZG", as_of)
    if v is None:
        return None, "", f"5.5: FP.CPI.TOTL.ZG latest year {y} older than {last_usable_year(as_of)}"
    return v, f"WDI FP.CPI.TOTL.ZG {y} {d3_text('IFS')}", ""


def t_real_policy_wdi(wb, bis, iso, as_of):
    cpi, y = _recent(wb, iso, "FP.CPI.TOTL.ZG", as_of)
    pol = pd.Series(dtype=float)
    if bis is not None:
        x = bis[(bis["iso"] == iso) & (bis["series"] == "POLICY_RATE") & (bis["period"] <= str(pd.Timestamp(as_of).date()))]
        pol = x.dropna(subset=["value"]).sort_values("period")["value"]
    if cpi is None or not len(pol):
        return None, "", "5.13: no BIS policy rate or no recent FP.CPI.TOTL.ZG"
    return float(pol.iloc[-1] - cpi), f"BIS POLICY_RATE minus WDI FP.CPI.TOTL.ZG {y} {d3_text('IFS')}", ""


def t_efn_wdi(wb, bis, iso, as_of):
    from .worldbank import wb_extra_transforms
    if wb is None:
        return None, "", "2.2: no World Bank file"
    ca, gdp = wb[wb["series"] == "BN.CAB.XOKA.GD.ZS"].copy(), wb[wb["series"] == "NY.GDP.MKTP.CD"].copy()
    ca["series"] = "BCA_NGDPD"
    gdp["series"], gdp["value"] = "NGDPD", gdp["value"] / 1e9
    try:
        ind, used, why = wb_extra_transforms(wb, pd.concat([ca, gdp]), iso, last_usable_year(as_of), as_of=as_of)
    except ValueError as e:
        return None, "", f"2.2: {e}"
    if "2.2" not in ind:
        return None, "", f"2.2: {why.get('2.2', 'not served')}"
    text = used["2.2"].replace("-WEO BCA_NGDPD x NGDPD", "-WDI BN.CAB.XOKA.GD.ZS x NY.GDP.MKTP.CD")
    return ind["2.2"], f"{text}; {d3_text('BOP and IFS')}", ""


def t_fxds_wdi(wb, bis, iso, as_of):
    """1.2 as Team B's rule (rules.dsa, which engine.dsa uses): PPG external debt service over the next two complete IDS projection years after the year
    before as_of, % of the latest WDI reserves (no countries.csv fallback: a client value reads cleared files only)."""
    from econquest.rules.dsa import ppg_debt_service_detail          # C15 (HO-20261026-A-B-004, EQ-A-0129)
    if wb is None:
        return None, "", "1.2: no World Bank file"
    w = wb.copy()
    w["period"] = pd.to_numeric(w["period"], errors="coerce")
    y0 = pd.Timestamp(as_of).year - 1
    ds, years, note = ppg_debt_service_detail(w, iso, y0)
    res, ry = _recent(wb, iso, "FI.RES.TOTL.CD", as_of)
    if not np.isfinite(ds) or res is None or res <= 0:
        return None, "", ("1.2: " + (note or ("no IDS DT.TDS.DPPG.CD projection years (IDS covers low- and middle-income "
                                              "economies only)" if not np.isfinite(ds) else
                                              f"no recent FI.RES.TOTL.CD (latest {ry})")))
    return (float(ds / res * 100), f"IDS DT.TDS.DPPG.CD {years} (World Bank) / WDI FI.RES.TOTL.CD {ry} {d3_text('IFS')}",
            "")


TRANSFORMS: dict[tuple[str, str], Callable] = {
    ("2.11", YES): t_export_concentration, ("5.12", YES): t_growth_sd, ("5.14", YES): t_gdp_per_head,
    ("2.8", COND): t_ca_wdi, ("5.5", COND): t_cpi_wdi, ("5.13", COND): t_real_policy_wdi, ("2.2", COND): t_efn_wdi,
    ("1.2", COND): t_fxds_wdi,
}

VALUE_COLUMNS = ["key", "country", "iso", "client", "value", "source_id", "source", "series", "reason"]


def client_safe_values(data_dir, as_of, wb_path=None, bis_path=None, keys=None,
                       include_conditional: bool = False) -> pd.DataFrame:
    """Non-IMF values for every routed indicator and desk country, from recorded files only.

    Rows with client 'yes' are what a client-safe build may use; with include_conditional, 'conditional' rows are
    added (IMF-compiled World Bank data, internal analysis only). A recorded file the licence register does not let
    out gives no values (fail closed); its reason is on every row. value is NaN with a reason when nothing applies."""
    from ..sources import read_csv_keep_na_code
    d = Path(data_dir)
    wbp = Path(wb_path) if wb_path else d / WB_REL
    bisp = Path(bis_path) if bis_path else d / BIS_REL
    blocked = {"wb": _file_cleared(wbp.name), "bis": _file_cleared(bisp.name)}
    wb = None if blocked["wb"] else _read_long(wbp, source_prefix=WB_SOURCE)
    bis = None if blocked["bis"] else _read_long(bisp)
    cty = read_csv_keep_na_code(d / "countries.csv", dtype=str)
    rows = []
    for key in (keys or ROUTE):
        kinds = [YES] + ([COND] if include_conditional else [])
        for kind in kinds:
            step = next((s for s in ROUTE.get(key, ()) if s.client == kind and s.built), None)
            fn = TRANSFORMS.get((key, kind))
            for _, r in cty.iterrows():
                base = {"key": key, "country": r["country"], "iso": r["iso"], "client": kind, "value": np.nan,
                        "source_id": step.source_id if step else "", "source": "", "series": "", "reason": ""}
                if fn is None or step is None:
                    if kind == YES:
                        rows.append({**base, "reason": NO_SUB_PREFIX + no_substitute_reason(key)})
                    continue
                if step.verified != VERIFIED:
                    rows.append({**base, "reason": f"{key}: step UNVERIFIED ({step.series})"})
                    continue
                if blocked["wb"]:
                    rows.append({**base, "reason": blocked["wb"]})
                    continue
                v, text, why = fn(wb, bis, r["iso"], as_of)
                if v is None or not np.isfinite(v):
                    rows.append({**base, "reason": why or "no value"})
                else:
                    rows.append({**base, "value": float(v), "source": WB_SOURCE if "POLICY_RATE" not in text
                                 else f"{WB_SOURCE}; BIS SDMX REST (stats.bis.org)", "series": text})
    return pd.DataFrame(rows, columns=VALUE_COLUMNS)


# ---------------------------------------------------------------------------------------------- client-safe build

REPLACEABLE = ("blank", "judgement placeholder: rulebook midpoint t50")
# a required-input placeholder: Team B's t50 marker before the route, or their rulebook worst score after
# stress_placeholders (EQ-B-0130 (c), validation.client_safe.WORST_KIND; HO-20261026-B-A-007)
PLACEHOLDER_KINDS = (REPLACEABLE[1], "judgement placeholder: rulebook worst score t100")


def apply_route(plan: pd.DataFrame, values: pd.DataFrame, d3: bool | None = None) -> pd.DataFrame:
    """Overlay the route on validation.client_safe.plan_replacements output (Team B's frame; a copy is returned).

    Only withheld IMF Inputs cells whose fallback is a blank or the rulebook placeholder change: a client 'yes' value
    replaces it (fallback ROUTE_FALLBACK); otherwise the replacement text gains the no-substitute label and the
    fallback is unchanged. Conditional rows count only when `d3` is True (default: the register's D3 row, d3_yes);
    a cleared 'yes' row wins over a conditional one for the same cell. Cells that are not withheld and Team B's own
    recomputes (5.14, 2.1) are never touched, so internal values and the withheld set are unchanged."""
    d3 = d3_yes() if d3 is None else d3
    out = plan.copy()
    use = values[(values["client"] == YES) | ((values["client"] == COND) & d3)]
    use = use[np.isfinite(use["value"])].sort_values("client", key=lambda c: c.map({YES: 0, COND: 1}))
    ok = pd.concat([use, values[(values["client"] == YES) & ~np.isfinite(values["value"])]])
    ok = ok[~ok.set_index(["key", "country"]).index.duplicated()].set_index(["key", "country"])
    for i, r in out.iterrows():
        if r.get("component") != "imf" or r.get("table") != "Inputs" or r.get("fallback") not in REPLACEABLE:
            continue
        cell = (str(r["key"]), r["country"])
        if cell in ok.index and np.isfinite(ok.at[cell, "value"]):
            out.at[i, "new_value"] = round(float(ok.at[cell, "value"]), 4)
            out.at[i, "replacement"] = ROUTE_PREFIX + ok.at[cell, "series"]
            out.at[i, "fallback"] = ROUTE_FALLBACK
        else:
            why = ok.at[cell, "reason"] if cell in ok.index else NO_SUB_PREFIX + no_substitute_reason(cell[0])
            out.at[i, "replacement"] = f"{r['replacement']} | {why}"
    return out


def counts(plan: pd.DataFrame) -> dict:
    """Withheld IMF cells by outcome: cleared value (Team B recompute or route), placeholder, blank."""
    w = plan[plan["component"] == "imf"]
    fb = w["fallback"].fillna("")
    return {"withheld_imf": int(len(w)), "route": int((fb == ROUTE_FALLBACK).sum()),
            "team_b_recompute": int(fb.str.startswith("World Bank").sum() + fb.str.startswith("recomputed").sum()),
            "placeholder": int(fb.isin(PLACEHOLDER_KINDS).sum()), "blank": int((fb == "blank").sum())}


# ---------------------------------------------------------------------------------------------- D3 report

def _register_variant(register: list[dict], client_output: str, strict: bool = True) -> list[dict]:
    """The register with the D3 row set to `client_output` and (strict) matching D3_STRICT_SERIES, as Sam's answer
    would leave it. ValueError when the row is missing."""
    import re

    def change(r: dict) -> dict:
        r = dict(r, client_output=client_output)
        if strict:
            r["match_series"] = D3_STRICT_SERIES
            if "_re" in r:                                  # licences.validate_register caches compiled patterns
                r["_re"] = {**r["_re"], "match_series": re.compile(D3_STRICT_SERIES, re.IGNORECASE)}
        return r
    out = [change(r) if r.get("source_id") == D3_ROW else r for r in register]
    if not any(r.get("source_id") == D3_ROW for r in out):
        raise ValueError(f"licence register has no {D3_ROW} row: the D3 switch is not installed (EQ-A-0117)")
    return out


def _withheld_by(register: list[dict], source: str, series: str, data_dir) -> bool:
    """Would licence enforcement withhold a record with this source / series under `register`? The register's most
    restrictive matching row (as audit.client_output_reason), then the pre-register rules (IMF / WEO text, Yahoo,
    theratesapi, national sources)."""
    from ..audit import REGISTER_CLEARABLE, _client_output_reason_rules
    from ..licences import licence_for
    row = licence_for(source=source, series=series, register=register)
    if row is not None and row.get("client_output") != "allowed" and row.get("source_id") not in REGISTER_CLEARABLE:
        return True
    return _client_output_reason_rules(source, "", series, data_dir=data_dir) is not None


def d3_flips(data_dir) -> pd.DataFrame:
    """Cells of audit_trail.csv (Inputs and Country Profile, the record classify_inputs uses) that the D3 switch alone
    decides: withheld when D3 is "no", allowed when "yes". Columns table, key, country, source, series."""
    from ..licences import load_register
    d = Path(data_dir)
    reg = load_register(d / "licences.csv")
    no, yes = _register_variant(reg, "restricted"), _register_variant(reg, "allowed")
    a = pd.read_csv(d / "audit_trail.csv", dtype=str, keep_default_na=False)
    a = a[a["table"].isin(["Inputs", "Country Profile"])].drop_duplicates(["table", "key", "country"])
    rows = [r for r in a[["table", "key", "country", "source", "series"]].to_dict("records")
            if _withheld_by(no, r["source"], r["series"], d) and not _withheld_by(yes, r["source"], r["series"], d)]
    return pd.DataFrame(rows, columns=["table", "key", "country", "source", "series"])


def _outcome(plan: pd.DataFrame) -> dict:
    c = counts(plan)
    fb = plan["fallback"].fillna("")
    w = plan["component"].fillna("") != ""
    c["cells"] = int(len(plan))
    c["withheld_all"] = int(w.sum())
    c["client_real_values"] = int(len(plan) - (w & fb.isin(REPLACEABLE + PLACEHOLDER_KINDS[1:])).sum())
    return c


def d3_report(data_dir, as_of, wb_path=None, allow_unapproved: bool = True) -> dict:
    """Client-safe cells under D3 "no" and D3 "yes", computable now (INTERNAL analysis; nothing is written).

    Starts from Team B's plan (validation.client_safe.plan_replacements, the cells licence enforcement withholds under
    the register as it stands) and the route values (client_safe_values with conditional rows). "no": the D3 cells
    are withheld (Team B's fallback: placeholder for a required input, else blank) and conditional values are not
    used. "yes": the D3 cells keep their applied value and conditional values fill withheld IMF cells.
    Returns {"register_d3": "yes"|"no", "no": counts, "yes": counts, "flips": frame, "yes_clears": frame}."""
    from ...scorecard.readiness import REQUIRED_INDICATORS
    from ...validation import client_safe as C
    d = Path(data_dir)
    flips = d3_flips(d)
    fl = set(zip(flips["table"], flips["key"].astype(str), flips["country"]))
    # the plan BEFORE the route (required inputs on Team B's t50 marker): the route runs once per outcome below, then
    # Team B's stress_placeholders (HO-20261026-B-A-007); re-routing the finished plan would miss cells on t100
    plan = C.plan_replacements(d, as_of, allow_unapproved=allow_unapproved, route=False)
    cell = list(zip(plan["table"], plan["key"].astype(str), plan["country"]))
    in_fl = pd.Series([c in fl for c in cell], index=plan.index)
    mid = C.rulebook_midpoints(d)
    p_no = plan.copy()
    # enforcement labels a D3 cell with its source's row (worldbank_wdi / worldbank_ids), so Team B files it as
    # component 'other'; the report counts it with the IMF cells, keeping Team B's fallback
    p_no.loc[in_fl & (p_no["component"].fillna("") != ""), ["component", "register_id"]] = ["imf", D3_ROW]
    for i in p_no.index[in_fl & (p_no["component"].fillna("") == "")]:     # register says yes now: withhold them
        k = str(p_no.at[i, "key"])
        req = p_no.at[i, "table"] == "Inputs" and k in REQUIRED_INDICATORS and np.isfinite(mid.get(k, np.nan))
        p_no.loc[i, ["component", "register_id"]] = ["imf", D3_ROW]
        p_no.at[i, "new_value"] = mid[k] if req else np.nan
        p_no.at[i, "fallback"] = REPLACEABLE[1] if req else "blank"
        p_no.at[i, "replacement"] = "D3 no: withheld"
    p_yes = plan.copy()
    back = in_fl & (p_yes["component"].fillna("") != "")
    p_yes.loc[back, ["component", "fallback", "replacement"]] = ["", "", ""]
    p_yes.loc[back, "new_value"] = p_yes.loc[back, "value"]
    values = client_safe_values(d, as_of, wb_path=wb_path, include_conditional=True)
    q_no = C.stress_placeholders(apply_route(p_no, values, d3=False), d)
    q_yes = C.stress_placeholders(apply_route(p_yes, values, d3=True), d)
    moved = (q_yes["fallback"] == ROUTE_FALLBACK) & (q_no["fallback"] != ROUTE_FALLBACK)
    clears = q_yes.loc[moved, ["table", "key", "country", "new_value", "replacement"]].reset_index(drop=True)
    reg = C.load_licence_register(d, allow_unapproved)
    row = d3_row(reg) or {}
    state = "yes" if d3_yes(reg) else ("no" if row.get("match_series") == D3_STRICT_SERIES else "undecided")
    return {"register_d3": state,
            "no": _outcome(q_no), "yes": _outcome(q_yes), "flips": flips, "yes_clears": clears}


def render_d3(rep: dict, as_of: str, wb_label: str) -> str:
    n, y = rep["no"], rep["yes"]
    rows = [("Client cells with a real value (of all Inputs and Country Profile cells)", "client_real_values"),
            ("Withheld (all components)", "withheld_all"), ("Withheld IMF and D3", "withheld_imf"),
            ("... given a cleared non-IMF value: route", "route"), ("... Team B recompute (5.14)", "team_b_recompute"),
            ("... rulebook placeholder", "placeholder"), ("... blank", "blank")]
    L = [f"D3 report, as_of {as_of}, World Bank file: {wb_label}. Register D3 now: {rep['register_d3']}. "
         f"Cells: {n['cells']}. INTERNAL."
         + (" Undecided: client output is as before the D3 row (the 'no' withholds below are allowed; conditional "
            "values are not used)." if rep["register_d3"] == "undecided" else ""), "", "| Count | D3 no | D3 yes |", "|---|---:|---:|"]
    L += [f"| {lab} | {n[k]} | {y[k]} |" for lab, k in rows]
    f = rep["flips"]
    L += ["", f"Withheld only under no (allowed today if yes): {len(f)} cells: "
          + "; ".join(f"{k} x{len(g)} ({g['series'].iloc[0][:40]})" for k, g in f.groupby(["table", "key"]))]
    c = rep["yes_clears"]
    L += [f"Filled by IMF-compiled WDI values only under yes: {len(c)} cells: "
          + "; ".join(f"{k} x{len(g)}" for k, g in c.groupby("key"))]
    return "\n".join(L)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.official.client_safe_route", description=__doc__.split("\n")[0])
    ap.add_argument("--data", default="data")
    ap.add_argument("--as-of", default=None)
    ap.add_argument("--wb", default=None, help="a recorded raw_worldbank*.csv instead of <data>/live/raw_worldbank.csv")
    ap.add_argument("--route-table", action="store_true", help="print the route and exit")
    ap.add_argument("--conditional", action="store_true", help="also compute IMF-compiled World Bank steps (internal)")
    ap.add_argument("--d3-report", action="store_true", help="client-safe cells under D3 no and yes (INTERNAL)")
    ap.add_argument("--out", default=None, help="with --d3-report: folder for the two cell lists (CSV)")
    ap.add_argument("--d3-patch", choices=("yes", "no"), default=None,
                    help="print the econquest change patch (JSON) for Sam's D3 answer and exit")
    a = ap.parse_args(argv)
    if a.route_table:
        print(route_table().to_csv(index=False))
        return 0
    if a.d3_patch:
        import json
        print(json.dumps(d3_patch(a.d3_patch)))
        return 0
    if not a.as_of:
        ap.error("--as-of is required")
    if a.d3_report:
        rep = d3_report(a.data, a.as_of, wb_path=a.wb)
        print(render_d3(rep, a.as_of, a.wb or f"{a.data}/{WB_REL}"))
        if a.out:
            out = Path(a.out)
            out.mkdir(parents=True, exist_ok=True)
            rep["flips"].to_csv(out / "d3_no_withholds.csv", index=False)
            rep["yes_clears"].to_csv(out / "d3_yes_clears.csv", index=False)
            print(f"lists written to {out}")
        return 0
    v = client_safe_values(a.data, a.as_of, wb_path=a.wb, include_conditional=a.conditional)
    got = v[np.isfinite(v["value"])]
    print(f"cells with a non-IMF value: {len(got[got.client == YES])} cleared, {len(got[got.client == COND])} conditional")
    print(got.groupby(["key", "client"]).size().to_string() if len(got) else "(none)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
