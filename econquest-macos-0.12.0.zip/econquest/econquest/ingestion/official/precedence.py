"""Source precedence for indicators two feeds can serve (EQ-A-0049).

Rule (documented in docs/validation/data-pipeline.md): for 2.12, 5.9 and 5.13, BIS first, then IMF.
  - BIS has a value for the country: the BIS value is used, whatever the IMF says. The IMF value, when there is one,
    is compared in the quality gate (official.gate, check 'bis_imf_cross') and the cell is held when the two differ by
    more than CROSS_TOL. The decision is written to transform_log.csv.
  - BIS has no value: the IMF value is used, and its provenance series says it is the fallback.
  - Neither: the cell stays empty (unserved reason from the IMF adapter).
Precedence is by source, never by freshness: a stale BIS value is held by the BIS staleness rule, it is not replaced
by the IMF value (Team B may change this; it is a model choice, not a data one).

5.9 has no IMF candidate yet: the credit gap for non-BIS economies needs a one-sided HP filter on IMF credit / WEO
GDP that Team B must approve. The rule is in place so the fallback needs no new wiring when it exists."""
from __future__ import annotations

import numpy as np

PRECEDENCE = {"2.12": ("bis", "imf_sdmx"), "5.9": ("bis", "imf_sdmx"), "5.13": ("bis", "imf_sdmx")}
# |BIS - IMF| above this (indicator units) holds the cell. Initial values, to calibrate on the first Mac pull:
#   2.12  5 pp: BIS broad and IMF CPI-based REER use different baskets and weights
#   5.9   3 pp: no IMF candidate yet
#   5.13  1 pp: same concept, but BIS is the latest daily rate and IMF a monthly figure
CROSS_TOL = {"2.12": 5.0, "5.9": 3.0, "5.13": 1.0}


def choose(key: str, values: dict) -> tuple[str | None, float | None, str]:
    """(feed used, value, note) for `key` given {feed: value or NaN}. Keys without a precedence rule: (None, None, '')."""
    order = PRECEDENCE.get(key)
    if not order:
        return None, None, ""
    have = {f: float(v) for f, v in values.items() if v is not None and np.isfinite(v)}
    for i, f in enumerate(order):
        if f in have:
            others = [o for o in order if o != f and o in have]
            if i == 0:
                note = (f"precedence {' > '.join(order)}: {f} used" + "".join(f"; {o} {have[o]:.4g} not used" for o in others))
            else:
                note = f"precedence {' > '.join(order)}: {f} used as fallback ({', '.join(order[:i])} has no value)"
            return f, have[f], note
    return None, None, f"precedence {' > '.join(order)}: no source has a value"


def disagreement(key: str, bis: float, imf: float, tol: dict | None = None) -> tuple[bool, str]:
    """(beyond tolerance, reason text) for the BIS-vs-IMF cross-check of `key`."""
    t = (tol or CROSS_TOL)[key]
    d = abs(bis - imf)
    bad = d > t
    return bad, (f"{key}: BIS {bis:.4g} vs IMF {imf:.4g} ({d:.3g} apart; tolerance {t:g})"
                 + ("" if bad else " within tolerance"))


# ---------------------------------------------------------------------------------------------- national sources
# EQ-A-0050: central-bank / national-statistics series (official.central_banks, feed 'cb') against the feeds that
# already serve the same cell (BIS / IMF for 5.13 and the profile policy rate, WEO for 5.5 and 1.3, World Bank for the
# profile reserves). Rule:
#   - national VERIFIED (data/panel/cb_series_verified.csv) and present: the national value is used; the existing
#     value is recorded in transform_log.csv and the gate compares the two ('cb_cross'), holding beyond NATIONAL_TOL;
#   - national UNVERIFIED: never replaces an existing value (recorded in transform_log.csv for calibration only); it
#     fills a cell only when no other feed did, and the gate holds it ('unverified');
#   - neither: the cell stays empty.
NATIONAL_FEED = "cb"
# |national - existing| above this (cell units) holds the cell. Initial values, to calibrate on the first Mac pull:
#   policy, 5.13  1 pp: same concept; national is the latest decision, BIS the latest monthly/daily print
#   5.5           3 pp: national 12-month CPI change vs the WEO current-year average (a forecast)
#   1.3          10 pp: national debt definitions (central vs general government, BCB DBGG) differ from WEO's
#   reserves      3 pp of GDP: latest monthly stock on WEO GDP vs the World Bank annual stock on WDI GDP
NATIONAL_TOL = {"policy": 1.0, "5.13": 1.0, "5.5": 3.0, "1.3": 10.0, "reserves": 3.0}


def choose_national(key: str, national: float, existing: float, existing_source: str | None,
                    verified: bool) -> tuple[str | None, float | None, str]:
    """(feed used, value, note) for one cell the national feed can serve. feed is NATIONAL_FEED when the national
    value is used, 'existing' when the cell keeps the value another feed wrote, None when neither has one."""
    nat = national is not None and np.isfinite(national)
    cur = existing is not None and np.isfinite(existing)
    other = existing_source or "existing feed"
    if nat and verified:
        return NATIONAL_FEED, float(national), (f"precedence national (verified) > {other}: cb used"
                                                + (f"; {other} {existing:.4g} not used" if cur else ""))
    if cur:
        return "existing", float(existing), (f"precedence {other} kept: cb " + (f"{national:.4g} " if nat else "")
                                             + ("not used (unverified)" if nat else "has no value"))
    if nat:
        return NATIONAL_FEED, float(national), "no other feed has a value: cb used as fallback (unverified, held)"
    return None, None, ""


def national_disagreement(key: str, national: float, other: float, tol: dict | None = None) -> tuple[bool, str]:
    """(beyond tolerance, reason) for the national-vs-existing cross-check of `key`."""
    t = (tol or NATIONAL_TOL).get(key, np.inf)
    d = abs(national - other)
    bad = d > t
    return bad, (f"{key}: national {national:.4g} vs existing {other:.4g} ({d:.3g} apart; tolerance {t:g})"
                 + ("" if bad else " within tolerance"))
