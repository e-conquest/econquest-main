"""OECD SDMX adapter (EQ-A-0049): 1.5 foreign-currency share of government debt for OECD members.

Lower priority than IMF / World Bank: it gives a better definition for about 17 OECD members of the 88, not
coverage (docs/runbooks/A-coverage-plan.md section 4). Named feed only (`fetch --only oecd`), not in the default
fetch, until its series are configured.

UNVERIFIED: OECD_BASE (SDMX REST of the 2024 OECD Data Explorer, per the OECD API data explainer), the CSV media
type, REF_AREA as ISO3, and every series. No central-government-debt-by-currency dataflow id or key is known from
here, so both specs are unconfigured (never requested) until the Mac structure check fills `key` and `filters`
(docs/runbooks/A-fetch-on-mac.md, IMF/OECD/Eurostat). Same transport, parser, raw-file and gate rules as the IMF
adapter."""
from __future__ import annotations

import urllib.parse
from dataclasses import dataclass, field

import pandas as pd

from . import OECD_LICENCE
from .sdmx import SdmxFeed, SeriesSpec, scaled

OECD_BASE = "https://sdmx.oecd.org/public/rest/data"     # UNVERIFIED
OECD_ACCEPT = "application/vnd.sdmx.data+csv; charset=utf-8"  # UNVERIFIED
OECD_LABEL = "OECD SDMX"

OECD_SPECS = {
    "cg_debt_fc": SeriesSpec("cg_debt_fc", "", None, "A", "central government debt, foreign currency",
                             candidate="OECD central government debt dataset; dataflow and key unknown (coverage map 1.5)"),
    "cg_debt_total": SeriesSpec("cg_debt_total", "", None, "A", "central government debt, all currencies",
                                candidate="same dataflow as cg_debt_fc; key unknown"),
}
FC_SHARE_COMPONENTS = ("cg_debt_fc", "cg_debt_total")


@dataclass
class OecdFeed(SdmxFeed):
    base: str = OECD_BASE
    accept: str = OECD_ACCEPT
    label: str = OECD_LABEL
    licence: str = OECD_LICENCE
    area_dim: str = "REF_AREA"
    registry: dict = field(default_factory=lambda: dict(OECD_SPECS))

    def url(self, spec: SeriesSpec, areas: list[str]) -> str:
        key = (spec.key or "{area}").format(area="+".join(areas))
        return f"{self.base}/{spec.flow}/{urllib.parse.quote(key, safe='+.')}?{urllib.parse.urlencode({'dimensionAtObservation': 'AllDimensions'})}"


def fc_share(raw: pd.DataFrame | None, iso: str, fc: str, total: str, label: str) -> tuple[float | None, str]:
    """Foreign-currency share of government debt, %: fc / total x 100 for the latest common period."""
    a, b = scaled(raw, iso, fc), scaled(raw, iso, total)
    common = sorted(set(a.index) & set(b.index))
    if not common or b[common[-1]] <= 0:
        return None, ""
    t = common[-1]
    return float(a[t] / b[t] * 100), f"{label} {fc} / {total} x 100, {t}"


def oecd_transforms(raw: pd.DataFrame | None, iso: str) -> tuple[dict, dict]:
    v, text = fc_share(raw, iso, *FC_SHARE_COMPONENTS, OECD_LABEL)
    return ({"1.5": v}, {"1.5": text}) if v is not None else ({}, {})
