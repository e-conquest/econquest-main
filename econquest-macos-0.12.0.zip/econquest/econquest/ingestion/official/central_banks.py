"""Central-bank and national-statistics adapters for the top-25 desk names (EQ-A-0050, coverage to 60% part 2).

Four concepts per country (CONCEPTS) and the cells they can serve:
    policy_rate   Country Profile `policy` (latest value) and Inputs 5.13 (policy minus WEO PCPIPCH, as the BIS rule)
    cpi           Inputs 5.5 (12-month change: a published y/y series, or computed from an index, t vs t-12)
    reserves      Country Profile `reserves` (% of GDP: latest reserves in US$ / WEO NGDPD of the fetch year)
    debt_stock    Inputs 1.3 (only when the national series is already % of GDP; a level series is fetched raw only)

CB_REGISTRY is keyed by ISO3, then concept: source, API, series key, frequency, unit, documented endpoint pattern,
licence / terms note, verified flag and a note. An entry whose api is MANUAL is not machine-readable from here, and
its note says why; an entry with an api but no series_key is a known API whose code is not known here. Neither is
requested: their cells are left to the other feeds or reported unserved with the reason.

EVERYTHING HERE IS UNVERIFIED. This cloud cannot reach any of these hosts. The endpoints, response layouts, series
codes and units below are written from the institutions' API documentation as remembered, not from a live answer.
Every registry entry ships verified="no"; a series counts as verified only when data/panel/cb_series_verified.csv has
a row for its (iso3, concept) with the SAME series_key and verified=yes, set after the per-country check on Sam's Mac
(docs/runbooks/A-central-bank-adapters.md). Until then:
  - precedence (official.precedence.choose_national): an unverified national value never replaces a BIS / IMF /
    WEO / World Bank value; it only fills a cell no other feed filled;
  - the quality gate (cb_gate_checks) holds every cell it fills ('unverified').

Transport: sources.https_get only (https, redirects refused, body capped), feeds._with_retries for transient errors.
Fail-fast per host: a proxy refusal, DNS failure or redirect stops every further request to that host (the other
institutions are still tried); when every host tried was unreachable the feed raises feeds.FeedUnreachable.
Credentials (Banxico token, ECOS key, BCCh user/password) come only from the environment or the OS keychain
(market.vendors.base.secret), never argv or files; they are redacted from every failure message and never written to
raw rows (the `endpoint` column is the documented pattern with placeholders). A missing credential skips that series
with a one-line reason.

Named feed only: `fetch --only cb` (not in feeds.FEED_ALIASES, so not in the default fetch) until series are verified.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import re
import urllib.parse
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Iterable, Mapping

import numpy as np
import pandas as pd

from .. import feeds as F
from ..sources import https_get
from .sdmx import month_minus

CB_FEED = "cb"
CONCEPTS = ("policy_rate", "cpi", "reserves", "debt_stock")
MANUAL = "manual"
SOURCE_PREFIX = "national: "                       # provenance source of every cell this feed fills
CB_RAW_COLUMNS = [*F.LONG_COLUMNS, "series_key", "unit", "freq", "licence", "endpoint"]
CB_MAX_BYTES = 10 * 1024 * 1024
VERIFIED_FILE = Path("panel") / "cb_series_verified.csv"
# licence_ok (EQ-A-0060): yes only once Sam has checked the publisher's terms allow client output; default no, and a
# national value without it stays out of client output (audit.client_output_reason)
VERIFIED_COLUMNS = ["iso3", "concept", "source", "series_key", "verified", "licence_ok", "checked_on", "checked_by",
                    "evidence"]
DEFAULT_DATA = Path(__file__).resolve().parents[3] / "data"
# cell(s) each concept serves: (table, key)
CONCEPT_CELLS = {"policy_rate": (("Country Profile", "policy"), ("Inputs", "5.13")), "cpi": (("Inputs", "5.5"),),
                 "reserves": (("Country Profile", "reserves"),), "debt_stock": (("Inputs", "1.3"),)}
KEY_CONCEPT = {k: c for c, cells in CONCEPT_CELLS.items() for _, k in cells}
UNIT_TO_USD = {"usd": 1.0, "usd_th": 1e3, "usd_mn": 1e6, "usd_bn": 1e9}


@dataclass(frozen=True)
class CbSeries:
    """One national series. `api` names an entry of APIS, or MANUAL. `series_key` is the code in that API ('' when
    not known here). `freq` D/W/M/Q/A, or E (an event series: the latest decision, dated on its decision day).
    `unit`: pct_pa, pct_yoy, index, usd/usd_th/usd_mn/usd_bn, pct_gdp, lcu_mn. `endpoint` is the documented URL
    pattern with placeholders (never a credential)."""
    iso3: str
    concept: str
    source: str
    api: str
    series_key: str = ""
    freq: str = ""
    unit: str = ""
    endpoint: str = ""
    licence: str = ""
    verified: str = "no"
    note: str = ""

    @property
    def machine(self) -> bool:
        return self.api != MANUAL and bool(self.series_key)

    def label(self) -> str:
        return f"{APIS[self.api].label} {self.series_key}" if self.api in APIS else self.source


# ---------------------------------------------------------------------------------------------- APIs
def _json(body: bytes, label: str):
    try:
        return json.loads(body.decode("utf-8-sig"))
    except (UnicodeDecodeError, ValueError) as e:
        raise F.FeedError(f"{label}: response is not JSON ({type(e).__name__})") from e


def _num(v) -> float | None:
    if v is None:
        return None
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return float(v) if np.isfinite(v) else None
    s = str(v).strip().replace(",", "")
    try:
        x = float(s)
    except ValueError:
        return None                                  # 'N/E', 'n.d.', 'NaN', '' : no observation, skipped
    return x if np.isfinite(x) else None


def _period(d: dt.date, freq: str) -> str:
    if freq == "M":
        return f"{d.year}-{d.month:02d}"
    if freq == "Q":
        return f"{d.year}-Q{(d.month - 1) // 3 + 1}"
    if freq == "A":
        return str(d.year)
    return d.isoformat()


def _dmy(s: str, sep: str) -> dt.date:
    d, m, y = (int(x) for x in str(s).strip().split(sep))
    return dt.date(y, m, d)


def _obs(rows: list, label: str) -> list[tuple[str, float]]:
    """Refuse two different values for one period (the answer is not one series)."""
    seen: dict[str, float] = {}
    for p, v in rows:
        if p in seen and seen[p] != v:
            raise F.FeedError(f"{label}: two values for period {p}; answer refused")
        seen[p] = v
    return sorted(seen.items())


def parse_sgs(body: bytes, s: CbSeries) -> list[tuple[str, float]]:
    """BCB SGS JSON: [{"data": "dd/MM/yyyy", "valor": "x"}, ...] (the answer does not echo the code)."""
    lab = f"BCB SGS {s.series_key}"
    data = _json(body, lab)
    if isinstance(data, dict):
        raise F.FeedError(f"{lab}: error answer {str(data)[:120]}")
    if not isinstance(data, list):
        raise F.FeedError(f"{lab}: not a list of observations")
    out = []
    for r in data:
        try:
            d = _dmy(r["data"], "/")
        except (KeyError, TypeError, ValueError) as e:
            raise F.FeedError(f"{lab}: unreadable date in {str(r)[:80]}") from e
        v = _num(r.get("valor"))
        if v is not None:
            out.append((_period(d, s.freq), v))
    return _obs(out, lab)


def parse_banxico(body: bytes, s: CbSeries) -> list[tuple[str, float]]:
    """Banxico SIE JSON: {"bmx": {"series": [{"idSerie": KEY, "datos": [{"fecha": "dd/mm/yyyy", "dato": "x"}]}]}}."""
    lab = f"Banxico SIE {s.series_key}"
    try:
        series = _json(body, lab)["bmx"]["series"]
    except (KeyError, TypeError) as e:
        raise F.FeedError(f"{lab}: no bmx.series in the answer") from e
    out = []
    for ser in series:
        if str(ser.get("idSerie", "")).strip() != s.series_key:
            raise F.FeedError(f"{lab}: answer carries idSerie {ser.get('idSerie')!r}; refused")
        for r in ser.get("datos") or []:
            v = _num(r.get("dato"))
            if v is not None:
                out.append((_period(_dmy(r["fecha"], "/"), s.freq), v))
    return _obs(out, lab)


def parse_bcra(body: bytes, s: CbSeries) -> list[tuple[str, float]]:
    """BCRA estadisticas JSON, v3 rows {"idVariable", "fecha": "YYYY-MM-DD", "valor"} or v4 rows
    {"idVariable", "detalle": [{"fecha", "valor"}]}; idVariable must be the one asked."""
    lab = f"BCRA {s.series_key}"
    data = _json(body, lab)
    res = data.get("results") if isinstance(data, dict) else None
    if not isinstance(res, list):
        raise F.FeedError(f"{lab}: no results list ({str(data)[:120]})")
    out = []
    for r in res:
        if str(r.get("idVariable", "")).strip() != s.series_key:
            raise F.FeedError(f"{lab}: answer carries idVariable {r.get('idVariable')!r}; refused")
        for o in (r.get("detalle") if isinstance(r.get("detalle"), list) else [r]):
            v = _num(o.get("valor"))
            if v is not None:
                out.append((_period(dt.date.fromisoformat(str(o["fecha"])[:10]), s.freq), v))
    return _obs(out, lab)


def _ecos_key(s: CbSeries) -> tuple[str, str, str]:
    stat, freq, item = s.series_key.split("/")
    return stat, freq, item


def _ecos_time(t: str, freq: str) -> str:
    t = str(t).strip()
    if freq == "D" and re.fullmatch(r"\d{8}", t):
        return f"{t[:4]}-{t[4:6]}-{t[6:]}"
    if freq == "M" and re.fullmatch(r"\d{6}", t):
        return f"{t[:4]}-{t[4:]}"
    if freq == "Q" and re.fullmatch(r"\d{4}Q[1-4]", t):
        return f"{t[:4]}-{t[4:]}"
    if freq == "A" and re.fullmatch(r"\d{4}", t):
        return t
    raise F.FeedError(f"ECOS: unreadable TIME {t!r} for frequency {freq}")


def parse_ecos(body: bytes, s: CbSeries) -> list[tuple[str, float]]:
    """BoK ECOS StatisticSearch JSON: {"StatisticSearch": {"row": [{"STAT_CODE", "ITEM_CODE1", "TIME",
    "DATA_VALUE"}]}}; {"RESULT": {"CODE": "INFO-200"}} means no data; any other RESULT code is an error."""
    stat, freq, item = _ecos_key(s)
    lab = f"BoK ECOS {stat}/{item}"
    data = _json(body, lab)
    if isinstance(data, dict) and "RESULT" in data:
        code = str(data["RESULT"].get("CODE", ""))
        if code == "INFO-200":
            return []
        raise F.FeedError(f"{lab}: ECOS error {code}")       # message text not copied: it may echo the key
    try:
        rows = data["StatisticSearch"]["row"]
    except (KeyError, TypeError) as e:
        raise F.FeedError(f"{lab}: no StatisticSearch.row") from e
    out = []
    for r in rows:
        if str(r.get("STAT_CODE")) != stat or str(r.get("ITEM_CODE1")) != item:
            raise F.FeedError(f"{lab}: answer carries {r.get('STAT_CODE')}/{r.get('ITEM_CODE1')}; refused")
        v = _num(r.get("DATA_VALUE"))
        if v is not None:
            out.append((_ecos_time(r["TIME"], freq), v))
    return _obs(out, lab)


def parse_bcch(body: bytes, s: CbSeries) -> list[tuple[str, float]]:
    """BCCh SIETE web service JSON: {"Codigo": 0, "Series": {"seriesId": KEY, "Obs": [{"indexDateString":
    "dd-mm-yyyy", "value": "x", "statusCode": "OK"}]}}; Codigo other than 0 is an error."""
    lab = f"BCCh {s.series_key}"
    data = _json(body, lab)
    if not isinstance(data, dict) or data.get("Codigo") not in (0, "0"):
        raise F.FeedError(f"{lab}: error answer (Codigo {data.get('Codigo') if isinstance(data, dict) else '?'})")
    ser = data.get("Series") or {}
    if ser.get("seriesId") not in (None, s.series_key):
        raise F.FeedError(f"{lab}: answer carries seriesId {ser.get('seriesId')!r}; refused")
    out = []
    for o in ser.get("Obs") or []:
        if str(o.get("statusCode", "OK")).upper() != "OK":
            continue
        v = _num(o.get("value"))
        if v is not None:
            out.append((_period(_dmy(o["indexDateString"], "-"), s.freq), v))
    return _obs(out, lab)


_ES_MONTHS = {"ene": 1, "feb": 2, "mar": 3, "abr": 4, "may": 5, "jun": 6, "jul": 7, "ago": 8, "sep": 9, "set": 9,
              "oct": 10, "nov": 11, "dic": 12}


def _bcrp_period(name: str, freq: str) -> str:
    n = str(name).strip()
    m = re.fullmatch(r"([A-Za-z]{3})\.(\d{4})", n)
    if freq == "M" and m and m[1].lower() in _ES_MONTHS:
        return f"{m[2]}-{_ES_MONTHS[m[1].lower()]:02d}"
    if freq == "A" and re.fullmatch(r"\d{4}", n):
        return n
    raise F.FeedError(f"BCRP: unreadable period {n!r} for frequency {freq}")


def parse_bcrp(body: bytes, s: CbSeries) -> list[tuple[str, float]]:
    """BCRPData JSON: {"config": {...}, "periods": [{"name": "Ago.2026", "values": ["4.25"]}]} (one series asked)."""
    lab = f"BCRP {s.series_key}"
    data = _json(body, lab)
    periods = data.get("periods") if isinstance(data, dict) else None
    if not isinstance(periods, list):
        raise F.FeedError(f"{lab}: no periods list")
    out = []
    for p in periods:
        vals = p.get("values") or []
        if len(vals) != 1:
            raise F.FeedError(f"{lab}: {len(vals)} values in one period (one series asked); refused")
        v = _num(vals[0])
        if v is not None:
            out.append((_bcrp_period(p.get("name"), s.freq), v))
    return _obs(out, lab)


def parse_bnm_opr(body: bytes, s: CbSeries) -> list[tuple[str, float]]:
    """BNM Open API /public/opr: {"data": {"date": "YYYY-MM-DD", "new_opr_level": x, ...}} (latest decision only)."""
    lab = "BNM OPR"
    data = _json(body, lab)
    d = data.get("data") if isinstance(data, dict) else None
    if not isinstance(d, dict) or "new_opr_level" not in d or "date" not in d:
        raise F.FeedError(f"{lab}: no data.new_opr_level / data.date")
    v = _num(d["new_opr_level"])
    return [] if v is None else [(dt.date.fromisoformat(str(d["date"])[:10]).isoformat(), v)]


def _ecos_stamp(d: dt.date, freq: str) -> str:
    return {"D": d.strftime("%Y%m%d"), "M": d.strftime("%Y%m"), "Q": f"{d.year}Q{(d.month - 1) // 3 + 1}",
            "A": str(d.year)}[freq]


@dataclass(frozen=True)
class CbApi:
    """A documented machine API. url(series, start, end, creds) builds the request; creds are read from `env`
    (environment, then keychain). `header_creds` maps a header name to the env name sent as an unredirected header."""
    name: str
    label: str
    host: str
    url: Callable[[CbSeries, dt.date, dt.date, dict], str]
    parse: Callable[[bytes, CbSeries], list]
    licence: str
    env: tuple = ()
    header_creds: tuple = ()
    accept: str = "application/json"


APIS = {a.name: a for a in (
    CbApi("bcb_sgs", "BCB SGS", "api.bcb.gov.br",
          lambda s, a, b, c: (f"https://api.bcb.gov.br/dados/serie/bcdata.sgs.{s.series_key}/dados?formato=json"
                              f"&dataInicial={a:%d/%m/%Y}&dataFinal={b:%d/%m/%Y}"),
          parse_sgs, "Banco Central do Brasil open data (dadosabertos.bcb.gov.br): free reuse with attribution "
                     "(terms UNVERIFIED)"),
    CbApi("banxico_sie", "Banxico SIE", "www.banxico.org.mx",
          lambda s, a, b, c: (f"https://www.banxico.org.mx/SieAPIRest/service/v1/series/{s.series_key}/datos/"
                              f"{a:%Y-%m-%d}/{b:%Y-%m-%d}"),
          parse_banxico, "Banco de Mexico SIE API: free registered token; Banxico terms of use (UNVERIFIED)",
          env=("BANXICO_SIE_TOKEN",), header_creds=(("Bmx-Token", "BANXICO_SIE_TOKEN"),)),
    CbApi("bcra", "BCRA", "api.bcra.gob.ar",
          lambda s, a, b, c: (f"https://api.bcra.gob.ar/estadisticas/v3.0/monetarias/{s.series_key}"
                              f"?desde={a:%Y-%m-%d}&hasta={b:%Y-%m-%d}"),
          parse_bcra, "BCRA public statistics API (api.bcra.gob.ar): terms UNVERIFIED"),
    CbApi("bok_ecos", "BoK ECOS", "ecos.bok.or.kr",
          lambda s, a, b, c: ("https://ecos.bok.or.kr/api/StatisticSearch/"
                              f"{urllib.parse.quote(c['ECOS_API_KEY'], safe='')}/json/en/1/1000/{_ecos_key(s)[0]}/"
                              f"{_ecos_key(s)[1]}/{_ecos_stamp(a, _ecos_key(s)[1])}/{_ecos_stamp(b, _ecos_key(s)[1])}/"
                              f"{_ecos_key(s)[2]}"),
          parse_ecos, "Bank of Korea ECOS Open API: free registered key; terms UNVERIFIED", env=("ECOS_API_KEY",)),
    CbApi("bcch", "BCCh SIETE", "si3.bcentral.cl",
          lambda s, a, b, c: ("https://si3.bcentral.cl/SieteRestWS/SieteRestWS.ashx?" + urllib.parse.urlencode(
              {"user": c["BCCH_USER"], "pass": c["BCCH_PASS"], "firstdate": f"{a:%Y-%m-%d}",
               "lastdate": f"{b:%Y-%m-%d}", "timeseries": s.series_key, "function": "GetSeries"})),
          parse_bcch, "Banco Central de Chile BDE web service: registered user; terms UNVERIFIED",
          env=("BCCH_USER", "BCCH_PASS")),
    CbApi("bcrp", "BCRPData", "estadisticas.bcrp.gob.pe",
          lambda s, a, b, c: (f"https://estadisticas.bcrp.gob.pe/estadisticas/series/api/{s.series_key}/json/"
                              f"{a.year}-{a.month}/{b.year}-{b.month}"),
          parse_bcrp, "BCRP BCRPData API: free; terms UNVERIFIED"),
    CbApi("bnm", "BNM Open API", "api.bnm.gov.my", lambda s, a, b, c: f"https://api.bnm.gov.my/public/{s.series_key}",
          parse_bnm_opr, "Bank Negara Malaysia Open API (apikijangportal.bnm.gov.my): terms UNVERIFIED",
          accept="application/vnd.BNM.API.v1+json"),
)}
ENDPOINTS = {   # documented patterns (placeholders, never credentials) written to raw rows and the registry
    "bcb_sgs": "https://api.bcb.gov.br/dados/serie/bcdata.sgs.{code}/dados?formato=json&dataInicial=dd/MM/yyyy&dataFinal=dd/MM/yyyy",
    "banxico_sie": "https://www.banxico.org.mx/SieAPIRest/service/v1/series/{id}/datos/{start}/{end} (header Bmx-Token)",
    "bcra": "https://api.bcra.gob.ar/estadisticas/v3.0/monetarias/{idVariable}?desde={start}&hasta={end}",
    "bok_ecos": "https://ecos.bok.or.kr/api/StatisticSearch/{ECOS_API_KEY}/json/en/1/1000/{stat}/{freq}/{start}/{end}/{item}",
    "bcch": "https://si3.bcentral.cl/SieteRestWS/SieteRestWS.ashx?user={BCCH_USER}&pass={BCCH_PASS}&firstdate=&lastdate=&timeseries={id}&function=GetSeries",
    "bcrp": "https://estadisticas.bcrp.gob.pe/estadisticas/series/api/{code}/json/{start}/{end}",
    "bnm": "https://api.bnm.gov.my/public/opr (Accept: application/vnd.BNM.API.v1+json)",
}


# ---------------------------------------------------------------------------------------------- registry
def _m(iso: str, concept: str, api: str, key: str, freq: str, unit: str, note: str) -> CbSeries:
    a = APIS[api]
    return CbSeries(iso, concept, a.label, api, key, freq, unit, ENDPOINTS[api], a.licence, "no", note)


def _manual(iso: str, concept: str, source: str, note: str) -> CbSeries:
    return CbSeries(iso, concept, source, MANUAL, note=note)


_NO_API = "no documented machine API known here; manual download until one is confirmed"
_NA_DOLLAR = "not applicable: dollarised economy with no central bank policy rate"
_ENTRIES = [
    # Brazil: BCB SGS (no key). Codes as remembered from the SGS catalogue, UNVERIFIED.
    _m("BRA", "policy_rate", "bcb_sgs", "432", "D", "pct_pa", "Selic target (Meta Selic, Copom), % p.a.; UNVERIFIED code"),
    _m("BRA", "cpi", "bcb_sgs", "13522", "M", "pct_yoy", "IPCA, 12-month change, %; UNVERIFIED code"),
    _m("BRA", "reserves", "bcb_sgs", "3546", "M", "usd_mn", "international reserves, liquidity concept, US$ mn; "
       "UNVERIFIED code and unit"),
    _m("BRA", "debt_stock", "bcb_sgs", "13762", "M", "pct_gdp", "general government gross debt (DBGG, BCB "
       "methodology), % of GDP; UNVERIFIED code; BCB DBGG differs from the IMF/WEO definition"),
    # Mexico: Banxico SIE (token BANXICO_SIE_TOKEN)
    _m("MEX", "policy_rate", "banxico_sie", "SF61745", "D", "pct_pa", "target for the overnight interbank rate; "
       "UNVERIFIED code"),
    _m("MEX", "cpi", "banxico_sie", "SP1", "M", "index", "INPC, general index (12-month change computed); UNVERIFIED code"),
    _m("MEX", "reserves", "banxico_sie", "SF43707", "W", "usd_mn", "international reserves, US$ mn, weekly; UNVERIFIED "
       "code and unit"),
    _manual("MEX", "debt_stock", "SHCP (Ministry of Finance)", "RFSP / debt statistics published by SHCP; " + _NO_API),
    # Argentina: BCRA statistics API (no key). Variable ids UNVERIFIED (the API has had v2/v3/v4 layouts).
    _m("ARG", "reserves", "bcra", "1", "D", "usd_mn", "BCRA gross international reserves, US$ mn; UNVERIFIED id"),
    _m("ARG", "policy_rate", "bcra", "6", "D", "pct_pa", "monetary policy rate, % n.a.; UNVERIFIED id; BCRA moved away "
       "from a policy-rate framework in 2024 (UNVERIFIED), so the series may stop: the staleness rule holds it"),
    _m("ARG", "cpi", "bcra", "28", "M", "pct_yoy", "CPI (INDEC) 12-month change as republished by BCRA; UNVERIFIED id"),
    _manual("ARG", "debt_stock", "Secretaria de Finanzas", "quarterly debt bulletin (spreadsheet); " + _NO_API),
    # Korea: BoK ECOS (key ECOS_API_KEY). series_key = STAT_CODE/FREQ/ITEM_CODE1.
    _m("KOR", "policy_rate", "bok_ecos", "722Y001/M/0101000", "M", "pct_pa", "Bank of Korea base rate; UNVERIFIED codes"),
    _m("KOR", "cpi", "bok_ecos", "901Y009/M/0", "M", "index", "CPI all items, index (12-month change computed); "
       "UNVERIFIED codes"),
    _m("KOR", "reserves", "bok_ecos", "732Y001/M/99", "M", "usd_th", "foreign reserves, total; UNVERIFIED codes; unit "
       "believed thousand US$ (UNVERIFIED: the range rule catches a wrong scale)"),
    _manual("KOR", "debt_stock", "Ministry of Economy and Finance", "D1/D2 debt published annually; " + _NO_API),
    # Chile: BCCh SIETE (BCCH_USER / BCCH_PASS)
    _m("CHL", "policy_rate", "bcch", "F022.TPM.TIN.D001.NO.Z.D", "D", "pct_pa", "monetary policy rate (TPM); "
       "UNVERIFIED code"),
    CbSeries("CHL", "cpi", "BCCh SIETE", "bcch", "", "M", "pct_yoy", ENDPOINTS["bcch"], APIS["bcch"].licence, "no",
             "series code not known here: find it with the SIETE SearchSeries function (runbook); not requested"),
    CbSeries("CHL", "reserves", "BCCh SIETE", "bcch", "", "M", "usd_mn", ENDPOINTS["bcch"], APIS["bcch"].licence, "no",
             "series code not known here: find it with the SIETE SearchSeries function (runbook); not requested"),
    _manual("CHL", "debt_stock", "DIPRES (Budget Office)", "quarterly gross debt report; " + _NO_API),
    # Peru: BCRPData (no key)
    _m("PER", "policy_rate", "bcrp", "PD04722MM", "M", "pct_pa", "BCRP reference rate, monthly; UNVERIFIED code"),
    _m("PER", "cpi", "bcrp", "PN01273PM", "M", "pct_yoy", "CPI Lima Metropolitana, 12-month change; UNVERIFIED code"),
    _m("PER", "reserves", "bcrp", "PN00026MM", "M", "usd_mn", "net international reserves, US$ mn; UNVERIFIED code; "
       "net, not gross"),
    _manual("PER", "debt_stock", "MEF / BCRP", "public debt % of GDP is published quarterly; series code not known "
            "here; " + _NO_API),
    # Malaysia: BNM Open API for the OPR only
    _m("MYS", "policy_rate", "bnm", "opr", "E", "pct_pa", "Overnight Policy Rate, latest decision only (event series, "
       "dated on the decision day); UNVERIFIED endpoint"),
    _manual("MYS", "cpi", "DOSM", "OpenDOSM / data.gov.my has an API (UNVERIFIED), not implemented: dataset id not "
            "confirmed"),
    _manual("MYS", "reserves", "Bank Negara Malaysia", "fortnightly reserves release; BNM Open API reserves endpoint "
            "not confirmed here"),
    _manual("MYS", "debt_stock", "Ministry of Finance Malaysia", _NO_API),
]
_MANUAL_ONLY = {   # (source per concept, note) for countries with no adapter here
    "SGP": ("Monetary Authority of Singapore / SingStat", "MAS and SingStat publish APIs, but resource / table ids are "
            "not known here (UNVERIFIED); " + _NO_API),
    "IND": ("Reserve Bank of India (DBIE) / MoSPI", "RBI DBIE has no documented public REST API known here; " + _NO_API),
    "PHL": ("Bangko Sentral ng Pilipinas / PSA", "PSA OpenSTAT (PX-Web) may have an API, table ids unknown; " + _NO_API),
    "CHN": ("People's Bank of China / NBS", _NO_API),
    "JPN": ("Bank of Japan / Statistics Bureau (e-Stat)", "e-Stat API needs an appId and table ids not known here; BoJ "
            "time-series API availability UNVERIFIED; " + _NO_API),
    "COL": ("Banco de la Republica / DANE", _NO_API),
    "NGA": ("Central Bank of Nigeria / NBS", _NO_API),
    "VNM": ("State Bank of Vietnam / GSO", _NO_API),
    "PAK": ("State Bank of Pakistan (EasyData) / PBS", "SBP EasyData has a keyed API (UNVERIFIED) but series codes are "
            "not known here; " + _NO_API),
    "SEN": ("BCEAO (regional) / ANSD", "BCEAO sets the WAEMU regional rate; " + _NO_API),
    "ZMB": ("Bank of Zambia / ZamStats", _NO_API),
    "BLZ": ("Central Bank of Belize / SIB", _NO_API),
    "VEN": ("Banco Central de Venezuela", "publication irregular; " + _NO_API),
    "ZWE": ("Reserve Bank of Zimbabwe / ZimStat", _NO_API),
    "IDN": ("Bank Indonesia / BPS", "BPS has a keyed Web API (UNVERIFIED), table ids not known here; " + _NO_API),
    "URY": ("Banco Central del Uruguay / INE", _NO_API),
    "PAN": ("INEC / MEF (no central bank)", _NO_API),
    "DOM": ("Banco Central de la Republica Dominicana", _NO_API),
}
for _iso, (_src, _note) in _MANUAL_ONLY.items():
    for _c in CONCEPTS:
        n = _NA_DOLLAR if (_iso == "PAN" and _c == "policy_rate") else (
            "not applicable: MAS has no policy interest rate (exchange-rate band policy)"
            if (_iso == "SGP" and _c == "policy_rate") else _note)
        _ENTRIES.append(_manual(_iso, _c, _src, n))

CB_REGISTRY: dict[str, dict[str, CbSeries]] = {}
for _e in _ENTRIES:
    CB_REGISTRY.setdefault(_e.iso3, {})[_e.concept] = _e
TOP25 = ("BRA", "SGP", "IND", "PHL", "ARG", "CHN", "JPN", "COL", "MYS", "NGA", "KOR", "VNM", "PAK", "SEN", "ZMB",
         "BLZ", "VEN", "ZWE", "IDN", "MEX", "CHL", "PER", "URY", "PAN", "DOM")


def registry_frame() -> pd.DataFrame:
    """The registry as a table (one row per country and concept), top-25 order."""
    rows = [{"iso3": i, **{k: getattr(CB_REGISTRY[i][c], k) for k in ("concept", "source", "api", "series_key",
                                                                      "freq", "unit", "endpoint", "licence",
                                                                      "verified", "note")},
             "machine": CB_REGISTRY[i][c].machine} for i in TOP25 for c in CONCEPTS]
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------------------------- verification
def load_verified(data_dir: str | Path | None = None) -> set[tuple[str, str, str]]:
    """{(iso3, concept, series_key)} marked verified=yes in panel/cb_series_verified.csv; empty when absent. A row
    counts only for the series_key it names, so changing a code in the registry drops its verification."""
    p = Path(data_dir or DEFAULT_DATA) / VERIFIED_FILE
    try:
        m = pd.read_csv(p, dtype=str, keep_default_na=False)
    except (OSError, ValueError):
        return set()
    if not {"iso3", "concept", "series_key", "verified"} <= set(m.columns):
        return set()
    m = m[m["verified"].str.strip().str.lower() == "yes"]
    return {(a.strip(), b.strip(), c.strip()) for a, b, c in zip(m["iso3"], m["concept"], m["series_key"])}


def licence_ok_sources(data_dir: str | Path | None = None) -> set[str]:
    """Provenance source texts (source_of) cleared for client output: every row of cb_series_verified.csv whose
    registry series has that source says licence_ok=yes (EQ-A-0060). Empty when the file or column is absent."""
    p = Path(data_dir or DEFAULT_DATA) / VERIFIED_FILE
    try:
        m = pd.read_csv(p, dtype=str, keep_default_na=False)
    except (OSError, ValueError):
        return set()
    if not {"iso3", "concept", "series_key", "licence_ok"} <= set(m.columns):
        return set()
    verdict: dict[str, bool] = {}
    for iso, concept, key, ok in zip(m["iso3"], m["concept"], m["series_key"], m["licence_ok"]):
        s = CB_REGISTRY.get(iso.strip(), {}).get(concept.strip())
        if s is None or s.series_key != key.strip():
            continue
        src = source_of(s)
        verdict[src] = verdict.get(src, True) and ok.strip().lower() == "yes"
    return {src for src, ok in verdict.items() if ok}


def is_verified(s: CbSeries | None, verified: set) -> bool:
    return s is not None and s.machine and (s.iso3, s.concept, s.series_key) in verified


def verified_template() -> pd.DataFrame:
    """Rows for every machine-readable series, verified=no (the file Sam's Mac check edits)."""
    rows = [{"iso3": s.iso3, "concept": s.concept, "source": s.source, "series_key": s.series_key, "verified": "no",
             "licence_ok": "no", "checked_on": "", "checked_by": "", "evidence": ""}
            for i in TOP25 for s in CB_REGISTRY[i].values() if s.machine]
    return pd.DataFrame(rows, columns=VERIFIED_COLUMNS)


# ---------------------------------------------------------------------------------------------- feed
def _redact(text: str, secrets: Iterable[str]) -> str:
    """Each secret replaced by *** as written raw, path-quoted (ECOS key) and form-encoded (BCCh query: urlencode
    uses quote_plus, so a space is '+'; SEC-A-007 L2)."""
    out = str(text)
    for s in secrets:
        if s:
            for form in dict.fromkeys((s, urllib.parse.quote(s, safe=""), urllib.parse.quote_plus(s, safe=""))):
                out = out.replace(form, "***")
    return out


@dataclass
class CentralBankFeed:
    """Fetch every machine-readable registry series for the countries asked (module docstring)."""
    registry: dict = field(default_factory=lambda: CB_REGISTRY)
    timeout: float = 30.0
    retries: int = 2
    backoff: float = 2.0
    sleep: Callable[[float], None] | None = None
    max_bytes: int = CB_MAX_BYTES
    years: int = 3
    today: dt.date | None = None
    env: Mapping | None = None
    concepts: Iterable[str] | None = None

    def _cred(self, name: str) -> str:
        from ..market.vendors.base import secret   # lazy: environment, then OS keychain; never argv or files
        return secret(name, env=self.env, keyring_service="econquest")

    def fetch(self, isos: Iterable[str]) -> pd.DataFrame:
        end = self.today or dt.date.today()
        start = end - dt.timedelta(days=int(366 * self.years))
        want = set(self.concepts or CONCEPTS)
        rows: list[dict] = []
        failures: list[str] = []
        dead: dict[str, str] = {}
        tried: set[str] = set()
        entries = [s for i in dict.fromkeys(isos) for c, s in self.registry.get(i, {}).items() if c in want]
        not_requested = [s for s in entries if not s.machine]
        if not_requested:
            failures.append("cb: not requested (manual or code unknown): "
                            + ", ".join(f"{s.iso3} {s.concept}" for s in not_requested))
        for s in (s for s in entries if s.machine):
            api = APIS[s.api]
            if api.host in dead:
                failures.append(f"{s.iso3} {s.concept}: {api.label} not requested ({dead[api.host]})")
                continue
            creds = {e: self._cred(e) for e in api.env}
            missing = [e for e, v in creds.items() if not v]
            if missing:
                failures.append(f"{s.iso3} {s.concept}: {api.label} needs {', '.join(missing)} in the environment or "
                                "keychain; not requested")
                continue
            secrets = list(creds.values())
            try:
                url = api.url(s, start, end, creds)
                hdrs = {"User-Agent": "econquest/0.2", "Accept": api.accept}
                unred = {h: creds[e] for h, e in api.header_creds}
                tried.add(api.host)
                body = F._with_retries(lambda url=url, hdrs=hdrs, unred=unred: https_get(
                                           url, hdrs, timeout=self.timeout, max_bytes=self.max_bytes, unredirected=unred),
                                       retries=self.retries, backoff=self.backoff, sleep=self.sleep)
                obs = api.parse(body, s)
            except Exception as e:  # noqa: BLE001 - classified; text redacted before it is kept
                why = F._stop_reason(e, api.host)
                if why:
                    dead[api.host] = _redact(why, secrets)
                    failures.append(f"{api.label}: unreachable ({dead[api.host]}); no further request to {api.host}")
                else:
                    failures.append(f"{s.iso3} {s.concept} {api.label} {s.series_key}: "
                                    + _redact(F._one_line(f"{type(e).__name__}: {e}", 200), secrets))
                continue
            if not obs:
                failures.append(f"{s.iso3} {s.concept} {api.label} {s.series_key}: no observation in {start}..{end}")
            rows += [{"iso": s.iso3, "series": s.concept, "period": p, "value": v, "source": source_of(s),
                      "series_key": s.series_key, "unit": s.unit, "freq": s.freq, "licence": s.licence,
                      "endpoint": s.endpoint} for p, v in obs]
        out = pd.DataFrame(rows, columns=CB_RAW_COLUMNS)
        if out.empty:
            if tried and tried <= set(dead):
                raise F.FeedUnreachable("; ".join(dict.fromkeys(dead[h] for h in sorted(tried))))
            raise F.FeedError("central banks: no rows: " + "; ".join(failures[:4]))
        out.attrs.update(failures=failures)
        return out.reset_index(drop=True)


def source_of(s: CbSeries) -> str:
    return f"{SOURCE_PREFIX}{s.source} ({APIS[s.api].host})" if s.api in APIS else f"{SOURCE_PREFIX}{s.source}"


# ---------------------------------------------------------------------------------------------- transforms
def _component(raw: pd.DataFrame | None, iso: str, concept: str) -> pd.Series:
    if raw is None or not len(raw):
        return pd.Series(dtype=float)
    s = raw[(raw["iso"] == iso) & (raw["series"] == concept)]
    out = pd.Series(pd.to_numeric(s["value"], errors="coerce").to_numpy(), index=s["period"].astype(str).to_numpy())
    out = out.dropna().sort_index()
    return out[~out.index.duplicated(keep="last")]


def _weo_value(weo: pd.DataFrame | None, iso: str, code: str, year: int) -> float | None:
    if weo is None or not len(weo):
        return None
    s = weo[(weo["iso"] == iso) & (weo["series"] == code)]
    s = s[pd.to_numeric(s["period"], errors="coerce") == year]
    v = pd.to_numeric(s["value"], errors="coerce").dropna()
    return float(v.iloc[-1]) if len(v) else None


def cb_transforms(raw: pd.DataFrame | None, iso: str, cpi_weo: float | None, weo: pd.DataFrame | None,
                  year: int, registry: dict | None = None) -> tuple[dict, dict, dict]:
    """({key: value}, {key: series text}, {key: reason not served}) for one country, keys from CONCEPT_CELLS."""
    reg = (registry or CB_REGISTRY).get(iso, {})
    val, used, why = {}, {}, {}

    def reason(concept: str) -> str:
        s = reg.get(concept)
        if s is None:
            return "no national source in the registry for this country"
        if not s.machine:
            return f"{s.source}: {s.note}"
        return f"{s.label()}: no observation fetched"

    for concept in CONCEPTS:
        s = reg.get(concept)
        x = _component(raw, iso, concept)
        keys = [k for _, k in CONCEPT_CELLS[concept]]
        if s is None or not s.machine or not len(x):
            for k in keys:
                why[k] = reason(concept)
            continue
        last, p = float(x.iloc[-1]), x.index[-1]
        desc = f"{s.label()} {p}"
        if concept == "policy_rate":
            val["policy"], used["policy"] = last, desc
            if cpi_weo is not None and np.isfinite(cpi_weo):
                val["5.13"], used["5.13"] = last - cpi_weo, f"{desc} minus WEO PCPIPCH"
            else:
                why["5.13"] = "national policy rate present but no WEO PCPIPCH to deflate it"
        elif concept == "cpi":
            if s.unit == "pct_yoy":
                val["5.5"], used["5.5"] = last, f"{desc} (12-month change as published)"
            elif s.unit == "index" and s.freq == "M":
                t0 = month_minus(p, 12)
                if t0 in x.index and x[t0] > 0:
                    val["5.5"] = float(last / x[t0] * 100 - 100)
                    used["5.5"] = f"{s.label()} {t0}..{p} (12-month change of the index)"
                else:
                    why["5.5"] = f"{s.label()}: no index value 12 months before {p}"
            else:
                why["5.5"] = f"{s.label()}: unit {s.unit} has no 12-month rule"
        elif concept == "reserves":
            gdp = _weo_value(weo, iso, "NGDPD", year)
            scale = UNIT_TO_USD.get(s.unit)
            if scale is None:
                why["reserves"] = f"{s.label()}: unit {s.unit} is not a US$ unit"
            elif gdp is None or gdp <= 0:
                why["reserves"] = f"{s.label()} present but no WEO NGDPD {year} for the % of GDP"
            else:
                val["reserves"] = float(last * scale / (gdp * 1e9) * 100)
                used["reserves"] = f"{desc} x {scale:g} / (WEO NGDPD {year} x 1e9) x 100"
        elif concept == "debt_stock":
            if s.unit == "pct_gdp":
                val["1.3"], used["1.3"] = last, f"{desc} (% of GDP as published; national definition)"
            else:
                why["1.3"] = f"{s.label()}: level series ({s.unit}) fetched raw only; % of GDP rule not set"
    return ({k: v for k, v in val.items() if np.isfinite(v)}, used, {k: r for k, r in why.items() if k not in val})


def national_cells(raw: dict, country: str, iso: str, cpi: float | None, inputs: pd.Series, profile: pd.Series,
                   have_src: dict, year: int, tlog: list, unserved: list,
                   verified: set | None = None, registry: dict | None = None) -> list[tuple]:
    """(kind, key, value, source, series) tuples for fetch_all's `put` (after every other feed). Precedence by
    official.precedence.choose_national: a verified national value replaces the existing one; an unverified one only
    fills an empty cell (and the gate holds it). Decisions go to `tlog`; empty cells with a reason to `unserved`."""
    from .precedence import choose_national
    reg = (registry or CB_REGISTRY).get(iso, {})
    verified = load_verified() if verified is None else verified
    vals, used, why = cb_transforms(raw.get(CB_FEED), iso, cpi, raw.get("weo"), year, registry)
    puts = []
    for concept in CONCEPTS:
        s = reg.get(concept)
        ok = is_verified(s, verified)
        for table, key in CONCEPT_CELLS[concept]:
            cur = profile.get(key, np.nan) if table == "Country Profile" else inputs.get(key, np.nan)
            cur = float(cur) if cur is not None and np.isfinite(cur) else np.nan
            other = have_src.get((table, key))
            nat = vals.get(key, np.nan)
            feed, v, note = choose_national(key, nat, cur, other, ok)
            if feed == CB_FEED:
                puts.append(("indicator" if table == "Inputs" else "profile", key, v, source_of(s),
                             f"{used[key]} ({note})"))
            if np.isfinite(nat) and np.isfinite(cur):
                tlog.append({"iso": iso, "series": key, "year": year, "value": v, "fallback": cur if feed == CB_FEED else nat,
                             "jump": np.nan, "sd_changes": np.nan, "rule": note, "country": country})
            if feed is None and key in why and reg and not any(
                    (x["table"], str(x["key"]), x["country"]) == (table, key, country) for x in unserved):
                unserved.append({"table": table, "key": key, "country": country, "iso": iso, "feed": CB_FEED,
                                 "reason": why[key]})
    return puts


# ---------------------------------------------------------------------------------------------- quality gate
# limits in days by frequency (national releases come faster than the IMF compilations: monthly 92, not 122). E
# (event series: the latest decision, dated on its decision day) has no age limit: a rate unchanged for a year is
# still the rate.
CB_STALE_DAYS = {"D": 30, "W": 45, "M": 92, "Q": 200, "A": 550}
# plausibility of the series as delivered, by unit (wrong code or wrong scale shows up here)
SERIES_RANGES = {"pct_pa": (-2.0, 200.0), "pct_yoy": (-30.0, 1000.0), "index": (1.0, 1e7), "pct_gdp": (0.0, 300.0),
                 "usd": (1e6, 5e12), "usd_th": (1e3, 5e9), "usd_mn": (1.0, 5e6), "usd_bn": (1e-3, 5e3)}
# plausibility of the cell (indicator or profile units)
CELL_RANGES = {"policy": (-2.0, 200.0), "5.13": (-100.0, 100.0), "5.5": (-30.0, 1000.0), "1.3": (0.0, 300.0),
               "reserves": (0.0, 200.0)}


def _last_obs(raw: pd.DataFrame | None, iso: str, concept: str) -> tuple[dt.date, str] | None:
    x = _component(raw, iso, concept)
    if not len(x):
        return None
    p = x.index[-1]
    if re.fullmatch(r"\d{4}", p):
        return dt.date(int(p), 12, 31), p
    e = F._period_end(p)
    return (e[0], p) if e else None


def cb_gate_checks(u, report, ref: dt.date, data_dir: str | Path | None = None,
                   registry: dict | None = None) -> pd.DataFrame:
    """CHECK_COLUMNS rows for every cell the cb feed filled: unverified, range (cell and series), stale, and the
    national-vs-existing cross-check (cb_cross) from the transform log when a verified national value was used."""
    from ..crosscheck import CHECK_COLUMNS
    from .precedence import national_disagreement
    prov = getattr(report, "provenance", None)
    rows: list[dict] = []
    raw = (report.raw or {}).get(CB_FEED)
    if prov is None or not len(prov) or not {"table", "key", "country", "source"} <= set(prov.columns):
        return pd.DataFrame(rows, columns=CHECK_COLUMNS)
    reg = registry or CB_REGISTRY
    verified = load_verified(data_dir)
    iso_of = dict(zip(u.names, u.countries["iso"]))
    tl = getattr(report, "transform_log", None)
    for r in prov[prov["source"].astype(str).str.startswith(SOURCE_PREFIX)].itertuples(index=False):
        key, n = str(r.key), r.country
        iso = iso_of.get(n)
        concept = KEY_CONCEPT.get(key)
        s = reg.get(iso, {}).get(concept)
        value = float(pd.to_numeric(r.value, errors="coerce"))

        def hold(check: str, reason: str, status: str = "hold", live=value, key=key, n=n, r=r) -> None:
            rows.append({"table": r.table, "key": key, "country": n, "check": check, "status": status,
                         "reason": reason, "live": live, "basis": str(getattr(r, "series", ""))})

        if s is None:
            hold("unverified", f"{key}: national source not in the registry")
            continue
        if not is_verified(s, verified):
            hold("unverified", f"{key} from {s.label()}: national series not yet confirmed on a live pull "
                               f"(data/panel/cb_series_verified.csv; docs/runbooks/A-central-bank-adapters.md)")
        lo, hi = CELL_RANGES.get(key, (-np.inf, np.inf))
        if np.isfinite(value) and not lo <= value <= hi:
            hold("range", f"{value:.4g} outside the plausibility bounds [{lo:g}, {hi:g}] for {key}")
        x = _component(raw, iso, concept)
        slo, shi = SERIES_RANGES.get(s.unit, (-np.inf, np.inf))
        if len(x) and not slo <= float(x.iloc[-1]) <= shi:
            hold("range", f"{s.label()} latest {float(x.iloc[-1]):.4g} outside [{slo:g}, {shi:g}] for unit {s.unit} "
                          "(wrong code or scale?)")
        limit = CB_STALE_DAYS.get(s.freq)
        last = _last_obs(raw, iso, concept)
        if limit is not None and last is not None and (ref - last[0]).days > limit:
            hold("stale", f"{s.label()} last observation {last[1]} ({last[0].isoformat()}), {(ref - last[0]).days} "
                          f"days before {ref.isoformat()} (limit {limit} days for frequency {s.freq})")
        if tl is not None and len(tl) and {"series", "country", "rule", "fallback"} <= set(tl.columns):
            t = tl[(tl["series"].astype(str) == key) & (tl["country"] == n)
                   & tl["rule"].astype(str).str.contains(f"{CB_FEED} used", regex=False)]
            for f in pd.to_numeric(t["fallback"], errors="coerce").dropna():
                bad, why = national_disagreement(key, value, float(f))
                hold("cb_cross", why, "hold" if bad else "ok")
    return pd.DataFrame(rows, columns=CHECK_COLUMNS)


# ---------------------------------------------------------------------------------------------- Mac helpers
def main(argv: list[str] | None = None) -> int:
    """`list` prints the registry; `sample ISO CONCEPT` fetches one series (network; credentials from the
    environment or keychain) and prints its last observations and failures; `template --out FILE` writes the
    verification file with every machine-readable series at verified=no."""
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.official.central_banks")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("list")
    p = sub.add_parser("sample"); p.add_argument("iso"); p.add_argument("concept", choices=CONCEPTS)
    p.add_argument("--years", type=int, default=2)
    p = sub.add_parser("template"); p.add_argument("--out", required=True)
    a = ap.parse_args(argv)
    if a.cmd == "list":
        df = registry_frame()
        with pd.option_context("display.max_rows", None, "display.width", 200, "display.max_colwidth", 60):
            print(df[["iso3", "concept", "api", "series_key", "freq", "unit", "verified", "machine", "note"]].to_string(index=False))
        return 0
    if a.cmd == "template":
        verified_template().to_csv(a.out, index=False)
        print(f"wrote {a.out}")
        return 0
    s = CB_REGISTRY.get(a.iso.upper(), {}).get(a.concept)
    if s is None or not s.machine:
        print(f"{a.iso} {a.concept}: not machine-readable here ({s.note if s else 'not in the registry'})")
        return 2
    feed = CentralBankFeed(registry={s.iso3: {s.concept: s}}, years=a.years)
    try:
        df = feed.fetch([s.iso3])
    except F.FeedError as e:
        print(f"FAILED: {F._one_line(e, 400)}")
        return 1
    print(f"{s.iso3} {s.concept}: {s.label()} unit={s.unit} freq={s.freq}")
    print(df[["period", "value"]].tail(15).to_string(index=False))
    print("failures:", df.attrs.get("failures"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
