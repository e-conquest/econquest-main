"""World Bank WDI history adapter (EQ-A-0062, coverage to 60% part 3): third-source fallbacks for 2.12 and 5.9.

Both indicators are BIS series (2.12 WS_EER, 5.9 WS_CREDIT_GAP). BIS has no series for 8 (2.12) and 9 (5.9) of the
18 desk names on the 2026-10-23 pull. The IMF fallback (official/imf.py) covers 2.12 only, with unverified codes,
and 5.9 has no IMF transform. This feed adds annual WDI history on the existing World Bank host:

    2.12  real exchange rate vs 10-year average, %: PX.REX.REER (real effective exchange rate index, 2010 = 100,
          annual; WDI attributes it to IMF International Financial Statistics). Latest year vs the mean of the
          last REER_WINDOW years (latest included), at least REER_MIN_YEARS of them. Annual, so coarser than the
          BIS rule (latest month vs 120-month mean).
    5.9   credit-to-GDP gap, pp of GDP: FS.AST.PRVT.GD.ZS (domestic credit to the private sector by banks and other
          financial corporations, % of GDP, annual; IMF IFS data republished in WDI). One-sided HP filter (trend at
          t from data up to t only) with lambda CREDIT_HP_LAMBDA = 400,000 / 4**4 (the BIS quarterly lambda
          rescaled to annual data, Ravn-Uhlig), on the longest run of consecutive years ending at the latest year,
          at least CREDIT_MIN_YEARS of them. Domestic private credit, not BIS total credit: a proxy (rule 5.9 WDI v1).

Team B decision (HO-20261024-A-B-011, EQ-B-0086, docs/validation/indicator-rules.md section 12), built under
EQ-A-0084: 5.9 approved with five changes, 2.12 with one.
    5.9   (1) gate check 'break' when, in the run used, the ratio moves by more than CREDIT_BREAK_PP pp of GDP or by
          more than CREDIT_BREAK_REL of its previous level between two consecutive years (credit_breaks);
          (2) gate check 'stale' when the latest year is more than WDI_STALE_YEARS before the as_of year;
          (3) IMF IFS data, restricted for client output: the provenance series names 'IMF IFS via WDI', which
          audit.client_output_reason restricts (CLIENT_RESTRICTED_SOURCE_RE; register row imf_derived);
          (4) provenance 'rule 5.9 WDI v1: domestic private credit gap (WDI/IFS, annual), not BIS total credit'
          (CREDIT_RULE_TEXT);
          (5) before the first release, compare_with_bis on the names that have a BIS gap: median |WDI gap - BIS
          Q4 gap of the same year| above COMPARE_TOL_PP pp sends the method back to Team B (`compare` CLI below).
    2.12  stale hold at WDI_STALE_YEARS (window 10, minimum 8, range and IMF restriction approved as built).
Known limit (Team B): financial deepening reads as a positive gap.
METHOD_APPROVED stays empty until Sam signs off the Tier 1 change (approval_effect / `effect` CLI give the batch
effect he sees first).

Precedence (by source, never by freshness): BIS, then IMF SDMX, then this feed. The feed only fills a cell that
neither BIS nor IMF filled; the decision is written to transform_log.csv and the provenance series says it is a
fallback. Every value is held by the quality gate ('unverified') until data/panel/coverage_source_map.csv marks the
indicator verified=yes; for 2.12 that needs BOTH the IMF REER code and PX.REX.REER confirmed on a live pull
(docs/runbooks/A-coverage-plan.md section 10).

UNVERIFIED: both series codes are World Bank WDI codes written from the WDI catalogue as remembered, not from a live
answer (this cloud cannot reach api.worldbank.org); which desk names have values is unknown. Licence: World Bank
data are mostly CC BY 4.0 per dataset (https://www.worldbank.org/en/about/legal/Permissions); PX.REX.REER is IMF data
republished by the World Bank, so its provenance names the IMF and audit.client_output_reason treats it as
restricted for client output (Sam 2026-10-24 12:38Z, HO-20261024-A-B-003).

Feed `wdi_extra`, registered through official.wiring.fetch_plan and pulled with the `worldbank` alias
(feeds.FEED_ALIASES, so in the default fetch; host api.worldbank.org in feeds.FEED_HOSTS)."""
from __future__ import annotations

import argparse
import datetime as dt
import re
import sys
from dataclasses import dataclass
from typing import Callable, Iterable

import numpy as np
import pandas as pd

from .. import feeds as F

WDI_EXTRA_FEED = "wdi_extra"
WDI_EXTRA_LABEL = "wbgapi World Bank API v2 (WDI annual history, EQ-A-0062)"
WDI_DB = 2
REER = "PX.REX.REER"
CREDIT = "FS.AST.PRVT.GD.ZS"
# series: (database, label). UNVERIFIED codes (module docstring).
WDI_EXTRA_SERIES = {
    REER: (WDI_DB, "real effective exchange rate index (2010 = 100), annual; IMF IFS via WDI"),
    CREDIT: (WDI_DB, "domestic credit to private sector (banks and other financial corporations), % of GDP, annual; "
                     "IMF IFS via WDI"),
}
WDI_EXTRA_START = 1980                 # credit gap: enough history for the one-sided HP filter
# indicator -> series it needs (gate staleness, unserved reasons)
WDI_EXTRA_COMPONENTS = {"2.12": (REER,), "5.9": (CREDIT,)}
WDI_EXTRA_IDS = frozenset(WDI_EXTRA_COMPONENTS)
FALLBACK_ORDER = ("bis", "imf_sdmx", WDI_EXTRA_FEED)
# Team B approval of the transform method (HO-20261024-A-B-011, EQ-B-0086: approved with changes, built under
# EQ-A-0084). An id not listed here is held ('method') even after its codes are verified. Adding an id is a Tier 1
# change (it moves the scorecard): Sam signs it off with the batch effect in hand (docs/runbooks/A-coverage-60.md
# section 10). It is a reviewed code change, never a data edit.
METHOD_APPROVED: frozenset = frozenset()
REER_WINDOW, REER_MIN_YEARS = 10, 8
CREDIT_HP_LAMBDA = 400_000 / 4 ** 4    # 1,562.5
CREDIT_MIN_YEARS = 15
WDI_STALE_YEARS = 2                    # Team B: latest year more than 2 years before the as_of year is stale (both ids)
CREDIT_BREAK_PP, CREDIT_BREAK_REL = 10.0, 0.5     # Team B change 1: a year-on-year step this large holds 5.9 ('break')
COMPARE_TOL_PP = 5.0                   # Team B change 5: median |WDI - BIS| gap above this goes back to Team B
CREDIT_RULE_TEXT = "rule 5.9 WDI v1: domestic private credit gap (WDI/IFS, annual), not BIS total credit"
WDI_RANGES = {"2.12": (-80.0, 300.0), "5.9": (-100.0, 100.0)}


@dataclass
class WdiExtraFeed:
    """Annual WDI history of WDI_EXTRA_SERIES for the given ISO3s, one wbgapi call per series
    (feeds._wb_history_frame, the World Bank history feed's own call). Returns feeds.LONG_COLUMNS rows; attrs
    ["failures"] lists what is missing. A proxy refusal or DNS failure stops the feed at once (FeedUnreachable);
    raises FeedError when no series returned a row."""
    series: tuple = tuple(WDI_EXTRA_SERIES)
    start: int = WDI_EXTRA_START
    end: int | None = None
    fetcher: Callable | None = None     # (code, start, end, isos, db) -> long frame; tests inject a stand-in

    def fetch(self, isos: Iterable[str]) -> pd.DataFrame:
        isos = [i for i in dict.fromkeys(isos) if isinstance(i, str) and i]
        end = int(self.end or dt.date.today().year)
        fetch_one = self.fetcher or F._wb_history_frame
        frames, failures = [], []
        for code in self.series:
            db = WDI_EXTRA_SERIES[code][0]
            try:
                df = fetch_one(code, self.start, end, isos, db)
            except Exception as e:  # noqa: BLE001 - recorded; the next series may still answer
                F._stop_if_unreachable(e, F.WB_HOST)
                failures.append(f"{code}: {type(e).__name__}: {str(e)[:120]}")
                continue
            if df is None or df.empty:
                failures.append(f"no rows for {code}")
                continue
            frames.append(df[df["iso"].astype(str).isin(isos)][["iso", "series", "period", "value"]])
        if not frames:
            raise F.FeedError("World Bank WDI history unreachable: " + "; ".join(failures[:3]))
        rows = pd.concat(frames, ignore_index=True)
        out = F._long(rows.to_dict("records"), WDI_EXTRA_LABEL)
        out["period"] = out["period"].astype(int)
        out.attrs["failures"] = failures
        return out


# ---------------------------------------------------------------------------------------------- transforms
def annual(raw: pd.DataFrame | None, iso: str, series: str) -> pd.Series:
    """Year -> value for one country and series. ValueError when a year has two rows (an ambiguous answer, e.g. a
    database with a counterpart dimension the long layout dropped): never pick one silently."""
    if raw is None or not len(raw):
        return pd.Series(dtype=float)
    s = raw[(raw["iso"] == iso) & (raw["series"] == series)]
    v = pd.Series(pd.to_numeric(s["value"], errors="coerce").to_numpy(),
                  index=pd.to_numeric(s["period"], errors="coerce").to_numpy()).dropna()
    v = v[np.isfinite(v.index.to_numpy(dtype=float))]
    v.index = v.index.astype(int)
    if v.index.duplicated().any():
        raise ValueError(f"{series} {iso}: more than one row for year(s) {sorted(set(v.index[v.index.duplicated()]))}")
    return v.sort_index()


def hp_trend(x: np.ndarray, lam: float) -> np.ndarray:
    """Two-sided Hodrick-Prescott trend of x: solve (I + lam D'D) trend = x, D the second-difference matrix."""
    n = len(x)
    if n < 3:
        return np.asarray(x, dtype=float)
    d = np.zeros((n - 2, n))
    for i in range(n - 2):
        d[i, i:i + 3] = (1.0, -2.0, 1.0)
    return np.linalg.solve(np.eye(n) + lam * d.T @ d, np.asarray(x, dtype=float))


def one_sided_gap(x: pd.Series, lam: float = CREDIT_HP_LAMBDA) -> float:
    """x at its last year minus the HP trend fitted on x up to and including that year (one-sided: no later data)."""
    return float(x.iloc[-1] - hp_trend(x.to_numpy(dtype=float), lam)[-1])


def _consecutive_tail(x: pd.Series) -> pd.Series:
    """The longest run of consecutive years ending at the last year."""
    if not len(x):
        return x
    yrs = x.index.to_numpy()
    k = len(yrs) - 1
    while k > 0 and yrs[k] - yrs[k - 1] == 1:
        k -= 1
    return x.iloc[k:]


def credit_run(raw: pd.DataFrame | None, iso: str, year: int) -> pd.Series:
    """The run of FS.AST.PRVT.GD.ZS years the 5.9 transform uses for `year`: consecutive years ending at the latest
    year <= `year` (empty when none; ValueError on a duplicated year, as `annual`)."""
    s = annual(raw, iso, CREDIT)
    return _consecutive_tail(s[s.index <= year])


def credit_breaks(run: pd.Series, pp: float = CREDIT_BREAK_PP, rel: float = CREDIT_BREAK_REL) -> list[tuple]:
    """(year before, year, value before, value) for every consecutive-year step in `run` larger than `pp` points or
    than `rel` times the previous level (Team B change 1: rebasing, redenomination, hyperinflation). A step from a
    previous level of 0 counts as relative when it is not 0."""
    out = []
    v = run.to_numpy(dtype=float)
    y = run.index.to_numpy()
    for i in range(1, len(v)):
        if y[i] - y[i - 1] != 1:
            continue
        d = abs(v[i] - v[i - 1])
        prev = abs(v[i - 1])
        if d > pp or (d > rel * prev if prev > 0 else d > 0):
            out.append((int(y[i - 1]), int(y[i]), float(v[i - 1]), float(v[i])))
    return out


def wdi_extra_transforms(raw: pd.DataFrame | None, iso: str, year: int) -> tuple[dict, dict, dict]:
    """({id: value}, {id: series text}, {id: reason not served}) for 2.12 and 5.9 of one country, using years up to
    `year` only."""
    out, used, why = {}, {}, {}
    for key, code in (("2.12", REER), ("5.9", CREDIT)):
        try:
            s = annual(raw, iso, code)
        except ValueError as e:
            why[key] = f"refused: {e}"
            continue
        s = s[s.index <= year]
        if not len(s):
            why[key] = f"no {code} value"
            continue
        if key == "2.12":
            last = int(s.index[-1])
            w = s[(s.index > last - REER_WINDOW) & (s.index <= last)]
            if len(w) < REER_MIN_YEARS or not w.mean() > 0:
                why[key] = f"{code}: {len(w)} of the last {REER_WINDOW} years (needs {REER_MIN_YEARS})"
                continue
            out[key] = float(s.iloc[-1] / w.mean() * 100 - 100)
            used[key] = (f"WDI {code} (IMF IFS via WDI) {last} vs mean of {int(w.index[0])}-{last} "
                         f"({len(w)} years; annual, BIS rule is monthly)")
        else:
            run = _consecutive_tail(s)
            if len(run) < CREDIT_MIN_YEARS:
                why[key] = f"{code}: {len(run)} consecutive years to {int(s.index[-1])} (needs {CREDIT_MIN_YEARS})"
                continue
            out[key] = one_sided_gap(run)
            used[key] = (f"{CREDIT_RULE_TEXT}; WDI {code} (IMF IFS via WDI) one-sided HP gap, lambda "
                         f"{CREDIT_HP_LAMBDA:g}, {int(run.index[0])}-{int(run.index[-1])}")
    return {k: v for k, v in out.items() if np.isfinite(v)}, used, why


def wdi_extra_cells(raw: dict, country: str, iso: str, have: pd.Series, filled: set, year: int,
                    tlog: list, unserved: list) -> list[tuple]:
    """Cells this feed fills for one country, as (kind, key, value, source, series) for fetch_all's `put`. Only cells
    that BIS (`have`, the country's Inputs column) and the IMF (`filled`) left empty. Cells still empty get one
    unserved row (feed wdi_extra) with the reason; any earlier unserved row for a cell this feed fills is removed."""
    if WDI_EXTRA_FEED not in raw:
        return []
    df = raw[WDI_EXTRA_FEED]
    src = str(df["source"].iloc[0]) if len(df) else WDI_EXTRA_LABEL
    vals, used, why = wdi_extra_transforms(df, iso, year)
    puts = []
    order = " > ".join(FALLBACK_ORDER)
    for key in sorted(WDI_EXTRA_IDS):
        cur = have.get(key, np.nan)
        if key in filled or (cur is not None and np.isfinite(cur)):
            continue
        if key in vals:
            note = f"precedence {order}: {WDI_EXTRA_FEED} used as fallback (bis, imf_sdmx have no value)"
            puts.append(("indicator", key, vals[key], src, f"{used[key]} ({note})"))
            tlog.append({"iso": iso, "series": key, "year": year, "value": vals[key], "fallback": np.nan,
                         "jump": np.nan, "sd_changes": np.nan, "rule": note, "country": country})
            unserved[:] = [u for u in unserved if not (u.get("table") == "Inputs" and u.get("key") == key
                                                       and u.get("country") == country)]
        else:
            unserved.append({"table": "Inputs", "key": key, "country": country, "iso": iso, "feed": WDI_EXTRA_FEED,
                             "reason": why.get(key, "no value")})
    return puts


# ---------------------------------------------------------------------------------------------- gate
def wdi_gate_rows(key: str, country: str, value: float, series: str, raw: dict, iso: str | None, year: int,
                  verified: set, stale_years: int = 3) -> list[dict]:
    """crosscheck.CHECK_COLUMNS hold rows for one cell this feed filled: unverified (coverage map), method (Team B
    approval, METHOD_APPROVED), range (WDI_RANGES), stale (latest year up to `year` more than
    min(stale_years, WDI_STALE_YEARS) before `year`; Team B: 2 years for both ids) and, for 5.9, break
    (credit_breaks in the run the transform used)."""
    rows = []

    def hold(check: str, reason: str) -> None:
        rows.append({"table": "Inputs", "key": key, "country": country, "check": check, "status": "hold",
                     "reason": reason, "live": value, "basis": series})

    if key not in verified:
        hold("unverified", f"{key} from {WDI_EXTRA_FEED}: WDI codes not yet confirmed on a live pull "
                           "(coverage_source_map.csv verified is not yes; docs/runbooks/A-coverage-plan.md section 10)")
    if key not in METHOD_APPROVED:
        hold("method", f"{key} from {WDI_EXTRA_FEED}: transform method awaits Team B approval (EQ-A-0062 handoff)")
    lo, hi = WDI_RANGES.get(key, (-np.inf, np.inf))
    if np.isfinite(value) and not lo <= value <= hi:
        hold("range", f"{value:.4g} outside the plausibility bounds [{lo:g}, {hi:g}] for {key}")
    df = raw.get(WDI_EXTRA_FEED)
    limit = min(int(stale_years), WDI_STALE_YEARS)
    for c in WDI_EXTRA_COMPONENTS.get(key, ()):
        if df is None or iso is None:
            continue
        s = df[(df["iso"] == iso) & (df["series"] == c)]
        per = pd.to_numeric(s["period"], errors="coerce")
        per = per[per <= year]
        last = per.max() if len(per) else np.nan
        if np.isfinite(last) and last < year - limit:
            hold("stale", f"World Bank {c} latest period {int(last)} (limit {limit} years before {year}, "
                          "Team B rule, indicator-rules.md section 12)")
    if key == "5.9" and df is not None and iso is not None:
        try:
            br = credit_breaks(credit_run(df, iso, year))
        except ValueError:
            br = []                     # duplicated years: the transform refused the cell already
        if br:
            txt = ", ".join(f"{a}-{b} {u:.4g} -> {v:.4g}" for a, b, u, v in br[:4]) + (" ..." if len(br) > 4 else "")
            hold("break", f"{CREDIT} step above {CREDIT_BREAK_PP:g} pp or {CREDIT_BREAK_REL:.0%} of the previous level "
                          f"in the run used: {txt} (rebasing, redenomination or hyperinflation; Team B change 1)")
    return rows


# ---------------------------------------------------------------------------------------------- before release
def _bis_q4(bis: pd.DataFrame | None, iso: str, year: int) -> float:
    """The BIS credit-to-GDP gap (raw_bis.csv series CREDIT_GAP) for `year`-Q4, NaN when absent."""
    if bis is None or not len(bis):
        return np.nan
    s = bis[(bis["iso"] == iso) & (bis["series"] == "CREDIT_GAP") & (bis["period"].astype(str) == f"{year}-Q4")]
    v = pd.to_numeric(s["value"], errors="coerce").dropna()
    return float(v.iloc[0]) if len(v) == 1 else np.nan


def compare_with_bis(wdi: pd.DataFrame | None, bis: pd.DataFrame | None, isos: Iterable[str],
                     year: int) -> tuple[pd.DataFrame, dict]:
    """Team B change 5: the WDI 5.9 gap against the BIS gap where BIS has one. For each iso: the WDI gap at the
    latest WDI year <= `year` (the value the feed would serve) and the BIS gap in Q4 of that same year. Returns
    (rows, summary) with summary n, median_abs_diff_pp, tol_pp and review (median above COMPARE_TOL_PP: Team B
    reviews before any WDI gap goes live). Reads only what it is given; numbers come from the two files."""
    rows = []
    for iso in dict.fromkeys(isos):
        vals, used, why = wdi_extra_transforms(wdi, iso, year)
        if "5.9" not in vals:
            rows.append({"iso": iso, "wdi_year": np.nan, "wdi_gap": np.nan, "bis_q4": np.nan, "abs_diff": np.nan,
                         "note": why.get("5.9", "no WDI gap")})
            continue
        y = int(credit_run(wdi, iso, year).index[-1])
        b = _bis_q4(bis, iso, y)
        rows.append({"iso": iso, "wdi_year": y, "wdi_gap": vals["5.9"], "bis_q4": b,
                     "abs_diff": abs(vals["5.9"] - b) if np.isfinite(b) else np.nan,
                     "note": "" if np.isfinite(b) else f"no BIS CREDIT_GAP for {y}-Q4"})
    out = pd.DataFrame(rows, columns=["iso", "wdi_year", "wdi_gap", "bis_q4", "abs_diff", "note"])
    d = out["abs_diff"].dropna()
    med = float(d.median()) if len(d) else np.nan
    return out, {"n": int(len(d)), "median_abs_diff_pp": med, "tol_pp": COMPARE_TOL_PP,
                 "review": bool(np.isfinite(med) and med > COMPARE_TOL_PP)}


_CHECK_RE = re.compile(r"(?:^|; )([a-z_]+): ")


def split_reasons(reason: str) -> dict:
    """review.csv reason text 'check: text; check: text' -> {check: text} (the texts may hold '; ' themselves)."""
    reason = "" if reason is None or (isinstance(reason, float) and np.isnan(reason)) else str(reason)
    parts = _CHECK_RE.split(reason)
    out = {}
    for i in range(1, len(parts) - 1, 2):
        out[parts[i]] = (out.get(parts[i], "") + ("; " if parts[i] in out else "") + parts[i + 1]).strip()
    return out


def approval_effect(review: pd.DataFrame, year: int, wdi: pd.DataFrame | None = None,
                    iso_of: dict | None = None, assume_verified: bool = True) -> pd.DataFrame:
    """The batch effect of adding 2.12 and 5.9 to METHOD_APPROVED, from a review.csv (Sam's pull) and, when given,
    the same pull's raw_wdi_extra.csv. One row per WDI-filled Inputs cell: seed, live, the holds today, the holds
    left after approval (method gone; unverified gone when assume_verified, i.e. after the Mac confirms the codes;
    stale recomputed at WDI_STALE_YEARS and break added when `wdi` and `iso_of` are given) and released
    (yes / no / 'yes unless break or 2-year stale' when the raw file is missing). Values are never changed: a released
    cell moves from seed to the live value already in the review."""
    r = review[(review["table"] == "Inputs") & review["key"].astype(str).isin(WDI_EXTRA_IDS)
               & review["reason"].astype(str).str.contains(f"from {WDI_EXTRA_FEED}", regex=False)]
    rows = []
    for x in r.itertuples(index=False):
        key, n = str(x.key), x.country
        now = split_reasons(x.reason)
        after = {k: v for k, v in now.items() if k != "method" and not (assume_verified and k == "unverified")}
        iso = (iso_of or {}).get(n)
        known = wdi is not None and iso is not None
        if known:
            after.pop("stale", None)
            live = float(pd.to_numeric(x.live, errors="coerce"))
            for h in wdi_gate_rows(key, n, live, "", {WDI_EXTRA_FEED: wdi}, iso, year, set(WDI_EXTRA_IDS)):
                if h["check"] in ("stale", "break"):
                    after[h["check"]] = h["reason"]
        if after:
            rel = "no"
        else:
            rel = "yes" if known else "yes unless break or 2-year stale (needs raw_wdi_extra.csv)"
        rows.append({"key": key, "country": n, "seed": x.seed, "live": x.live, "holds_now": ", ".join(now),
                     "holds_after": ", ".join(after), "released": rel,
                     "after_reasons": "; ".join(f"{k}: {v}" for k, v in after.items())})
    return pd.DataFrame(rows, columns=["key", "country", "seed", "live", "holds_now", "holds_after", "released",
                                       "after_reasons"])


def _read_long(path: str) -> pd.DataFrame:
    df = pd.read_csv(path, dtype={"iso": str, "series": str, "period": str})
    return df


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.official.wdi_extra",
                                 description="WDI 5.9 / 2.12 fallbacks: checks before METHOD_APPROVED (EQ-A-0084)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("compare", help="Team B change 5: median |WDI 5.9 gap - BIS Q4 gap| on names with a BIS gap")
    c.add_argument("--raw", required=True, help="raw_wdi_extra.csv of a pull (iso, series, period, value)")
    c.add_argument("--bis", required=True, help="raw_bis.csv of the same pull")
    c.add_argument("--year", type=int, required=True, help="as_of year of the pull")
    c.add_argument("--isos", default="", help="comma list; default every iso with a BIS CREDIT_GAP row")
    e = sub.add_parser("effect", help="batch effect of METHOD_APPROVED = {2.12, 5.9} on a pull's review.csv")
    e.add_argument("--review", required=True)
    e.add_argument("--year", type=int, required=True)
    e.add_argument("--raw", default="", help="raw_wdi_extra.csv of the same pull (stale at 2 years, break)")
    e.add_argument("--data", default="data", help="econquest data folder (country -> iso3)")
    e.add_argument("--desk", action="store_true", help="only rows with a seed value (the desk names)")
    for p in (c, e):
        p.add_argument("--csv", action="store_true", help="print rows as CSV")
    a = ap.parse_args(argv)
    if a.cmd == "compare":
        wdi = _read_long(a.raw)
        wdi["period"] = pd.to_numeric(wdi["period"], errors="coerce")
        bis = _read_long(a.bis)
        isos = [i for i in a.isos.split(",") if i] or sorted(bis.loc[bis["series"] == "CREDIT_GAP", "iso"].unique())
        rows, summ = compare_with_bis(wdi, bis, isos, a.year)
        print(rows.to_csv(index=False) if a.csv else rows.to_string(index=False))
        print(f"n={summ['n']} median |WDI - BIS| = {summ['median_abs_diff_pp']:.3f} pp (tol {COMPARE_TOL_PP:g}); "
              + ("ABOVE: Team B reviews before any WDI 5.9 goes live" if summ["review"] else "within tolerance"))
        return 1 if summ["review"] else 0
    review = pd.read_csv(a.review, dtype={"key": str})
    wdi = None
    if a.raw:
        wdi = _read_long(a.raw)
        wdi["period"] = pd.to_numeric(wdi["period"], errors="coerce")
    from ..loaders import load_universe
    u = load_universe(a.data)
    out = approval_effect(review, a.year, wdi, dict(zip(u.names, u.countries["iso"])))
    if a.desk:
        out = out[pd.to_numeric(out["seed"], errors="coerce").notna()]
    print(out.to_csv(index=False) if a.csv else out.drop(columns=["after_reasons"]).to_string(index=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
