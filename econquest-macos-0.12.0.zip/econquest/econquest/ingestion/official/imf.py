"""IMF SDMX adapter (EQ-A-0049), against the IMF's new data portal (https://data.imf.org/en/Resource-Pages/IMF-API).

In the default fetch since Sam's decision of 2026-10-24 12:38Z (HO-20261024-A-B-003): IMF data is for internal
research use only and never goes into client output. Every raw row carries official.IMF_LICENCE; audit.client_output_reason
treats it as restricted for client output.

UNVERIFIED (this cloud cannot reach api.imf.org; written from the IMF API pages and package docs as remembered):
  IMF_BASE                   SDMX 3.0 REST root of the new portal
  IMF_AGENCY                 agency of the statistics dataflows
  query form                 /data/dataflow/{agency}/{flow}/+/*?c[DIM]=code&c[COUNTRY]=USA,BRA (SDMX 3.0 component
                             filters, so the positional dimension order need not be known)
  IMF_ACCEPT                 SDMX-CSV 2.0 media type
  area codes                 ISO 3166 alpha-3 in a COUNTRY dimension
  every flow and code in IMF_SPECS (each spec's `candidate` says where it comes from)
Specs whose codes are not known at all are left unconfigured (filters=None): they are never requested, and the
indicators that need them are reported unserved with that reason. Fill them from `python -m
econquest.ingestion.official.imf structure <FLOW>` on the Mac (docs/runbooks/A-fetch-on-mac.md).

Every cell this adapter fills is held by the quality gate until data/panel/coverage_source_map.csv marks the
indicator verified=yes (official.gate)."""
from __future__ import annotations

import argparse
import re
import sys
import urllib.parse
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import pandas as pd

from . import IMF_LICENCE
from .sdmx import SdmxFeed, SeriesSpec, month_minus, quarter_to_month, scaled

IMF_BASE = "https://api.imf.org/external/sdmx/3.0"          # UNVERIFIED
IMF_AGENCY = "IMF.STA"                                      # UNVERIFIED
IMF_ACCEPT = "application/vnd.sdmx.data+csv;version=2.0.0"  # UNVERIFIED
IMF_AREA_DIM = "COUNTRY"                                    # UNVERIFIED
IMF_LABEL = "IMF SDMX"
IMF_HOST = "api.imf.org"
FLOW_ID_RE = re.compile(r"[A-Za-z][A-Za-z0-9_.-]{0,63}")     # SDMX dataflow id (main: structure / sample)

_M = (("FREQUENCY", "M"),)
IMF_SPECS = {
    "cpi_index": SeriesSpec(
        "cpi_index", "CPI", (("INDEX_TYPE", "CPI"), ("COICOP_1999", "_T"), ("TYPE_OF_TRANSFORMATION", "IX"), *_M), "M",
        "consumer price index, all items, index",
        candidate="new-portal CPI dataflow; dimension names and codes as remembered from the portal, UNVERIFIED"),
    "odc_deposits": SeriesSpec(
        "odc_deposits", "MFS_ODC", None, "M", "other depository corporations: transferable and other deposits",
        candidate="MFS ODC survey; dataflow id and indicator codes unknown (coverage map 5.11)"),
    "odc_claims_cg": SeriesSpec(
        "odc_claims_cg", "MFS_ODC", None, "M", "other depository corporations: claims on central government",
        candidate="MFS ODC survey; codes unknown (coverage map 5.1)"),
    "odc_total_assets": SeriesSpec(
        "odc_total_assets", "MFS_ODC", None, "M", "other depository corporations: total assets",
        candidate="MFS ODC survey; codes unknown (coverage map 5.1)"),
    "fsi_fx_loans_pct": SeriesSpec(
        "fsi_fx_loans_pct", "FSIC", None, "Q", "FSI: foreign-currency-denominated loans to total loans, %",
        candidate="FSI encouraged set; dataflow FSIC named in the coverage map, code unknown (5.2)"),
    "fsi_fx_liab_pct": SeriesSpec(
        "fsi_fx_liab_pct", "FSIC", None, "Q", "FSI: foreign-currency-denominated liabilities to total liabilities, %",
        candidate="FSI encouraged set; code unknown (2.4, proxy for FX deposits)"),
    "irfcl_reserve_assets": SeriesSpec(
        "irfcl_reserve_assets", "IRFCL", (("INDICATOR", "RAFA_USD"), *_M), "M", "official reserve assets, US$",
        candidate="legacy IFS/IRFCL code RAFA_USD; new-portal dataflow and code UNVERIFIED"),
    "irfcl_drains_12m": SeriesSpec(
        "irfcl_drains_12m", "IRFCL", None, "M",
        "IRFCL section II: predetermined short-term net drains, principal + interest, up to 1 year, US$",
        candidate="IRFCL section II; code unknown (1.2)"),
    "iip_portfolio_debt_liab": SeriesSpec(
        "iip_portfolio_debt_liab", "IIP", None, "Q", "IIP: portfolio investment liabilities, debt securities, US$",
        candidate="BOP/IIP dataflow; code unknown (2.3)"),
    "reer_index": SeriesSpec(
        "reer_index", "EER", (("INDICATOR", "EREER_IX"), *_M), "M", "real effective exchange rate, CPI-based, index",
        candidate="legacy IFS EREER_IX; new-portal dataflow EER and code UNVERIFIED (2.12 fallback)"),
    "policy_rate": SeriesSpec(
        "policy_rate", "MFS_IR", (("INDICATOR", "FPOLM_PA"), *_M), "M", "monetary policy-related interest rate, % p.a.",
        candidate="legacy IFS FPOLM_PA; MFS_IR named in the imfapi docs; UNVERIFIED (5.13 fallback)"),
}

# indicator -> components it needs (official.gate staleness, unserved reasons)
IMF_COMPONENTS = {
    "5.11": ("odc_deposits", "cpi_index"),
    "5.1": ("odc_claims_cg", "odc_total_assets"),
    "2.3": ("iip_portfolio_debt_liab", "irfcl_reserve_assets"),
    "1.2": ("irfcl_drains_12m", "irfcl_reserve_assets"),
    "2.4": ("fsi_fx_liab_pct",),
    "5.2": ("fsi_fx_loans_pct",),
    "2.12": ("reer_index",),
    "5.13": ("policy_rate",),
}
IMF_IDS = frozenset(IMF_COMPONENTS)
# 2.1 needs the IMF ARA metric, an annual file with no SDMX series: reserves are fetched (irfcl_reserve_assets) for the
# numerator, but the indicator is not served by this adapter.
IMF_NOT_SERVED = {"2.1": ("IMF ARA metric is an annual IMF file, not an SDMX series: no live denominator "
                          "(IRFCL reserve assets are fetched into raw_imf_sdmx.csv); 2.1 stays with econquest dsa")}
REER_MIN_OBS, REER_WINDOW = 60, 120            # same rule as feeds.bis_transforms (2.12)


@dataclass
class ImfSdmxFeed(SdmxFeed):
    base: str = IMF_BASE
    accept: str = IMF_ACCEPT
    label: str = IMF_LABEL
    licence: str = IMF_LICENCE
    area_dim: str = IMF_AREA_DIM
    registry: dict = field(default_factory=lambda: dict(IMF_SPECS))
    agency: str = IMF_AGENCY

    def url(self, spec: SeriesSpec, areas: list[str]) -> str:
        params = {f"c[{self.area_dim}]": ",".join(areas)}
        params.update({f"c[{d}]": c for d, c in spec.filters or ()})
        return f"{self.base}/data/dataflow/{self.agency}/{spec.flow}/+/*?{urllib.parse.urlencode(params)}"

    def source(self) -> str:
        return f"IMF SDMX 3.0 ({IMF_HOST}, new data portal)"


# ---------------------------------------------------------------------------------------------- transforms
def _desc(name: str, period: str) -> str:
    return f"{IMF_SPECS[name].describe()} {period}"


def _latest_common(*series: pd.Series):
    common = sorted(set.intersection(*(set(s.index) for s in series))) if series else []
    return common[-1] if common else None


def imf_transforms(raw: pd.DataFrame | None, iso: str, cpi_weo: float | None = None) -> tuple[dict, dict]:
    """({id: value}, {id: series text}) for one country from the raw IMF table. Ids: 5.11, 5.1, 2.3, 1.2, 2.4, 5.2
    and the BIS fallbacks 2.12, 5.13 (official.precedence decides whether they are used). A value needs every
    component for the same period; nothing is carried across periods or countries."""
    out, used = {}, {}
    if raw is None or not len(raw):
        return out, used
    s = {n: scaled(raw, iso, n) for n in IMF_SPECS}
    # 5.11 real deposit growth, 12 months: (dep_t / dep_t-12) / (cpi_t / cpi_t-12) x 100 - 100
    dep, cpi = s["odc_deposits"], s["cpi_index"]
    for t in sorted(set(dep.index) & set(cpi.index), reverse=True):
        t0 = month_minus(t, 12)
        if t0 in dep.index and t0 in cpi.index and dep[t0] > 0 and cpi[t0] > 0 and cpi[t] > 0:
            out["5.11"] = float((dep[t] / dep[t0]) / (cpi[t] / cpi[t0]) * 100 - 100)
            used["5.11"] = f"{_desc('odc_deposits', f'{t0}..{t}')} deflated by {_desc('cpi_index', f'{t0}..{t}')}"
            break
    # 5.1 banks' claims on government % of bank assets
    t = _latest_common(s["odc_claims_cg"], s["odc_total_assets"])
    if t and s["odc_total_assets"][t] > 0:
        out["5.1"] = float(s["odc_claims_cg"][t] / s["odc_total_assets"][t] * 100)
        used["5.1"] = f"{_desc('odc_claims_cg', t)} / {_desc('odc_total_assets', t)} x 100"
    # 2.3 hot money proxy: IIP portfolio debt liabilities (stock, quarter end) / reserve assets of that month x 100
    res = s["irfcl_reserve_assets"]
    iip = s["iip_portfolio_debt_liab"]
    if len(iip) and len(res):
        iip_m = pd.Series(iip.to_numpy(), index=[quarter_to_month(p) for p in iip.index])
        t = _latest_common(iip_m, res)
        if t and res[t] > 0:
            out["2.3"] = float(iip_m[t] / res[t] * 100)
            used["2.3"] = (f"{_desc('iip_portfolio_debt_liab', t)} / {_desc('irfcl_reserve_assets', t)} x 100 "
                           "(proxy: IIP stock, not the 1-year due share)")
    # 1.2 FX debt service due: IRFCL 12-month predetermined drains / reserve assets x 100 (1-year horizon, not 24)
    t = _latest_common(s["irfcl_drains_12m"], res)
    if t and res[t] > 0:
        out["1.2"] = float(abs(s["irfcl_drains_12m"][t]) / res[t] * 100)
        used["1.2"] = (f"|{_desc('irfcl_drains_12m', t)}| / {_desc('irfcl_reserve_assets', t)} x 100 "
                       "(IRFCL horizon 12 months, the rulebook asks 24)")
    for key, name in (("2.4", "fsi_fx_liab_pct"), ("5.2", "fsi_fx_loans_pct")):
        if len(s[name]):
            out[key] = float(s[name].iloc[-1])
            used[key] = _desc(name, s[name].index[-1]) + (" (FX liabilities share as proxy for FX deposits)" if key == "2.4" else "")
    reer = s["reer_index"]
    if len(reer) >= REER_MIN_OBS:
        out["2.12"] = float(reer.iloc[-1] / reer.iloc[-REER_WINDOW:].mean() * 100 - 100)
        used["2.12"] = f"{_desc('reer_index', reer.index[-1])} vs mean of last {min(len(reer), REER_WINDOW)} months"
    pol = s["policy_rate"]
    if len(pol) and cpi_weo is not None and np.isfinite(cpi_weo):
        out["5.13"] = float(pol.iloc[-1] - cpi_weo)
        used["5.13"] = f"{_desc('policy_rate', pol.index[-1])} minus WEO PCPIPCH"
    return {k: v for k, v in out.items() if np.isfinite(v)}, used


def unserved_reason(raw: pd.DataFrame | None, iso: str, key: str, cpi_weo: float | None = None) -> str:
    """Why `key` has no IMF value for `iso`: unconfigured components first, then missing observations."""
    if key in IMF_NOT_SERVED:
        return IMF_NOT_SERVED[key]
    comps = IMF_COMPONENTS.get(key, ())
    unconf = [c for c in comps if not IMF_SPECS[c].configured]
    if unconf:
        return (f"IMF series not configured ({', '.join(unconf)}: codes unknown; {IMF_SPECS[unconf[0]].candidate}); "
                "confirm with `python -m econquest.ingestion.official.imf structure` on the Mac")
    have = [c for c in comps if len(scaled(raw, iso, c))]
    if len(have) < len(comps):
        return f"IMF SDMX returned no observation for {', '.join(c for c in comps if c not in have)}"
    if key == "5.13" and (cpi_weo is None or not np.isfinite(cpi_weo)):
        return "IMF policy rate present but no WEO PCPIPCH to deflate it"
    return "IMF SDMX components present but no common period (or fewer observations than the rule needs)"


# ---------------------------------------------------------------------------------------------- Mac verification
def structure_url(flow: str, agency: str = IMF_AGENCY, base: str = IMF_BASE) -> str:
    """SDMX 3.0 structure query for one dataflow with its codelists (UNVERIFIED path)."""
    return f"{base}/structure/dataflow/{agency}/{flow}/+?references=descendants"


def main(argv: list[str] | None = None) -> int:
    """Mac verification helpers (network): `structure FLOW` saves the dataflow's structure (dimensions, codelists) to
    --out; `sample FLOW --iso USA --filter DIM=CODE ...` fetches one series through the adapter and prints its rows,
    so a candidate code can be confirmed before the coverage map is set to verified=yes."""
    from ..sources import https_get
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.official.imf")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("structure"); p.add_argument("flow"); p.add_argument("--out", default="outputs/imf_structure")
    p = sub.add_parser("sample"); p.add_argument("flow"); p.add_argument("--iso", default="USA")
    p.add_argument("--filter", action="append", default=[], help="DIM=CODE, repeatable")
    p.add_argument("--freq", default="M")
    a = ap.parse_args(argv)
    if not FLOW_ID_RE.fullmatch(a.flow):     # SEC-A-007 L4: the flow id is joined to the URL path and the --out file name
        print(f"not an SDMX dataflow id: {a.flow[:80]!r} (letters, digits, '_', '-', '.')", file=sys.stderr)
        return 2
    if a.cmd == "structure":
        body = https_get(structure_url(a.flow), {"User-Agent": "econquest/0.2"}, timeout=60, max_bytes=50 * 1024 * 1024)
        out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
        f = out / f"{a.flow}.structure.xml"
        f.write_bytes(body)
        print(f"{f} ({len(body)} bytes): read the dimension ids and codes, then set IMF_SPECS and the coverage map")
        return 0
    filt = tuple(tuple(x.split("=", 1)) for x in a.filter)
    spec = SeriesSpec("sample", a.flow, filt, a.freq, "sample")
    feed = ImfSdmxFeed(registry={"sample": spec})
    df = feed.fetch([a.iso])
    print(df.tail(24).to_string(index=False))
    print("failures:", df.attrs.get("failures"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
