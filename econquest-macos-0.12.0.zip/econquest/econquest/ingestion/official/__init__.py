"""Official statistics adapters (EQ-A-0049): IMF SDMX, OECD SDMX, Eurostat SDMX, World Bank additions.

Layout (each module is small and offline-testable):
    sdmx.py        shared transport (sources.https_get: https only, no redirects, byte cap; FeedUnreachable fail-fast)
                   and the SDMX-CSV parser that refuses rows whose dimensions differ from the requested series
    imf.py         IMF SDMX 3.0 (new data portal): CPI, MFS, FSI, IRFCL, IIP, REER, policy rate -> 5.11, 5.1, 2.3,
                   1.2, 2.4, 5.2 and the BIS fallbacks 2.12 / 5.13. In the default fetch (Sam 2026-10-24 12:38Z).
    oecd.py        OECD SDMX (sdmx.oecd.org) -> 1.5 for OECD members. Named feed only (`--only oecd`).
    eurostat.py    Eurostat SDMX 2.1 (ec.europa.eu) -> 1.5 for EU members. Named feed only (`--only eurostat`).
    worldbank.py   transforms for the World Bank additions fetched by feeds.WorldBankFeed: 2.2, 2.11, 7.10 (6.10 Gini
                   is fetched raw only: its 0-4 level mapping belongs to Team B)
    precedence.py  BIS first, then IMF, for 2.12 / 5.9 / 5.13, and the BIS-vs-IMF cross-check tolerances
    gate.py        quality-gate rules for every new series: unverified codes, ranges, staleness, BIS/IMF cross-check
    wiring.py      what feeds.fetch_all / quality_gate call (lazy imports there, so this package can import feeds)
    central_banks.py  EQ-A-0050: central-bank / national-statistics registry and adapters for the top-25 desk names
                   (policy rate, CPI, reserves, debt stock). Named feed only (`--only cb`); verification per series in
                   data/panel/cb_series_verified.csv (docs/runbooks/A-central-bank-adapters.md)
    macro.py       EQ-A-0134: BIS WS_EER real/nominal broad/narrow (through feeds.BisFeed), World Bank Pink Sheet
                   commodity prices, export-share commodity terms-of-trade index; research inputs, no desk cell, own
                   gate (macro_gate, reusing gate.py); pull-pack step 8 (docs/runbooks/A-macro-inputs.md)

Every dataflow id, dimension name and code in these modules is UNVERIFIED: this cloud cannot reach api.imf.org,
sdmx.oecd.org or ec.europa.eu. Values are fetched, but the quality gate holds every cell an adapter fills until
data/panel/coverage_source_map.csv marks its indicator verified=yes after a live check on Sam's Mac
(docs/runbooks/A-fetch-on-mac.md, section "IMF/OECD/Eurostat").

This module imports nothing from the package on purpose: feeds.py imports from it lazily."""

# Sam 2026-10-24 12:38Z (decision card, HO-20261024-A-B-003): IMF data is for internal research use only and never goes
# into client output. The tag rides on every IMF raw row; audit.client_output_reason recognises it (and IMF / WEO
# sources) as restricted for client output. It does NOT bar the value from desk numbers or the internal data room.
IMF_LICENCE = ("IMF: internal research use only (EXC-003, Sam 2026-10-24; external validator under NDA only; commercial reuse/bulk download need IMF permission)")
OECD_LICENCE = "OECD terms: believed CC BY 4.0 (unverified) https://www.oecd.org/en/about/terms-conditions.html"
EUROSTAT_LICENCE = ("Eurostat: free reuse with attribution (unverified) "
                    "https://ec.europa.eu/eurostat/about-us/policies/copyright")

# feed names as fetch_all knows them
IMF_FEED = "imf_sdmx"
OECD_FEED = "oecd"
EUROSTAT_FEED = "eurostat"
OFFICIAL_FEEDS = (IMF_FEED, OECD_FEED, EUROSTAT_FEED)
