"""Quality-gate rules for the series the official adapters and World Bank additions serve (EQ-A-0049).

Called from feeds.quality_gate; returns crosscheck.CHECK_COLUMNS rows that merge_into_review folds into the review
(holds only act; a hold is never downgraded). For every Inputs cell these sources filled:

  unverified     held while data/panel/coverage_source_map.csv does not mark the indicator verified=yes (every new
                 code is unverified until a live response on Sam's Mac confirms it; no code is presented as verified)
  range          held when the value is outside OFFICIAL_RANGES (hard plausibility bounds in the indicator's unit,
                 on top of the rulebook-threshold range check feeds.quality_gate already applies)
  stale          IMF / OECD / Eurostat: the last observation of a component is older than OFFICIAL_STALE_DAYS for
                 its frequency at the gate's reference date (same rule and period parsing as the BIS staleness of
                 EQ-A-0044); World Bank additions: a component's latest year is more than `stale_years` before
                 `year` (the World Bank rule)
  bis_imf_cross  2.12 / 5.13 where BIS was used and the IMF also has a value: held when they differ by more than
                 precedence.CROSS_TOL ('ok' rows are returned too, so the comparison is on record)
  method         EQ-A-0062: WDI fallbacks (official.wdi_extra, 2.12 / 5.9) also hold while Team B has not approved
                 the transform (wdi_extra.METHOD_APPROVED); unverified / range / stale apply to them as above
  EQ-A-0096      ids_fc_debt (1.5 IDS proxy): official.ids_fc_debt.ids_fc_gate_rows (unverified, method, range, stale);
                 dsa (econquest dsa rows 1.2 / 1.1 / 2.1): official.dsa_feed.dsa_gate_rows (dsa_mixed, unverified,
                 replay, stale, range)"""
from __future__ import annotations

import datetime as dt
from pathlib import Path

import numpy as np
import pandas as pd

from .. import feeds as F
from . import EUROSTAT_FEED, IMF_FEED, OECD_FEED
from .eurostat import EUROSTAT_SPECS, EurostatFeed
from .imf import IMF_COMPONENTS, IMF_IDS, IMF_SPECS, ImfSdmxFeed, imf_transforms
from .oecd import FC_SHARE_COMPONENTS, OECD_SPECS, OecdFeed
from .precedence import CROSS_TOL, PRECEDENCE, disagreement
from .sdmx import norm_period
from .dsa_feed import DSA_FEED, DSA_KEYS, DSA_LABEL, dsa_gate_rows
from .ids_fc_debt import IDS_FC_FEED, IDS_FC_LABEL, ids_fc_gate_rows
from .qeds import KEYS as QEDS_KEYS, QEDS_FEED, QEDS_LABEL, data_year_of as qeds_year, qeds_gate_rows
from .wdi_extra import WDI_EXTRA_FEED, WDI_EXTRA_IDS, WDI_EXTRA_LABEL, wdi_gate_rows
from .worldbank import WB_EXTRA_COMPONENTS, WB_EXTRA_IDS

DEFAULT_DATA = Path(__file__).resolve().parents[3] / "data"
MAP_FILE = Path("panel") / "coverage_source_map.csv"
# limits in days by frequency: monthly ~ two releases plus the 1-3 month IMF lag; quarterly as BIS (EQ-A-0044)
OFFICIAL_STALE_DAYS = {"D": 30, "M": 122, "Q": 275, "A": 730}
# hard plausibility bounds, indicator units (shares 0-100; ratios to reserves allow very weak reserve positions)
OFFICIAL_RANGES = {
    "5.11": (-90.0, 500.0), "5.1": (0.0, 100.0), "2.3": (0.0, 5000.0), "1.2": (0.0, 5000.0), "2.4": (0.0, 100.0),
    "5.2": (0.0, 100.0), "2.12": (-80.0, 300.0), "5.13": (-100.0, 100.0), "1.5": (0.0, 100.0),
    "2.11": (0.0, 100.0), "7.10": (0.0, 100.0), "2.2": (-1000.0, 10000.0),
}
FC_COMPONENTS = {OECD_FEED: (FC_SHARE_COMPONENTS, OECD_SPECS), EUROSTAT_FEED: (("gg_debt_fc", "gg_debt_total"), EUROSTAT_SPECS)}


def verified_ids(data_dir: str | Path | None = None) -> set[str]:
    """Indicator ids that coverage_source_map.csv marks verified=yes; empty when the map is absent or unreadable."""
    p = Path(data_dir or DEFAULT_DATA) / MAP_FILE
    try:
        m = pd.read_csv(p, dtype=str, keep_default_na=False)
    except (OSError, ValueError):
        return set()
    if not {"id", "verified"} <= set(m.columns):
        return set()
    return set(m.loc[m["verified"].str.strip().str.lower() == "yes", "id"].str.strip())


def _current_value(u, key: str, country: str) -> float:
    """The value indicators.csv holds now for (key, country); NaN when absent."""
    ind = getattr(u, "indicators", None)
    try:
        frame = ind.set_index(ind["id"].astype(str)) if "id" in ind.columns else ind
        return float(pd.to_numeric(frame.at[key, country], errors="coerce"))
    except (AttributeError, KeyError, TypeError, ValueError):
        return float("nan")


def _applied_from(data_dir, key: str, country: str, source: str) -> bool:
    """True when audit_trail.csv says the applied (key, country) value already came from `source` (so a new value
    is not the first one). Unreadable or absent: False, so the first-value checks apply (conservative)."""
    p = Path(data_dir or DEFAULT_DATA) / "audit_trail.csv"
    try:
        a = pd.read_csv(p, dtype=str, keep_default_na=False, usecols=["table", "key", "country", "source"])
    except (OSError, ValueError):
        return False
    hit = a[(a["table"] == "Inputs") & (a["key"] == key) & (a["country"] == country)]
    return bool(len(hit)) and hit["source"].iloc[-1] == source


def _feed_of(source: str, key: str) -> str | None:
    s = str(source)
    if s == WDI_EXTRA_LABEL and key in WDI_EXTRA_IDS:          # EQ-A-0062
        return WDI_EXTRA_FEED
    if s == IDS_FC_LABEL and key == "1.5":                     # EQ-A-0096
        return IDS_FC_FEED
    if s == QEDS_LABEL and key in QEDS_KEYS:                   # EQ-A-0117 (HO-20261025-A-A-002)
        return QEDS_FEED
    if s == DSA_LABEL and key in DSA_KEYS:                     # EQ-A-0096
        return DSA_FEED
    for feed, label in ((IMF_FEED, ImfSdmxFeed().source()), (OECD_FEED, OecdFeed().source()),
                        (EUROSTAT_FEED, EurostatFeed().source())):
        if s == label:
            return feed
    if key in WB_EXTRA_IDS and s.startswith("wbgapi"):
        return "worldbank"
    return None


def _age(raw: pd.DataFrame | None, iso: str, series: str, ref: dt.date) -> tuple[int, str, str] | None:
    """(age in days, last date, frequency) of a component's last observation; None without readable rows."""
    if raw is None or not len(raw):
        return None
    s = raw[(raw["iso"] == iso) & (raw["series"] == series)]
    ends = []
    for p in s["period"]:
        n = norm_period(p)
        if n is None:
            continue
        if len(n) == 4:
            ends.append((dt.date(int(n), 12, 31), "A"))
        else:
            e = F._period_end(n)
            if e is not None:
                ends.append(e)
    if not ends:
        return None
    last, freq = max(ends)
    return (ref - last).days, last.isoformat(), freq


def _stale_reasons(feed: str, raw: dict, iso: str, key: str, ref: dt.date, year: int, stale_years: int) -> list[str]:
    out = []
    if feed == "worldbank":
        wb = raw.get("worldbank")
        for c in WB_EXTRA_COMPONENTS.get(key, ()):
            if wb is None:
                continue
            s = wb[(wb["iso"] == iso) & (wb["series"] == c)]
            last = pd.to_numeric(s["period"], errors="coerce").max() if len(s) else np.nan
            if np.isfinite(last) and last < year - stale_years:
                out.append(f"World Bank {c} latest period {int(last)} (limit {stale_years} years before {year})")
        return out
    if feed == IMF_FEED:
        comps, specs = IMF_COMPONENTS.get(key, ()), IMF_SPECS
    else:
        comps, specs = FC_COMPONENTS[feed]
    for c in comps:
        a = _age(raw.get(feed), iso, c, ref)
        if a is None:
            continue
        age, last, freq = a
        limit = OFFICIAL_STALE_DAYS.get(freq, OFFICIAL_STALE_DAYS.get(specs[c].freq, 275))
        if age > limit:
            out.append(f"{feed} {c} last observation {last}, {age} days before {ref.isoformat()} (limit {limit} days)")
    return out


def gate_checks(u, report, ref: dt.date, year: int, data_dir: str | Path | None = None,
                stale_years: int = 3, dsa_vintage: str | None = None) -> pd.DataFrame:
    """CHECK_COLUMNS rows for the official adapters' cells (module docstring)."""
    from ..crosscheck import CHECK_COLUMNS
    prov = getattr(report, "provenance", None)
    rows: list[dict] = []
    if prov is None or not len(prov) or not {"table", "key", "country", "source"} <= set(prov.columns):
        return pd.DataFrame(rows, columns=CHECK_COLUMNS)
    iso_of = dict(zip(u.names, u.countries["iso"]))
    ok_ids = verified_ids(data_dir)
    raw = report.raw or {}
    ours = IMF_IDS | WB_EXTRA_IDS | WDI_EXTRA_IDS | {"1.5"} | set(DSA_KEYS) | set(QEDS_KEYS)   # DSA_KEYS: EQ-A-0096; QEDS: EQ-A-0117
    for r in prov[(prov["table"] == "Inputs") & prov["key"].astype(str).isin(ours)].itertuples(index=False):
        key, n = str(r.key), r.country
        feed = _feed_of(r.source, key)
        if feed is None:
            continue
        value = float(pd.to_numeric(r.value, errors="coerce"))
        series = str(getattr(r, "series", ""))
        if feed == WDI_EXTRA_FEED:      # EQ-A-0062: unverified / method / range / stale (official.wdi_extra)
            rows.extend(wdi_gate_rows(key, n, value, series, raw, iso_of.get(n), year, ok_ids, stale_years))
            continue
        if feed == IDS_FC_FEED:         # EQ-A-0096: unverified / method / range / stale; EQ-A-0106: seed
            rows.extend(ids_fc_gate_rows(n, value, series, raw, iso_of.get(n), year, ok_ids,
                                         seed=_current_value(u, "1.5", n),
                                         first=not _applied_from(data_dir, "1.5", n, IDS_FC_LABEL)))
            continue
        if feed == QEDS_FEED:           # EQ-A-0117: unverified / method / range / stale (official.qeds)
            rows.extend(qeds_gate_rows(key, n, value, series, qeds_year(series), year))
            continue
        if feed == DSA_FEED:            # EQ-A-0096: dsa_mixed / unverified / replay / stale / range (official.dsa_feed)
            rows.extend(dsa_gate_rows(key, n, value, series, raw.get(DSA_FEED), dsa_vintage, year, stale_years))
            continue

        def hold(check: str, reason: str, key=key, n=n, value=value, series=series) -> None:
            rows.append({"table": "Inputs", "key": key, "country": n, "check": check, "status": "hold",
                         "reason": reason, "live": value, "basis": series})

        if key not in ok_ids:
            hold("unverified", f"{key} from {feed}: series codes not yet confirmed on a live pull "
                               f"(coverage_source_map.csv verified is not yes; docs/runbooks/A-fetch-on-mac.md)")
        lo, hi = OFFICIAL_RANGES.get(key, (-np.inf, np.inf))
        if np.isfinite(value) and not lo <= value <= hi:
            hold("range", f"{value:.4g} outside the plausibility bounds [{lo:g}, {hi:g}] for {key}")
        for why in _stale_reasons(feed, raw, iso_of.get(n), key, ref, year, stale_years):
            hold("stale", why)
    # BIS vs IMF where BIS won
    imf = raw.get(IMF_FEED)
    if imf is not None and len(imf):
        bis_rows = prov[(prov["table"] == "Inputs") & prov["key"].astype(str).isin(set(PRECEDENCE) & set(CROSS_TOL))
                        & prov["source"].astype(str).str.startswith("BIS")]
        for r in bis_rows.itertuples(index=False):
            key, n = str(r.key), r.country
            cpi = report.indicators.at["5.5", n] if "5.5" in report.indicators.index and n in report.indicators.columns else None
            vals, _ = imf_transforms(imf, iso_of.get(n), cpi)
            if key not in vals:
                continue
            bis = float(pd.to_numeric(r.value, errors="coerce"))
            bad, reason = disagreement(key, bis, vals[key])
            rows.append({"table": "Inputs", "key": key, "country": n, "check": "bis_imf_cross",
                         "status": "hold" if bad else "ok", "reason": reason, "live": bis,
                         "basis": "precedence BIS > IMF (official.precedence)"})
    out = pd.DataFrame(rows, columns=CHECK_COLUMNS)
    from .central_banks import cb_gate_checks          # EQ-A-0050: national series (unverified / range / stale / cb_cross)
    cb = cb_gate_checks(u, report, ref, data_dir)
    return pd.concat([out, cb], ignore_index=True) if len(cb) else out
