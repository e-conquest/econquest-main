"""Team A reader of `econquest dsa` scorecard rows (EQ-A-0096; contract HO-20261024-A-B-007, EQ-B-0078).

`econquest dsa` (engine/dsa.py, Team B) writes outputs/dsa_scorecard_feeds.csv: one proposed Inputs cell per
(key, country) with `derived_from` (live / mixed / estimate), `inputs` ('<source>:<series> <period>; ...') and
`vintage_id` (the data/live vintage whose raw files the DSA read; '' = not replayable). The DSA never writes data/;
this module is the "Team A follow-up" the contract names: it turns those rows into a feed for fetch_all / the gate.

    live      served as feed `dsa`, provenance source DSA_LABEL ('econquest dsa (derived from live)')
    mixed     served and held by the gate (check `dsa_mixed`): an analyst estimate or profile seed is an input
    estimate  not served (unserved row with the reason)

Ids: DSA_KEYS. Only 1.2 (FX debt service due in 24 months, % of reserves: IDS DT.TDS.DPPG.CD next two complete
projection years / WDI FI.RES.TOTL.CD, Team B's method in engine/dsa.ppg_debt_service_detail) can be `live`; 1.1
always has the analyst average maturity (mixed) and 2.1 the ARA components (mixed / estimate), so they are read but
never released by this feed. The rulebook names this source for 1.2 ("World Bank IDS API (DT.TDS.DPPG.CD) + IMF
IRFCL"). Precedence for 1.2: IMF SDMX IRFCL (official.imf, unconfigured today) first, then this feed.

Gate (dsa_gate_rows), on top of feeds.quality_gate's own checks:
    dsa_mixed   derived_from is mixed
    unverified  a live input series not in DSA_VERIFIED_INPUTS (codes confirmed on a pull)
    replay      vintage_id is '' or differs from the vintage being gated (the value would not be point in time)
    range       outside DSA_RANGES
    stale       a dated input older than stale_years before the gate year (reserves); debt-service years must be
                after the DSA base year (they are projections by construction)
    dsa_reseed  (dsa_reseed_rows, added by official.dsa_regate) the seed itself was written by the old `dsa --apply`
                and the new value moves it by more than 25% (F8: Pakistan / Argentina 1.2 from the doubled IDS rows)

DSA_VERIFIED_INPUTS evidence: Sam's 0.4.2 pull (team/inbox/pull-20261025T013150Z/raw_worldbank.csv, World
counterpart fix EQ-A-0068): DT.TDS.DPPG.CD 360 rows, 60 countries, one row per country and year (no duplicate, no
negative, no blank), years 2027-2032; FI.RES.TOTL.CD 510 rows, 85 countries, one row per country and year. Read
offline under EQ-A-0096; nothing was fetched from the cloud.

Licence: inputs are World Bank IDS / WDI (CC BY 4.0, per dataset UNVERIFIED); the register row econquest_derived
(source '^econquest ') applies, and an IMF / WEO input would be caught on the series by imf_derived. 1.2 has none.

Wiring: dsa is never a fetch_all feed (the DSA reads the vintage a fetch saved). official.dsa_regate re-gates that
vintage offline (pullpack step dsa_regate): official.wiring.country_cells calls dsa_cells after the IMF cells and
official.gate.gate_checks calls dsa_gate_rows, with dsa_vintage set to the vintage being re-gated."""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd

DSA_FEED = "dsa"
DSA_LABEL = "econquest dsa (derived from live)"
DSA_FILE = "dsa_scorecard_feeds.csv"
# contract columns (engine/dsa.FEED_COLUMNS, HO-20261024-A-B-007); read as text, never imported from the engine
DSA_COLUMNS = ("table", "key", "country", "value", "source", "series", "retrieved", "iso", "year0", "dsa_column",
               "derived_from", "inputs", "vintage_id")
DSA_KEYS = ("1.2", "1.1", "2.1")
DERIVED = ("live", "mixed", "estimate")
DSA_VERIFIED_INPUTS = {
    "wbgapi IDS:DT.TDS.DPPG.CD": "0.4.2 pull: 60 countries, one World row per country-year, 2027-2032 (EQ-A-0096)",
    "wbgapi WDI:FI.RES.TOTL.CD": "0.4.2 pull: 85 countries, one row per country-year (EQ-A-0096)",
}
DSA_RANGES = {"1.2": (0.0, 5000.0), "1.1": (0.0, 500.0), "2.1": (0.0, 1000.0)}
PRECEDENCE_12 = ("imf_sdmx", DSA_FEED)
DSA_RESEED_SOURCE = "econquest dsa"            # data/audit_trail.csv source of a value the old `dsa --apply` wrote
DSA_RESEED_REL = 0.25                          # F8: hold when the new value is more than 25% away from such a seed
_INPUT_RE = re.compile(r"^(?P<ref>[^:]+:[^\s(]+)(?:\s+(?P<period>\d{4}(?:-\d{4})?))?\s*(?P<note>\(.*\))?$")


def read_dsa_feeds(path: str | Path) -> pd.DataFrame:
    """The DSA scorecard file as text columns. ValueError when a contract column is missing (an older DSA build)."""
    df = pd.read_csv(path, dtype=str, keep_default_na=False)
    miss = [c for c in DSA_COLUMNS if c not in df.columns]
    if miss:
        raise ValueError(f"{path}: not a HO-20261024-A-B-007 DSA scorecard file, missing {', '.join(miss)}")
    return df


def parse_inputs(text: str) -> list[dict]:
    """'<source>:<series> <period>; ...' -> [{ref, period, note}]; an input with a bracket note is not live."""
    out = []
    for part in [p.strip() for p in str(text or "").split(";") if p.strip()]:
        m = _INPUT_RE.match(part)
        out.append({"ref": m["ref"] if m else part, "period": (m["period"] or "") if m else "",
                    "note": (m["note"] or "") if m else ""})
    return out


def _row(feeds: pd.DataFrame | None, key: str, country: str) -> pd.Series | None:
    if feeds is None or not len(feeds):
        return None
    r = feeds[(feeds["table"] == "Inputs") & (feeds["key"].astype(str) == key) & (feeds["country"] == country)]
    if len(r) != 1:
        return None
    return r.iloc[0]


def dsa_cells(feeds: pd.DataFrame | None, country: str, iso: str, have: pd.Series, filled: set,
              vintage_id: str | None, year: int, tlog: list, unserved: list) -> list[tuple]:
    """Cells this feed fills for one country, as (kind, key, value, source, series) for fetch_all's `put`. Only cells
    no earlier source filled (`have` finite or `filled`). `vintage_id` is the vintage being fetched or re-gated: a
    row from another vintage is not served (its inputs are not this pull's)."""
    if feeds is None:
        return []
    puts = []
    for key in DSA_KEYS:
        cur = have.get(key, np.nan)
        if key in filled or (cur is not None and np.isfinite(pd.to_numeric(cur, errors="coerce"))):
            continue
        r = _row(feeds, key, country)

        def gone(reason: str, key=key) -> None:
            unserved.append({"table": "Inputs", "key": key, "country": country, "iso": iso, "feed": DSA_FEED,
                             "reason": reason})
        if r is None:
            gone("no econquest dsa row (or more than one) for this country")
            continue
        v = float(pd.to_numeric(r["value"], errors="coerce"))
        how = str(r["derived_from"]).strip()
        if how not in DERIVED or not np.isfinite(v):
            gone(f"econquest dsa row unreadable (derived_from '{how}', value '{r['value']}')")
            continue
        if how == "estimate":
            gone("econquest dsa: derived_from estimate (no live input); not applied (HO-20261024-A-B-007)")
            continue
        vid = str(r["vintage_id"]).strip()
        if vintage_id is not None and vid and vid != vintage_id:
            gone(f"econquest dsa row is from vintage {vid}, this pull is {vintage_id}: rerun `econquest dsa` on it")
            continue
        note = "precedence " + " > ".join(PRECEDENCE_12) if key == "1.2" else "econquest dsa"
        from ..research.base import safe_text           # SEC-A-011 I3: a hand-passed --dsa file reaches provenance.csv
        series = (f"{safe_text(r['series'])} [derived_from {how}; inputs {r['inputs']}; dsa year0 {r['year0']}; "
                  f"vintage {vid or 'none'}] ({note})")
        puts.append(("indicator", key, v, DSA_LABEL, series))
        tlog.append({"iso": iso, "series": key, "year": year, "value": v, "fallback": np.nan, "jump": np.nan,
                     "sd_changes": np.nan, "rule": f"{note}: {DSA_FEED} used ({how})", "country": country})
        unserved[:] = [u for u in unserved if not (u.get("table") == "Inputs" and u.get("key") == key
                                                   and u.get("country") == country)]
    return puts


def dsa_gate_rows(key: str, country: str, value: float, series: str, feeds: pd.DataFrame | None,
                  vintage_id: str | None, year: int, stale_years: int = 3) -> list[dict]:
    """crosscheck.CHECK_COLUMNS hold rows for one cell this feed filled (module docstring)."""
    rows = []

    def hold(check: str, reason: str) -> None:
        rows.append({"table": "Inputs", "key": key, "country": country, "check": check, "status": "hold",
                     "reason": reason, "live": value, "basis": series})

    r = _row(feeds, key, country)
    if r is None:
        hold("replay", f"{key}: the econquest dsa row behind this cell is not in the file read by the gate")
        return rows
    how = str(r["derived_from"]).strip()
    if how == "mixed":
        hold("dsa_mixed", f"{key} from econquest dsa uses a non-live input ({r['inputs']}); review before apply")
    vid = str(r["vintage_id"]).strip()
    if not vid:
        hold("replay", f"{key} from econquest dsa has no vintage_id: not replayable (HO-20261024-A-B-007)")
    elif vintage_id is not None and vid != vintage_id:
        hold("replay", f"{key} from econquest dsa vintage {vid}, gated against {vintage_id}")
    year0 = pd.to_numeric(r["year0"], errors="coerce")
    for inp in parse_inputs(r["inputs"]):
        if inp["note"]:
            continue
        if inp["ref"] not in DSA_VERIFIED_INPUTS:
            hold("unverified", f"{key}: input {inp['ref']} not confirmed on a pull (dsa_feed.DSA_VERIFIED_INPUTS)")
        p = inp["period"]
        if not p:
            continue
        first, last = (int(x) for x in (p.split("-") + [p])[:2])
        if inp["ref"].endswith(":DT.TDS.DPPG.CD"):
            if np.isfinite(year0) and first <= int(year0):
                hold("stale", f"{key}: debt-service years {p} are not after the DSA base year {int(year0)}")
        elif last < year - stale_years:
            hold("stale", f"{key}: {inp['ref']} period {p} (limit {stale_years} years before {year})")
    lo, hi = DSA_RANGES.get(key, (-np.inf, np.inf))
    if np.isfinite(value) and not lo <= value <= hi:
        hold("range", f"{value:.4g} outside the plausibility bounds [{lo:g}, {hi:g}] for {key}")
    return rows


def dsa_reseed_rows(data_dir: str | Path | None, cells, rel: float = DSA_RESEED_REL) -> list[dict]:
    """F8 guard (EQ-A-0096, AGENT-08 decision 3): CHECK_COLUMNS hold rows, check `dsa_reseed`, for dsa cells whose
    seed was itself written by econquest dsa. `cells`: (key, country, seed, live) tuples. A cell is held when the
    latest data/audit_trail.csv row for (Inputs, key, country) has source DSA_RESEED_SOURCE and origin 'live feed'
    (the value the old `dsa --apply` wrote into the seed, e.g. the 2026-10-23 1.2 values for Pakistan 131.4 and
    Argentina 72.6, built on the doubled IDS rows) and |live - seed| > rel x |seed|. A seed the gate kept ('seed kept')
    or an analyst seed is not a dsa value and is left to the usual change check. Never releases anything; no
    audit_trail.csv (or no data_dir) means no row."""
    p = Path(data_dir) / "audit_trail.csv" if data_dir is not None else None
    if p is None or not p.is_file():
        return []
    a = pd.read_csv(p, dtype=str, keep_default_na=False)
    if not {"table", "key", "country", "source", "origin"} <= set(a.columns):
        return []
    a = a[a["table"] == "Inputs"]
    last = {(str(r.key), r.country): r for r in a.itertuples(index=False)}     # file order: the last row is the latest
    rows = []
    for key, country, seed, live in cells:
        r = last.get((str(key), country))
        seed, live = float(pd.to_numeric(seed, errors="coerce")), float(pd.to_numeric(live, errors="coerce"))
        if (r is None or str(r.source).strip() != DSA_RESEED_SOURCE or not str(r.origin).startswith("live feed")
                or not (np.isfinite(seed) and np.isfinite(live)) or seed == 0):
            continue
        move = (live - seed) / abs(seed)
        if abs(move) > rel:
            rows.append({"table": "Inputs", "key": str(key), "country": country, "check": "dsa_reseed", "status": "hold",
                         "reason": (f"seed {seed:.4g} was written by econquest dsa ({getattr(r, 'retrieved', '') or 'undated'}, "
                                    f"data/audit_trail.csv); new value {live:.4g} is {move * 100:+.1f}% away (limit "
                                    f"{rel * 100:.0f}%): Sam reviews before apply (F8), never auto-applied"),
                         "live": live, "basis": "data/audit_trail.csv"})
    return rows


def summary(feeds: pd.DataFrame, names: list[str] | None = None) -> pd.DataFrame:
    """Per key: rows by derived_from (for the runbook and the Mac check)."""
    f = feeds if names is None else feeds[feeds["country"].isin(names)]
    return (f.groupby(["key", "derived_from"]).size().unstack(fill_value=0)
            .reindex(columns=list(DERIVED), fill_value=0))


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.official.dsa_feed",
                                 description="What the dsa feed would serve from an econquest dsa scorecard file")
    ap.add_argument("--file", default=f"outputs/{DSA_FILE}")
    ap.add_argument("--vintage", default=None, help="vintage id being gated (default: accept the file's own)")
    ap.add_argument("--year", type=int, required=True, help="as_of year")
    a = ap.parse_args(argv)
    f = read_dsa_feeds(a.file)
    print(summary(f).to_string())
    for r in f.itertuples(index=False):
        if r.key not in DSA_KEYS or r.derived_from == "estimate":
            continue
        v = float(pd.to_numeric(r.value, errors="coerce"))
        holds = [h["check"] for h in dsa_gate_rows(r.key, r.country, v, "", f, a.vintage, a.year)]
        print(f"{r.key:4s} {r.country:22s} {v:10.4f} {r.derived_from:8s} {', '.join(holds) or 'served'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
