"""theratesapi.com: fx3m for VES, NGN, PKR, VND and ZMW (EQ-A-0073, Sam 2026-10-24 20:32Z / 20:33Z / 20:37Z).

Why: BIS WS_XRU and the ECB reference rates have no series for these five desk currencies and none is a hard peg, so
before this adapter their fx3m came only from hand-entered rows (data/fx_manual.csv, EQ-A-0072). Sam chose Banca
d'Italia's daily rates (20:32Z), as internal research only under governance exception EXC-005 (20:33Z), and then to
read them through theratesapi.com instead of Banca d'Italia's own API (20:37Z).

What theratesapi.com is (its homepage, read 2026-10-24): a free, keyless JSON mirror of the ECB euro reference rates
(29 currencies) and Banca d'Italia's daily rates against the euro (121 more); the ECB figure is used where both publish.
Rates for any other base are CALCULATED by the mirror from those per-EUR figures and rounded to 6 decimals. So a
`base=USD` answer is (Banca d'Italia CCY per EUR) / (USD per EUR), computed by the mirror, not a rate either bank
publishes against the dollar. Its terms page says "as is", information only, no licence or attribution text.

    GET https://theratesapi.com/api/{YYYY-MM-DD|latest}?base=USD&symbols=VES,NGN,PKR,VND,ZMW
    -> {"date": "2026-10-23", "base": "USD", "rates": {"VES": 885.1193, ...}}

A weekend or holiday date answers with the previous working day's rates, so the fetch asks for every weekday in
THERATES_DAYS calendar days and keeps one row per returned `date` (dedupe; never a filled day).

Checks (a failed check refuses the answer, it is never repaired):
  * https only, host THERATES_HOST only, redirects refused, body capped (sources.https_get), retries on timeouts /
    429 / 5xx and fail-fast on proxy refusal or DNS failure (feeds._with_retries / feeds._stop_if_unreachable)
  * `base` must be USD: rates are units of the currency per 1 USD, as BIS publishes them. A response with another
    base is refused, never inverted or crossed here
  * the returned `date` must be a real date, not after the requested date and at most THERATES_MAX_LAG days before it
  * a rate must be a positive finite number; a currency missing from an answer has no row that day

Licence: every raw row carries THERATES_LICENCE ("internal research use only", EXC-005), so audit.client_output_reason
keeps the values out of client output; the source string names theratesapi.com, which audit recognises as well. The
licence carries no "personal" / "non-commercial" term, so audit.restricted_reason does not bar the values from desk
numbers (same split as the IMF, EXC-003).

Probe (run on the Mac; the cloud cannot reach the host):

    python -m econquest.ingestion.official.theratesapi --probe

UNVERIFIED until the first Mac pull: that every one of the five currencies is present on most business days (Banca
d'Italia can suspend a rate), and whether the mirror repeats an old rate on a day Banca d'Italia did not publish one.
fx3m is refused when the latest rate has not changed for THERATES_MAX_FLAT_RUN observations (a carried-forward rate
would look like that)."""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import math
import os
import sys
import tempfile
import time
import urllib.error
import urllib.parse
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable

import numpy as np
import pandas as pd

from .. import feeds as F
from ..sources import https_get

THERATES_FEED = "theratesapi_fx"                    # feeds.fetch_all name; raw table raw_theratesapi_fx.csv
THERATES_RESPONSES = f"{THERATES_FEED}_responses"   # raw_theratesapi_fx_responses.csv: every response body as received
THERATES_HOST = "theratesapi.com"
THERATES_BASE = f"https://{THERATES_HOST}/api"
THERATES_AGAINST = "USD"
# EQ-A-0073: on by default for exactly these currencies (BIS, ECB and the pegs have nothing for them). A currency is
# used only when BIS, ECB and HARD_PEGS give nothing (feeds.official_fx_transforms), so adding one here never
# overrides an official series.
THERATES_CURRENCIES = ("VES", "NGN", "PKR", "VND", "ZMW")
# Calendar days of weekdays asked for. fx3m needs more than 70 observations and one at least 91 days before the latest:
# 100 calendar days is about 71 weekdays, one TARGET holiday short of the limit, so 110 (about 78 weekdays).
THERATES_DAYS = 110
THERATES_MAX_LAG = 7                # days the returned date may lag the requested date (Easter: Thu -> Mon is 4)
THERATES_MAX_FLAT_RUN = 10          # latest rate unchanged for this many observations: fx3m refused (carried forward?)
THERATES_MAX_BYTES = 1024 * 1024    # an answer for 5 symbols is ~150 bytes
THERATES_REQUESTS_PER_SECOND = 4.0  # SEC-A-009 L2: every fetch is throttled (the service asks for restraint)
THERATES_MAX_CONSECUTIVE_FAILURES = 10   # failed dates in a row (5xx, transport, refused; not 4xx) end the fetch
THERATES_SOURCE = "theratesapi.com (mirror of Banca d'Italia/ECB reference rates)"
THERATES_LICENCE = ("theratesapi.com mirror of Banca d'Italia rates: internal research use only "
                    "(EXC-005; client output restricted; mirror terms unverified)")
RAW_COLUMNS = [*F.LONG_COLUMNS, "sdmx_key", "licence", "requested_date", "response_sha256"]
# body: the answer as received, with a formula prefix (= + - @ TAB CR) neutralised by a leading apostrophe
# (ledger._neutralise, SEC-A-009 L3); sha256 is of the bytes as received. from_cache / fetched_utc: SEC-A-009 L1.
RESPONSE_COLUMNS = ["requested_date", "returned_date", "base", "sha256", "body", "from_cache", "fetched_utc"]


class RefusedAnswer(F.FeedError):
    """A response that fails a check (wrong base, bad date, bad rate): the whole answer is refused."""


def _date(text) -> dt.date | None:
    try:
        return dt.date.fromisoformat(str(text).strip())
    except (TypeError, ValueError):
        return None


def parse_response(body: str | bytes, currencies: Iterable[str], requested: dt.date | None = None,
                   against: str = THERATES_AGAINST) -> tuple[str, list[dict]]:
    """One theratesapi.com JSON answer -> (returned date, raw rows) for `currencies`. Rows: iso '' (rates are
    currency-level, as the ECB rows), series '<CCY>_PER_USD', period = the returned `date`, value = units of the
    currency per 1 `against`. Raises RefusedAnswer when the answer is not JSON with date / base / rates, when base is
    not `against` (never inverted), when the date is unreadable, after `requested` or more than THERATES_MAX_LAG days
    before it, or when a requested currency's rate is not a positive finite number."""
    try:                     # SEC-A-009 M1: UnicodeDecodeError (a ValueError) and RecursionError are a refused answer
        if isinstance(body, bytes):
            body = body.decode("utf-8-sig")
        doc = json.loads(body)
    except (ValueError, RecursionError) as e:
        raise RefusedAnswer(f"theratesapi.com: answer is not UTF-8 JSON ({type(e).__name__}: "
                            f"{str(body)[:60]!r})") from None
    if not isinstance(doc, dict) or not {"date", "base", "rates"} <= set(doc) or not isinstance(doc["rates"], dict):
        raise RefusedAnswer(f"theratesapi.com: answer without date / base / rates (keys {sorted(doc)[:6] if isinstance(doc, dict) else type(doc).__name__})")
    base = str(doc["base"]).strip().upper()
    if base != against.upper():
        raise RefusedAnswer(f"theratesapi.com: base {doc['base']!r}, asked {against}: refused (rates must be units of "
                            f"the currency per 1 {against}; nothing is inverted)")
    day = _date(doc["date"])
    if day is None:
        raise RefusedAnswer(f"theratesapi.com: unreadable date {doc['date']!r}")
    if requested is not None:
        if day > requested:
            raise RefusedAnswer(f"theratesapi.com: asked {requested}, answer dated {day} (later): refused")
        if (requested - day).days > THERATES_MAX_LAG:
            raise RefusedAnswer(f"theratesapi.com: asked {requested}, answer dated {day} "
                                f"(more than {THERATES_MAX_LAG} days earlier): refused")
    rows = []
    for ccy in dict.fromkeys(c.upper() for c in currencies):
        if ccy not in doc["rates"]:
            continue                                    # not published that day: no row, never filled
        v = doc["rates"][ccy]
        if isinstance(v, bool) or not isinstance(v, (int, float, str)):
            raise RefusedAnswer(f"theratesapi.com {day}: {ccy} rate {v!r} is not a number")
        try:
            x = float(v)
        except (ValueError, OverflowError):                 # SEC-A-009 M1: a 400-digit integer overflows float()
            raise RefusedAnswer(f"theratesapi.com {day}: {ccy} rate {str(v)[:40]!r} is not a number") from None
        if not math.isfinite(x) or x <= 0:
            raise RefusedAnswer(f"theratesapi.com {day}: {ccy} rate {v!r} is not a positive number")
        rows.append({"iso": "", "series": f"{ccy}{F.FX_PER_USD_SUFFIX}", "period": day.isoformat(), "value": x,
                     "sdmx_key": f"theratesapi.com /api/{day.isoformat()}?base={against} {ccy}",
                     "licence": THERATES_LICENCE})
    return day.isoformat(), rows


def business_dates(today: dt.date, days: int = THERATES_DAYS) -> list[dt.date]:
    """Weekdays from `days` calendar days before `today` to `today`, oldest first."""
    start = today - dt.timedelta(days=int(days))
    return [start + dt.timedelta(days=i) for i in range((today - start).days + 1)
            if (start + dt.timedelta(days=i)).weekday() < 5]


@dataclass
class TheRatesApiFeed:
    """theratesapi.com, one request per business date for all currencies at once (see the module docstring)."""
    base: str = THERATES_BASE
    timeout: float = 20.0
    retries: int = 3
    backoff: float = 2.0
    sleep: Callable[[float], None] | None = None
    max_bytes: int = THERATES_MAX_BYTES
    against: str = THERATES_AGAINST

    def url(self, day: dt.date | str, currencies: Iterable[str]) -> str:
        path = day if day == "latest" else dt.date.fromisoformat(str(day)).isoformat()
        q = urllib.parse.urlencode({"base": self.against, "symbols": ",".join(currencies)}, safe=",")
        url = f"{self.base}/{path}?{q}"
        parts = urllib.parse.urlsplit(url)
        if parts.scheme != "https" or parts.hostname != THERATES_HOST:      # host allow-list: this one host only
            raise ValueError(f"theratesapi base must be https://{THERATES_HOST}/...: {self.base!r}")
        return url

    def _get(self, url: str) -> bytes:
        # fixed https base on the allow-listed host; redirects refused, body capped (SEC-A-006 L1)
        return https_get(url, {"User-Agent": "econquest/0.2", "Accept": "application/json"}, timeout=self.timeout,
                         max_bytes=self.max_bytes)

    def get(self, day: dt.date | str, currencies: Iterable[str]) -> bytes:
        """One answer, with feeds' retry rule; a proxy refusal, DNS failure or redirect raises FeedUnreachable."""
        url = self.url(day, list(currencies))
        try:
            return F._with_retries(lambda: self._get(url), retries=self.retries, backoff=self.backoff, sleep=self.sleep)
        except Exception as e:  # noqa: BLE001 - classified, then re-raised as it was
            F._stop_if_unreachable(e, THERATES_HOST)
            raise

    def fetch(self, currencies: Iterable[str] | None = None, days: int | None = None,
              today: dt.date | None = None, min_interval: float | None = None) -> pd.DataFrame:
        """Rates per USD for `currencies` (default THERATES_CURRENCIES) on every weekday of the last `days` (default
        THERATES_DAYS) calendar days: fetch_dates over business_dates(today, days), throttled to
        THERATES_REQUESTS_PER_SECOND unless `min_interval` says otherwise (SEC-A-009 L2)."""
        today = today or dt.datetime.now(dt.timezone.utc).date()
        gap = 1.0 / THERATES_REQUESTS_PER_SECOND if min_interval is None else min_interval
        return self.fetch_dates(business_dates(today, days or THERATES_DAYS), currencies, min_interval=gap, today=today)

    def fetch_dates(self, dates: Iterable[dt.date], currencies: Iterable[str] | None = None,
                    cache_dir: Path | None = None, min_interval: float = 0.0,
                    clock: Callable[[], float] | None = None, log: Callable[[str], None] | None = None,
                    today: dt.date | None = None) -> pd.DataFrame:
        """One request per date in `dates` for all `currencies`; one row per currency and RETURNED date (a weekend or
        holiday answer repeating the previous working day is dropped: dedupe on `date`). Returns RAW_COLUMNS;
        attrs["responses"] is every response body as received (RESPONSE_COLUMNS), attrs["missing"] the currencies
        with no row, attrs["failures"] what went wrong, attrs["requests"] / attrs["cached"] the counts.

        `cache_dir` (EQ-A-0073 history pull): each answer that passed parse_response is also written there as
        <requested date>.json, and a later call reuses it instead of asking again, so an interrupted pull resumes.
        Refused or failed answers are never cached, and neither is an answer dated before the requested date while
        that date is within THERATES_MAX_LAG days of `today` (default today UTC): the day's own rate may not be
        published yet (SEC-A-009 L1). `min_interval` seconds are kept between network requests (throttle; cache
        hits are not throttled). Any error on one date (transport, refused answer, anything unexpected) is recorded
        in failures and the next date is tried (SEC-A-009 M1); THERATES_MAX_CONSECUTIVE_FAILURES in a row end the
        fetch. FeedUnreachable ends the fetch at once (the cache keeps what came back); FeedError when no row came
        back."""
        want = [c for c in dict.fromkeys(str(c).strip().upper() for c in (currencies or THERATES_CURRENCIES))
                if len(c) == 3 and c.isalpha() and c != self.against]
        if not want:
            raise F.FeedError("theratesapi.com: no currency to fetch")
        rows: list[dict] = []
        responses: list[dict] = []
        failures: list[str] = []
        seen: set[str] = set()
        n_net = n_cache = 0
        streak = 0
        last = None
        sleep = self.sleep or time.sleep
        clock = clock or time.monotonic
        today = today or dt.datetime.now(dt.timezone.utc).date()
        for day in sorted(set(dates)):
            if streak >= THERATES_MAX_CONSECUTIVE_FAILURES:
                failures.append(f"theratesapi.com: {streak} dates in a row failed; stopped before {day} "
                                "(answers already received are kept)")
                break
            hit = _cached(cache_dir, day, want, self.against) if cache_dir is not None else None
            fetched = ""
            if hit is not None:
                body, fetched = hit
                n_cache += 1
            else:
                if last is not None and min_interval > 0:
                    wait = last + min_interval - clock()
                    if wait > 0:
                        sleep(wait)
                last = clock()
                n_net += 1
                if log and n_net % 100 == 0:
                    log(f"  theratesapi.com: {n_net} requests ({n_cache} from the cache), at {day}")
                try:
                    body = self.get(day, want)
                except F.FeedUnreachable:
                    raise
                except urllib.error.HTTPError as e:      # a 4xx is an answer about this date; 5xx counts
                    failures.append(f"theratesapi.com {day}: HTTP {e.code}")
                    streak += 1 if e.code >= 500 or e.code == 429 else 0
                    continue
                except Exception as e:  # noqa: BLE001
                    failures.append(f"theratesapi.com {day}: {type(e).__name__}: {F._one_line(e, 100)}")
                    streak += 1; continue
                fetched = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            sha = hashlib.sha256(body).hexdigest()
            rec = {"requested_date": day.isoformat(), "returned_date": "", "base": "", "sha256": sha,
                   "body": body.decode("utf-8", errors="replace"), "from_cache": hit is not None, "fetched_utc": fetched}
            responses.append(rec)
            try:
                got_day, got = parse_response(body, want, requested=day, against=self.against)
            except Exception as e:  # noqa: BLE001 - SEC-A-009 M1: one bad answer costs only its date
                failures.append(f"theratesapi.com {day}: refused: {F._one_line(e, 200)}"); streak += 1; continue
            streak = 0
            rec.update(returned_date=got_day, base=self.against)
            settled = got_day == day.isoformat() or (today - day).days > THERATES_MAX_LAG
            if cache_dir is not None and hit is None and settled:      # SEC-A-009 L1
                _cache_put(cache_dir, day, want, self.against, body)
            if got_day in seen:
                continue                                 # weekend / holiday: the previous working day again
            seen.add(got_day)
            rows += [dict(r, requested_date=day.isoformat(), response_sha256=sha) for r in got]
        out = pd.DataFrame(rows, columns=[c for c in RAW_COLUMNS if c != "source"])
        out.insert(4, "source", THERATES_SOURCE)
        out = out[RAW_COLUMNS].sort_values(["series", "period"]).reset_index(drop=True)
        if out.empty:
            raise F.FeedError("theratesapi.com returned no rate: " + "; ".join(failures[:3]))
        have = {s[:-len(F.FX_PER_USD_SUFFIX)] for s in out["series"].unique()}
        missing = sorted(c for c in want if c not in have)
        if missing:
            failures.append(f"theratesapi.com: no rate for {', '.join(missing)}")
        out.attrs.update(missing=missing, failures=failures, requests=n_net, cached=n_cache,
                         responses=pd.DataFrame(responses, columns=RESPONSE_COLUMNS))
        return out


# ---------------------------------------------------------------------------------------------- response cache
def _cache_file(cache_dir: Path, day: dt.date) -> Path:
    return Path(cache_dir) / f"{day.isoformat()}.json"


def _cached(cache_dir: Path, day: dt.date, want: list[str], against: str) -> tuple[bytes, str] | None:
    """The cached body for `day` when it was asked with the same base and at least `want`'s symbols and its sha256
    still matches, else None (asked again)."""
    p = _cache_file(cache_dir, day)
    if not p.is_file() or p.is_symlink():
        return None
    try:
        rec = json.loads(p.read_text(encoding="utf-8"))
        body = str(rec["body"]).encode("utf-8")
    except (OSError, ValueError, KeyError, TypeError):
        return None
    if (rec.get("base") != against or not set(want) <= set(rec.get("symbols") or [])
            or rec.get("sha256") != hashlib.sha256(body).hexdigest()):
        return None
    return body, str(rec.get("fetched_utc", ""))


def _cache_put(cache_dir: Path, day: dt.date, want: list[str], against: str, body: bytes) -> None:
    d = Path(cache_dir)
    d.mkdir(parents=True, exist_ok=True)
    rec = {"requested_date": day.isoformat(), "base": against, "symbols": sorted(want),
           "fetched_utc": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
           "sha256": hashlib.sha256(body).hexdigest(), "body": body.decode("utf-8")}
    fd, tmp = tempfile.mkstemp(dir=d, prefix=f".{day.isoformat()}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(rec, f, sort_keys=True)
        os.replace(tmp, _cache_file(d, day))
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


def responses_frame(raw: pd.DataFrame | None) -> pd.DataFrame:
    """The response bodies a fetch kept (RESPONSE_COLUMNS), ready for CSV: text cells starting with a formula prefix
    are neutralised (ledger._neutralise, SEC-A-009 L3). Empty when none."""
    from ..ledger import _neutralise
    r = raw.attrs.get("responses") if raw is not None else None
    if not isinstance(r, pd.DataFrame):
        return pd.DataFrame(columns=RESPONSE_COLUMNS)
    out = r.copy()
    for c in ("body", "returned_date", "base"):
        if c in out.columns:
            out[c] = out[c].map(_neutralise)
    return out


def _flat_run(s: pd.Series) -> int:
    """How many of the last observations equal the latest one."""
    v = s.to_numpy(dtype=float)
    n = 1
    while n < len(v) and v[-1 - n] == v[-1]:
        n += 1
    return n


def theratesapi_fx_transforms(raw: pd.DataFrame | None, ccy: str,
                              as_of: pd.Timestamp | None = None) -> tuple[dict, str, str, str]:
    """({'fx3m': value} or {}, source, series, reason-if-empty) for one currency from raw_theratesapi_fx rows, with the
    shared definition feeds.fx3m (more than 70 observations, one at least 91 days before the latest). Too few
    observations, none far enough back, or a latest rate unchanged for THERATES_MAX_FLAT_RUN observations: {} and the
    reason. Never forward-filled: a day the mirror did not publish has no row."""
    s = F.fx_usd_series(raw, ccy)
    if not len(s):
        return {}, "", "", f"theratesapi.com returned no {ccy}/USD rate (fx3m stays empty)"
    first, last = s.index[0], s.index[-1]
    v = F.fx3m(s, as_of)
    if not np.isfinite(v):
        return {}, "", "", (f"theratesapi.com {ccy}/USD: {len(s)} observations {first} -> {last}; fx3m needs more than "
                            f"70 and one at least 91 days before the latest (fx3m stays empty; nothing forward-filled)")
    run = _flat_run(s)
    if run >= THERATES_MAX_FLAT_RUN:
        return {}, "", "", (f"theratesapi.com {ccy}/USD: the latest rate {s.iloc[-1]:g} is unchanged over the last {run} "
                            f"observations (to {last}); possibly carried forward, fx3m refused (fx3m stays empty)")
    series = (f"theratesapi.com /api/<date>?base=USD&symbols={ccy}: {ccy} per 1 USD (mirror cross of Banca d'Italia "
              f"{ccy}/EUR and EUR/USD), {len(s)} business days {first} -> {last}")
    return {"fx3m": v}, THERATES_SOURCE, series, ""


# ---------------------------------------------------------------------------------------------- probe (Mac)
def probe(currencies: Iterable[str] = THERATES_CURRENCIES, feed: TheRatesApiFeed | None = None,
          out: Callable[[str], None] = print) -> int:
    """One GET of /api/latest for `currencies` against USD; prints each per-USD rate and the date. 0 when every
    currency came back, 2 when some are missing, 1 when the request or the answer failed."""
    feed = feed or TheRatesApiFeed(retries=0)
    want = list(currencies)
    try:
        body = feed.get("latest", want)
    except Exception as e:  # noqa: BLE001 - one line for the operator
        out(f"theratesapi probe: request failed: {type(e).__name__}: {F._one_line(e, 200)}")
        return 1
    out(f"theratesapi probe: {feed.url('latest', want)}")
    out(f"  raw answer ({len(body)} bytes, sha256 {hashlib.sha256(body).hexdigest()[:16]}): "
        f"{F._one_line(body.decode('utf-8', errors='replace'), 400)}")
    try:
        day, rows = parse_response(body, want, against=feed.against)
    except F.FeedError as e:
        out(f"  REFUSED: {e}")
        return 1
    got = {r["series"][:-len(F.FX_PER_USD_SUFFIX)]: r["value"] for r in rows}
    out(f"  date {day}, base {feed.against} (units of the currency per 1 {feed.against})")
    for c in want:
        out(f"  {c}: {got[c]:,.10g} per USD" if c in got else f"  {c}: MISSING from the answer")
    missing = [c for c in want if c not in got]
    return 2 if missing else 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.official.theratesapi",
                                 description="theratesapi.com FX adapter (EQ-A-0073)")
    ap.add_argument("--probe", action="store_true", help="fetch /api/latest once and print the per-USD rates")
    ap.add_argument("--currencies", default=",".join(THERATES_CURRENCIES), help="comma-separated ISO 4217 codes")
    a = ap.parse_args(argv)
    if not a.probe:
        ap.print_help()
        return 0
    return probe([c.strip().upper() for c in a.currencies.split(",") if c.strip()])


if __name__ == "__main__":
    sys.exit(main())
