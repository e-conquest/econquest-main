"""1.5 foreign-currency share of government debt from IDS external public debt (EQ-A-0096, coverage part 4).

The map's documented fallback for 1.5 (data/panel/coverage_source_map.csv: "fallback IDS PPG external debt / WEO
GGXWDG") for the names Eurostat and OECD do not serve (the 13 IDS desk names; OECD returned no value for any desk
name on the 0.4.2 pull):

    1.5 = DT.DOD.DPPG.CD (IDS public and publicly guaranteed external debt stock, US$, World counterpart)
          / (WEO GGXWDG_NGDP / 100 x NGDPD x 1e9) x 100,  both for the same year Y,
    Y = the latest year <= the as_of year that both have (IDS debt stocks are actuals; WEO years after the last IDS
    year are never paired with an older stock).

A proxy, not the rulebook measure: external debt is not the same as foreign-currency debt (local-currency bonds held
by non-residents are external; FX bonds held by residents are domestic), PPG includes publicly guaranteed debt of
public corporations that WEO general-government debt may not, and the two sources revalue differently. So:
    method      held until Team B approves (METHOD_APPROVED; approved with changes, HO-20261025-A-B-008, section 18)
    seed        a first value more than SEED_DIVERGENCE_PP points from the indicators.csv value (section 18)
    tier1       every first value (ARCH-A-PI10 R3): the first values are a parked Tier 1 data batch
    unverified  held until coverage_source_map.csv marks 1.5 verified=yes (DT.DOD.DPPG.CD is UNVERIFIED: not in
                any pull uploaded so far; Mac probe: `python -m econquest.ingestion.official.ids_fc_debt probe`)
    range       a ratio above 100 (external PPG larger than all government debt) or below 0 is held
    stale       Y more than IDS_FC_STALE_YEARS before the as_of year
Values derived from WEO are IMF data: the provenance series names WEO, so audit.client_output_reason restricts them
for client output (imf_derived register row).

Precedence for 1.5: Eurostat, then OECD (official.wiring.FC_DEBT_ORDER), then this feed.

Wiring (feeds.py held by EQ-A-0100; listed in docs/runbooks/A-coverage-60.md section 10): feed `ids_fc_debt` in
the `worldbank` alias and FEED_HOSTS (api.worldbank.org), official.wiring.fetch_plan entry IdsFcDebtFeed().fetch,
ids_fc_cells after the Eurostat / OECD block of country_cells, ids_fc_gate_rows in official.gate.gate_checks."""
from __future__ import annotations

import argparse
import datetime as dt
import sys
from dataclasses import dataclass
from typing import Callable, Iterable

import numpy as np
import pandas as pd

from .. import feeds as F

IDS_FC_FEED = "ids_fc_debt"
IDS_FC_LABEL = "wbgapi World Bank API v2 (IDS external public debt, EQ-A-0096)"
PPG_STOCK = "DT.DOD.DPPG.CD"          # UNVERIFIED code (IDS, source 6): not in an uploaded pull yet
IDS_DB = 6
WEO_DEBT, WEO_GDP = "GGXWDG_NGDP", "NGDPD"
IDS_FC_YEARS = 10                     # history requested, ending in the as_of year
IDS_FC_STALE_YEARS = 3                # as the World Bank rule of official.gate
IDS_FC_RANGE = (0.0, 100.0)
# Team B approval of the proxy: HO-20261025-A-B-008, approved with changes (docs/validation/indicator-rules.md section
# 18, EQ-B-0104), built under EQ-A-0106. Every cell is still held while DT.DOD.DPPG.CD is UNVERIFIED ('unverified'),
# and a first value far from the seed is held for Team B ('seed'). The first values that replace seeds are a parked
# Tier 1 data batch (Sam, after the MVP).
METHOD_APPROVED: frozenset = frozenset({"1.5"})
SEED_DIVERGENCE_PP = 20.0             # section 18 change 3: |first proxy value - indicators.csv value| above this is held
SEED_REASON = "1.5 proxy vs seed"
# ARCH-A-PI10 R3 (EQ-A-0117): a first value within 20 points still moves PDs, so every first value is held as part of
# the parked Tier 1 data batch (indicator-rules 18 'Tier'; first-mac-pass D2), not only the far ones.
TIER1_REASON = "Tier 1: Sam sign-off (parked): 1.5 first value"   # same start as the 1.8 CRAG Tier 1 hold (macpass_landing lists "Tier 1" holds)
RULE_TEXT = ("IDS PPG external debt / WEO general government gross debt, same year (proxy: external, not "
             "foreign-currency, debt)")


@dataclass
class IdsFcDebtFeed:
    """DT.DOD.DPPG.CD for the given ISO3s from IDS (World counterpart; feeds._wb_history_frame), IDS_FC_YEARS years
    ending at `end`. Returns feeds.LONG_COLUMNS rows; attrs["failures"]. FeedUnreachable on a proxy refusal or DNS
    failure, FeedError when nothing came back."""
    end: int | None = None
    fetcher: Callable | None = None     # (code, start, end, isos, db) -> long frame; tests inject a stand-in

    def fetch(self, isos: Iterable[str]) -> pd.DataFrame:
        isos = [i for i in dict.fromkeys(isos) if isinstance(i, str) and i]
        end = int(self.end or dt.date.today().year)
        fetch_one = self.fetcher or F._wb_history_frame
        try:
            df = fetch_one(PPG_STOCK, end - IDS_FC_YEARS + 1, end, isos, IDS_DB)
        except Exception as e:  # noqa: BLE001 - one series: the failure is the feed's
            F._stop_if_unreachable(e, F.WB_HOST)
            raise F.FeedError(f"IDS {PPG_STOCK}: {type(e).__name__}: {str(e)[:160]}") from e
        if df is None or df.empty:
            raise F.FeedError(f"IDS {PPG_STOCK}: no rows")
        df = df[df["iso"].astype(str).isin(isos)][["iso", "series", "period", "value"]]
        out = F._long(df.to_dict("records"), IDS_FC_LABEL)
        out["period"] = out["period"].astype(int)
        out.attrs["failures"] = []
        return out


def _annual(raw: pd.DataFrame | None, iso: str, series: str) -> pd.Series:
    """Year -> value; ValueError on a year with two rows (per-creditor IDS rows must never be summed or picked)."""
    if raw is None or not len(raw):
        return pd.Series(dtype=float)
    s = raw[(raw["iso"] == iso) & (raw["series"] == series)]
    per = pd.to_numeric(s["period"].astype(str).str[:4], errors="coerce")
    v = pd.Series(pd.to_numeric(s["value"], errors="coerce").to_numpy(), index=per.to_numpy()).dropna()
    v = v[np.isfinite(v.index.to_numpy(dtype=float))]
    v.index = v.index.astype(int)
    if v.index.duplicated().any():
        raise ValueError(f"{series} {iso}: more than one row for year(s) {sorted(set(v.index[v.index.duplicated()]))}")
    return v.sort_index()


def ids_fc_transform(ids: pd.DataFrame | None, weo: pd.DataFrame | None, iso: str,
                     year: int) -> tuple[float | None, str, str, int | None]:
    """(value, series text, reason not served, year used) for 1.5 of one country, years <= `year` only."""
    try:
        stock = _annual(ids, iso, PPG_STOCK)
        debt, gdp = _annual(weo, iso, WEO_DEBT), _annual(weo, iso, WEO_GDP)
    except ValueError as e:
        return None, "", f"refused: {e}", None
    stock = stock[stock.index <= year]
    if not len(stock):
        return None, "", f"no IDS {PPG_STOCK} value (IDS covers low- and middle-income economies only)", None
    common = sorted(set(stock.index) & set(debt.index) & set(gdp.index))
    if not common:
        return None, "", f"no year with {PPG_STOCK}, WEO {WEO_DEBT} and {WEO_GDP} together", None
    y = common[-1]
    denom = debt[y] / 100.0 * gdp[y] * 1e9
    if not denom > 0:
        return None, "", f"WEO general government debt not positive in {y}", None
    v = float(stock[y] / denom * 100.0)
    text = (f"rule 1.5 IDS v1: proxy: IDS PPG external / WEO GG debt, year {y}; external, not foreign-currency "
            f"(IDS {PPG_STOCK} / (WEO {WEO_DEBT} x {WEO_GDP}))")         # section 18 change 7: cell note
    return v, text, "", y


def ids_fc_cells(raw: dict, country: str, iso: str, filled: set, have: pd.Series, year: int,
                 tlog: list, unserved: list) -> list[tuple]:
    """(kind, key, value, source, series) for 1.5 when neither Eurostat nor OECD filled it."""
    if IDS_FC_FEED not in raw:
        return []
    cur = have.get("1.5", np.nan)
    if "1.5" in filled or (cur is not None and np.isfinite(pd.to_numeric(cur, errors="coerce"))):
        return []
    v, text, why, _ = ids_fc_transform(raw[IDS_FC_FEED], raw.get("weo"), iso, year)
    if v is None:
        unserved.append({"table": "Inputs", "key": "1.5", "country": country, "iso": iso, "feed": IDS_FC_FEED,
                         "reason": why})
        return []
    note = f"precedence eurostat > oecd > {IDS_FC_FEED}: {IDS_FC_FEED} used as fallback"
    tlog.append({"iso": iso, "series": "1.5", "year": year, "value": v, "fallback": np.nan, "jump": np.nan,
                 "sd_changes": np.nan, "rule": note, "country": country})
    unserved[:] = [u for u in unserved if not (u.get("table") == "Inputs" and u.get("key") == "1.5"
                                               and u.get("country") == country)]
    return [("indicator", "1.5", v, IDS_FC_LABEL, f"{text} ({note})")]


def ids_fc_gate_rows(country: str, value: float, series: str, raw: dict, iso: str | None, year: int,
                     verified: set, seed: float | None = None, first: bool = True) -> list[dict]:
    """Hold rows (unverified, method, range, stale, seed) for one 1.5 cell this feed filled. `seed`: the current
    indicators.csv value; `first`: the applied value does not already come from this feed. A first value more than
    SEED_DIVERGENCE_PP from the seed is held for Team B review (indicator-rules 18, change 3); no seed, no check."""
    rows = []

    def hold(check: str, reason: str) -> None:
        rows.append({"table": "Inputs", "key": "1.5", "country": country, "check": check, "status": "hold",
                     "reason": reason, "live": value, "basis": series})

    if "1.5" not in verified:
        hold("unverified", f"1.5 from {IDS_FC_FEED}: {PPG_STOCK} not yet confirmed on a live pull "
                           "(coverage_source_map.csv verified is not yes)")
    if "1.5" not in METHOD_APPROVED:
        hold("method", f"1.5 from {IDS_FC_FEED}: external-debt proxy awaits Team B approval (EQ-A-0096 handoff)")
    lo, hi = IDS_FC_RANGE
    if np.isfinite(value) and not lo <= value <= hi:
        hold("range", f"{value:.4g} outside [{lo:g}, {hi:g}]: external PPG debt larger than government debt")
    if iso is not None:
        _, _, _, y = ids_fc_transform(raw.get(IDS_FC_FEED), raw.get("weo"), iso, year)
        if y is not None and y < year - IDS_FC_STALE_YEARS:
            hold("stale", f"1.5 year used {y} (limit {IDS_FC_STALE_YEARS} years before {year})")
    s = pd.to_numeric(seed, errors="coerce") if seed is not None else np.nan
    if first:                                  # ARCH-A-PI10 R3 (EQ-A-0117): every first value is a Tier 1 data batch
        hold("tier1", f"{TIER1_REASON} {value:.4g} replaces the seed"
                      + (f" {float(s):.4g}" if np.isfinite(s) else "") + "; released only by Sam's approval (D2)")
    if first and np.isfinite(value) and np.isfinite(s) and abs(value - s) > SEED_DIVERGENCE_PP:
        hold("seed", f"{SEED_REASON}: first value {value:.4g} differs from the current {float(s):.4g} by "
                     f"{abs(value - s):.3g} points (> {SEED_DIVERGENCE_PP:g}); the proxy measures external, not "
                     "foreign-currency, debt: Team B reviews (indicator-rules 18)")
    return rows


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.official.ids_fc_debt",
                                 description="1.5 IDS external-debt proxy (EQ-A-0096)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("probe", help="fetch DT.DOD.DPPG.CD for the desk names once and print what came back "
                                     "(network: Sam's Mac)")
    p.add_argument("--isos", default="VNM,PHL,CHN,IND,PAK,BLZ,BRA,ARG,COL,NGA,SEN,ZMB,ZWE")
    p.add_argument("--end", type=int, default=None)
    a = ap.parse_args(argv)
    isos = [i for i in a.isos.split(",") if i]
    try:
        out = IdsFcDebtFeed(end=a.end).fetch(isos)
    except F.FeedError as e:
        print(f"FAIL {e}")
        return 1
    dup = int(out.duplicated(["iso", "period"]).sum())
    print(f"{PPG_STOCK}: {len(out)} rows, {out['iso'].nunique()} of {len(isos)} countries, years "
          f"{out['period'].min()}-{out['period'].max()}, duplicate country-years {dup}")
    print(out.groupby("iso")["period"].agg(["min", "max", "count"]).to_string())
    return 0 if dup == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
