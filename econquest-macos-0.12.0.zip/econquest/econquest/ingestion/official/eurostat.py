"""Eurostat SDMX adapter (EQ-A-0049): 1.5 foreign-currency share of government debt for EU members.

Lower priority (6 EU members of the 88): better definitions, not coverage. Named feed only (`fetch --only eurostat`),
not in the default fetch, until its series are configured. Uses the SDMX 2.1 API in SDMX-CSV rather than JSON-stat,
so the shared parser (sdmx.parse_sdmx_csv) and its refusal rules apply unchanged.

UNVERIFIED: EUROSTAT_BASE (dissemination API, sdmx/2.1), format=SDMX-CSV, the `geo` area column and Eurostat's
country codes (ISO2 except Greece EL and the United Kingdom UK), and every series: no dataset id and key for
government debt by currency are known from here, so the specs are unconfigured (never requested) until the Mac
structure check fills them (docs/runbooks/A-fetch-on-mac.md, IMF/OECD/Eurostat)."""
from __future__ import annotations

import urllib.parse
from dataclasses import dataclass, field

import pandas as pd

from . import EUROSTAT_LICENCE
from .oecd import fc_share
from .sdmx import SdmxFeed, SeriesSpec

EUROSTAT_BASE = "https://ec.europa.eu/eurostat/api/dissemination/sdmx/2.1/data"   # UNVERIFIED
EUROSTAT_LABEL = "Eurostat SDMX"
EUROSTAT_GEO_EXCEPTIONS = {"GRC": "EL", "GBR": "UK"}       # Eurostat country codes that are not ISO2 (UNVERIFIED)

EUROSTAT_SPECS = {
    "gg_debt_fc": SeriesSpec("gg_debt_fc", "", None, "Q", "general government debt, foreign currency",
                             candidate="Eurostat government debt by currency; dataset and key unknown (coverage map 1.5)"),
    "gg_debt_total": SeriesSpec("gg_debt_total", "", None, "Q", "general government debt, all currencies",
                                candidate="same dataset; key unknown"),
}


@dataclass
class EurostatFeed(SdmxFeed):
    base: str = EUROSTAT_BASE
    accept: str = "text/csv"
    label: str = EUROSTAT_LABEL
    licence: str = EUROSTAT_LICENCE
    area_dim: str = "geo"
    registry: dict = field(default_factory=lambda: dict(EUROSTAT_SPECS))
    iso2: dict = field(default_factory=dict)                  # ISO3 -> ISO2 (countries.csv iso2)

    def area_code(self, iso3: str) -> str | None:
        return EUROSTAT_GEO_EXCEPTIONS.get(iso3) or self.iso2.get(iso3)

    def url(self, spec: SeriesSpec, areas: list[str]) -> str:
        key = (spec.key or "{area}").format(area="+".join(areas))
        return f"{self.base}/{spec.flow}/{urllib.parse.quote(key, safe='+.')}?{urllib.parse.urlencode({'format': 'SDMX-CSV'})}"


def eurostat_transforms(raw: pd.DataFrame | None, iso: str) -> tuple[dict, dict]:
    v, text = fc_share(raw, iso, "gg_debt_fc", "gg_debt_total", EUROSTAT_LABEL)
    return ({"1.5": v}, {"1.5": text}) if v is not None else ({}, {})
