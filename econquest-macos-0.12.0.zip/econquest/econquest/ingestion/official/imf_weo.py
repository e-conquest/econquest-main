"""IMF WEO releases through the IMF SDMX 3.0 API (EQ-A-0068, RCA-A-002).

Why: on Sam's Mac pull of 2026-10-24 every www.imf.org media download failed (imf-reader's bulk SDMX zips: HTTP 403;
the weo package's tab-delimited files: a body that is not a WEO file), while api.imf.org answered the imf_sdmx feed
(32,927 rows). This module reads a WEO release from its API dataflow instead, so panel_history can try it before the
media-file routes.

Where the names come from (none of it was checked against the live API from the cloud: UNVERIFIED until the probe runs)
* imf-reader 2.2.0 source (``imf_reader/weo/api.py``): agency ``IMF.RES``; dataflows ``WEO`` (latest release) and
  ``WEO_<YYYY>_<MON>_VINTAGE`` (archived releases, e.g. ``WEO_2025_OCT_VINTAGE``); catalogue
  ``/structure/dataflow/IMF.RES/*/*?detail=allstubs`` (JSON ``data.dataflows[].id/version``); dimensions
  ``COUNTRY``, ``INDICATOR``, ``FREQUENCY`` in that key order; ``SCALE`` as a power of ten with OBS_VALUE in units;
  the bare ``WEO`` flow labelled by its ``PUBLICATION_DATE`` attribute.
* official/imf.py (verified by the 2026-10-24 imf_sdmx feed on the Mac, for IMF.STA flows): base
  ``https://api.imf.org/external/sdmx/3.0``, the ``/data/dataflow/{agency}/{flow}/{version}/*?c[DIM]=a,b`` filter form
  and the SDMX-CSV Accept header.
Whether releases before October 2025 exist as ``WEO_<YYYY>_<MON>_VINTAGE`` dataflows is not known: imf-reader only
documents October 2025 onwards. A release with no dataflow is refused cleanly (``WeoApiAbsent``) and panel_history
falls through to its next route. ``python -m econquest.ingestion.panel_history --probe-weo-api`` writes the catalogue's
WEO dataflows and one sample request per dataflow form to a folder Sam sends back, which settles it.

Transport: sources.https_get (https only, redirects refused, body capped), retried on transient errors with
feeds._with_retries. Parsing is strict, like official.sdmx.parse_sdmx_csv: a row with an indicator, country or
frequency that was not asked for, a non-annual period, or two values for one country/indicator/year refuses the whole
answer. Nothing is filled or carried."""
from __future__ import annotations

import datetime as dt
import io
import json
import math
import re
import urllib.error
import urllib.parse
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Iterable

import pandas as pd

from .imf import IMF_ACCEPT, IMF_BASE

WEO_AGENCY = "IMF.RES"                          # imf-reader 2.2.0; UNVERIFIED here
WEO_LATEST_FLOW = "WEO"
WEO_VINTAGE_RE = re.compile(r"WEO_(\d{4})_([A-Z]{3})_VINTAGE")
WEO_DIMS = {"country": "COUNTRY", "indicator": "INDICATOR", "freq": "FREQUENCY", "scale": "SCALE"}
WEO_API_MAX_BYTES = 200 * 2**20                 # the full-dataflow fallback is the whole release (tens of MB)
_MON = {"JAN": 1, "FEB": 2, "MAR": 3, "APR": 4, "MAY": 5, "JUN": 6, "JUL": 7, "AUG": 8, "SEP": 9, "OCT": 10, "NOV": 11,
        "DEC": 12}
_PRINTABLE = re.compile(r"[^\x20-\x7e]")


def _url_version(version: str | None) -> str:
    """A catalogue version string as one URL path segment (SEC-A-009 I7, EQ-A-0141): '/', '?', '#' and the like are
    percent-encoded, so a version from the catalogue can only name a version; empty means '+' (latest)."""
    return urllib.parse.quote(str(version), safe=".+*") if version else "+"


class WeoApiError(RuntimeError):
    """The API route could not serve the release. `permanent` is True when a retry cannot change the answer."""

    permanent = False


class WeoApiAbsent(WeoApiError):
    """The catalogue has no dataflow for the release: a clean refusal, final."""

    permanent = True


def sanitise_head(body: bytes, n: int = 512) -> str:
    """First `n` bytes as one printable-ASCII line (control and non-ASCII bytes -> '.', '|' -> '/', backtick -> "'"),
    so a served page can be quoted in a manifest, a markdown report or a JSON file without breaking any of them."""
    text = _PRINTABLE.sub(".", body[:n].decode("latin-1"))
    return text.replace("|", "/").replace("`", "'")


def sniff(body: bytes) -> str:
    """What a body looks like, from its first bytes: html, xml, json, zip, utf-16 text, empty or text."""
    if not body:
        return "empty"
    if body[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return "utf-16 text (BOM)"
    head = body[:512].lstrip().lower()
    if head.startswith(b"pk\x03\x04"):
        return "zip (xlsx or zip archive)"
    if head.startswith((b"<!doctype html", b"<html")) or b"<html" in head:
        return "html"
    if head.startswith(b"<?xml") or head.startswith(b"<"):
        return "xml"
    if head[:1] in (b"{", b"[") or head.endswith(b"}"):
        return "json"
    return "text"


def flow_vintage(flow_id: str) -> str | None:
    """'WEO_2025_OCT_VINTAGE' -> '2025-10' (September 2011 stays '2011-09'); None for other ids."""
    m = WEO_VINTAGE_RE.fullmatch(str(flow_id))
    if not m or m.group(2) not in _MON:
        return None
    return f"{int(m.group(1)):04d}-{_MON[m.group(2)]:02d}"


def _version_key(v: str) -> tuple:
    try:
        return tuple(int(p) for p in str(v).split("."))
    except ValueError:
        return (0,)


def parse_catalogue(body: bytes) -> list[dict]:
    """Dataflow stubs from a structure answer, JSON (SDMX-JSON 2.0, ``data.dataflows``) or SDMX-ML: rows of agency,
    id, version, name. Raises WeoApiError (with the content sniffed) when neither form can be read."""
    text = body.decode("utf-8", errors="replace").lstrip("﻿").lstrip()
    rows: list[dict] = []
    if text.startswith("{"):
        try:
            data = json.loads(text)
        except ValueError as e:
            raise WeoApiError(f"catalogue is not valid JSON ({e}); starts {sanitise_head(body, 160)!r}") from e
        flows = ((data.get("data") or {}).get("dataflows") or data.get("dataflows") or []) if isinstance(data, dict) else []
        for f in flows:
            if not isinstance(f, dict) or not f.get("id"):
                continue
            name = f.get("name")
            if isinstance(name, dict):
                name = name.get("en") or next(iter(name.values()), "")
            rows.append({"agency": str(f.get("agencyID", "")), "id": str(f["id"]), "version": str(f.get("version", "")),
                         "name": " ".join(str(name or "").split())})
    elif text.startswith("<"):
        for m in re.finditer(r"<(?:[A-Za-z0-9]+:)?Dataflow\b([^>]*)>", text):
            attrs = dict(re.findall(r'(\w+)="([^"]*)"', m.group(1)))
            if attrs.get("id"):
                rows.append({"agency": attrs.get("agencyID", ""), "id": attrs["id"], "version": attrs.get("version", ""),
                             "name": ""})
    else:
        raise WeoApiError(f"catalogue answer is {sniff(body)}, not SDMX JSON or XML; starts {sanitise_head(body, 160)!r}")
    return rows


def weo_flows(catalogue: list[dict]) -> list[dict]:
    """The WEO-related rows of a catalogue (id 'WEO' or starting 'WEO'), with the release each vintage id names."""
    out = []
    for r in catalogue:
        if r["id"] == WEO_LATEST_FLOW or r["id"].upper().startswith("WEO"):
            out.append({**r, "vintage": flow_vintage(r["id"]) or ""})
    return sorted(out, key=lambda r: (r["vintage"], r["id"], _version_key(r["version"])))



def _non_finite_text(v) -> bool:
    """True when an OBS_VALUE string parses as an infinite float (inf, -inf, 1e400)."""
    try:
        return math.isinf(float(str(v).strip()))
    except ValueError:
        return False

def parse_weo_api_csv(body: bytes, codes: Iterable[str] | None, isos: Iterable[str] | None, label: str,
                      strict: bool = True) -> tuple[pd.DataFrame, str]:
    """SDMX-CSV for a WEO dataflow -> (long rows iso, series, period, value; note on scaling).

    strict=True (the answer of a filtered request): a row with an indicator, country or frequency not asked for
    refuses the whole answer. strict=False (the whole-dataflow fallback): those rows are dropped instead. Either way a
    non-annual period or two values for one country, indicator and year refuses the answer; empty OBS_VALUE is skipped.
    Values come back in the tab file's units: OBS_VALUE / 10**SCALE where SCALE > 0 (imf-reader's rule)."""
    kind = sniff(body)
    if kind in ("html", "xml", "json", "zip (xlsx or zip archive)", "empty"):
        raise WeoApiError(f"{label}: answer is {kind}, not SDMX-CSV; starts {sanitise_head(body, 200)!r}")
    from ..sources import read_csv_keep_na_code
    try:
        raw = read_csv_keep_na_code(io.BytesIO(body), dtype=str, encoding="utf-8-sig")
    except Exception as e:  # noqa: BLE001
        raise WeoApiError(f"{label}: not SDMX-CSV ({type(e).__name__}); starts {sanitise_head(body, 200)!r}") from e
    d = WEO_DIMS
    need = [d["country"], d["indicator"], "TIME_PERIOD", "OBS_VALUE"]
    miss = [c for c in need if c not in raw.columns]
    if miss:
        raise WeoApiError(f"{label}: SDMX-CSV without {miss} (columns {list(raw.columns)[:12]}); cannot confirm the series")
    raw = raw.copy()
    for c in (d["country"], d["indicator"], "TIME_PERIOD"):
        raw[c] = raw[c].astype(str).str.strip()
    codes = None if codes is None else set(codes)
    isos = None if isos is None else set(isos)
    checks = [(d["indicator"], codes), (d["country"], isos)]
    if d["freq"] in raw.columns:
        checks.append((d["freq"], {"A"}))
    for col, allowed in checks:
        if allowed is None:
            continue
        bad = ~raw[col].astype(str).str.strip().isin(allowed)
        if bad.any():
            if strict:
                raise WeoApiError(f"{label}: unexpected {col}={raw.loc[bad, col].iloc[0]!r} (not asked); answer refused")
            raw = raw[~bad]
    years = raw["TIME_PERIOD"].str.fullmatch(r"\d{4}")
    if not years.all():
        raise WeoApiError(f"{label}: non-annual TIME_PERIOD {raw.loc[~years, 'TIME_PERIOD'].iloc[0]!r}; answer refused")
    raw["value"] = pd.to_numeric(raw["OBS_VALUE"], errors="coerce")
    # SEC-A-009 L6 (EQ-A-0141): inf / 1e400 is never a value. Checked on the raw text, because some pandas versions
    # coerce "1e400" to NaN (which dropna would then drop silently) rather than to inf.
    inf = raw["OBS_VALUE"].map(_non_finite_text) | ~raw["value"].abs().lt(float("inf")) & raw["value"].notna()
    if inf.any():
        raise WeoApiError(f"{label}: non-finite OBS_VALUE {raw.loc[inf, 'OBS_VALUE'].iloc[0]!r}; answer refused")
    raw = raw.dropna(subset=["value"])
    note = ""
    if d["scale"] in raw.columns:
        sc = pd.to_numeric(raw[d["scale"]], errors="coerce")
        bad_sc = raw[d["scale"]].notna() & (raw[d["scale"]].astype(str).str.strip() != "") & ~(
            sc.notna() & (sc == sc.round()) & sc.between(0, 12))
        if bad_sc.any():                                   # SEC-A-009 L6: SCALE 400 would turn a value into 0.0
            raise WeoApiError(f"{label}: SCALE {raw.loc[bad_sc, d['scale']].iloc[0]!r} is not an integer 0..12; "
                              "answer refused")
        scaled = sc.notna() & (sc > 0)
        if scaled.any():
            raw.loc[scaled, "value"] = raw.loc[scaled, "value"] / (10.0 ** sc[scaled])
            note = f"; OBS_VALUE / 10^SCALE for {int(scaled.sum())} rows (tab-file units)"
    dup = raw.duplicated([d["country"], d["indicator"], "TIME_PERIOD"], keep=False)
    if dup.any():
        r = raw[dup].iloc[0]
        raise WeoApiError(f"{label}: more than one value for {r[d['country']]} {r[d['indicator']]} {r['TIME_PERIOD']}; "
                          "answer refused")
    out = pd.DataFrame({"iso": raw[d["country"]], "series": raw[d["indicator"]],
                        "period": raw["TIME_PERIOD"].astype(int), "value": raw["value"].astype(float)})
    return out.reset_index(drop=True), note


def _default_get(url: str, accept: str | None, max_bytes: int, timeout: float = 120.0) -> bytes:
    from ..sources import https_get
    headers = {"User-Agent": "econquest/0.4"}
    if accept:
        headers["Accept"] = accept
    # fixed https base of the IMF API (constant); redirects refused, body capped (SEC-A-006 L1)
    return https_get(url, headers, timeout=timeout, max_bytes=max_bytes)


def _http_text(e: BaseException) -> str:
    if isinstance(e, urllib.error.HTTPError):
        return f"HTTP {e.code}"
    return f"{type(e).__name__}: {' '.join(str(e).split())[:160]}"


@dataclass
class WeoApi:
    """One catalogue read per instance, then one data request per release. `get(url, accept, max_bytes) -> bytes`
    is injectable (tests); the default is sources.https_get with feeds' transient-error retries."""
    base: str = IMF_BASE
    agency: str = WEO_AGENCY
    get: Callable | None = None
    retries: int = 2
    backoff: float = 2.0
    sleep: Callable[[float], None] | None = None
    _catalogue: list | None = field(default=None, repr=False)
    _catalogue_error: str | None = field(default=None, repr=False)
    _latest: tuple | None = field(default=None, repr=False)

    def catalogue_url(self) -> str:
        return f"{self.base}/structure/dataflow/{self.agency}/*/*?detail=allstubs"

    def data_url(self, flow: str, version: str, codes: Iterable[str] | None, isos: Iterable[str] | None) -> str:
        """Filtered form (codes given) or the whole dataflow (codes None)."""
        url = f"{self.base}/data/dataflow/{self.agency}/{flow}/{_url_version(version)}/*"
        if codes is None:
            return url
        params = {f"c[{WEO_DIMS['indicator']}]": ",".join(codes), f"c[{WEO_DIMS['freq']}]": "A"}
        if isos is not None:
            params[f"c[{WEO_DIMS['country']}]"] = ",".join(isos)
        return url + "?" + urllib.parse.urlencode(params)

    def _fetch(self, url: str, accept: str | None, max_bytes: int = WEO_API_MAX_BYTES) -> bytes:
        get = self.get or _default_get
        from .. import feeds as F
        return F._with_retries(lambda: get(url, accept, max_bytes), retries=self.retries, backoff=self.backoff,
                               sleep=self.sleep)

    # ---------------------------------------------------------------- catalogue
    def catalogue(self) -> list[dict]:
        """Every dataflow stub of the agency (read once; a failure is remembered so 40 releases cost one request)."""
        if self._catalogue is not None:
            return self._catalogue
        if self._catalogue_error is not None:
            raise WeoApiError(self._catalogue_error)
        try:
            body = self._fetch(self.catalogue_url(), None, 20 * 2**20)
            self._catalogue = parse_catalogue(body)
        except WeoApiError as e:
            self._catalogue_error = f"IMF API catalogue {self.catalogue_url()}: {e}"
            raise WeoApiError(self._catalogue_error) from e
        except Exception as e:  # noqa: BLE001 - recorded once, raised for every release
            self._catalogue_error = f"IMF API catalogue {self.catalogue_url()}: {_http_text(e)}"
            raise WeoApiError(self._catalogue_error) from e
        return self._catalogue

    def latest_release(self, version: str) -> str | None:
        """Release (YYYY-MM) the bare WEO dataflow carries, from its PUBLICATION_DATE attribute (one small request,
        imf-reader's probe); None when it cannot be read."""
        if self._latest is not None and self._latest[0] == version:
            return self._latest[1]
        url = (f"{self.base}/data/dataflow/{self.agency}/{WEO_LATEST_FLOW}/{_url_version(version)}/USA.NGDP_RPCH.A"
               "?attributes=dataset&lastNObservations=1")
        rel = None
        try:
            t = pd.read_csv(io.BytesIO(self._fetch(url, "text/csv", 2**20)), dtype=str)
            if "PUBLICATION_DATE" in t.columns and len(t):
                p = pd.to_datetime(t["PUBLICATION_DATE"].iloc[0])
                rel = f"{p.year:04d}-{4 if p.month < 7 else 10:02d}"
        except Exception:  # noqa: BLE001 - unknown label: the bare flow is then not used for any release
            rel = None
        self._latest = (version, rel)
        return rel

    def resolve(self, vintage: str) -> tuple[str, str]:
        """(dataflow id, version) serving release `vintage`; WeoApiAbsent when the catalogue has none."""
        flows = weo_flows(self.catalogue())
        hits = [f for f in flows if f["vintage"] == vintage]
        if hits:
            best = max(hits, key=lambda f: _version_key(f["version"]))
            return best["id"], best["version"]
        bare = [f for f in flows if f["id"] == WEO_LATEST_FLOW]
        if bare and vintage >= "2025-10":
            best = max(bare, key=lambda f: _version_key(f["version"]))
            if self.latest_release(best["version"]) == vintage:
                return best["id"], best["version"]
        have = sorted({f["vintage"] for f in flows if f["vintage"]})
        span = f"vintage dataflows {have[0]}..{have[-1]} ({len(have)})" if have else "no WEO_<YYYY>_<MON>_VINTAGE dataflow"
        raise WeoApiAbsent(f"IMF API has no WEO dataflow for {vintage} under {self.agency}: {span}")

    # ---------------------------------------------------------------- data
    def fetch(self, vintage: str, codes: Iterable[str] | None, isos: Iterable[str] | None = None) -> pd.DataFrame:
        """Long rows (iso, series, period, value, source) of release `vintage`. Filtered request first; if that is
        refused (HTTP error or an answer the strict parser rejects), the whole dataflow, filtered here."""
        flow, version = self.resolve(vintage)
        codes = None if codes is None else list(codes)
        isos = None if isos is None else list(isos)
        label = f"IMF API {self.agency}:{flow}({version})"
        errors = []
        forms = [("filtered", codes, True), ("whole dataflow", None, False)] if codes is not None else [("whole dataflow", None, False)]
        for form, req_codes, strict in forms:
            url = self.data_url(flow, version, req_codes, isos if req_codes is not None else None)
            try:
                body = self._fetch(url, IMF_ACCEPT if strict else "text/csv")
                out, note = parse_weo_api_csv(body, codes, isos, label, strict=strict)
            except WeoApiError as e:
                errors.append(f"{form}: {e}")
                continue
            except Exception as e:  # noqa: BLE001 - next form, all errors reported
                errors.append(f"{form}: {_http_text(e)}")
                continue
            if out.empty:
                errors.append(f"{form}: no observation for the requested series")
                continue
            out["source"] = f"IMF WEO {vintage} via IMF SDMX 3.0 API dataflow {self.agency}:{flow} version {version} ({form}{note})"
            return out
        raise WeoApiError(f"{label}: " + " | ".join(errors))


# ---------------------------------------------------------------------------------------------- Mac probe
def probe(out_dir: str | Path, api: WeoApi | None = None, now: dt.datetime | None = None,
          log: Callable[[str], None] = print) -> int:
    """List the WEO dataflows of the API catalogue and try one small request per dataflow form; write
    <out>/weo_dataflows.csv, <out>/weo_api_samples.csv, <out>/probe.json and the raw catalogue. Returns 0 when the
    catalogue lists at least one WEO dataflow and a sample request parsed, 1 otherwise (each failure printed)."""
    api = api or WeoApi()
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    now = now or dt.datetime.now(dt.timezone.utc)
    rep: dict = {"created_utc": now.strftime("%Y-%m-%dT%H:%M:%SZ"), "catalogue_url": api.catalogue_url(), "status": "failed"}
    try:
        body = api._fetch(api.catalogue_url(), None, 20 * 2**20)
    except Exception as e:  # noqa: BLE001 - the probe's job is to report it
        rep["error"] = _http_text(e)
        (out / "probe.json").write_text(json.dumps(rep, indent=1))
        log(f"FAILED: catalogue {api.catalogue_url()}: {rep['error']}")
        return 1
    (out / ("catalogue_raw.json" if body.lstrip()[:1] == b"{" else "catalogue_raw.txt")).write_bytes(body)
    rep.update(catalogue_bytes=len(body), catalogue_sniff=sniff(body), catalogue_head=sanitise_head(body, 200))
    try:
        api._catalogue = parse_catalogue(body)
    except WeoApiError as e:
        rep["error"] = str(e)
        (out / "probe.json").write_text(json.dumps(rep, indent=1))
        log(f"FAILED: {e}")
        return 1
    flows = weo_flows(api._catalogue)
    pd.DataFrame(flows, columns=["agency", "id", "version", "name", "vintage"]).to_csv(out / "weo_dataflows.csv", index=False)
    rep.update(n_dataflows=len(api._catalogue), n_weo_dataflows=len(flows),
               weo_vintages=sorted({f["vintage"] for f in flows if f["vintage"]}))
    log(f"catalogue: {len(api._catalogue)} dataflows, {len(flows)} WEO-related -> {out / 'weo_dataflows.csv'}")
    vint = [f for f in flows if f["vintage"]]
    picks = ([vint[0], vint[-1]] if len(vint) > 1 else vint) + [f for f in flows if f["id"] == WEO_LATEST_FLOW][-1:]
    samples = []
    for f in picks:
        url = api.data_url(f["id"], f["version"], ["NGDP_RPCH"], ["USA"])
        row = {"dataflow": f["id"], "version": f["version"], "vintage": f["vintage"], "url": url}
        try:
            b = api._fetch(url, IMF_ACCEPT, 2**20)
            df, note = parse_weo_api_csv(b, ["NGDP_RPCH"], ["USA"], f["id"], strict=True)
            row.update(status="ok", rows=len(df), first_year=int(df["period"].min()) if len(df) else "",
                       last_year=int(df["period"].max()) if len(df) else "", note=note.strip("; "),
                       columns=";".join(pd.read_csv(io.BytesIO(b), nrows=0).columns))
        except Exception as e:  # noqa: BLE001
            row.update(status="failed", error=str(e)[:400] if isinstance(e, WeoApiError) else _http_text(e))
        samples.append(row)
        log(f"sample {f['id']} {f['version']}: {row['status']} {row.get('rows', row.get('error', ''))}")
    pd.DataFrame(samples).to_csv(out / "weo_api_samples.csv", index=False)
    ok = bool(flows) and any(s["status"] == "ok" for s in samples)
    rep.update(samples=samples, status="ok" if ok else "failed")
    (out / "probe.json").write_text(json.dumps(rep, indent=1, default=str))
    if not flows:
        log(f"FAILED: no WEO dataflow under {api.agency} in the catalogue")
    elif not ok:
        log("FAILED: no sample request parsed (see weo_api_samples.csv)")
    log(f"send back: {out}/probe.json, weo_dataflows.csv, weo_api_samples.csv")
    return 0 if ok else 1
