"""Shared SDMX transport, series specs and SDMX-CSV parsing for the official adapters (EQ-A-0049).

Transport: every request goes through sources.https_get (https only, redirects refused, body capped), with the
feeds.py retry rule (timeouts, connection errors, 429 and 5xx retried with backoff) and fail-fast rule (a proxy
refusal, DNS failure or redirect raises feeds.FeedUnreachable and ends the feed at once, EQ-A-0037 / SEC-A-006 L1).

Parsing: an SDMX-CSV answer is accepted only when every row carries the dimension values that were asked for. A row
with another value (or a missing dimension column, or two values for one country and period) raises FeedError for the
whole answer: a wrong code fails loudly instead of being read as something else. Empty or non-numeric OBS_VALUE
rows are skipped, never filled. Values are kept exactly as delivered, with UNIT_MULT beside them; transforms scale."""
from __future__ import annotations

import io
import re
import urllib.error
import urllib.parse
from dataclasses import dataclass, field
from typing import Callable, Iterable

import pandas as pd

from .. import feeds as F
from ..sources import https_get, read_csv_keep_na_code

RAW_COLUMNS = [*F.LONG_COLUMNS, "sdmx_key", "unit_mult", "licence"]
SDMX_MAX_BYTES = 50 * 1024 * 1024          # per response (SEC-A-006 L1); a 25-country monthly batch is a few MB


@dataclass(frozen=True)
class SeriesSpec:
    """One series an adapter may request.

    name      component name, written to the raw table's `series` column
    flow      dataflow id (agency handled by the adapter)
    filters   ((dimension, code), ...) that every returned row must carry; None = not configured, never requested
    freq      'M', 'Q' or 'A' (staleness rule in official.gate)
    label     what the series is meant to be
    key       positional SDMX 2.1 key template with {area} (OECD, Eurostat); None where the adapter uses filters only
    candidate where the codes come from and what the Mac check must confirm"""
    name: str
    flow: str
    filters: tuple | None
    freq: str
    label: str
    key: str | None = None
    candidate: str = ""

    @property
    def configured(self) -> bool:
        return self.filters is not None

    def describe(self) -> str:
        dims = ",".join(f"{d}={c}" for d, c in (self.filters or ()))
        return f"{self.flow} {dims}".strip()


def specs_for(registry: dict, names: Iterable[str] | None) -> dict:
    """The specs named in `names` (all when None). An unknown name raises ValueError: nothing is requested."""
    if names is None:
        return dict(registry)
    names = list(names)
    unknown = [n for n in names if n not in registry]
    if unknown:
        raise ValueError(f"unknown series {unknown}; known: {sorted(registry)}")
    return {n: registry[n] for n in names}


_PERIOD_RES = (
    (re.compile(r"(\d{4})-(\d{2})-(\d{2})"), lambda m: m.group(0)),
    (re.compile(r"(\d{4})-?M(\d{2})"), lambda m: f"{m[1]}-{m[2]}"),
    (re.compile(r"(\d{4})-(\d{2})"), lambda m: f"{m[1]}-{m[2]}"),
    (re.compile(r"(\d{4})-?Q([1-4])"), lambda m: f"{m[1]}-Q{m[2]}"),
    (re.compile(r"(\d{4})(?:-A1?)?"), lambda m: m[1]),
)


def norm_period(p) -> str | None:
    """'2026-08', '2026-M08', '2026M08' -> '2026-08'; '2026-Q3', '2026Q3' -> '2026-Q3'; '2026' -> '2026';
    'YYYY-MM-DD' unchanged. None when unreadable."""
    s = str(p).strip()
    for rx, fmt in _PERIOD_RES:
        m = rx.fullmatch(s)
        if m:
            return fmt(m)
    return None


def parse_sdmx_csv(body: str, spec: SeriesSpec, area_dim: str, to_iso: dict, licence: str, label: str) -> list[dict]:
    """SDMX-CSV text for one spec -> raw rows (RAW_COLUMNS minus source). `to_iso` maps the area codes asked for to
    ISO3. Raises FeedError when the answer cannot be confirmed to be the requested series (see module docstring)."""
    try:
        raw = read_csv_keep_na_code(io.StringIO(body), dtype=str)
    except Exception as e:  # noqa: BLE001
        raise F.FeedError(f"{label} {spec.flow}: response is not SDMX-CSV: {type(e).__name__}") from e
    if raw.empty:
        return []
    cols = set(raw.columns)
    if not {"TIME_PERIOD", "OBS_VALUE"} <= cols:
        raise F.FeedError(f"{label} {spec.flow}: SDMX-CSV without TIME_PERIOD / OBS_VALUE")
    if area_dim not in cols:
        raise F.FeedError(f"{label} {spec.flow}: no {area_dim} column; cannot attribute rows to countries")
    filters = tuple(spec.filters or ())
    absent = [d for d, _ in filters if d not in cols]
    if absent:
        raise F.FeedError(f"{label} {spec.flow}: dimension column(s) {absent} missing; cannot confirm the series "
                          f"{spec.describe()}")
    rows, seen = [], set()
    for r in raw.to_dict("records"):
        for d, code in filters:
            if str(r[d]).strip() != code:
                raise F.FeedError(f"{label} {spec.flow}: unexpected {d}={r[d]!r} (asked {spec.describe()}); answer refused")
        area = str(r[area_dim]).strip()
        if area not in to_iso:
            raise F.FeedError(f"{label} {spec.flow}: unexpected {area_dim}={area!r} (not requested); answer refused")
        period = norm_period(r["TIME_PERIOD"])
        if period is None:
            raise F.FeedError(f"{label} {spec.flow}: unreadable TIME_PERIOD {r['TIME_PERIOD']!r}")
        v = pd.to_numeric(r["OBS_VALUE"], errors="coerce")
        if pd.isna(v):
            continue                                       # no observation: skipped, never filled
        if (area, period) in seen:
            raise F.FeedError(f"{label} {spec.flow}: more than one series for {area} {period} under "
                              f"{spec.describe()}; add a dimension filter")
        seen.add((area, period))
        um = pd.to_numeric(r.get("UNIT_MULT", 0), errors="coerce")
        rows.append({"iso": to_iso[area], "series": spec.name, "period": period, "value": float(v),
                     "sdmx_key": f"{spec.describe()} {area_dim}={area}", "unit_mult": int(um) if pd.notna(um) else 0,
                     "licence": licence})
    return rows


@dataclass
class SdmxFeed:
    """Base of the three SDMX adapters: batches countries, requests each configured spec, parses with
    parse_sdmx_csv. Subclasses set `base`, `label`, `licence`, `area_dim`, `registry` and `url()`."""
    base: str = ""
    timeout: float = 30.0
    batch: int = 25
    retries: int = 3
    backoff: float = 2.0
    sleep: Callable[[float], None] | None = None
    max_bytes: int = SDMX_MAX_BYTES
    series: Iterable[str] | None = None            # spec names; None = the whole registry
    accept: str = "text/csv"
    label: str = "SDMX"
    licence: str = ""
    area_dim: str = "REF_AREA"
    registry: dict = field(default_factory=dict)

    # --- per adapter
    def area_code(self, iso3: str) -> str | None:
        return iso3

    def url(self, spec: SeriesSpec, areas: list[str]) -> str:  # pragma: no cover - interface
        raise NotImplementedError

    # --- transport
    def host(self) -> str:
        return urllib.parse.urlsplit(self.base).hostname or self.base

    def _get(self, url: str) -> str:
        if not url.startswith("https://") or not self.base.startswith("https://"):
            raise ValueError(f"{self.label} base must be https: {self.base!r}")
        # fixed https base of the official API (constant in the adapter); redirects refused, body capped (SEC-A-006 L1)
        return https_get(url, {"User-Agent": "econquest/0.2", "Accept": self.accept}, timeout=self.timeout,
                         max_bytes=self.max_bytes).decode("utf-8")

    def _get_retry(self, url: str) -> str:
        try:
            return F._with_retries(lambda: self._get(url), retries=self.retries, backoff=self.backoff, sleep=self.sleep)
        except Exception as e:  # noqa: BLE001 - classified, then re-raised as it was
            F._stop_if_unreachable(e, self.host())
            raise

    # --- fetch
    def fetch(self, isos: Iterable[str]) -> pd.DataFrame:
        """Raw rows (RAW_COLUMNS) for every configured spec and country. attrs["failures"] lists what went wrong,
        attrs["unconfigured"] the specs not requested because their codes are not set. FeedUnreachable ends the
        feed at once; FeedError when no row came back at all."""
        specs = specs_for(self.registry, self.series)
        pairs = [(i, self.area_code(i)) for i in dict.fromkeys(isos) if isinstance(i, str) and i]
        pairs = [(i3, a) for i3, a in pairs if a]
        size = max(1, int(self.batch))
        rows: list[dict] = []
        failures: list[str] = []
        unconfigured = sorted(n for n, s in specs.items() if not s.configured)
        if unconfigured:
            failures.append(f"{self.label}: not configured (codes unknown, not requested): {', '.join(unconfigured)}")
        for spec in (s for s in specs.values() if s.configured):
            for start in range(0, len(pairs), size):
                chunk = pairs[start:start + size]
                got = self._one(spec, chunk, failures)
                if got is None and len(chunk) > 1:        # transport failure: one country per call
                    failures.append(f"{self.label} {spec.name} batch of {len(chunk)} failed; retrying one by one")
                    for p in chunk:
                        rows += self._one(spec, [p], failures) or []
                else:
                    rows += got or []
        out = pd.DataFrame(rows, columns=[c for c in RAW_COLUMNS if c != "source"])
        out.insert(4, "source", self.source())
        if out.empty:
            raise F.FeedError(f"{self.label}: no rows: " + "; ".join(failures[:3]))
        out = out[RAW_COLUMNS].reset_index(drop=True)
        out.attrs.update(failures=failures, unconfigured=unconfigured)
        return out

    def source(self) -> str:
        return f"{self.label} ({self.host()})"

    def _one(self, spec: SeriesSpec, chunk: list, failures: list) -> list[dict] | None:
        """Rows for one request; [] when the answer was refused or empty (recorded), None on a transport failure
        worth retrying per country. FeedUnreachable propagates."""
        to_iso = {a: i3 for i3, a in chunk}
        url = self.url(spec, list(to_iso))
        try:
            body = self._get_retry(url)
        except F.FeedUnreachable:
            raise
        except urllib.error.HTTPError as e:
            failures.append(f"{self.label} {spec.name} {'+'.join(to_iso)}: HTTP {e.code}")
            return [] if e.code == 404 else None          # 404 = no data for this key: final
        except Exception as e:  # noqa: BLE001
            failures.append(f"{self.label} {spec.name} {'+'.join(to_iso)}: {type(e).__name__}: {str(e)[:100]}")
            return None
        try:
            return parse_sdmx_csv(body, spec, self.area_dim, to_iso, self.licence, self.label)
        except F.FeedError as e:
            failures.append(F._one_line(e, 200))
            return []


def scaled(raw: pd.DataFrame, iso: str, name: str) -> pd.Series:
    """Values of component `name` for `iso`, multiplied by 10**unit_mult, indexed by period (sorted)."""
    if raw is None or not len(raw):
        return pd.Series(dtype=float)
    s = raw[(raw["iso"] == iso) & (raw["series"] == name)]
    if s.empty:
        return pd.Series(dtype=float)
    um = pd.to_numeric(s["unit_mult"], errors="coerce").fillna(0) if "unit_mult" in s.columns else 0
    vals = pd.to_numeric(s["value"], errors="coerce") * (10.0 ** um)
    out = pd.Series(vals.to_numpy(dtype=float), index=s["period"].astype(str).to_numpy()).sort_index()
    return out[~out.index.duplicated(keep="last")].dropna()


def quarter_to_month(period: str) -> str:
    """'2026-Q2' -> '2026-06' (the quarter's last month); other periods unchanged."""
    m = re.fullmatch(r"(\d{4})-Q([1-4])", str(period))
    return f"{m[1]}-{int(m[2]) * 3:02d}" if m else str(period)


def month_minus(period: str, n: int) -> str | None:
    m = re.fullmatch(r"(\d{4})-(\d{2})", str(period))
    if not m:
        return None
    k = int(m[1]) * 12 + int(m[2]) - 1 - n
    return f"{k // 12}-{k % 12 + 1:02d}"
