"""Review ledger (EQ-A-0006): analysts' decisions on quality-gate cells, kept apart from the gate output.

`data/live/review_ledger.csv` is append-only: `record_decision` opens it in append mode (under an exclusive lock on
POSIX) and never rewrites a row, so every decision keeps its author, approver and time. `data/live/review.csv` is
regenerated on every fetch by `write_review` as the fresh gate output joined with the latest ledger decision per cell,
so a new pull never loses a decision. `effective_holds` turns gate status plus decisions into the set of cells
`apply_report` must skip.

Four-eyes rule (roadmap 4.4): applying a cell the gate held needs an approver who is not the author. Single-operator
mode (Sam, 2026-10-23): a self-approval is allowed only when flagged with `self_approved=True`; the row then has
approver = author and `self_approved` = "yes", so the audit trail shows it as a governance exception.

An approval is bound to what was approved (SEC-A-001 M1): an 'apply' decision releases a gate hold only for the same
vintage or the same live value. hold and reject decisions stay in force across vintages.

Overriding a colleague (SEC-A-001 L3, HO-20261023-C-A-004): an 'apply' that follows a hold or reject by another person
needs the same approval as a gate-held cell (different approver, or flagged self-approval), whatever the gate says.
record_decision refuses it otherwise, and effective_holds keeps the cell held if such a row reaches the ledger anyway.

Every text column written to the ledger is neutralised against spreadsheet formula injection (SEC-A-001 L4).

Hand-entered cells (EQ-A-0018): data/adjustments.csv, data/cds_quotes.csv, data/prediction_markets.csv and
data/fx_manual.csv (EQ-A-0072) are typed by analysts, not pulled. `attest_cells` records one ledger row per cell (table = file stem, decision 'apply', live = the
value, `content_sha256` of what was attested) under the four-eyes rule, and `unattested_cells` lists every cell whose
current content has no such attestation. Loading never blocks on an unattested cell: the audit trail reports it.

Tamper evidence (EQ-A-0103, SEC-A-011 L5): every row appended from 0.6.0 on carries `prev_hash` (the row_hash of the
chained row before it, GENESIS for the first row of a new ledger) and `row_hash` (sha256 of the canonical JSON of the
row's stored text without row_hash), as presentation/editorial.py does. An existing ledger written before that gets one
"chain starts here" anchor row on its first append (table CHAIN_TABLE, decision 'anchor'): its prev_hash is the sha256
of the legacy rows above it, so those rows are reported as unchained, never as tampered, and editing them after the
anchor is a break. `verify_ledger` recomputes the chain; `_append` refuses to extend a broken chain;
`python -m econquest.ingestion.ledger verify` exits 1 on a break. `chain_head` gives (seq, row_hash) for a keyed seal
(D4, Sam's decision; not built here). Without a key, someone who rewrites the whole file and recomputes every hash, or
cuts rows off the end, is not detected: that is what a seal adds. `import_legacy_review` refuses a fresh import when
the ledger is missing, vintages exist and a review.csv still records a named decision taken from a ledger (a deleted
ledger), unless `first_install=True`."""
from __future__ import annotations

import contextlib
import csv
import datetime as dt
import hashlib
import json
import math
import os
import tempfile
import unicodedata
from pathlib import Path

import pandas as pd

try:                                    # POSIX only; on other platforms appends are unlocked
    import fcntl
except ImportError:                     # pragma: no cover
    fcntl = None

LEDGER_COLUMNS = ["ts_utc", "vintage_id", "table", "key", "country", "gate_status", "live", "decision", "author", "approver",
                  "note", "self_approved", "content_sha256", "prev_hash", "row_hash"]
CHAIN_COLUMNS = ("prev_hash", "row_hash")                # EQ-A-0103: last two columns, never neutralised
GENESIS = "0" * 64
CHAIN_TABLE, CHAIN_KEY, CHAIN_DECISION = "_chain", "anchor", "anchor"     # the "chain starts here" row (not a decision)
CHAIN_AUTHOR = "econquest (system)"
VINTAGES_REL = ("live", "vintages")
DECISIONS = ("apply", "hold", "reject")
CELL = ["table", "key", "country"]
REVIEW_DECISION_COLUMNS = ["decision", "author", "approver", "self_approved", "decided_utc"]
LEGACY_AUTHOR = "unknown (imported from hand-edited review.csv)"
LEGACY_RESET_NOTE = "legacy decision reset, needs Sam's decision"      # EQ-A-0101
LIVE_REL_TOL, LIVE_ABS_TOL = 1e-6, 1e-9
# every text column is neutralised against spreadsheet formula injection (SEC-A-001 L4); ts_utc is ours, live numeric
_TEXT_FIELDS = ("vintage_id", "table", "key", "country", "gate_status", "decision", "author", "approver", "note",
                "self_approved")
_FORMULA_PREFIXES = ("=", "+", "-", "@", "\t", "\r")
_UNGUARD_FIELDS = ("vintage_id", "table", "key", "country")   # identifiers: guard apostrophe dropped on read for matching
# Small confusables map (SEC-A-001 L2): Cyrillic and Greek lowercase letters that look like Latin ones (applied after
# casefold). Deliberately small: a false match only makes the four-eyes check stricter.
_CONFUSABLES = str.maketrans({
    "а": "a", "в": "b", "е": "e", "ё": "e", "з": "3", "и": "u", "і": "i", "ї": "i", "ј": "j", "к": "k", "м": "m",
    "н": "h", "о": "o", "р": "p", "с": "c", "т": "t", "у": "y", "х": "x", "ѕ": "s", "һ": "h", "ԁ": "d", "ӏ": "l",
    "ԛ": "q", "ԝ": "w",
    "α": "a", "β": "b", "ε": "e", "η": "n", "ι": "i", "κ": "k", "μ": "m", "ν": "v", "ο": "o", "ρ": "p", "τ": "t",
    "υ": "u", "χ": "x", "ζ": "z", "ı": "i",
})


def ledger_path(data_dir: Path) -> Path:
    return Path(data_dir) / "live" / "review_ledger.csv"


def _ts(now: dt.datetime | None) -> str:
    now = now or dt.datetime.now(dt.timezone.utc)
    now = now.replace(tzinfo=dt.timezone.utc) if now.tzinfo is None else now.astimezone(dt.timezone.utc)
    return now.strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def clean_person(name) -> str:
    """A person's name as stored: NFKC-normalised, Unicode format characters (category Cf, e.g. zero-width space)
    removed, runs of whitespace collapsed to one space, surrounding whitespace stripped."""
    s = unicodedata.normalize("NFKC", "" if name is None else str(name))
    return " ".join("".join(ch for ch in s if unicodedata.category(ch) != "Cf").split())


def person_key(name) -> str:
    """Comparison key for author/approver: clean_person, every leading apostrophe dropped (formula guard or typed),
    casefolded, all whitespace removed, and common Cyrillic/Greek homoglyphs mapped to Latin (SEC-A-001 L2). So
    `'alice`, `a lice`, `ALICE` and Cyrillic `аlice` all compare equal to `alice`. Names stay self-asserted: this is a
    guard against accidental or lazy evasion, not authentication."""
    s = clean_person(name).lstrip("'").casefold()
    s = "".join(s.split()).translate(_CONFUSABLES)
    return "" if s == "nan" else s


def _is_number(v: str) -> bool:
    try:
        return math.isfinite(float(v))
    except ValueError:
        return False


def _neutralise(v):
    """Prefix text starting with = + - @ TAB or CR with an apostrophe so a spreadsheet opening the ledger treats it as
    text. A plain number such as '-1.5' is left alone (a spreadsheet does not evaluate it)."""
    if isinstance(v, str) and v[:1] in _FORMULA_PREFIXES and not _is_number(v):
        return "'" + v
    return v


def _unguard(v: str) -> str:
    """Inverse of _neutralise for identifier columns, so a neutralised key still matches the review frame."""
    return v[1:] if isinstance(v, str) and v[:1] == "'" and v[1:2] in _FORMULA_PREFIXES else v


def check_approval(author, approver=None, self_approved: bool = False) -> tuple[str, str, str]:
    """Validate an approval of a gate-held cell and return (author, approver, self_approved flag) as stored.
    Four-eyes: approver must be given and differ from author after normalisation. With self_approved=True the
    approver may be empty or equal to the author; it is then stored as the author and the flag is "yes". A distinct
    approver is an ordinary four-eyes approval even when self_approved=True (flag "")."""
    author, approver = clean_person(author), clean_person(approver)
    if not person_key(author):
        raise ValueError("author is required")
    _refuse_legacy_name(author, approver)
    if not person_key(approver) or person_key(approver) == person_key(author):
        if not self_approved:
            raise ValueError("needs an approver other than the author (four-eyes); pass self_approved=True for a "
                             "flagged single-operator self-approval")
        return author, author, "yes"
    return author, approver, ""


def _refuse_legacy_name(*names) -> None:
    """SEC-A-011 L1: LEGACY_AUTHOR is written only by import_legacy_review. A decision typed with that name (any case
    or spacing) would be treated as legacy by effective_holds (a hold that never pins a gate-ok cell) while an apply
    under it, with an approver, would release a hold that no legacy row may release."""
    legacy = person_key(LEGACY_AUTHOR)
    if any(person_key(n) == legacy for n in names if n is not None):
        raise ValueError(f"{LEGACY_AUTHOR!r} is reserved for imported legacy rows: name the person deciding")


@contextlib.contextmanager
def locked_append(path: Path, fieldnames: list[str]):
    """Open `path` for append under an exclusive flock (POSIX) and yield (DictWriter, file, is_new). is_new is decided
    after the lock is taken, so two concurrent writers never both write a header."""
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a", newline="") as f:
        if fcntl is not None:
            fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        try:
            f.seek(0, os.SEEK_END)
            new = f.tell() == 0
            yield csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore"), f, new
            f.flush()
        finally:
            if fcntl is not None:
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)


class LedgerChainError(ValueError):
    """The review ledger's hash chain is broken (EQ-A-0103): nothing was appended."""


class LedgerMissingError(ValueError):
    """The review ledger is missing while vintages exist: a fresh legacy import was refused (EQ-A-0103)."""


def _canon(obj) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def _row_hash(rec: dict) -> str:
    """sha256 of the canonical JSON of a chained row's stored text (every LEDGER_COLUMNS field except row_hash)."""
    return hashlib.sha256(_canon({c: rec.get(c, "") for c in LEDGER_COLUMNS if c != "row_hash"}).encode("utf-8")).hexdigest()


def _legacy_digest(header: list[str], legacy: list[list[str]]) -> str:
    """What an anchor row commits to: sha256 of the canonical JSON of the header and the legacy rows above it, as parsed
    CSV fields (so a re-quoted copy still matches; an edited value does not)."""
    return hashlib.sha256(_canon({"header": header, "rows": legacy}).encode("utf-8")).hexdigest()


def _stored(col: str, v) -> str:
    """The exact text written for one cell (and hashed): neutralised as _cell_out does, then str()."""
    v = _cell_out(col, v)
    return v if isinstance(v, str) else str(v)


def _chain_rows(rows: list[dict], prev: str) -> list[dict]:
    out = []
    for r in rows:
        rec = {c: _stored(c, r.get(c)) for c in LEDGER_COLUMNS if c not in CHAIN_COLUMNS}
        rec["prev_hash"] = prev
        rec["row_hash"] = prev = _row_hash(rec)
        out.append(rec)
    return out


def _anchor_row(n_legacy: int, digest: str, now: dt.datetime | None = None) -> dict:
    return {"ts_utc": _ts(now), "table": CHAIN_TABLE, "key": CHAIN_KEY, "decision": CHAIN_DECISION, "author": CHAIN_AUTHOR,
            "note": (f"chain starts here (EQ-A-0103): the {n_legacy} row(s) above were written before the hash chain and "
                     "are unchained; this row's prev_hash is the sha256 of them and the header"),
            "_prev": digest}


def _append(data_dir: Path, rows: list[dict]) -> None:
    """Append rows to the ledger (header first when the file is new), each chained to the one before (EQ-A-0103).
    Existing bytes are never rewritten. Under the same lock: verify_ledger first, and refuse (LedgerChainError, nothing
    written) when the chain is broken; a ledger with no chained row yet gets the "chain starts here" anchor row first.
    A ledger written before the self_approved or hash columns existed keeps its old header; new rows carry the extra
    trailing fields and read_ledger maps them."""
    p = ledger_path(data_dir)
    with locked_append(p, LEDGER_COLUMNS) as (w, f, new):
        if new:
            w.writeheader()
            f.flush()
            prev, todo = GENESIS, list(rows)
        else:
            st = verify_ledger(data_dir)
            if st["problems"]:
                raise LedgerChainError(f"review ledger {p} hash chain is broken, nothing appended: "
                                       + "; ".join(st["problems"][:3])
                                       + ". Check it with: python -m econquest.ingestion.ledger verify --data "
                                       + str(Path(data_dir)))
            if st["chained"]:
                prev, todo = st["head"]["row_hash"], list(rows)
            elif st["needs_anchor"]:
                anchor = _anchor_row(st["legacy_unchained"], st["legacy_digest"])
                if rows and str(rows[0].get("ts_utc") or ""):  # same time as the row it precedes: a cut by ts keeps both
                    anchor["ts_utc"] = str(rows[0]["ts_utc"])
                prev, todo = anchor.pop("_prev"), [anchor] + list(rows)
            else:                                        # header-only file with the full header: a new chain
                prev, todo = GENESIS, list(rows)
        for rec in _chain_rows(todo, prev):
            w.writerow(rec)


def _vintage_ids(data_dir: Path) -> list[str]:
    root = Path(data_dir).joinpath(*VINTAGES_REL)
    if not root.is_dir():
        return []
    return sorted(c.name for c in root.iterdir() if c.is_dir() and not c.name.startswith("."))


def named_decision_evidence(data_dir: Path, limit: int = 3) -> list[str]:
    """Where a named decision is recorded although the ledger may be gone (EQ-A-0103): data/live/review.csv and every
    data/live/vintages/<id>/review.csv rows that write_review joined from a ledger (decided_utc set) with an author
    other than LEGACY_AUTHOR. Returns up to `limit` "path (n row(s))" entries. A deleted ledger loses exactly these
    decisions; a ledger that only ever held legacy imports (or never existed) leaves none, and re-importing review.csv
    then reproduces what was there."""
    legacy = person_key(LEGACY_AUTHOR)
    root = Path(data_dir).joinpath(*VINTAGES_REL)
    files = [Path(data_dir) / "live" / "review.csv"] + [root / v / "review.csv" for v in reversed(_vintage_ids(data_dir))]
    out = []
    for f in files:
        if not f.is_file():
            continue
        try:
            with open(f, newline="", encoding="utf-8") as fh:
                rd = csv.DictReader(fh)
                if not {"decided_utc", "author"} <= set(rd.fieldnames or []):
                    continue
                n = sum(1 for r in rd if str(r.get("decided_utc") or "").strip()
                        and person_key(r.get("author")) not in ("", legacy))
        except (OSError, csv.Error, UnicodeDecodeError):
            continue
        if n:
            out.append(f"{f} ({n} row(s))")
            if len(out) >= limit:
                break
    return out


def verify_ledger(data_dir: Path) -> dict:
    """Recompute the review ledger's hash chain (EQ-A-0103). Returns a dict:
    ok (no problem), exists, rows (body rows), legacy_unchained (rows before the chain, written before 0.6.0),
    chained (rows with prev_hash/row_hash, the anchor included), anchor (a "chain starts here" row is present),
    head {seq: chained, row_hash: last row_hash or GENESIS} (what a keyed seal would sign), legacy_digest,
    needs_anchor (the next append writes an anchor first), vintages (count under data/live/vintages),
    problems (breaks: edited, deleted, inserted or reordered chained rows, legacy rows edited after the anchor, an
    unreadable file), notes (not breaks: legacy rows, no ledger).
    Legacy rows are reported as unchained, never as tampered. Not detected without a seal: a full rewrite with every
    hash recomputed, or rows cut off the end."""
    p = ledger_path(data_dir)
    n_vint = len(_vintage_ids(data_dir))
    res = {"ok": True, "exists": p.is_file(), "path": str(p), "rows": 0, "legacy_unchained": 0, "chained": 0,
           "anchor": False, "head": {"seq": 0, "row_hash": GENESIS}, "legacy_digest": "", "needs_anchor": False,
           "vintages": n_vint, "problems": [], "notes": []}
    problems, notes = res["problems"], res["notes"]
    header: list[str] = []
    legacy: list[list[str]] = []
    prev, started = None, False
    if not res["exists"] or p.stat().st_size == 0:
        lost = named_decision_evidence(data_dir) if n_vint else []
        if lost:
            notes.append(f"no review ledger at {p}, but named decisions recorded from one are in {', '.join(lost)}: "
                         "restore the ledger from a backup")
        elif n_vint:
            notes.append(f"no review ledger at {p} while {n_vint} vintage(s) exist: fine before the first named "
                         "decision")
        return res
    try:
        with open(p, newline="", encoding="utf-8") as f:
            rd = csv.reader(f)
            header = next(rd, [])
            if header != LEDGER_COLUMNS[:len(header)] or not header:
                problems.append(f"line 1: unexpected header {header[:4]}...")
                res["ok"] = False
                return res
            full = header == LEDGER_COLUMNS
            for r in rd:
                if not r:
                    continue
                line = rd.line_num
                res["rows"] += 1
                chained = len(r) == len(LEDGER_COLUMNS) and bool(r[-1])
                if not chained:
                    if started or full:
                        problems.append(f"line {line}: unchained row inside the hash chain (inserted, or its hash "
                                        "columns removed)")
                    else:
                        legacy.append(r)
                    continue
                rec = dict(zip(LEDGER_COLUMNS, r))
                is_anchor = rec["table"] == CHAIN_TABLE and rec["decision"] == CHAIN_DECISION
                if not started:
                    started = True
                    if legacy or not full:
                        res["legacy_digest"] = _legacy_digest(header, legacy)
                        if not is_anchor:
                            problems.append(f"line {line}: the chain starts without its anchor row after "
                                            f"{len(legacy)} legacy row(s)")
                        elif rec["prev_hash"] != res["legacy_digest"]:
                            problems.append(f"line {line}: the {len(legacy)} legacy row(s) above the anchor were changed "
                                            "after the chain started")
                    elif rec["prev_hash"] != GENESIS:
                        problems.append(f"line {line}: first row's prev_hash is not GENESIS (rows deleted from the start?)")
                    res["anchor"] = res["anchor"] or is_anchor
                else:
                    if is_anchor:
                        problems.append(f"line {line}: a second 'chain starts here' anchor row")
                    if rec["prev_hash"] != prev:
                        problems.append(f"line {line}: prev_hash does not match the row before (row deleted, inserted "
                                        "or moved?)")
                if rec["row_hash"] != _row_hash(rec):
                    problems.append(f"line {line}: row_hash does not match the row (edited?)")
                prev = rec["row_hash"]
                res["chained"] += 1
    except (csv.Error, UnicodeDecodeError) as e:
        problems.append(f"unreadable ledger: {e}")
    res["legacy_unchained"] = len(legacy)
    if not started and header:
        res["legacy_digest"] = _legacy_digest(header, legacy)
        res["needs_anchor"] = bool(legacy) or header != LEDGER_COLUMNS
    if res["chained"]:
        res["head"] = {"seq": res["chained"], "row_hash": prev}
    if res["legacy_unchained"]:
        notes.append(f"{res['legacy_unchained']} legacy row(s) written before the hash chain (EQ-A-0103) are unchained"
                     + (": the anchor row commits to them" if res["anchor"] else ": the next append anchors them"))
    res["ok"] = not problems
    return res


def chain_head(data_dir: Path) -> dict:
    """{seq, row_hash} of the ledger's last chained row (GENESIS, 0 when none): what a keyed seal (D4) would sign, as
    ops/ledger_key.seal does for the editorial ledger. Raises LedgerChainError when the chain is broken."""
    st = verify_ledger(data_dir)
    if st["problems"]:
        raise LedgerChainError("review ledger hash chain is broken: " + "; ".join(st["problems"][:3]))
    return dict(st["head"])


def _cell_out(col: str, v):
    if v is None:
        return ""
    if col in _TEXT_FIELDS:
        return _neutralise(str(v))
    if col == "live" and isinstance(v, str) and not _is_number(v.strip() or "0"):
        return _neutralise(v)                    # live is numeric; text in it is guarded like any other text
    return v


def _standing_objection(rows) -> str:
    """Walk one cell's decisions in order and return the author of the hold/reject still in force, or ''.
    A hold/reject stands until its own author applies, or an approved apply (_approved) supersedes it. An unapproved
    apply by someone else leaves it standing (SEC-A-001 L3). A row may carry `objection_by` (from load_decisions):
    the objection standing before it."""
    standing = ""
    for d in rows:
        prior = str(getattr(d, "objection_by", "") or "").strip()
        if prior and prior != "nan":
            standing = prior
        dec = str(getattr(d, "decision", "") or "")
        if dec in ("hold", "reject"):
            standing = clean_person(getattr(d, "author", "")) or "unknown"
        elif dec == "apply":
            if not standing or person_key(standing) == person_key(getattr(d, "author", "")) or _approved(d):
                standing = ""
    return standing


def record_decision(data_dir: Path, table: str, key: str, country: str, decision: str, author: str, approver: str | None = None,
                    note: str = "", vintage_id: str = "", live=None, gate_status: str = "", now: dt.datetime | None = None,
                    self_approved: bool = False) -> dict:
    """Append one decision on one cell and return the row written. `decision` is apply, hold or reject; `author` is
    required. Applying a cell whose gate status is 'hold' needs an `approver` different from the author (four-eyes),
    otherwise ValueError, unless `self_approved=True` (single-operator mode: approver stored as the author,
    self_approved "yes"). Pass `vintage_id` and/or `live`: an apply releases a gate hold only for the same vintage or
    the same live value (effective_holds)."""
    decision = str(decision).strip().lower()
    if decision not in DECISIONS:
        raise ValueError(f"decision must be one of {DECISIONS}, got {decision!r}")
    author, approver = clean_person(author), clean_person(approver)
    if not person_key(author):
        raise ValueError("author is required")
    _refuse_legacy_name(author, approver)
    flag = ""
    objection = ""
    if decision == "apply":
        hist = read_ledger(data_dir)
        hist = hist[(hist["table"] == str(table)) & (hist["key"] == str(key)) & (hist["country"] == str(country))]
        objection = _standing_objection(hist.itertuples(index=False))
        if objection and person_key(objection) == person_key(author):
            objection = ""
    if decision == "apply" and (gate_status == "hold" or objection):
        why = "a held cell" if gate_status == "hold" else f"a cell {objection} put on hold or rejected"
        try:
            author, approver, flag = check_approval(author, approver, self_approved)
        except ValueError as e:
            raise ValueError(f"applying {why} ({table}, {key}, {country}) {e}") from None
    elif self_approved and (not person_key(approver) or person_key(approver) == person_key(author)):
        approver, flag = author, "yes"
    row = {"ts_utc": _ts(now), "vintage_id": vintage_id or "", "table": table, "key": str(key), "country": country,
           "gate_status": gate_status, "live": "" if live is None else live, "decision": decision, "author": author,
           "approver": approver, "note": note, "self_approved": flag}
    _append(data_dir, [row])
    return row


def read_ledger(data_dir: Path) -> pd.DataFrame:
    """Every ledger decision row, in the order written, with all LEDGER_COLUMNS as strings (self_approved, prev_hash
    and row_hash are '' for rows written before those columns existed). The "chain starts here" anchor row is left
    out; verify_ledger checks the chain."""
    p = ledger_path(data_dir)
    if not p.exists() or p.stat().st_size == 0:
        return pd.DataFrame(columns=LEDGER_COLUMNS)
    with open(p, newline="") as f:
        rows = list(csv.reader(f))
    header, body = rows[0], [r for r in rows[1:] if r]
    out = []
    for r in body:
        names = LEDGER_COLUMNS if len(r) > len(header) and header == LEDGER_COLUMNS[:len(header)] else header
        rec = dict(zip(names, r))
        if rec.get("table") == CHAIN_TABLE and rec.get("decision") == CHAIN_DECISION:
            continue                                     # the "chain starts here" row is not a decision (EQ-A-0103)
        out.append({c: (_unguard(rec.get(c, "")) if c in _UNGUARD_FIELDS else rec.get(c, "")) for c in LEDGER_COLUMNS})
    return pd.DataFrame(out, columns=LEDGER_COLUMNS, dtype=str)


def load_decisions(data_dir: Path) -> pd.DataFrame:
    """The latest decision per (table, key, country): the last row written for that cell (all ledger columns,
    including vintage_id, live and self_approved), plus `objection_by`: the author of a colleague's hold/reject still
    standing before that row ('' if none), which effective_holds uses (SEC-A-001 L3)."""
    led = read_ledger(data_dir)
    if led.empty:
        return led.assign(objection_by=pd.Series(dtype=str))
    latest = led.drop_duplicates(CELL, keep="last")
    obj = {}
    for cell, g in led.groupby(CELL, sort=False):
        obj[cell] = _standing_objection(g.iloc[:-1].itertuples(index=False))
    latest = latest.assign(objection_by=[obj[(r.table, r.key, r.country)] for r in latest.itertuples(index=False)])
    return latest.reset_index(drop=True)


def normalise_decision(text) -> str:
    """Map a decision cell to apply, hold, reject or '' (free text from the hand-edited review.csv: 'applied ...' is
    apply, 'kept on hold ...' is hold)."""
    t = str(text if text is not None else "").strip().lower()
    if t in ("", "nan"):
        return ""
    if t.startswith("appl"):
        return "apply"
    if t.startswith("reject"):
        return "reject"
    if "hold" in t or "keep seed" in t:
        return "hold"
    return ""


def import_legacy_review(data_dir: Path, now: dt.datetime | None = None, first_install: bool = False) -> dict:
    """One-off: when the ledger does not exist yet, copy the free-text decisions in the current review.csv into it,
    with author LEGACY_AUTHOR, no approver and the original text as note (EQ-A-0101, AGENT-08 decision 2026-10-25):
    - a row whose gate status is hold or missing (or anything but ok) is imported as decision 'hold': nobody can be
      named for a hand-edited 'applied ...', so the import never creates an apply; the note keeps what the text said
      ("[legacy 'apply' imported as hold] applied 2026-10-23: ..."), and the cell needs a named decision;
    - a row whose gate status is ok is skipped and counted: no legacy row may pin a gate-ok cell to seed, and the
      ledger has no decision that neither applies nor holds.
    Returns {"imported": rows written, "skipped_ok": gate-ok rows not imported}; does nothing (zeros) once the ledger
    exists. legacy_reset covers ledgers imported before this rule.
    The gate never writes status 'ok' with a reason (a reason always makes the cell 'hold' or 'missing'), so such a row
    is a hold whose status was hand-edited to 'ok' when it was accepted on review (the 2026-10-23 review.csv has 72):
    it is imported with gate_status 'hold' and a note saying so, so the ledger keeps the gate's verdict (EQ-A-0044).
    EQ-A-0103 (SEC-A-011 L5): when there is something to import, data/live/vintages holds vintages and review.csv or a
    vintage's review.csv records a named decision joined from a ledger (named_decision_evidence), the ledger was
    deleted or moved: a fresh import would turn every named decision into unnamed legacy holds and drop the named holds
    on gate-ok cells. It raises LedgerMissingError and writes nothing, unless `first_install=True`
    (`python -m econquest.ingestion.ledger import-legacy --first-install`). Legacy-only state (the repo's hand-edited
    review.csv, a ledger that only ever held legacy imports, synthetic fixtures) imports as before."""
    rev_p = Path(data_dir) / "live" / "review.csv"
    none = {"imported": 0, "skipped_ok": 0}
    if ledger_path(data_dir).exists() or not rev_p.exists():
        return none
    old = pd.read_csv(rev_p, dtype=str, keep_default_na=False)
    if "decision" not in old.columns:
        return none

    def gate_status(r) -> tuple[str, str]:
        st, reason = str(r.get("status", "")), str(r.get("reason", "") or "").strip()
        if st == "ok" and reason:
            return "hold", f"[gate held it ({reason}); review.csv status hand-edited to ok] "
        return st, ""

    rows, skipped = [], 0
    for _, r in old.iterrows():
        said = normalise_decision(r["decision"])
        if said:
            st, prefix = gate_status(r)
            if st == "ok":                       # gate passed it: a legacy row must not pin it to seed
                skipped += 1
                continue
            rows.append({"ts_utc": _ts(now), "vintage_id": "", "table": r["table"], "key": r["key"], "country": r["country"],
                         "gate_status": st, "live": r.get("live", ""), "decision": "hold",
                         "author": LEGACY_AUTHOR, "approver": "",
                         "note": prefix + f"[legacy '{said}' imported as hold] " + r["decision"]})
    if rows and not first_install:
        vint = _vintage_ids(data_dir)
        lost = named_decision_evidence(data_dir) if vint else []
        if lost:
            raise LedgerMissingError(
                f"refused: the review ledger {ledger_path(data_dir)} is missing but {len(vint)} vintage(s) exist under "
                f"{Path(data_dir).joinpath(*VINTAGES_REL)} and named decisions taken from a ledger are recorded in "
                f"{', '.join(lost)}; importing review.csv now would replace the decision history with {len(rows)} "
                f"unnamed legacy hold(s). If the ledger was deleted or moved, restore it from a backup "
                f"and check it with: python -m econquest.ingestion.ledger verify --data {Path(data_dir)}. Only for a "
                f"genuine first install, run once: python -m econquest.ingestion.ledger import-legacy --data "
                f"{Path(data_dir)} --first-install")
    if rows:
        _append(data_dir, rows)
    return {"imported": len(rows), "skipped_ok": skipped}


def legacy_reset(data_dir: Path, author: str, approver: str | None = None, self_approved: bool = False,
                 dry_run: bool = False, now: dt.datetime | None = None) -> list[dict]:
    """EQ-A-0101 cleanup for ledgers imported before import_legacy_review wrote holds (Sam's 0.5.0 install, 12:10:34Z:
    87 LEGACY_AUTHOR rows, 85 of them 'apply', Pakistan and Argentina 1.2 among them). Appends one 'hold' row by
    `author` per cell whose latest decision is by LEGACY_AUTHOR and whose recorded gate status is hold or missing, note
    LEGACY_RESET_NOTE, with that row's gate status and live value; vintage_id empty. Gate-ok cells are left alone: no
    legacy row may pin a gate-ok cell to seed (AGENT-08 decision 2026-10-25), and a legacy apply there is inert (the
    gate's ok applies it either way; tests/test_legacy_review_a101.py). Append-only: nothing is rewritten. A hold is
    sticky (effective_holds) until a named decision is recorded. Running it again finds nothing.
    `approver` / `self_approved` are stored as record_decision does (self_approved=True: approver = author, flag yes).
    dry_run=True returns the rows without writing. Returns the rows (to be) written."""
    author, approver = clean_person(author), clean_person(approver)
    if not person_key(author):
        raise ValueError("author is required")
    if person_key(author) == person_key(LEGACY_AUTHOR):
        raise ValueError("the reset must be authored by a named person")
    _refuse_legacy_name(approver)
    flag = ""
    if self_approved and (not person_key(approver) or person_key(approver) == person_key(author)):
        approver, flag = author, "yes"
    latest = load_decisions(data_dir)
    if latest.empty:
        return []
    legacy = latest[(latest["author"].map(person_key) == person_key(LEGACY_AUTHOR))
                    & latest["gate_status"].str.strip().isin(["hold", "missing"])]
    ts = _ts(now)
    rows = [{"ts_utc": ts, "vintage_id": "", "table": r.table, "key": str(r.key), "country": r.country,
             "gate_status": r.gate_status, "live": r.live, "decision": "hold", "author": author, "approver": approver,
             "note": LEGACY_RESET_NOTE, "self_approved": flag} for r in legacy.itertuples(index=False)]
    if rows and not dry_run:
        _append(data_dir, rows)
    return rows


def write_review(data_dir: Path, review: pd.DataFrame, now: dt.datetime | None = None,
                 first_install: bool = False) -> pd.DataFrame:
    """Write data/live/review.csv as the fresh gate output joined with the latest ledger decision per cell (columns
    decision, author, approver, self_approved, decided_utc) and return it. Use this instead of `review.to_csv`. The
    ledger is only read (after a one-off import of legacy free-text decisions), so the gate never deletes a decision.
    The import refuses (LedgerMissingError, nothing written) when the ledger is missing but vintages and named
    decisions exist, unless `first_install=True` (EQ-A-0103)."""
    import_legacy_review(data_dir, now, first_install=first_install)
    dec = load_decisions(data_dir)[CELL + ["decision", "author", "approver", "self_approved", "ts_utc"]].rename(columns={"ts_utc": "decided_utc"})
    base = review.drop(columns=[c for c in REVIEW_DECISION_COLUMNS if c in review.columns]).copy()
    base["key"] = base["key"].astype(str)
    merged = base.merge(dec, on=CELL, how="left")
    merged[REVIEW_DECISION_COLUMNS] = merged[REVIEW_DECISION_COLUMNS].fillna("")
    p = Path(data_dir) / "live" / "review.csv"; p.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=p.parent, prefix=".review.csv.", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", newline="") as f:
            merged.to_csv(f, index=False)
        os.chmod(tmp, 0o644); os.replace(tmp, p)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise
    return merged


def decisions_from_review(review: pd.DataFrame | None) -> pd.DataFrame:
    """Decisions carried in a review frame's decision / author / approver columns (as written by write_review, or free
    text from the hand-edited review.csv), in the shape of load_decisions. For display only: apply_report reads
    decisions from the ledger, never from a review frame (SEC-A-001)."""
    if review is None or "decision" not in review.columns:
        return pd.DataFrame(columns=LEDGER_COLUMNS)
    d = review.copy()
    d["decision"] = d["decision"].map(normalise_decision)
    for c in ("author", "approver", "self_approved", "vintage_id", "live"):
        d[c] = d[c].fillna("").astype(str) if c in d.columns else ""
    d["key"] = d["key"].astype(str)
    return d[d["decision"] != ""][CELL + ["decision", "author", "approver", "self_approved", "vintage_id", "live"]].reset_index(drop=True)


def _num(v) -> float | None:
    try:
        x = float(str(v).strip().lstrip("'"))
    except (TypeError, ValueError):
        return None
    return x if math.isfinite(x) else None


def _bound(d, row, review_vintage: str | None) -> bool:
    """True when decision d was made on what the review row now shows: same vintage (both known) or same live value
    within LIVE_REL_TOL / LIVE_ABS_TOL."""
    a, b = _num(getattr(d, "live", None)), _num(getattr(row, "live", None))
    if a is not None and b is not None:          # a decision that names a value binds to that value (SEC-A-001 L1)
        return math.isclose(a, b, rel_tol=LIVE_REL_TOL, abs_tol=LIVE_ABS_TOL)
    dv = str(getattr(d, "vintage_id", "") or "").strip()
    rv = str(getattr(row, "vintage_id", "") or "").strip() or str(review_vintage or "").strip()
    return dv not in ("", "nan") and rv not in ("", "nan") and Path(dv).name == Path(rv).name


def _approved(d) -> bool:
    """An 'apply' with a four-eyes approver, or a flagged single-operator self-approval."""
    if d is None or str(d.decision) != "apply":
        return False
    author, approver = person_key(getattr(d, "author", "")), person_key(getattr(d, "approver", ""))
    if not author or not approver:
        return False
    return approver != author or str(getattr(d, "self_approved", "") or "").strip().lower() == "yes"


# EQ-A-0096 (F8, AGENT-08 2026-10-25): gate reasons whose hold only a named, vintage-bound decision releases
STRICT_HOLD_REASONS = ("dsa_reseed:",)


def _strict_release(d, row, review_vintage: str | None) -> bool:
    """For a STRICT_HOLD_REASONS hold: the apply names its author (not LEGACY_AUTHOR, e.g. Pakistan / Argentina 1.2
    'apply' rows imported from the zip's seed review.csv) and is bound to this review's vintage by vintage_id (a live
    value match alone is not enough)."""
    if person_key(getattr(d, "author", "")) in ("", person_key(LEGACY_AUTHOR)):
        return False
    dv = str(getattr(d, "vintage_id", "") or "").strip()
    rv = str(getattr(row, "vintage_id", "") or "").strip() or str(review_vintage or "").strip()
    return dv not in ("", "nan") and rv not in ("", "nan") and Path(dv).name == Path(rv).name


def effective_holds(review: pd.DataFrame | None, decisions: pd.DataFrame | None, vintage_id: str | None = None) -> set:
    """Cells (table, key, country) apply_report must not apply:
    - gate status 'hold', unless the latest decision is an approved 'apply' (four-eyes, or flagged self-approval)
      bound to this review: its vintage_id equals the review's vintage (row column `vintage_id`, else the
      `vintage_id` argument) or its `live` equals the review's live value (rel tol 1e-6, abs 1e-9);
    - any cell whose latest decision is 'hold' or 'reject', even when the gate passed it (sticky across vintages);
    - any cell where an apply by someone else follows a hold/reject without _approved (SEC-A-001 L3), gate ok or not;
    - a hold whose reason carries a STRICT_HOLD_REASONS check (dsa_reseed, EQ-A-0096 F8) unless that apply also names
      its author and is bound to this vintage by vintage_id (_strict_release).
    A hold/reject by LEGACY_AUTHOR (imported from the hand-edited review.csv) never pins a cell this review's gate
    passes ('ok'): it holds only while the gate holds the cell or has no value for it (EQ-A-0101, AGENT-08 decision
    2026-10-25: no legacy row may pin a gate-ok cell to seed). A named person's hold stays sticky.
    `decisions` is load_decisions (latest row per cell with objection_by) or the full ledger in written order."""
    latest, history = {}, {}
    if decisions is not None and len(decisions):
        for r in decisions.itertuples(index=False):
            cell = (r.table, str(r.key), r.country)
            latest[cell] = r
            history.setdefault(cell, []).append(r)
    out = set()
    gate_ok = set()
    if review is not None:
        for r in review.itertuples(index=False):
            cell = (r.table, str(r.key), r.country)
            if r.status == "ok":
                gate_ok.add(cell)
            if r.status == "hold":
                d = latest.get(cell)
                if not (_approved(d) and _bound(d, r, vintage_id)):
                    out.add(cell)
                elif (any(x in str(getattr(r, "reason", "") or "") for x in STRICT_HOLD_REASONS)
                      and not _strict_release(d, r, vintage_id)):
                    out.add(cell)
    legacy = person_key(LEGACY_AUTHOR)

    def pins(cell, who) -> bool:                  # a legacy objection never pins a gate-ok cell (EQ-A-0101)
        return not (cell in gate_ok and person_key(who) == legacy)
    out |= {cell for cell, d in latest.items() if d.decision in ("hold", "reject") and pins(cell, getattr(d, "author", ""))}
    for cell, rows in history.items():
        who = _standing_objection(rows)
        if who and pins(cell, who):
            out.add(cell)
    return out


# ---- Hand-entered cells (EQ-A-0018) ----------------------------------------------------------------------------------
# file -> how a cell is identified. Wide files have one cell per (row, country column); long files one cell per row.
HAND_ENTERED = {
    "adjustments.csv": {"key": ("block", "pillar"), "fixed": ("block", "pillar", "item", "rule"), "wide": True,
                        "label": ("block", "item")},
    "cds_quotes.csv": {"key": ("date", "tenor_y"), "country": "country", "value": "spread_bp",
                       "label": ("date", "tenor_y", "source")},
    "prediction_markets.csv": {"key": ("id",), "country": "country", "value": "yes_price", "label": ("contract",)},
    # EQ-A-0072: official FX rates typed from central-bank pages (feeds.fx_manual_cells). Long: content_sha256 covers
    # the whole row, so editing rate_3m, either date, the source or the url withdraws the attestation as rate_now does.
    "fx_manual.csv": {"key": ("currency", "date_now"), "country": "country", "value": "rate_now",
                      "label": ("currency", "date_now", "date_3m", "source")},
}
ATTEST_NOTE = "attested hand-entered cell"
ATTEST_COLUMNS = ["table", "key", "country", "label", "value", "content_sha256", "attested", "author", "approver",
                  "self_approved", "attested_utc"]


def _hand_file(file) -> str:
    name = str(file)
    name = name if name.endswith(".csv") else name + ".csv"
    if name not in HAND_ENTERED:                         # a bare file name only: never a path
        raise ValueError(f"not a hand-entered file: {file!r} (one of {sorted(HAND_ENTERED)})")
    return name


def hand_entered_cells(data_dir: Path, file) -> list[dict]:
    """The cells of one hand-entered file as dicts: table (file stem), key, country, label, value (raw text) and
    content_sha256 (SHA-256 over the file stem, key, country and the raw text of every field that defines the cell:
    the whole row for long files, the row's descriptive columns plus that country's value for wide ones)."""
    name = _hand_file(file)
    spec, p = HAND_ENTERED[name], Path(data_dir) / name
    if not p.exists():
        return []
    with open(p, newline="") as f:
        rd = csv.DictReader(f)
        cols, rows = list(rd.fieldnames or []), list(rd)
    stem = name[:-4]
    out = []

    def add(r, country, value, fields):
        key = "|".join(str(r.get(k, "") or "").strip() for k in spec["key"])
        blob = json.dumps({"file": stem, "key": key, "country": country, "fields": fields}, sort_keys=True,
                          ensure_ascii=False)
        out.append({"table": stem, "key": key, "country": country,
                    "label": " | ".join(str(r.get(k, "") or "").strip() for k in spec["label"] if r.get(k)),
                    "value": value, "content_sha256": hashlib.sha256(blob.encode()).hexdigest()})

    for r in rows:
        if spec.get("wide"):
            fixed = {c: r.get(c, "") for c in spec["fixed"]}
            for c in cols:
                if c not in spec["fixed"]:
                    add(r, c, r.get(c, "") or "", {**fixed, c: r.get(c, "") or ""})
        else:
            add(r, str(r.get(spec["country"], "") or "").strip(), r.get(spec["value"], "") or "",
                {c: r.get(c, "") or "" for c in cols})
    return out


def _attest_live(value: str):
    x = _num(value)
    return x if x is not None else value


def attest_cells(data_dir: Path, file, author: str, approver: str | None = None, self_approved: bool = False,
                 note: str = "", all_cells: bool = False, now: dt.datetime | None = None,
                 only: set[tuple[str, str]] | None = None) -> list[dict]:
    """Record that `author` entered, and `approver` checked, the current content of a hand-entered file: one ledger row
    per cell (table = file stem, key, country, decision 'apply', live = value, content_sha256). Four-eyes as for gate
    holds: an approver other than the author, or `self_approved=True` (flagged 'yes'); ValueError before anything is
    written otherwise. By default only cells whose current content is not yet attested are written (`all_cells=True`
    re-attests every cell). `only`, a set of (key, country), limits the rows to those cells (HO-20261024-C-A-005).
    Returns the rows written."""
    name = _hand_file(file)
    author, approver, flag = check_approval(author, approver, self_approved)
    cells = hand_entered_cells(data_dir, name)
    if not all_cells:
        todo = {(c["table"], c["key"], c["country"], c["content_sha256"]) for c in unattested_cells(data_dir, [name])}
        cells = [c for c in cells if (c["table"], c["key"], c["country"], c["content_sha256"]) in todo]
    if only is not None:
        cells = [c for c in cells if (c["key"], c["country"]) in only]
    ts = _ts(now)
    rows = [{"ts_utc": ts, "vintage_id": "", "table": c["table"], "key": c["key"], "country": c["country"],
             "gate_status": "", "live": _attest_live(c["value"]), "decision": "apply", "author": author,
             "approver": approver, "note": (note or ATTEST_NOTE), "self_approved": flag,
             "content_sha256": c["content_sha256"]} for c in cells]
    if rows:
        _append(data_dir, rows)
    return rows


def attestation_status(data_dir: Path, files=None) -> list[dict]:
    """Every cell of the hand-entered files (all of HAND_ENTERED by default) with its attestation: attested 'yes'
    when the ledger holds an approved 'apply' (_approved) for that cell with the cell's current content_sha256 and no
    later hold/reject on the cell; then author, approver, self_approved and attested_utc of that row. 'no' otherwise
    (never attested, or the content changed since, or a later hold/reject)."""
    files = [_hand_file(f) for f in (files or HAND_ENTERED)]
    led = read_ledger(data_dir)
    led = led[led["table"].isin([f[:-4] for f in files])]
    best: dict = {}                                      # cell -> {content_sha256: latest approved attestation row}
    for r in led.itertuples(index=False):
        cell = (r.table, r.key, r.country)
        if r.decision in ("hold", "reject"):
            best.pop(cell, None)                         # a later hold/reject withdraws every earlier attestation
        elif r.decision == "apply" and r.content_sha256 and _approved(r):
            best.setdefault(cell, {})[r.content_sha256] = r
    out = []
    for f in files:
        for c in hand_entered_cells(data_dir, f):
            r = (best.get((c["table"], c["key"], c["country"])) or {}).get(c["content_sha256"])
            out.append({**c, "attested": "yes" if r is not None else "no",
                        "author": r.author if r is not None else "", "approver": r.approver if r is not None else "",
                        "self_approved": r.self_approved if r is not None else "",
                        "attested_utc": r.ts_utc if r is not None else ""})
    return out


def unattested_cells(data_dir: Path, files=None) -> list[dict]:
    """The hand-entered cells whose current content has no matching attestation (see attestation_status). Report
    only: loading never blocks on these (whether it should is a policy decision for Sam)."""
    return [c for c in attestation_status(data_dir, files) if c["attested"] != "yes"]


# ---- Attested rows of other append-only tables (EQ-A-0032, additive) -------------------------------------------------
def attest_rows(data_dir: Path, table: str, cells: list[dict], author: str, approver: str | None = None,
                self_approved: bool = False, note: str = "", now: dt.datetime | None = None) -> list[dict]:
    """Like attest_cells, for rows that do not live in a HAND_ENTERED file (e.g. data/live/market/manual_quotes.csv):
    one 'apply' ledger row per cell dict (key, country, value, content_sha256) under `table`. Four-eyes via
    check_approval (ValueError before anything is written). Returns the rows written."""
    if not isinstance(table, str) or not table.replace("_", "").isalnum() or table + ".csv" in HAND_ENTERED:
        raise ValueError(f"bad attestation table {table!r}")
    author, approver, flag = check_approval(author, approver, self_approved)
    ts = _ts(now)
    rows = []
    for c in cells:
        if not str(c.get("content_sha256", "")).strip():
            raise ValueError("every attested cell needs a content_sha256")
        rows.append({"ts_utc": ts, "vintage_id": c.get("vintage_id", ""), "table": table, "key": str(c["key"]),
                     "country": str(c.get("country", "") or ""), "gate_status": "",
                     "live": _attest_live(str(c.get("value", ""))), "decision": "apply", "author": author,
                     "approver": approver, "note": (note or ATTEST_NOTE), "self_approved": flag,
                     "content_sha256": c["content_sha256"]})
    if rows:
        _append(data_dir, rows)
    return rows


def attested_content(data_dir: Path, table: str) -> dict:
    """(key, country) -> {content_sha256: latest approved 'apply' ledger row} for one table, with the same rule as
    attestation_status: a later hold/reject on the cell withdraws every earlier attestation."""
    led = read_ledger(data_dir)
    best: dict = {}
    for r in led[led["table"] == table].itertuples(index=False):
        cell = (r.key, r.country)
        if r.decision in ("hold", "reject"):
            best.pop(cell, None)
        elif r.decision == "apply" and r.content_sha256 and _approved(r):
            best.setdefault(cell, {})[r.content_sha256] = r
    return best


# ---- command line (EQ-A-0101, EQ-A-0103) -----------------------------------------------------------------------------
# Until Team C wires these into cli.py:
#     python -m econquest.ingestion.ledger legacy-reset --data data --author Sam --self-approved [--dry-run]
#     python -m econquest.ingestion.ledger verify --data data [--json]          exit 1 on a broken chain
#     python -m econquest.ingestion.ledger import-legacy --data data --first-install

def print_verify(st: dict, out=None) -> None:
    import sys
    out = out or sys.stdout
    if not st["exists"]:
        print(f"review ledger: none at {st['path']}", file=out)
    else:
        print(f"review ledger {st['path']}: {st['rows']} row(s): {st['chained']} chained"
              + (" (anchor included)" if st["anchor"] else "") + f", {st['legacy_unchained']} legacy unchained", file=out)
        print(f"head: seq {st['head']['seq']} row_hash {st['head']['row_hash']}", file=out)
    for n in st["notes"]:
        print(f"note: {n}", file=out)
    for b in st["problems"]:
        print(f"BROKEN: {b}", file=out)
    print("RESULT: " + ("ok" if st["ok"] else f"BROKEN ({len(st['problems'])} problem(s))"), file=out)

def main(argv: list[str] | None = None) -> int:
    import argparse
    import sys
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.ledger",
                                 description="Review ledger maintenance (offline, append-only).")
    sub = ap.add_subparsers(dest="cmd", required=True)
    lr = sub.add_parser("legacy-reset", help="one 'hold' row per gate-held or missing cell whose latest decision was "
                                             "imported from the hand-edited review.csv (author LEGACY_AUTHOR); gate-ok "
                                             "cells are left alone; needs a named decision after")
    lr.add_argument("--data", default="data", help="econquest data folder (default data)")
    lr.add_argument("--author", required=True)
    lr.add_argument("--approver")
    lr.add_argument("--self-approved", action="store_true", help="single-operator mode: approver = author, flagged")
    lr.add_argument("--dry-run", action="store_true", help="list the cells, write nothing")
    vf = sub.add_parser("verify", help="recompute the hash chain (EQ-A-0103); exit 1 on a break, 0 when intact "
                                       "(legacy rows written before the chain are reported as unchained, not as tampered)")
    vf.add_argument("--data", default="data", help="econquest data folder (default data)")
    vf.add_argument("--json", action="store_true", help="print the result as JSON")
    il = sub.add_parser("import-legacy", help="one-off import of the decision column of data/live/review.csv into a new "
                                              "ledger as unnamed legacy holds; refused while vintages exist unless "
                                              "--first-install")
    il.add_argument("--data", default="data", help="econquest data folder (default data)")
    il.add_argument("--first-install", action="store_true",
                    help="this is a genuine first install: import even though vintages already exist")
    a = ap.parse_args(argv)
    d = Path(a.data)
    if a.cmd == "verify":
        st = verify_ledger(d)
        if a.json:
            print(json.dumps(st, indent=1, sort_keys=True))
        else:
            print_verify(st)
        return 0 if st["ok"] else 1
    if a.cmd == "import-legacy":
        if ledger_path(d).exists():
            print(f"nothing to do: {ledger_path(d)} already exists", file=sys.stderr)
            return 0
        try:
            res = import_legacy_review(d, first_install=a.first_install)
        except (LedgerMissingError, LedgerChainError) as e:
            print(f"error: {e}", file=sys.stderr)
            return 2
        print(f"imported {res['imported']} legacy hold row(s), skipped {res['skipped_ok']} gate-ok row(s)"
              + (f" into {ledger_path(d)}" if res["imported"] else ""))
        return 0
    if not ledger_path(d).is_file():
        print(f"error: no ledger at {ledger_path(d)} (run from the econquest folder)", file=sys.stderr)
        return 2
    try:
        rows = legacy_reset(d, a.author, a.approver, a.self_approved, dry_run=a.dry_run)
    except ValueError as e:
        print(f"error: {e}", file=sys.stderr)
        return 2
    for r in rows:
        print(f"  {r['table']} | {r['key']} | {r['country']}  gate {r['gate_status'] or '-'}  -> hold")
    verb = "would write" if a.dry_run else "wrote"
    print(f"{verb} {len(rows)} hold row(s) to {ledger_path(d)}" + (" (dry run: nothing written)" if a.dry_run else "")
          + ("; each cell now needs a named apply/hold/reject" if rows and not a.dry_run else ""))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
