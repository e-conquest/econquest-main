"""Point-in-time WEO vintage archive (EQ-A-0064): every IMF World Economic Outlook release as an immutable, verified
vintage, for the nowcast (Team B, EQ-B-0071) and the hazard refit.

Nothing is downloaded here. The releases come from what ``panel_history`` (EQ-A-0010/0015) already pulled on Sam's Mac:
a staging run folder (``data/panel/staging/<run_id>/``: manifest.json + weo/<YYYY-MM>.csv) or the assembled
``data/panel/weo_history.csv``, plus the WEO file cache (``data/panel/staging/weo_cache/weo_<YYYY-MM>.xls``).

    python -m econquest.ingestion.weo_vintages import --from data/panel/staging/<run_id> [--cache-dir DIR] [--releases 2007-10:2026-10]
    python -m econquest.ingestion.weo_vintages import --from data/panel/weo_history.csv
    python -m econquest.ingestion.weo_vintages verify [RELEASE ...]
    python -m econquest.ingestion.weo_vintages list
    python -m econquest.ingestion.weo_vintages asof --as-of 2019-12-31 [--indicators NGDP_RPCH,PCPIPCH] [--countries BRA,TUR] [--out F]
(all take ``--root``, default ``data/panel/weo_vintages``)

Layout, one folder per release, written once and never changed (files 0444, folder 0555)::

    <root>/<YYYY-MM>/raw_<name>       the file as downloaded (or the panel_history extract, see raw kinds)
    <root>/<YYYY-MM>/raw.sha256       "<sha256>  raw_<name>" (sha256sum format)
    <root>/<YYYY-MM>/weo_long.csv     iso3, indicator, year, value, vintage, release_date
    <root>/<YYYY-MM>/manifest.json    source, method, route, licence, release date and its basis, hashes, provenance
    <root>/index.csv                  append-only, one row per release (content_hash over every file in the folder)

Raw kinds. ``release_file``: the WEO "all countries" tab file that panel_history downloaded through the weo package
(or a manual drop-in it read), byte for byte; the normalised file then holds every subject code and economy in it, and
the staged panel_history rows are checked against it (a cache file that is not the one panel_history parsed is
refused). ``panel_history_extract``: imf-reader and, since EQ-A-0068, the IMF SDMX 3.0 API route (official/imf_weo.py,
manifest route ``imf-api``) return a parsed table, not a file, so panel_history kept no download for those releases
(2019-04 .. 2025-04 except 2021-04 and 2023-10 through imf-reader; 2025-04 onward through the API); the raw file
is then the panel_history rows (hazard_panel.WEO_CODES only) in a canonical CSV, and the manifest says so.

Release dates. The IMF's exact publication day is not recorded anywhere in the pull, so it is not guessed: every
vintage gets the last calendar day of its release month (2019-04 -> 2019-04-30; the autumn 2011 release, 2011-09 ->
2011-09-30), ``release_date_basis = estimated``. WEO databases are normally published in the middle of the release
month, so the rule is late, i.e. conservative: ``weo_asof`` may show the previous release for a couple of weeks after
the real publication, but never a release before it was public. A release published after the end of its month would
break that; none is known, not verified.

Immutability. ``import`` builds a release in a temp folder and renames it into place. If the release already exists:
same raw and normalised hashes -> ``unchanged`` (no-op); an extract whose rows are all in the existing vintage with the
same values -> ``covered`` (no-op); anything else -> ``refused`` (exit 1, nothing written). There is no overwrite.

``weo_asof(as_of, indicators, countries)`` returns the rows of the latest release whose release_date <= as_of (no
look-ahead), after verifying that release. Point in time starts with the first archived release (October 2007 from the
packages); earlier as-of dates raise NoVintageError: Team B's rule for earlier years applies (HO-20261023-A-B-007).

Licence: IMF terms (docs/governance/issues-log.md EXC-003): internal research use only; disclosure to the
independent model validator under NDA is allowed (Sam 2026-10-24). Recorded in every manifest.
"""
from __future__ import annotations

import argparse
import calendar
import csv
import datetime as dt
import hashlib
import io
import json
import os
import re
import shutil
import stat
import sys
import tempfile
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd

from .official import IMF_LICENCE
from .panel_history import (FetchUnitError, RUN_ID_RE, _parse_vintage_arg, normalise_vintage, parse_weo_tab,
                            sha256_file)

DEFAULT_ROOT = Path("data") / "panel" / "weo_vintages"
SCHEMA = "weo_vintage/1"
TICKET = "EQ-A-0064"
LONG_COLUMNS = ["iso3", "indicator", "year", "value", "vintage", "release_date"]
EXTRACT_COLUMNS = ["iso", "series", "period", "value", "source"]
INDEX_COLUMNS = ["release", "release_date", "release_date_basis", "imported_utc", "content_hash", "n_files", "raw_kind",
                 "raw_sha256", "normalised_sha256", "rows", "n_countries", "n_indicators", "route"]
NORMALISED = "weo_long.csv"
MANIFEST = "manifest.json"
RAW_SHA = "raw.sha256"
LICENCE = IMF_LICENCE + "; disclosure to the independent model validator under NDA allowed (Sam 2026-10-24)"
RELEASE_DATE_RULE = ("last calendar day of the release month; the IMF's exact publication day is not recorded, and WEO "
                     "databases are normally published mid-month, so the date is late (conservative), never early")
RELEASE_RE = re.compile(r"\d{4}-\d{2}")
ISO3_RE = re.compile(r"[A-Z][A-Z0-9]{2}")
CODE_RE = re.compile(r"[A-Z][A-Z0-9_]{0,63}")
_LOCAL_RE = re.compile(r"local file (weo_\d{4}-\d{2}\.(?:xls|csv|tsv|txt)) sha256:([0-9a-f]{16})")
_TOL = 1e-9


class WeoVintageError(ValueError):
    """An import was refused (conflict, bad input) or a vintage failed verification."""


class NoVintageError(LookupError):
    """No archived WEO release was published on or before the as-of date."""


# ------------------------------------------------------------------------------------------ helpers

def _utc(now: dt.datetime | None = None) -> dt.datetime:
    now = now or dt.datetime.now(dt.timezone.utc)
    return now.replace(tzinfo=dt.timezone.utc) if now.tzinfo is None else now.astimezone(dt.timezone.utc)


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _content_hash(files: dict[str, bytes]) -> str:
    """SHA-256 over the files in name order (name, NUL, content, NUL), as feeds/panel_history vintages."""
    h = hashlib.sha256()
    for name in sorted(files):
        h.update(name.encode() + b"\0" + files[name] + b"\0")
    return h.hexdigest()


def release_date_for(release: str) -> str:
    """Documented conservative rule: last calendar day of the release month ('2019-04' -> '2019-04-30')."""
    release = normalise_vintage(release)
    y, m = int(release[:4]), int(release[5:])
    return dt.date(y, m, calendar.monthrange(y, m)[1]).isoformat()


def _as_date(x) -> dt.date:
    if isinstance(x, dt.datetime):
        return x.date()
    if isinstance(x, dt.date):
        return x
    if isinstance(x, pd.Timestamp):
        return x.date()
    s = str(x).strip()
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", s):
        raise ValueError(f"as_of must be a date YYYY-MM-DD, got {x!r}")
    return dt.date.fromisoformat(s)


def _route(source: str) -> str:
    s = str(source)
    if "via IMF SDMX 3.0 API" in s:                  # EQ-A-0068 route (official/imf_weo.py): a parsed table, no file
        return "imf-api"
    if "via imf-reader" in s:
        return "imf-reader"
    if "via weo package" in s:
        return "weo-package"
    if "local file" in s:
        return "local-file"
    return "unknown"


def _csv_bytes(df: pd.DataFrame) -> bytes:
    return df.to_csv(index=False, lineterminator="\n").encode()


def _canonical_extract(df: pd.DataFrame) -> pd.DataFrame:
    d = df[EXTRACT_COLUMNS].copy()
    d["iso"] = d["iso"].astype(str).str.strip()
    d["series"] = d["series"].astype(str).str.strip()
    d["period"] = pd.to_numeric(d["period"], errors="coerce")
    d["value"] = pd.to_numeric(d["value"], errors="coerce")
    d = d.dropna(subset=["period", "value"])
    d["period"] = d["period"].astype(int)
    return d.sort_values(["iso", "series", "period"], kind="stable").reset_index(drop=True)


def _normalise(rows: pd.DataFrame, release: str, release_date: str) -> pd.DataFrame:
    """iso/series/period/value rows -> the archive's long schema; rows with a non-ISO3 code, a non-WEO subject code or
    no value are dropped; conflicting duplicates raise (an exact duplicate is kept once)."""
    d = pd.DataFrame({"iso3": rows["iso"].astype(str).str.strip(), "indicator": rows["series"].astype(str).str.strip(),
                      "year": pd.to_numeric(rows["period"], errors="coerce"),
                      "value": pd.to_numeric(rows["value"], errors="coerce")})
    d = d.dropna(subset=["year", "value"])
    d = d[d["iso3"].str.fullmatch(ISO3_RE.pattern) & d["indicator"].str.fullmatch(CODE_RE.pattern)
          & np.isfinite(d["value"])]
    d["year"] = d["year"].astype(int)
    d = d.drop_duplicates()
    dup = d[d.duplicated(["iso3", "indicator", "year"], keep=False)]
    if len(dup):
        ex = dup.head(3).to_dict("records")
        raise WeoVintageError(f"WEO {release}: {len(dup)} rows give two values for one (iso3, indicator, year), e.g. {ex}")
    if d.empty:
        raise WeoVintageError(f"WEO {release}: no usable rows")
    d["vintage"] = release
    d["release_date"] = release_date
    return d.sort_values(["iso3", "indicator", "year"], kind="stable").reset_index(drop=True)[LONG_COLUMNS]


def _compare_subset(sub: pd.DataFrame, full: pd.DataFrame) -> tuple[int, int]:
    """(rows of `sub` missing from `full`, rows whose values differ); both in the long schema."""
    k = ["iso3", "indicator", "year"]
    m = sub[k + ["value"]].merge(full[k + ["value"]], on=k, how="left", suffixes=("", "_full"))
    missing = int(m["value_full"].isna().sum())
    both = m.dropna(subset=["value_full"])
    diff = ~np.isclose(both["value"].to_numpy(float), both["value_full"].to_numpy(float), rtol=_TOL, atol=_TOL)
    return missing, int(diff.sum())


def _read_long(path: Path) -> pd.DataFrame:
    return pd.read_csv(path, dtype={"iso3": str, "indicator": str, "vintage": str, "release_date": str},
                       keep_default_na=False, na_values=[""])


# ------------------------------------------------------------------------------------------ sources

def _release_inputs(src: Path, cache_dir: Path | None, releases: Iterable[str] | None) -> tuple[list[dict], list[dict]]:
    """Read panel_history output. Returns (inputs, refusals). Each input: release, rows (iso, series, period, value,
    source), source, provenance; refusals: release, reason."""
    want = set(releases) if releases is not None else None
    inputs, refusals = [], []
    if src.is_dir() and (src / "manifest.json").is_file():                      # one staging run
        if not RUN_ID_RE.fullmatch(src.name):
            raise WeoVintageError(f"{src}: not a panel_history staging run folder (name YYYYMMDDTHHMMSSZ[-n])")
        man = json.loads((src / "manifest.json").read_text())
        cache = cache_dir or (src.parent / "weo_cache")
        for unit, rec in sorted(man.get("units", {}).items()):
            if not unit.startswith("weo/"):
                continue
            rel = unit.split("/", 1)[1]
            if not RELEASE_RE.fullmatch(rel) or (want is not None and rel not in want):
                continue
            f = src / "weo" / f"{rel}.csv"
            if rec.get("status") != "ok" or not f.is_file():
                refusals.append({"release": rel, "reason": f"unit {unit} is not ok in run {src.name} ({rec.get('status')})"})
                continue
            if sha256_file(f) != rec.get("sha256"):
                refusals.append({"release": rel, "reason": f"staged {f.name} does not match the run manifest sha256"})
                continue
            rows = pd.read_csv(f, dtype={"iso": str, "series": str, "vintage": str}, keep_default_na=False, na_values=[""])
            inputs.append({"release": rel, "rows": rows, "source": str(rec.get("source", "")), "cache": cache,
                           "provenance": {"kind": "panel_history_staging_run", "run_id": man.get("run_id", src.name),
                                          "unit": unit, "staged_file": f"weo/{rel}.csv", "staged_sha256": rec.get("sha256"),
                                          "fetched_utc": rec.get("fetched_utc", "")}})
    elif src.is_file():                                                           # assembled weo_history.csv
        df = pd.read_csv(src, dtype={"iso": str, "series": str, "vintage": str}, keep_default_na=False, na_values=[""])
        miss = [c for c in EXTRACT_COLUMNS + ["vintage"] if c not in df.columns]
        if miss:
            raise WeoVintageError(f"{src}: not a panel_history weo_history.csv (missing {miss})")
        cache = cache_dir or (src.parent / "staging" / "weo_cache")
        digest = sha256_file(src)
        for rel, rows in df.groupby("vintage", sort=True):
            rel = str(rel)
            if not RELEASE_RE.fullmatch(rel) or (want is not None and rel not in want):
                continue
            srcs = sorted(set(rows["source"].astype(str)))
            if len(srcs) != 1:
                refusals.append({"release": rel, "reason": f"{len(srcs)} different source strings in {src.name}"})
                continue
            inputs.append({"release": rel, "rows": rows, "source": srcs[0], "cache": cache,
                           "provenance": {"kind": "panel_history_weo_history_csv", "file": src.name, "file_sha256": digest}})
    else:
        if not src.exists():
            raise WeoVintageError(f"{src} does not exist (panel_history has not written it yet: run the history pull "
                                  "on the Mac first, docs/runbooks/A-full-panel-fetch.md)")
        raise WeoVintageError(f"{src}: give a panel_history staging run folder (data/panel/staging/<run_id>) or "
                              "data/panel/weo_history.csv")
    if want is not None:
        seen = {i["release"] for i in inputs} | {r["release"] for r in refusals}
        refusals += [{"release": r, "reason": f"not in {src}"} for r in sorted(want - seen)]
    return inputs, refusals


def _build(inp: dict, allow_extract: bool, now: dt.datetime) -> dict[str, bytes]:
    """Files of one release vintage (name -> bytes). Raises WeoVintageError when the input is refused."""
    rel = normalise_vintage(inp["release"])
    rdate = release_date_for(rel)
    route = _route(inp["source"])
    staged = _normalise(_canonical_extract(inp["rows"]), rel, rdate)
    raw_path, cross = None, {}
    if route in ("weo-package", "local-file"):
        cache = Path(inp["cache"])
        if route == "local-file":
            m = _LOCAL_RE.search(inp["source"])
            cand = cache / m.group(1) if m else None
            if cand is not None and cand.is_file() and sha256_file(cand)[:16] != m.group(2):
                raise WeoVintageError(f"WEO {rel}: {cand} has changed since panel_history read it (sha256 prefix "
                                      f"{sha256_file(cand)[:16]} != {m.group(2)} in the source string)")
        else:
            cand = cache / f"weo_{rel}.xls"
        if cand is not None and cand.is_file():
            raw_path = cand
        elif not allow_extract:
            raise WeoVintageError(f"WEO {rel}: route {route} but the downloaded file {cand} is not there; pass "
                                  "--cache-dir, or --allow-extract to archive only the panel_history rows")
    if raw_path is not None:
        try:
            full = _normalise(parse_weo_tab(raw_path, None), rel, rdate)
        except FetchUnitError as e:
            raise WeoVintageError(f"WEO {rel}: {raw_path.name} is not a WEO release file: {e}") from e
        missing, diff = _compare_subset(staged, full)
        if missing or diff:
            raise WeoVintageError(f"WEO {rel}: {raw_path.name} is not the file panel_history parsed ({missing} staged rows "
                                  f"missing, {diff} with other values)")
        raw_name, raw_bytes, kind, long = f"raw_{raw_path.name}", raw_path.read_bytes(), "release_file", full
        cross = {"staged_rows": len(staged), "staged_rows_missing": 0, "staged_rows_differing": 0}
        method = (f"raw = the WEO tab file panel_history used ({route}), byte for byte; weo_long.csv = every subject code "
                  "and economy parsed from it (panel_history.parse_weo_tab); panel_history's staged rows checked equal")
    else:
        raw_name, kind, long = f"raw_panel_history_{rel}.csv", "panel_history_extract", staged
        raw_bytes = _csv_bytes(_canonical_extract(inp["rows"]))
        method = (f"route {route}: panel_history kept no downloaded file for this release (imf-api and imf-reader "
                  "return a parsed table), so raw = panel_history's rows (hazard_panel.WEO_CODES only) as canonical CSV, "
                  "not the IMF's file; weo_long.csv = those rows")
    norm = _csv_bytes(long)
    years = [int(long["year"].min()), int(long["year"].max())]
    manifest = {
        "schema": SCHEMA, "ticket": TICKET, "release": rel,
        "release_label": f"IMF World Economic Outlook database, {calendar.month_name[int(rel[5:])]} {rel[:4]}",
        "release_date": rdate, "release_date_basis": "estimated", "release_date_rule": RELEASE_DATE_RULE,
        "source": inp["source"], "route": route, "method": method, "licence": LICENCE,
        "raw": {"file": raw_name, "kind": kind, "sha256": _sha(raw_bytes), "bytes": len(raw_bytes)},
        "normalised": {"file": NORMALISED, "sha256": _sha(norm), "rows": len(long), "columns": LONG_COLUMNS,
                       "n_countries": int(long["iso3"].nunique()), "indicators": sorted(long["indicator"].unique()),
                       "years": years},
        "cross_check": cross, "imported_from": inp["provenance"],
        "imported_utc": now.strftime("%Y-%m-%dT%H:%M:%SZ"), "imported_by": "econquest.ingestion.weo_vintages",
    }
    return {raw_name: raw_bytes, RAW_SHA: f"{_sha(raw_bytes)}  {raw_name}\n".encode(), NORMALISED: norm,
            MANIFEST: json.dumps(manifest, indent=1, sort_keys=True).encode()}


# ------------------------------------------------------------------------------------------ store

def _index_rows(root: Path) -> list[dict]:
    idx = Path(root) / "index.csv"
    if not idx.exists():
        return []
    with open(idx, newline="") as f:
        return list(csv.DictReader(f))


def list_releases(root: str | Path = DEFAULT_ROOT) -> list[str]:
    root = Path(root)
    return sorted(p.name for p in root.iterdir() if p.is_dir() and RELEASE_RE.fullmatch(p.name)) if root.exists() else []


def _read_manifest(folder: Path) -> dict:
    return json.loads((folder / MANIFEST).read_text())


def verify_release(root: str | Path, release: str) -> dict:
    """Check one release folder against its manifest and its first index.csv row. Returns {release, ok, problems,
    warnings, content_hash}. Problems: missing/extra files, hash mismatches (raw, raw.sha256, weo_long.csv, whole folder
    vs index), vintage/release_date columns that disagree with the manifest, a release_date that does not follow the
    rule, index rows that disagree with each other. Warnings: writable files or folder."""
    root, release = Path(root), str(release)
    folder = root / release
    out = {"release": release, "ok": False, "problems": [], "warnings": [], "content_hash": ""}
    p = out["problems"]
    if not RELEASE_RE.fullmatch(release) or not folder.is_dir() or folder.is_symlink():
        p.append(f"no release folder {folder}")
        return out
    try:
        man = _read_manifest(folder)
    except (OSError, ValueError) as e:
        p.append(f"manifest.json unreadable: {e}")
        return out
    names = {q.name for q in folder.iterdir()}
    raw_name = str(man.get("raw", {}).get("file", ""))
    want = {MANIFEST, RAW_SHA, NORMALISED, raw_name}
    if names - want:
        p.append(f"extra files {sorted(names - want)}")
    if want - names:
        p.append(f"missing files {sorted(want - names)}")
        return out
    files = {n: (folder / n).read_bytes() for n in sorted(names)}
    if man.get("release") != release or man.get("schema") != SCHEMA:
        p.append(f"manifest release/schema {man.get('release')}/{man.get('schema')} != {release}/{SCHEMA}")
    raw_sha = str(man.get("raw", {}).get("sha256"))
    if _sha(files[raw_name]) != raw_sha:
        p.append(f"{raw_name} sha256 {_sha(files[raw_name])[:16]} != manifest {raw_sha[:16]}")
    if files[RAW_SHA].decode(errors="replace").split() != [raw_sha, raw_name]:
        p.append("raw.sha256 does not match the manifest")
    if _sha(files[NORMALISED]) != man.get("normalised", {}).get("sha256"):
        p.append(f"{NORMALISED} sha256 differs from the manifest")
    rdate = man.get("release_date")
    if man.get("release_date_basis") == "estimated" and rdate != release_date_for(release):
        p.append(f"release_date {rdate} does not follow the estimated rule ({release_date_for(release)})")
    try:
        long = _read_long(folder / NORMALISED)
        if list(long.columns) != LONG_COLUMNS:
            p.append(f"{NORMALISED} columns {list(long.columns)}")
        else:
            if set(long["vintage"]) != {release} or set(long["release_date"]) != {rdate}:
                p.append(f"{NORMALISED} vintage/release_date columns disagree with the manifest")
            if len(long) != man.get("normalised", {}).get("rows"):
                p.append(f"{NORMALISED} has {len(long)} rows, manifest {man.get('normalised', {}).get('rows')}")
    except (OSError, ValueError, pd.errors.ParserError) as e:
        p.append(f"{NORMALISED} unreadable: {e}")
    digest = _content_hash(files)
    out["content_hash"] = digest
    rows = [r for r in _index_rows(root) if r.get("release") == release]
    if not rows:
        p.append(f"no row for {release} in {root / 'index.csv'}")
    else:
        if len({(r.get("content_hash"), r.get("n_files"), r.get("release_date")) for r in rows}) > 1:
            p.append("index.csv rows for this release disagree (index is append-only; a second row is not a fix)")
        first = rows[0]
        if first.get("content_hash") != digest:
            p.append(f"folder content hash {digest[:16]} != index {str(first.get('content_hash'))[:16]}")
        if str(first.get("n_files")) != str(len(files)) or first.get("release_date") != rdate:
            p.append("index row file count or release_date differs from the folder")
    if os.stat(folder).st_mode & stat.S_IWUSR or any(os.stat(folder / n).st_mode & stat.S_IWUSR for n in names):
        out["warnings"].append("folder or files are writable (expected read-only)")
    out["ok"] = not p
    return out


def verify_all(root: str | Path = DEFAULT_ROOT, releases: Iterable[str] | None = None) -> list[dict]:
    root = Path(root)
    rels = list(releases) if releases else list_releases(root)
    res = [verify_release(root, r) for r in rels]
    if not releases:
        orphans = sorted({r.get("release") for r in _index_rows(root)} - set(list_releases(root)))
        res += [{"release": r, "ok": False, "problems": ["index.csv row without a release folder"], "warnings": [],
                 "content_hash": ""} for r in orphans]
    return res


def _write_release(root: Path, release: str, files: dict[str, bytes], now: dt.datetime) -> Path:
    from .ledger import locked_append
    root.mkdir(parents=True, exist_ok=True)
    final = root / release
    tmp = Path(tempfile.mkdtemp(dir=root, prefix=f".{release}."))
    try:
        for name in sorted(files):
            (tmp / name).write_bytes(files[name])
            os.chmod(tmp / name, 0o444)
        # a directory needs the x bit to be listed; no write bit anywhere, so the vintage is read-only
        os.chmod(tmp, 0o555)  # nosec B103
        if final.exists():
            raise FileExistsError(f"{final} appeared during the import")
        os.rename(tmp, final)
    except BaseException:
        if tmp.exists():
            os.chmod(tmp, stat.S_IRWXU)
            shutil.rmtree(tmp)
        raise
    man = json.loads(files[MANIFEST])
    with locked_append(root / "index.csv", INDEX_COLUMNS) as (w, f, new):
        if new:
            w.writeheader()
        w.writerow({"release": release, "release_date": man["release_date"], "release_date_basis": man["release_date_basis"],
                    "imported_utc": now.strftime("%Y-%m-%dT%H:%M:%SZ"), "content_hash": _content_hash(files),
                    "n_files": len(files), "raw_kind": man["raw"]["kind"], "raw_sha256": man["raw"]["sha256"],
                    "normalised_sha256": man["normalised"]["sha256"], "rows": man["normalised"]["rows"],
                    "n_countries": man["normalised"]["n_countries"], "n_indicators": len(man["normalised"]["indicators"]),
                    "route": man["route"]})
    return final


def import_releases(src: str | Path, root: str | Path = DEFAULT_ROOT, cache_dir: str | Path | None = None,
                    releases: Iterable[str] | None = None, allow_extract: bool = False, dry_run: bool = False,
                    now: dt.datetime | None = None) -> list[dict]:
    """Archive every WEO release found in panel_history output `src`. One result per release: {release, status,
    detail, raw_kind}; status is created, unchanged, covered (no-op) or refused. Never overwrites a release."""
    now, root = _utc(now), Path(root)
    rels = [normalise_vintage(r) for r in releases] if releases is not None else None
    inputs, refused = _release_inputs(Path(src), Path(cache_dir) if cache_dir else None, rels)
    results = [{"release": r["release"], "status": "refused", "detail": r["reason"], "raw_kind": ""} for r in refused]
    for inp in inputs:
        rel = inp["release"]
        try:
            files = _build(inp, allow_extract, now)
        except (WeoVintageError, FetchUnitError, OSError, ValueError) as e:
            results.append({"release": rel, "status": "refused", "detail": str(e), "raw_kind": ""})
            continue
        man = json.loads(files[MANIFEST])
        kind = man["raw"]["kind"]
        if (root / rel).exists():
            v = verify_release(root, rel)
            if not v["ok"]:
                results.append({"release": rel, "status": "refused", "raw_kind": kind,
                                "detail": "existing vintage fails verification: " + "; ".join(v["problems"])})
                continue
            old = _read_manifest(root / rel)
            if old["raw"]["sha256"] == man["raw"]["sha256"] and old["normalised"]["sha256"] == man["normalised"]["sha256"]:
                results.append({"release": rel, "status": "unchanged", "raw_kind": old["raw"]["kind"], "detail": "same content"})
                continue
            if kind == "panel_history_extract":
                missing, diff = _compare_subset(_read_long(io.BytesIO(files[NORMALISED])), _read_long(root / rel / NORMALISED))
                if not missing and not diff:
                    results.append({"release": rel, "status": "covered", "raw_kind": old["raw"]["kind"],
                                    "detail": "every row is already in the vintage with the same value"})
                    continue
                why = f"{missing} rows not in the vintage, {diff} with other values"
            else:
                why = f"raw sha256 {man['raw']['sha256'][:16]} != archived {old['raw']['sha256'][:16]}"
            results.append({"release": rel, "status": "refused", "raw_kind": kind,
                            "detail": f"release already archived with different content ({why}); vintages are never "
                                      "overwritten"})
            continue
        if not dry_run:
            _write_release(root, rel, files, now)
        results.append({"release": rel, "status": "created" if not dry_run else "would create", "raw_kind": kind,
                        "detail": f"{man['normalised']['rows']} rows, {man['normalised']['n_countries']} economies, "
                                  f"{len(man['normalised']['indicators'])} indicators, release_date "
                                  f"{man['release_date']} (estimated)"})
    return sorted(results, key=lambda r: r["release"])


# ------------------------------------------------------------------------------------------ as-of

# EQ-A-0075 (AGENT-05 review, via AGENT-08): weo_asof(verify=True) is called inside Team B's hazard loops, and
# verify_release rehashes the whole release each time. weo_asof keeps the PASSES of verify_release in memory, keyed on
# the release folder path plus (name, mtime_ns, size) of every file in it and of root/index.csv (which verify_release
# also reads), so any file added, removed, replaced or touched forces a full verify again. A failed verify is never
# cached: it raises every time. verify_release / verify_all themselves are never cached.
_VERIFY_CACHE: set = set()


def clear_verify_cache() -> None:
    """Forget every cached verify pass (tests; or after editing an archive by hand)."""
    _VERIFY_CACHE.clear()


def _verify_key(root: Path, rel: str) -> tuple | None:
    folder = root / rel
    try:
        stats = []
        for q in sorted(folder.iterdir(), key=lambda x: x.name):
            st = q.lstat()
            stats.append((q.name, st.st_mtime_ns, st.st_size))
        ist = (root / "index.csv").lstat()
        stats.append(("../index.csv", ist.st_mtime_ns, ist.st_size))
    except OSError:
        return None                                          # unreadable: no key, verify_release reports why
    return (str(folder.resolve()), tuple(stats))


def _verify_cached(root: Path, rel: str) -> None:
    key = _verify_key(root, rel)
    if key is not None and key in _VERIFY_CACHE:
        return
    v = verify_release(root, rel)
    if not v["ok"]:
        raise WeoVintageError(f"WEO vintage {rel} failed verification: " + "; ".join(v["problems"]))
    if key is not None and _verify_key(root, rel) == key:     # unchanged while verifying: safe to remember
        _VERIFY_CACHE.add(key)


def weo_asof(as_of_date, indicators: Iterable[str] | None = None, countries: Iterable[str] | None = None,
             root: str | Path = DEFAULT_ROOT, verify: bool = True, strict: bool = True) -> pd.DataFrame:
    """Rows of the latest archived WEO release whose release_date <= as_of_date (no look-ahead): columns iso3,
    indicator, year, value, vintage, release_date, filtered to `indicators` and `countries` (ISO3) when given.

    Only that one release is used (no mixing of releases; an indicator the release lacks is listed in
    attrs['missing_indicators'], not filled from an older one). attrs also carry vintage, release_date,
    release_date_basis, raw_kind, licence and missing_countries. verify=True (default) runs verify_release on the
    chosen release and raises WeoVintageError if it fails (a pass is cached per path + file mtime_ns/size, EQ-A-0075). With no release on or before as_of: NoVintageError, or an
    empty frame when strict=False. Never reads the clock."""
    asof, root = _as_date(as_of_date), Path(root)
    cands = []
    for rel in list_releases(root):
        try:
            man = _read_manifest(root / rel)
            d = dt.date.fromisoformat(str(man["release_date"]))
        except (OSError, ValueError, KeyError) as e:
            raise WeoVintageError(f"WEO vintage {rel}: unreadable manifest ({e}); run verify") from e
        if d <= asof:
            cands.append((d, rel, man))
    if not cands:
        if strict:
            raise NoVintageError(f"no archived WEO release published on or before {asof} under {root} "
                                 "(point in time starts with the first archived release; earlier years need Team B's rule)")
        empty = pd.DataFrame(columns=LONG_COLUMNS)
        ind = [str(i).strip() for i in indicators] if indicators is not None else []
        cty = [str(c).strip().upper() for c in countries] if countries is not None else []
        empty.attrs.update(vintage=None, release_date=None, as_of=asof.isoformat(), release_date_basis=None,
                           raw_kind=None, licence=LICENCE, missing_indicators=sorted(set(ind)),
                           missing_countries=sorted(set(cty)))     # same attrs keys as a served frame (EQ-A-0075)
        return empty
    d, rel, man = max(cands, key=lambda c: (c[0], c[1]))
    if verify:
        _verify_cached(root, rel)
    df = _read_long(root / rel / NORMALISED)
    ind = [str(i).strip() for i in indicators] if indicators is not None else None
    cty = [str(c).strip().upper() for c in countries] if countries is not None else None
    if ind is not None:
        df = df[df["indicator"].isin(ind)]
    if cty is not None:
        df = df[df["iso3"].isin(cty)]
    if (pd.to_datetime(df["release_date"]).dt.date > asof).any():           # belt and braces: no look-ahead
        raise WeoVintageError(f"WEO vintage {rel}: rows dated after {asof}")
    df = df.reset_index(drop=True)
    df.attrs.update(as_of=asof.isoformat(), vintage=rel, release_date=man["release_date"],
                    release_date_basis=man.get("release_date_basis"), raw_kind=man.get("raw", {}).get("kind"),
                    licence=man.get("licence"),
                    missing_indicators=sorted(set(ind) - set(df["indicator"])) if ind is not None else [],
                    missing_countries=sorted(set(cty) - set(df["iso3"])) if cty is not None else [])
    return df


# ------------------------------------------------------------------------------------------ command line

def _csv_list(s: str | None) -> list[str] | None:
    return [x.strip() for x in s.split(",") if x.strip()] if s else None


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.weo_vintages",
                                 description="Point-in-time WEO vintage archive (one immutable folder per release).")
    sub = ap.add_subparsers(dest="cmd", required=True)
    pi = sub.add_parser("import", help="archive WEO releases from panel_history output (no download)")
    pi.add_argument("--from", dest="src", required=True, help="data/panel/staging/<run_id> or data/panel/weo_history.csv")
    pi.add_argument("--cache-dir", help="WEO file cache (default: the staging folder's weo_cache)")
    pi.add_argument("--releases", help="'2007-10:2026-10' or a comma list (default: every release in the source)")
    pi.add_argument("--allow-extract", action="store_true",
                    help="archive panel_history rows when a weo-package/local file is no longer in the cache")
    pi.add_argument("--dry-run", action="store_true")
    pv = sub.add_parser("verify", help="check hashes, manifests and index of archived releases")
    pv.add_argument("releases", nargs="*")
    sub.add_parser("list", help="archived releases (index.csv)")
    pa = sub.add_parser("asof", help="latest release published on or before a date")
    pa.add_argument("--as-of", required=True, help="YYYY-MM-DD")
    pa.add_argument("--indicators", help="comma list of WEO subject codes")
    pa.add_argument("--countries", help="comma list of ISO3 codes")
    pa.add_argument("--out", help="write the rows to this CSV (default: print a summary)")
    for p in (pi, pv, pa, sub.choices["list"]):
        p.add_argument("--root", default=str(DEFAULT_ROOT), help=f"archive folder (default {DEFAULT_ROOT})")
    a = ap.parse_args(argv)
    root = Path(a.root)
    try:
        if a.cmd == "import":
            rels = _parse_vintage_arg(a.releases) if a.releases else None
            res = import_releases(a.src, root, cache_dir=a.cache_dir, releases=rels, allow_extract=a.allow_extract,
                                  dry_run=a.dry_run)
            for r in res:
                print(f"{r['release']}  {r['status']:<12} {r['raw_kind'] or '-':<22} {r['detail']}")
            n = {s: sum(r["status"] == s for r in res) for s in ("created", "would create", "unchanged", "covered", "refused")}
            print("summary: " + ", ".join(f"{k} {v}" for k, v in n.items() if v) if res else "summary: no WEO releases found")
            return 1 if n["refused"] else 0
        if a.cmd == "verify":
            res = verify_all(root, a.releases or None)
            for r in res:
                print(f"{r['release']}  {'OK' if r['ok'] else 'FAIL'}  " + "; ".join(r["problems"] + r["warnings"]))
            bad = [r for r in res if not r["ok"]]
            print(f"verified {len(res)} release(s) under {root}: {len(res) - len(bad)} ok, {len(bad)} failed")
            return 1 if bad else 0
        if a.cmd == "list":
            rows = _index_rows(root)
            if not rows:
                print(f"no WEO vintages under {root}")
                return 0
            for r in rows:
                print(f"{r['release']}  released {r['release_date']} ({r['release_date_basis']})  {r['raw_kind']:<22} "
                      f"{r['rows']:>8} rows {r['n_countries']:>4} economies {r['n_indicators']:>3} indicators  "
                      f"{r['route']}  {r['content_hash'][:12]}")
            return 0
        df = weo_asof(a.as_of, _csv_list(a.indicators), _csv_list(a.countries), root=root)
        print(f"as of {df.attrs['as_of']}: WEO {df.attrs['vintage']} (release_date {df.attrs['release_date']}, "
              f"{df.attrs['release_date_basis']}), {len(df)} rows; licence: {df.attrs['licence']}")
        if df.attrs["missing_indicators"] or df.attrs["missing_countries"]:
            print(f"not in this release: indicators {df.attrs['missing_indicators']}, countries {df.attrs['missing_countries']}")
        if a.out:
            df.to_csv(a.out, index=False)
            print(f"wrote {a.out}")
        return 0
    except NoVintageError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    except (WeoVintageError, ValueError, FileNotFoundError) as e:
        print(f"error: {e}", file=sys.stderr)
        return 2 if a.cmd != "verify" else 1


if __name__ == "__main__":
    raise SystemExit(main())
