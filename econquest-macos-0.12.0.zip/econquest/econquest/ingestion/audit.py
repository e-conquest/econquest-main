"""Audit trail (roadmap 1.6): one row per Inputs and Country Profile cell saying where its value came from.

For every cell the row carries the current value, its origin (live feed, seed kept after a hold, seed estimate),
the source and series, the transform that turned the raw series into the workbook unit, the retrieval date of the
vintage, the quality-gate status and reason, the review decision, and any robustness rule the transform applied.
Everything is read from data/: indicators.csv, countries.csv, rulebook.csv and data/live/{provenance,review,transform_log}.csv.

EQ-A-0018 (columns added at the end, existing ones unchanged): `author`, `approver`, `self_approved` (from the review
ledger decision for Inputs / Country Profile cells, from the attestation for hand-entered cells) and `attested`. The
hand-entered files (ledger.HAND_ENTERED: adjustments, cds_quotes, prediction_markets) get one row per cell with
origin "hand-entered (attested)" or "hand-entered (UNATTESTED)" and attested yes/no. Unattested cells are reported,
never blocked: whether loading should refuse them is a policy decision for Sam.

SEC-A-006 M1 (EQ-A-0045): `restricted_source_cells(data_dir)` lists the applied cells (indicators.csv, countries.csv)
whose value came from a source whose terms bar desk use: Yahoo Finance / yfinance (personal, non-commercial terms;
Sam replaced Yahoo on 2026-10-23, EQ-A-0040) or any record whose licence carries a desk-barred term (non-commercial,
personal: market.gate.DESK_BARRED_LICENCE_TERMS). `econquest fetch --apply` and `review apply` print a loud warning
while the list is not empty (feeds.apply_report); after the first official FX pull it must be empty:

    python -m econquest.ingestion.audit restricted        # exit 0 and "0 restricted-source cells", else 1 and the list
"""
from __future__ import annotations

import argparse
import datetime as dt
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd

from .sources import read_csv_keep_na_code
from .feeds import (WEO_CODES, WEO_SOURCE_SERIES, WB_SOURCE_SERIES, BIS_SOURCE_SERIES, NO_OFFICIAL_SOURCE, RG_CAP,
                    FX_MANUAL_SOURCE_PREFIX)
from .ledger import attestation_status

PROFILE_FIELDS = {"pop": "Population (mm)", "exports": "Exports (% of GDP)", "reserves": "Reserves (% of GDP)",
                  "fx3m": "FX change 3m (%)", "policy": "Policy rate (%)"}

TRANSFORMS = {
    "1.1": "econquest dsa: (WEO interest + debt / average maturity) / revenue, year t+1",
    "1.2": "econquest dsa: World Bank IDS PPG debt service years t+1 and t+2 / reserves",
    "2.1": "econquest dsa: usable reserves / IMF ARA metric (fixed 30/20/10/10, floating 30/15/5/5, managed averaged)",
    "1.3": "GGXWDG_NGDP, year t as delivered",
    # EQ-A-0124: 1.6 is computed from WEO inputs; the text names them (feeds.WEO_SOURCE_SERIES["1.6"]) so the client
    # licence check (audit.provenance_imf_reason, Team C's licence_rule.imf_text_hits) sees the IMF input
    "1.6": f"WEO {WEO_SOURCE_SERIES['1.6']}: primary balance minus debt-stabilising balance: pb - (r-g)/(1+g) x d(t-1); r = (pb - overall balance)/d(t-1); g = nominal GDP growth with a 3-SD outlier fallback to t-1; r-g capped at +/-{RG_CAP:g}",
    "1.7": "GGXWDG_NGDP(t) - GGXWDG_NGDP(t-5)",
    "2.8": "BCA_NGDPD, year t; falls back to t-1 when |change| > 3 SD of 15y annual changes",
    "5.5": "PCPIPCH, year t as delivered",
    "5.6": "NGDP_RPCH, year t+1 (projection)",
    "5.12": "SD of NGDP_RPCH over 15y excluding 2020-21",
    "5.14": "NGDPDPC, year t as delivered",
    "2.9": "latest IDS value as delivered",
    "2.10": "latest IDS value as delivered",
    "3.4": "mean WGI rank (RL, CC, RQ), latest minus 3 years earlier",
    "3.5": "mean WGI rank (RL, CC, RQ), latest year",
    "5.10": "latest value as delivered",
    "6.2": "latest value as delivered",
    "6.6": "latest value as delivered",
    "2.12": "latest real broad EER / mean of last 120 months x 100 - 100",
    "5.9": "latest BIS credit-to-GDP gap as delivered",
    "5.13": "BIS policy rate minus WEO PCPIPCH (year t)",
    "pop": "SP.POP.TOTL / 1e6",
    "exports": "NE.EXP.GNFS.ZS latest as delivered",
    "reserves": "FI.RES.TOTL.CD / NY.GDP.MKTP.CD x 100",
    "fx3m": "local currency per USD: % change over about 91 days (positive = weaker)",
    "equity_vol": "annualised SD of ETF daily log returns, last 60 trading days (no live source since EQ-A-0040)",
    "policy": "latest BIS WS_CBPOL policy rate",
}
SERIES = {**WEO_SOURCE_SERIES, **WB_SOURCE_SERIES, **BIS_SOURCE_SERIES, "policy": "WS_CBPOL",
          # EQ-A-0040: official FX; equity_vol has no official free source and is left unserved
          "fx3m": ("BIS WS_XRU D.<area>.<CCY>.A, else ECB EXR D.<CCY>.EUR.SP00.A via EUR/USD, else the legal parity of "
                   "a hard peg (feeds.HARD_PEGS, EQ-A-0071), else theratesapi.com for VES/NGN/PKR/VND/ZMW (EQ-A-0073, "
                   "EXC-005, internal research only), else an attested row of data/fx_manual.csv (EQ-A-0072)"),
          "equity_vol": f"none: {NO_OFFICIAL_SOURCE}"}
SEED_NOTE = "seed estimate (analyst/Claude, Oct 2026); not yet replaced by a feed"
ATTESTATION_COLUMNS = ["author", "approver", "self_approved", "attested"]     # EQ-A-0018, after the original columns
HAND_ATTESTED = "hand-entered (attested)"
HAND_UNATTESTED = "hand-entered (UNATTESTED: no author/approver for the current content)"


def _read(p: Path, **kw) -> pd.DataFrame | None:
    return pd.read_csv(p, **kw) if p.exists() else None


def _text(v) -> str:
    return v if isinstance(v, str) else ""


def build_audit_trail(data_dir: str | Path, hand_entered: bool = True) -> pd.DataFrame:
    """One row per Inputs and Country Profile cell and, with `hand_entered` (default), one row per hand-entered cell
    with its attestation (EQ-A-0018). Columns: the original 16 followed by ATTESTATION_COLUMNS."""
    d = Path(data_dir)
    ind = pd.read_csv(d / "indicators.csv", dtype={"id": str, "pillar": str})
    cty = read_csv_keep_na_code(d / "countries.csv", dtype=str)   # keep ISO2 "NA" (Namibia), EQ-A-0027
    rb = pd.read_csv(d / "rulebook.csv", dtype={"id": str}).set_index("id")
    names = list(cty["country"])
    live = d / "live"
    prov = _read(live / "provenance.csv", dtype={"key": str})
    review = _read(live / "review.csv", dtype={"key": str})
    tlog = _read(live / "transform_log.csv")
    prov_i = prov.set_index(["table", "key", "country"]) if prov is not None and len(prov) else None
    rev_i = review.set_index(["table", "key", "country"]) if review is not None and len(review) else None
    held = set()                         # cells the gate holds and no approved decision released (ledger.effective_holds)
    if review is not None and len(review):
        from . import ledger
        rv_all = review.fillna("").astype(str)
        held = ledger.effective_holds(rv_all, ledger.load_decisions(d))
    tlog_i = {}
    if tlog is not None and len(tlog):
        for r in tlog.itertuples(index=False):
            key = "2.8" if r.series == "BCA_NGDPD" else "1.6"
            tlog_i.setdefault((r.country, key), []).append(r.rule)

    def cell(table, key, country, label, value):
        row = {"table": table, "key": key, "indicator": label, "country": country, "value": value,
               "origin": "", "source": "", "series": "", "transform": "", "retrieved": "", "gate_status": "", "gate_reason": "",
               "decision": "", "seed_value": np.nan, "live_value": np.nan, "robustness_rule": "; ".join(tlog_i.get((country, key), [])),
               "author": "", "approver": "", "self_approved": "", "attested": ""}
        k = (table, key, country)
        rv = rev_i.loc[k] if rev_i is not None and k in rev_i.index else None
        pv = prov_i.loc[k] if prov_i is not None and k in prov_i.index else None
        if rv is not None:
            row["gate_status"], row["gate_reason"] = rv["status"], rv["reason"] if isinstance(rv["reason"], str) else ""
            row["decision"] = rv["decision"] if isinstance(rv["decision"], str) else ""
            row["seed_value"], row["live_value"] = rv["seed"], rv["live"]
            for c in ("author", "approver", "self_approved"):     # written by ledger.write_review
                row[c] = _text(rv.get(c, ""))
        if pv is not None:
            row["source"], row["series"], row["retrieved"] = pv["source"], pv["series"], pv["retrieved"]
            row["transform"] = TRANSFORMS.get(key, "as delivered")
            applied = np.isfinite(value) and np.isfinite(pv["value"]) and abs(float(pv["value"]) - value) <= 1e-3 * max(1.0, abs(value))  # indicators.csv keeps 4 decimals
            if applied and k in held:        # the value in place equals a held live value: the gate did not apply it
                row["origin"] = "seed kept (live value held by the quality gate)"
                row["source"] = f"value in place equals the held live value, not applied by the gate: {pv['source']}"
            elif applied:
                row["origin"] = "live feed"
            elif rv is not None and rv["status"] == "hold":
                row["origin"] = "seed kept (live value held by the quality gate)"
            else:
                row["origin"] = "seed kept (live value not applied)"
        else:
            if rv is not None and rv["status"] == "missing":
                row["origin"] = "seed estimate (feed returned no value)"
            else:
                row["origin"] = "seed estimate"
            row["source"] = SEED_NOTE
            if table == "Inputs" and key in rb.index:
                src = rb.at[key, "source"]; api = rb.at[key, "api"]
                row["series"] = f"intended: {src}" if isinstance(src, str) else ""
                row["transform"] = f"planned feed: {api}" if isinstance(api, str) else ""
            else:
                row["series"] = f"intended: {SERIES.get(key, '')}"; row["transform"] = TRANSFORMS.get(key, "")
        return row

    rows = []
    for _, r in ind.iterrows():
        for n in names:
            v = pd.to_numeric(r.get(n), errors="coerce")
            rows.append(cell("Inputs", r["id"], n, r["indicator"], float(v) if pd.notna(v) else np.nan))
    for _, c in cty.iterrows():
        for key, label in PROFILE_FIELDS.items():
            if key in cty.columns:
                v = pd.to_numeric(c[key], errors="coerce")
                rows.append(cell("Country Profile", key, c["country"], label, float(v) if pd.notna(v) else np.nan))
    if hand_entered:
        for c in attestation_status(d):
            ok = c["attested"] == "yes"
            v = pd.to_numeric(c["value"], errors="coerce")
            rows.append({"table": c["table"], "key": c["key"], "indicator": c["label"], "country": c["country"],
                         "value": float(v) if pd.notna(v) else np.nan, "origin": HAND_ATTESTED if ok else HAND_UNATTESTED,
                         "source": f"hand-entered: data/{c['table']}.csv", "series": "", "transform": "",
                         "retrieved": c["attested_utc"], "gate_status": "", "gate_reason": "",
                         "decision": "attested" if ok else "", "seed_value": np.nan, "live_value": np.nan,
                         "robustness_rule": "", "author": c["author"], "approver": c["approver"],
                         "self_approved": c["self_approved"], "attested": c["attested"]})
    df = pd.DataFrame(rows)
    df.attrs["built"] = dt.date.today().isoformat()
    return df


def audit_summary(df: pd.DataFrame) -> pd.DataFrame:
    s = df.groupby(["table", "origin"]).size().rename("cells").reset_index()
    return s.sort_values(["table", "cells"], ascending=[True, False])


def audit_plan(df: pd.DataFrame, sheet: str = "Audit Trail") -> list[dict]:
    """Values for the Audit Trail tab: title, note, header on row 4, one row per cell from row 5."""
    from ..common_format import _v
    cols = ["table", "key", "indicator", "country", "value", "origin", "source", "series", "transform", "retrieved",
            "gate_status", "gate_reason", "decision", "seed_value", "live_value", "robustness_rule"]
    header = ["Table", "Id", "Indicator", "Country", "Value in workbook", "Origin", "Source (seed = analyst estimate, Oct 2026)", "Series (for seed rows: intended source)", "Transform (for seed rows: planned feed)", "Retrieved",
              "Gate status", "Gate reason", "Review decision", "Seed value", "Live value", "Robustness rule applied"]
    summ = audit_summary(df)
    counts = "; ".join(f"{r.table}: {r.cells} {r.origin}" for r in summ.itertuples(index=False))
    note = (f"Written by `python -m econquest audit` on {df.attrs.get('built', dt.date.today().isoformat())}. One row per Inputs and Country Profile cell: "
            f"where the value came from, how it was transformed, when it was retrieved and what the quality gate decided. {counts}.")
    wb = df.copy()
    seed = wb["origin"].str.startswith("seed estimate")
    wb.loc[seed, "source"] = "seed"                      # keep the tab compact: the long note is in audit_trail.csv
    wb.loc[seed, "series"] = wb.loc[seed, "series"].str.replace("intended: ", "", regex=False)
    wb.loc[seed, "transform"] = wb.loc[seed, "transform"].str.replace("planned feed: ", "", regex=False)
    body = [[_v(x) for x in row] for row in wb[cols].itertuples(index=False)]
    return [{"range": f"'{sheet}'!A1:A2", "values": [["Audit trail: provenance of every input cell"], [note]]},
            {"range": f"'{sheet}'!A4:P4", "values": [header]},
            {"range": f"'{sheet}'!A5:P{4 + len(body)}", "values": body}]



# ------------------------------------------------------------------------------------------------ SEC-A-006 M1
RESTRICTED_SOURCE_RE = re.compile(r"yahoo|yfinance", re.IGNORECASE)
RESTRICTED_SOURCE_REASON = ("Yahoo Finance terms: personal, non-commercial use only; not allowed in desk numbers or a "
                            "publish (Sam 2026-10-23, EQ-A-0040)")
LICENCE_COLUMNS = ("licence", "license", "licences", "licenses")
RESTRICTED_COLUMNS = ["table", "key", "country", "value", "source", "series", "retrieved", "reason", "evidence"]


def restricted_reason(source="", licence="") -> str | None:
    """Why a record's source or licence bars its value from desk numbers (SEC-A-006 M1), or None.

    EQ-A-0076: the licence register (data/licences.csv) is consulted first. A row with internal_use=no bars the
    record; the reason is the existing rule's text when that rule also bars it (unchanged wording), else the
    register's (licences.register_reason). A row saying internal_use=yes, or no row, falls back to the rules below.
    A register file that exists but is invalid bars every record (licences.invalid_reason, fail closed); a missing
    one leaves the rules alone."""
    from .licences import invalid_reason, licence_for, register_reason
    bad = invalid_reason()                             # register present but invalid: fail closed (AGENT-05 review)
    if bad:
        return bad
    row = licence_for(source=_text(source), licence=_text(licence))
    if row is not None and row["internal_use"] == "no":
        return _restricted_reason_rules(source, licence) or register_reason(row, "desk")
    return _restricted_reason_rules(source, licence)


def _restricted_reason_rules(source="", licence="") -> str | None:
    """The pre-register rules of restricted_reason (Yahoo / yfinance source, desk-barred licence terms)."""
    from .market.gate import DESK_BARRED_LICENCE_TERMS
    if RESTRICTED_SOURCE_RE.search(_text(source)):
        return RESTRICTED_SOURCE_REASON
    lic = _text(licence).casefold()
    hits = [t for t in DESK_BARRED_LICENCE_TERMS if t in lic]
    if hits:
        return f"licence: {', '.join(hits)} use only ({_text(licence)[:120]}); not allowed in desk numbers or a publish"
    return None


def _same(a: float, b: float) -> bool:
    """indicators.csv keeps 4 decimals and countries.csv 4 significant digits: the tolerance build_audit_trail uses."""
    return bool(np.isfinite(a) and np.isfinite(b) and abs(a - b) <= 1e-3 * max(1.0, abs(a)))


def _records(path: Path, evidence: str, value_col: str) -> list[dict]:
    """Rows of a provenance-like CSV (table, key, country, value, source[, series, retrieved, licence])."""
    if not path.is_file() or path.is_symlink():
        return []
    try:
        df = pd.read_csv(path, dtype=str, keep_default_na=False)
    except (ValueError, OSError):
        return []
    if not {"table", "key", "country", "source", value_col} <= set(df.columns):
        return []
    lic = next((c for c in df.columns if c.strip().lower() in LICENCE_COLUMNS), None)
    ptext = [c for c in PROVENANCE_TEXT_COLUMNS if c in df.columns]      # EQ-A-0124 / HO-20261026-B-A-005
    out = []
    for r in df.to_dict("records"):
        out.append({"table": r["table"], "key": str(r["key"]), "country": r["country"], "source": r["source"],
                    "series": r.get("series", ""), "retrieved": r.get("retrieved", ""),
                    "licence": r.get(lic, "") if lic else "",
                    "transform": " | ".join(str(r[c]) for c in ptext if str(r.get(c, "")).strip()),
                    "value": pd.to_numeric(r[value_col], errors="coerce"), "evidence": evidence})
    return out


def restricted_source_cells(data_dir: str | Path) -> pd.DataFrame:
    """Applied cells whose current value came from a restricted source (SEC-A-006 M1): one row per cell, columns
    RESTRICTED_COLUMNS, empty when none. See _matching_cells for how a value is tied to its source."""
    return _matching_cells(data_dir, lambda r: restricted_reason(r["source"], r["licence"]))


def _matching_cells(data_dir: str | Path, reason_of) -> pd.DataFrame:
    """Applied cells whose current value a record ties to a source for which `reason_of(record)` gives a reason.

    A cell is listed when its value in indicators.csv (Inputs) or countries.csv (Country Profile) matches, within the
    audit trail's rounding tolerance, a value that a record attributes to Yahoo / yfinance or to a non-commercial or
    personal licence: the current pull's live/provenance.csv, the provenance.csv of any live vintage (so a value
    applied from an older pull is still found after the next pull replaced provenance.csv) or audit_trail.csv. It is
    not listed when the current pull's provenance.csv gives the same value from a source that is not restricted.
    `evidence` names the files that tie the value to the restricted source. Reads only; never changes data."""
    d = Path(data_dir)
    live = d / "live"
    current = _records(live / "provenance.csv", "live/provenance.csv", "value")
    recs = list(current)
    vroot = live / "vintages"
    if vroot.is_dir() and not vroot.is_symlink():
        for v in sorted(p for p in vroot.iterdir() if p.is_dir() and not p.is_symlink()):
            recs += _records(v / "provenance.csv", f"live/vintages/{v.name}/provenance.csv", "value")
    trail = _records(d / "audit_trail.csv", "audit_trail.csv", "value")
    for r in trail:          # EQ-A-0124: a trail built before a TRANSFORMS change is read with today's derivation text
        t = str(r.get("transform") or "")
        cur = TRANSFORMS.get(r["key"])
        if t and cur and cur not in t and not t.strip().casefold().startswith(PLANNED_FEED_PREFIX):
            r["transform"] = f"{t} | {cur}"
    recs += trail
    # EQ-A-0124 / HO-20261026-B-A-005: provenance.csv has no transform column. A record there that audit_trail.csv
    # describes too (same cell, source and value) carries the trail's transform, so a WEO input named only there is not
    # taken for an allowed record of the same value.
    tx = {(r["table"], r["key"], r["country"], r["source"]): (r["value"], r["transform"]) for r in trail
          if r.get("transform")}
    for r in recs:
        t = tx.get((r["table"], r["key"], r["country"], r["source"]))
        if t and not r.get("transform") and np.isfinite(r["value"]) and np.isfinite(t[0]) and _same(t[0], r["value"]):
            r["transform"] = t[1]
    bad = [dict(r, reason=reason_of(r)) for r in recs]
    bad = [r for r in bad if r["reason"] and np.isfinite(r["value"])]
    if not bad:
        return pd.DataFrame(columns=RESTRICTED_COLUMNS)
    allowed = {}
    for r in current:
        if not reason_of(r) and np.isfinite(r["value"]):
            allowed.setdefault((r["table"], r["key"], r["country"]), []).append(float(r["value"]))

    values: dict = {}
    cty = read_csv_keep_na_code(d / "countries.csv", dtype=str)   # keep ISO2 "NA" (Namibia), EQ-A-0027
    names = list(cty["country"])
    keys = {r["key"] for r in bad if r["table"] == "Country Profile"} & set(cty.columns)
    for _, row in cty.iterrows():
        for k in keys:
            v = pd.to_numeric(row[k], errors="coerce")
            if pd.notna(v):
                values[("Country Profile", k, row["country"])] = float(v)
    ind = d / "indicators.csv"
    if any(r["table"] == "Inputs" for r in bad) and ind.is_file():
        df = pd.read_csv(ind, dtype={"id": str, "pillar": str})
        for _, row in df.iterrows():
            for c in names:
                v = pd.to_numeric(row.get(c), errors="coerce")
                if pd.notna(v):
                    values[("Inputs", str(row["id"]), c)] = float(v)

    cells: dict = {}
    for r in bad:
        cell = (r["table"], r["key"], r["country"])
        v = values.get(cell)
        if v is None or not _same(v, float(r["value"])):
            continue
        if any(_same(v, a) for a in allowed.get(cell, [])):
            continue                                     # the current pull gives the same value from an allowed source
        if cell not in cells:
            cells[cell] = {"table": cell[0], "key": cell[1], "country": cell[2], "value": v, "source": r["source"],
                           "series": r["series"], "retrieved": r["retrieved"], "reason": r["reason"], "evidence": []}
        if r["evidence"] not in cells[cell]["evidence"]:
            cells[cell]["evidence"].append(r["evidence"])
    rows = [dict(c, evidence="; ".join(c["evidence"])) for _, c in sorted(cells.items())]
    return pd.DataFrame(rows, columns=RESTRICTED_COLUMNS)


def restricted_warning(cells: pd.DataFrame, limit: int = 20) -> str:
    """The loud multi-line warning fetch / review apply print while restricted-source cells are applied, or ''."""
    if cells is None or cells.empty:
        return ""
    by_key = cells.groupby(["table", "key"]).size()
    lines = ["!" * 100,
             f"WARNING (SEC-A-006 M1): {len(cells)} applied cell(s) still hold values from a restricted source "
             f"({', '.join(f'{t} {k}: {n}' for (t, k), n in by_key.items())}).",
             "They must not reach desk numbers or a publish. Replace them with the official FX pull on the Mac "
             "(docs/runbooks/A-official-fx.md):  econquest fetch --only fx --apply",
             "Check with:  python -m econquest.ingestion.audit restricted"]
    for r in cells.head(limit).itertuples(index=False):
        lines.append(f"  {r.table} {r.key} {r.country} = {r.value:g}  ({r.source}; {r.evidence})")
    if len(cells) > limit:
        lines.append(f"  ... and {len(cells) - limit} more")
    lines.append("!" * 100)
    return "\n".join(lines)


# ------------------------------------------------------------------------------------------------ client output
# Sam 2026-10-24 12:38Z (HO-20261024-A-B-003, EQ-A-0049): IMF data is for internal research use only and never goes
# into client output. Separate from restricted_reason on purpose: IMF values stay in desk numbers, the review and the
# internal data room; only client-facing output (publish, distribution) must leave them out. The publish side is
# Team C's (handoff); this is the hook it calls: client_output_reason per record, client_restricted_cells per data folder.
CLIENT_RESTRICTED_LICENCE_TERMS = ("internal research use only", "internal use only")
# IMF sources as feeds and the official adapters label them (imf-reader WEO, weo package WEO, IMF SDMX), and derived
# values whose series names a WEO input (e.g. 5.13 = BIS policy rate minus WEO PCPIPCH, econquest dsa 1.1).
CLIENT_RESTRICTED_SOURCE_RE = re.compile(r"\bimf\b|imf-reader|\bweo\b", re.IGNORECASE)
CLIENT_RESTRICTED_REASON = ("IMF data: internal research use only, not for client output (Sam 2026-10-24 12:38Z, "
                            "HO-20261024-A-B-003; commercial reuse and bulk download need IMF permission)")
# EQ-A-0060: national central-bank / statistics values (official.central_banks, source 'national: ...') have unchecked
# licences; they stay out of client output until their rows in data/panel/cb_series_verified.csv say licence_ok=yes.
NATIONAL_SOURCE_PREFIX = "national: "
CLIENT_NATIONAL_REASON = ("national central-bank / statistics value: licence not checked for client output "
                          "(set licence_ok=yes in data/panel/cb_series_verified.csv once checked; EQ-A-0060)")


# EQ-A-0072: fx3m typed from a national central bank's rates page (feeds.FX_MANUAL_SOURCE_PREFIX) is a desk number
# (not restricted_reason), but the page's terms are no more checked than those of the national adapters: it stays out of
# client output. `national_ok` is checked for symmetry, but cb_series_verified.csv clears only registry series, so today
# no hand-entered FX source is cleared: a licence switch for these rows is a follow-up (EQ-A-0072 report).
CLIENT_HAND_FX_REASON = ("hand-entered central-bank FX rate (data/fx_manual.csv): licence of the central bank's page "
                         "not checked for client output (EQ-A-0072, same rule as national sources, EQ-A-0060)")


# EQ-A-0073 (Sam 2026-10-24 20:33Z / 20:37Z): fx3m from theratesapi.com, a mirror of Banca d'Italia's daily rates, is
# internal research only under governance exception EXC-005, like the IMF under EXC-003. It is NOT a desk restriction:
# its licence tag (official.theratesapi.THERATES_LICENCE) carries no "personal" / "non-commercial" term, so
# restricted_reason passes it and it stays in desk numbers; only client output must leave it out. Recognised by the
# EXC-005 licence tag or, because provenance.csv carries no licence column, by a source naming theratesapi.com or
# Banca d'Italia.
CLIENT_THERATES_SOURCE_RE = re.compile(r"theratesapi|banca d'italia|bancaditalia", re.IGNORECASE)
CLIENT_THERATES_LICENCE_TERMS = ("exc-005",)
CLIENT_THERATES_REASON = ("theratesapi.com mirror of Banca d'Italia rates: internal research use only, not for client "
                          "output (EXC-005, Sam 2026-10-24 20:33Z; mirror terms unverified; EQ-A-0073)")


def national_licence_ok(data_dir: str | Path | None = None) -> set[str]:
    """National source texts cleared for client output (official.central_banks.licence_ok_sources)."""
    from .official.central_banks import licence_ok_sources
    return licence_ok_sources(data_dir)


# EQ-A-0076: register rows whose client_output=restricted can be cleared per series by licence_ok=yes in
# data/panel/cb_series_verified.csv (`national_ok`): for these the existing rule below decides alone.
REGISTER_CLEARABLE = ("cb_registry", "fx_manual")
# Register rows for which CLIENT_RESTRICTED_REASON (the IMF text) is the right reason. Any other row that the generic
# 'internal research use only' licence term catches (the research datasets, EQ-A-0067) gets the register's own reason.
REGISTER_IMF = ("imf_weo", "imf_sdmx", "imf_derived")


# EQ-A-0124 / HO-20261026-B-A-005 (same pattern as Team C's EQ-C-0151): a value can name its IMF input only in its
# free-text provenance. The applied-vintage audit rows of data/mvp say source "econquest full fetch on Sam's Mac ..."
# with an empty series, and the WEO code only in `transform` ("GGXWDG_NGDP, year t as delivered", "BIS policy rate
# minus WEO PCPIPCH"). Those columns are read too, and a WEO code or an IMF / WEO word there restricts the record. A seed
# row's "planned feed: ..." text names the feed meant to replace it, not its input, and is skipped.
PROVENANCE_TEXT_COLUMNS = ("transform", "robustness_rule", "method", "derivation", "inputs", "upstream")
PLANNED_FEED_PREFIX = "planned feed:"


def weo_code_re() -> re.Pattern:
    """IMF WEO series codes as whole words: Team C's one rule, ops.licence_rule.weo_code_re (EQ-C-0151), so Team A's
    audit and Team C's enforcement read the same list. feeds.WEO_CODES are always included (fail closed if the import
    is unavailable)."""
    try:
        from ..ops.licence_rule import weo_code_re as team_c_re
        pat = team_c_re()
    except Exception:                                    # noqa: BLE001 - fall back to the codes feeds fetches
        pat = None
    codes = sorted(set(WEO_CODES), key=len, reverse=True)
    own = r"\b(" + "|".join(re.escape(c) for c in codes) + r")\b"
    return re.compile(f"{pat.pattern}|{own}" if pat is not None else own, re.IGNORECASE)


_WEO_CODE_RE = weo_code_re()


def provenance_imf_reason(series="", transform="") -> str | None:
    """CLIENT_RESTRICTED_REASON (with the code found) when the series or the free-text provenance names an IMF WEO
    code, or the transform names the IMF / WEO; None otherwise."""
    t = _text(transform).strip()
    if t.casefold().startswith(PLANNED_FEED_PREFIX):
        t = ""
    m = _WEO_CODE_RE.search(f"{_text(series)} {t}")
    if m:
        return f"{CLIENT_RESTRICTED_REASON}; provenance names IMF WEO code {m.group(0)}"
    if t and CLIENT_RESTRICTED_SOURCE_RE.search(t):
        return f"{CLIENT_RESTRICTED_REASON}; provenance names an IMF / WEO input"
    return None


def client_output_reason(source="", licence="", series="", national_ok=None, data_dir=None,
                         transform="") -> str | None:
    """Why a record must stay out of client output, or None. Everything restricted_reason bars is barred here too;
    on top, theratesapi.com / Banca d'Italia values (EXC-005, EQ-A-0073: CLIENT_THERATES_REASON), any IMF source or
    licence tag (official.IMF_LICENCE: 'internal research use only'), any value derived
    from a WEO series, and any national source ('national: ...') not in `national_ok` (default: national_licence_ok
    of data_dir, licence_ok=yes in panel/cb_series_verified.csv; EQ-A-0060).

    EQ-A-0076: the licence register (data/licences.csv, licences.cell_licence) is consulted first. A row with
    client_output restricted or barred keeps the record out; the reason is the existing rule's text when that rule
    also restricts it (unchanged wording), else the register's; the one exception is the IMF text
    (CLIENT_RESTRICTED_REASON), which only REGISTER_IMF rows keep: a research dataset tagged 'internal research use
    only' gets the register's reason naming its own row. Rows in REGISTER_CLEARABLE (national sources,
    hand-entered FX) defer to the licence_ok check. A row saying allowed, or no row, falls back to the rules.
    A register file that exists but is invalid restricts every record (licences.invalid_reason); a missing one leaves
    the rules alone."""
    from .licences import cell_licence, invalid_reason, register_reason
    bad = invalid_reason()                             # register present but invalid: fail closed (AGENT-05 review)
    if bad:
        return bad
    row = cell_licence({"source": _text(source), "licence": _text(licence), "series": _text(series)})
    rules = _client_output_reason_rules(source, licence, series, national_ok=national_ok, data_dir=data_dir)
    if row is not None and row["client_output"] != "allowed" and row["source_id"] not in REGISTER_CLEARABLE:
        if rules == CLIENT_RESTRICTED_REASON and row["source_id"] not in REGISTER_IMF:
            return register_reason(row, "client")      # a non-IMF 'internal research use only' tag (EQ-A-0067 datasets)
        return rules or register_reason(row, "client")
    return rules or provenance_imf_reason(series, transform)        # EQ-A-0124: WEO named only in the provenance


def _client_output_reason_rules(source="", licence="", series="", national_ok=None, data_dir=None) -> str | None:
    """The pre-register rules of client_output_reason (see there)."""
    why = _restricted_reason_rules(source, licence)
    if why:
        return why
    src = _text(source).strip()
    if src.startswith(NATIONAL_SOURCE_PREFIX) or src.startswith(FX_MANUAL_SOURCE_PREFIX):
        ok = national_licence_ok(data_dir) if national_ok is None else national_ok
        if src not in ok:
            return CLIENT_NATIONAL_REASON if src.startswith(NATIONAL_SOURCE_PREFIX) else CLIENT_HAND_FX_REASON
    lic = _text(licence).casefold()
    if any(t in lic for t in CLIENT_THERATES_LICENCE_TERMS) or CLIENT_THERATES_SOURCE_RE.search(_text(source)):
        return CLIENT_THERATES_REASON                    # EQ-A-0073: before the IMF rule, so the reason names EXC-005
    if any(t in lic for t in CLIENT_RESTRICTED_LICENCE_TERMS) or CLIENT_RESTRICTED_SOURCE_RE.search(_text(source)) \
            or CLIENT_RESTRICTED_SOURCE_RE.search(_text(series)):
        return CLIENT_RESTRICTED_REASON
    return None


def client_restricted_cells(data_dir: str | Path) -> pd.DataFrame:
    """Applied cells (indicators.csv, countries.csv) whose value must not go into client output: one row per cell,
    RESTRICTED_COLUMNS, matched to provenance / vintages / audit_trail.csv the same way as restricted_source_cells.
    Reads only. Not a desk-number restriction: nothing in fetch or apply refuses these cells."""
    ok = national_licence_ok(data_dir)
    return _matching_cells(data_dir, lambda r: client_output_reason(r["source"], r["licence"], r.get("series", ""),
                                                                     national_ok=ok, transform=r.get("transform", "")))


def _csv_export(cells: pd.DataFrame) -> None:
    """Print cells as CSV with text starting = + - @ TAB or CR neutralised for spreadsheets (SEC-A-007 I1)."""
    from .ledger import _neutralise
    out = cells.copy()
    for c in out.columns:
        if not pd.api.types.is_numeric_dtype(out[c]):
            out[c] = out[c].map(_neutralise)
    out.to_csv(sys.stdout, index=False)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.audit",
                                 description="Audit-trail checks (Team A)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("restricted", help="list applied cells whose value came from Yahoo or a non-commercial / "
                                          "personal licence (SEC-A-006 M1); exit 1 when any")
    r.add_argument("--data", default="data", help="econquest data folder (default: data)")
    r.add_argument("--csv", action="store_true", help="print the cells as CSV")
    c = sub.add_parser("client", help="list applied cells that must stay out of client output (IMF: internal research "
                                      "use only, Sam 2026-10-24; plus everything `restricted` lists); exit 1 when any")
    c.add_argument("--data", default="data", help="econquest data folder (default: data)")
    c.add_argument("--csv", action="store_true", help="print the cells as CSV")
    a = ap.parse_args(argv)
    if a.cmd == "client":
        cells = client_restricted_cells(a.data)
        if a.csv:
            _csv_export(cells)
        else:
            print(f"{len(cells)} cells restricted from client output in {a.data}")
            for r in cells.itertuples(index=False):
                print(f"  {r.table} {r.key} {r.country} = {r.value:g}  ({r.source}): {r.reason}")
        return 1 if len(cells) else 0
    cells = restricted_source_cells(a.data)
    if a.csv:
        _csv_export(cells)
    else:
        print(f"{len(cells)} restricted-source cells in {a.data}")
        if len(cells):
            print(restricted_warning(cells, limit=len(cells)))
    return 1 if len(cells) else 0


if __name__ == "__main__":
    sys.exit(main())
