"""MVP shared dataset (EQ-A-0110, MVP row M2): one complete, frozen, offline data directory built only from what is
already in the shared folder, with a value and a provenance label on every input cell.

Sources (nothing is fetched, nothing is invented):
- the shared ``data/`` folder (seed values, the 2026-10-23 vintage already applied, FX ``market_history/prices.csv``,
  ``fx_manual.csv``, the CRAG panel ``panel/sovereign_defaults_crag*.csv``), labelled per cell from
  ``data/audit_trail.csv``;
- Sam's latest full fetch, ``team/inbox/pull-20261025-fullfetch/review.csv`` (13:03Z, applied on his Mac as vintage
  ``2026-10-25T130355Z-aac8592d``). A review cell is taken live only where the gate passed it (status ``ok``) or a named,
  approved decision bound to that value released it, and no sticky hold pins it (``ledger.effective_holds``, which
  already refuses legacy hand-edited "apply" rows, EQ-A-0101). Every other review cell keeps the value the shared folder
  has and carries the gate's reason.
- Optional extra held candidates (``held_candidates``), e.g. the CRAG 1.8 count (EQ-A-0083): recorded in the gate report
  as held with their reason; the cell keeps its seed value.

Output, ``data/mvp/``::

    data/            a loadable data directory (``load_universe(data/mvp/data)``), files frozen read-only
    provenance.csv   one row per cell of indicators.csv and countries.csv: value, label (live | seed), source, vintage,
                     gate_status, reason
    gate_report.json every review cell's outcome; held, missing and blank cells each with an explicit reason;
                     ``unexplained`` must be 0
    manifest.json    sha256 per file, counts live/seed per table, as_of, the input files' sha256

Entry points: ``build`` / ``verify`` / ``mvp_data_dir`` / ``load_mvp_universe`` / ``materialize``, and
``python -m econquest.ingestion.mvp_dataset build|verify|materialize``.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import io
import json
import math
import os
import shutil
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REVIEW_UPLOAD = Path("team/inbox/pull-20261025-fullfetch/review.csv")
VINTAGE_ID = "2026-10-25T130355Z-aac8592d"
AS_OF = "2026-10-25"
SCHEMA = "econquest-mvp-dataset/1"
LABELS = ("live", "seed")

# paths under data/ that are not frozen into the MVP data directory (relative, POSIX)
EXCLUDE_DIRS = ("mvp", "live/vintages", "live/snapshots", "panel/staging", "panel/universe_staging",
                "market_history/archive", "market_history/builds", "market_history/repairs",
                "corpus",            # EQ-A-0131 point-in-time text corpus (publisher texts; never frozen)
                "sanctions",         # EQ-A-0133 sanctions-list snapshots (personal names; never frozen)
                "calendar/drop",     # EQ-A-0132 raw publisher files for the event calendar (events.csv is frozen)
                "live/macro",        # EQ-A-0134 macro pull vintages (BIS EER, Pink Sheet, ToT)
                "panel/hazard_panel_wide")   # EQ-A-0140 wide hazard predictor panel: IMF-via-WDI columns, internal
                                             # only, rebuilt by one command (hazard_panel_wide); never frozen
# EQ-A-0140: swap work folders of hazard_panel_wide.write_folder (<name>.tmp-* / <name>.old-<pid>); one definition,
# imported there, so a folder a SIGKILL leaves behind is never frozen (data/-relative, compared case-insensitively)
PANEL_WIDE_WORK_PREFIXES = ("panel/hazard_panel_wide.tmp-", "panel/hazard_panel_wide.old-")
# EQ-A-0130 (ARCH-A-PI10 R4): each live cell from the full fetch names its feed. First choice: the feed-specific
# record of the same cell and value in data/live/provenance.csv or a data/live/vintages/*/provenance.csv. Second: a
# recorded Mac pull from which econquest's own transform reproduces the value exactly (TRACE_PULLS). A cell with
# neither keeps the value but is labelled UNESTABLISHED (never the generic "econquest full fetch" text, which the
# econquest_derived register row would match as client-allowed).
GENERIC_SOURCE_PREFIX = "econquest full fetch"
TRACE_PULLS = ("team/inbox/pull-20261025T013150Z/raw_worldbank.csv",)   # Sam's Mac pull, 2026-10-25 01:31Z (wbgapi)
UNESTABLISHED = "unestablished source (no feed-specific record of this cell and value; EQ-A-0130)"
EXCLUDE_FILES = ("live/raw_bis.csv", "live/raw_yahoo.csv",          # raw pull responses the engine does not read
                 "live/review_ledger.csv")      # per-install named decisions (SEC-A-012 L1): the MVP has its own review
EXCLUDE_NAMES = (".lock", ".DS_Store")
OVERLAID = ("indicators.csv", "countries.csv")                      # rewritten by build
# also rewritten by build: live/review.csv, live/provenance.csv, audit_trail.csv (the MVP's own gate state)
REVIEW_FIELDS = ["table", "key", "country", "seed", "live", "status", "reason", "decision", "author", "approver",
                 "self_approved", "decided_utc"]


def vintage_as_of(vintage_id: str) -> str:
    """The date a vintage id starts with (YYYY-MM-DD...), the MVP's as_of."""
    v = str(vintage_id or "")
    try:
        return dt.date.fromisoformat(v[:10]).isoformat()
    except ValueError:
        raise MvpError(f"vintage id {v!r} does not start with a date (YYYY-MM-DD)") from None


class MvpError(RuntimeError):
    """The MVP dataset is missing, inconsistent or fails verification. Never falls back to data/."""


def _sha(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _num(v) -> float | None:
    try:
        x = float(str(v).strip().lstrip("'"))
    except (TypeError, ValueError):
        return None
    return x if math.isfinite(x) else None


def _read_csv(path: Path) -> tuple[list[str], list[dict]]:
    with open(path, newline="", encoding="utf-8") as f:
        r = csv.DictReader(f)
        return list(r.fieldnames or []), list(r)


def _csv_text(fields: list[str], rows: list[dict]) -> str:
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=fields, lineterminator="\n")
    w.writeheader()
    w.writerows(rows)
    return buf.getvalue()


def _excluded_dir(rel: str) -> bool:
    """rel (POSIX, relative to data/) is an EXCLUDE_DIRS folder or lies under one. Compared case-insensitively
    (SEC-A-015 P2-I3, EQ-A-0141): macOS file systems are case-insensitive, so data/Corpus/ or data/Sanctions/ is the
    same store and must stay out too."""
    r = rel.casefold()
    return any(r == d.casefold() or r.startswith(d.casefold() + "/") for d in EXCLUDE_DIRS)


def _excluded_file(rel: str, name: str) -> bool:
    """rel is an EXCLUDE_FILES path or name an EXCLUDE_NAMES name, case-insensitively (SEC-A-015 P2-I3)."""
    return (name.casefold() in {n.casefold() for n in EXCLUDE_NAMES}
            or rel.casefold() in {f.casefold() for f in EXCLUDE_FILES})


def _frozen_files(data_dir: Path) -> list[str]:
    out = []
    for p in sorted(data_dir.rglob("*")):
        if p.is_symlink():                               # SEC-A-012 L1: never freeze what a link points at
            rel = p.relative_to(data_dir).as_posix()
            if not _excluded_dir(rel):
                raise MvpError(f"data/{rel} is a symbolic link: the MVP freezes only regular files (remove the link)")
            continue
        if not p.is_file():
            continue
        rel = p.relative_to(data_dir).as_posix()
        if _excluded_file(rel, p.name) or "__pycache__" in rel:
            continue
        if _excluded_dir(rel):
            continue
        if rel.split("/")[0].startswith(".mvp-"):     # build / landing work folders (EQ-A-0116)
            continue
        if rel.casefold().startswith(PANEL_WIDE_WORK_PREFIXES):
            continue                                   # EQ-A-0140 swap work folders (hazard_panel_wide.write_folder)
        out.append(rel)
    return out


# ---- cell reconstruction ---------------------------------------------------------------------------------------------

def _audit(data_dir: Path) -> dict:
    p = data_dir / "audit_trail.csv"
    if not p.exists():
        return {}
    return {(r["table"], str(r["key"]), r["country"]): r for r in _read_csv(p)[1]}


def _base_label(audit_row: dict | None, value: str, table: str) -> tuple[str, str, str]:
    """(label, source, vintage) for a value as the shared folder has it."""
    if not str(value).strip():
        return "seed", f"blank in seed data/{table} (no value; not invented)", ""
    if audit_row and audit_row.get("origin") == "live feed" and _same_value(audit_row.get("value"), value):
        vint = audit_row.get("retrieved", "")
        return "live", f"vintage data/live/vintages/{vint} ({audit_row.get('source', '')}; {audit_row.get('series', '')})", vint
    if audit_row:
        return "seed", f"seed: {audit_row.get('origin', '')} ({audit_row.get('source', '')})", ""
    return "seed", f"seed: data/{table} (no audit-trail row)", ""


def _same_value(recorded, value) -> bool:
    """True when the audit trail recorded no value, or recorded this one (audit._same's rounding tolerance: indicators.csv
    keeps 4 decimals, countries.csv 4 significant digits). A live record whose value differs from the cell does not make
    the cell live (ARCH-A-PI10)."""
    a = _num(recorded)
    if recorded is None or not str(recorded).strip():
        return True
    b = _num(value)
    return a is not None and b is not None and abs(a - b) <= 1e-3 * max(1.0, abs(a))


def review_outcome(review_path: Path, vintage_id: str = VINTAGE_ID, decisions=None) -> list[dict]:
    """Each review row with ``applied`` (bool) and ``why``: the reconstruction of what Sam's apply took live.

    EQ-A-0114 (SEC-A-012 L3): a gate hold is released only by ``decisions``, the rows of a review ledger that
    ``ledger.verify_ledger`` passed (``ledger.load_decisions`` / ``read_ledger``). The upload's own decision columns
    are plain text, so only their hold / reject rows are used (they can only keep a cell on seed); an "apply" typed
    into the upload never releases anything."""
    import pandas as pd
    from .ledger import decisions_from_review, effective_holds
    review = pd.read_csv(review_path, dtype=str, keep_default_na=False)
    for c in ("decision", "author", "approver", "self_approved", "reason", "live", "status"):
        if c not in review.columns:
            review[c] = ""
    text = decisions_from_review(review)
    text = text[text["decision"].isin(["hold", "reject"])]
    ledger_rows = decisions if decisions is not None and len(decisions) else None
    dec = text if ledger_rows is None else pd.concat([text, ledger_rows[[c for c in ledger_rows.columns]]],
                                                       ignore_index=True)
    held = effective_holds(review, dec, vintage_id=vintage_id)
    latest = {}
    if ledger_rows is not None:
        for d in ledger_rows.itertuples(index=False):
            latest[(d.table, str(d.key), d.country)] = d
    out = []
    for r in review.to_dict("records"):
        cell = (r["table"], str(r["key"]), r["country"])
        live = _num(r.get("live"))
        status = str(r.get("status", "")).strip()
        kind = "held"
        if cell in held:
            reason, dec = str(r.get("reason", "")).strip(), str(r.get("decision", "")).strip()
            if status == "hold":                      # ARCH-A-PI10: no reason -> '' -> counted as unexplained
                why = f"held by gate (hold): {reason}" if reason else ""
            else:
                why = f"held by a standing decision ({dec} by {r.get('author', '')})" if dec else ""
            applied = False
        elif status == "ok" and live is not None:
            applied, why = True, "gate ok"
        elif status == "hold" and live is not None:
            d = latest.get(cell)
            if d is None:                             # cannot happen: effective_holds holds it without a ledger row
                raise MvpError(f"{cell}: hold released without a ledger decision")
            applied, why = True, (f"released by ledger-verified named decision: {d.decision} by {d.author}"
                                  f"{' (approver ' + d.approver + ')' if str(getattr(d, 'approver', '') or '') else ''}")
        elif status == "missing":
            applied, why, kind = False, f"missing: {r.get('reason', '') or 'feed returned no value'}", "missing"
        else:
            applied, why, kind = False, f"{status or 'no status'}: no usable live value", "missing"
        out.append({**r, "applied": applied, "why": why, "kind": "live" if applied else kind})
    return out


def _feed_value_same(a, b) -> bool:
    x, y = _num(a), _num(b)
    return x is not None and y is not None and abs(x - y) <= 1e-3 * max(1.0, abs(x))


def vintage_feed_records(data_dir: Path) -> dict:
    """{(table, key, country): [record]} of feed-specific provenance in the shared folder: data/live/provenance.csv and
    every data/live/vintages/*/provenance.csv (generic "econquest full fetch" records skipped). Read only."""
    root = Path(data_dir)
    files = [root / "live" / "provenance.csv"] + sorted((root / "live" / "vintages").glob("*/provenance.csv"))
    out: dict = {}
    for f in files:
        if not f.is_file() or f.is_symlink():
            continue
        for r in _read_csv(f)[1]:
            if not str(r.get("source", "")).strip() or str(r.get("source", "")).startswith(GENERIC_SOURCE_PREFIX):
                continue
            out.setdefault((r["table"], str(r["key"]), r["country"]), []).append(
                {**r, "evidence": f.relative_to(root.parent).as_posix() if root.parent in f.parents else f.name})
    return out


def traced_feed_records(root: Path, cells: dict) -> dict:
    """{cell: record} for applied Inputs cells (cells: {(table, key, country): value}) that econquest's own World Bank
    transform (feeds.wb_transforms) reproduces exactly from a recorded Mac pull in TRACE_PULLS. Read only."""
    import pandas as pd
    from . import feeds
    want = {c: v for c, v in cells.items() if c[0] == "Inputs"}
    if not want:
        return {}
    cty = pd.read_csv(Path(root) / "data" / "countries.csv", dtype=str, keep_default_na=False)
    iso = dict(zip(cty["country"], cty["iso"]))
    out = {}
    for rel in TRACE_PULLS:
        p = Path(root) / rel
        if not p.is_file():
            continue
        sha = _sha(p)
        long = pd.read_csv(p)
        long["period"] = pd.to_numeric(long["period"], errors="coerce")
        cache: dict = {}
        for (t, k, c), v in want.items():
            if (t, k, c) in out or c not in iso:
                continue
            if c not in cache:
                used: dict = {}
                cache[c] = (feeds.wb_transforms(long, iso[c], used)[0], used)
            ind, used = cache[c]
            x, y = ind.get(k), _num(v)
            if x is None or y is None or not math.isfinite(x) or abs(x - y) > 1e-9 * max(1.0, abs(x)):
                continue
            series = feeds.WB_SOURCE_SERIES.get(k, "") or used.get(k, "")
            out[(t, k, c)] = {"source": f"World Bank API via wbgapi ({series}); recomputed with econquest "
                                        f"feeds.wb_transforms from recorded pull {rel} sha256:{sha}, equal to the "
                                        "full-fetch value",
                              "series": used.get(k, "") or series, "evidence": f"{rel} sha256:{sha}"}
    return out


def feed_sources(root: Path, data_dir: Path, applied: dict) -> dict:
    """{cell: {"source", "series", "evidence", "how"}} for every applied full-fetch cell (applied: {cell: value}).
    how: vintage_record | traced | unestablished."""
    recs = vintage_feed_records(data_dir)
    out, rest = {}, {}
    for cell, v in applied.items():
        hits = [r for r in recs.get(cell, []) if _feed_value_same(r.get("value"), v)]
        if hits:
            srcs = list(dict.fromkeys(r["source"] for r in hits))
            sers = list(dict.fromkeys(r.get("series", "") for r in hits if r.get("series", "")))
            out[cell] = {"source": " | ".join(srcs), "series": " | ".join(sers),
                         "evidence": " | ".join(dict.fromkeys(r["evidence"] for r in hits)), "how": "vintage_record"}
        else:
            rest[cell] = v
    for cell, r in traced_feed_records(root, rest).items():
        out[cell] = {**r, "how": "traced"}
    for cell in rest:
        out.setdefault(cell, {"source": UNESTABLISHED, "series": "", "evidence": "", "how": "unestablished"})
    return out


def _cells(data_dir: Path, outcomes: list[dict], held_candidates: list[dict], upload_label: str,
           vintage_id: str = VINTAGE_ID, as_of: str = AS_OF, feeds_of=None):
    """Overlay applied live values onto indicators.csv / countries.csv. Returns (tables, provenance rows, gate rows)."""
    audit = _audit(data_dir)
    ind_f, ind = _read_csv(data_dir / "indicators.csv")
    cty_f, cty = _read_csv(data_dir / "countries.csv")
    ind_by = {r["id"]: r for r in ind}
    cty_by = {r["country"]: r for r in cty}
    applied, gate_rows, touched, review_out = {}, [], {}, {}
    for o in outcomes:
        t, k, c = o["table"], str(o["key"]), o["country"]
        if t == "Inputs":
            row, col = ind_by.get(k), c
        elif t == "Country Profile":
            row, col = cty_by.get(c), k
        else:
            row, col = None, None
        is_cell = row is not None and col in row
        g = {"table": t, "key": k, "country": c, "status": o.get("status", ""), "live": o.get("live", ""),
             "seed": o.get("seed", ""), "outcome": "", "reason": ""}
        if is_cell:
            review_out[(t, k, c)] = {f: o.get(f, "") for f in REVIEW_FIELDS}
        if not is_cell:
            g["outcome"], g["reason"] = "not_a_cell", f"no {t} cell for this key in data/ ({o['why']})"
        elif o["applied"]:
            row[col] = str(o["live"]).strip()
            applied[(t, k, c)] = o
            g["outcome"], g["reason"] = "live", o["why"]
        else:
            g["outcome"] = o["kind"]
            g["reason"] = o["why"]
            touched[(t, k, c)] = g
        gate_rows.append(g)
    for h in held_candidates or []:
        cell = (h["table"], str(h["key"]), h["country"])
        outcome = h.get("outcome", "held")
        if outcome not in ("held", "missing") or not str(h.get("reason", "")).strip():
            raise MvpError(f"held candidate {cell} needs outcome held|missing and a reason")
        g = {"table": h["table"], "key": str(h["key"]), "country": h["country"],
             "status": "hold" if outcome == "held" else "missing",
             "live": "" if h.get("value") is None else str(h["value"]), "seed": h.get("seed", ""),
             "outcome": outcome, "reason": h["reason"]}
        if cell in applied:
            raise MvpError(f"held candidate {cell} is also applied live from the review")
        gate_rows.append(g)
        touched[cell] = g
        review_out[cell] = {**{f: "" for f in REVIEW_FIELDS}, "table": g["table"], "key": g["key"], "country": g["country"],
                            "seed": g["seed"], "live": g["live"], "status": g["status"], "reason": g["reason"]}
    feed = feeds_of({c: o["live"] for c, o in applied.items()}) if feeds_of else {}
    prov, live_prov, kept_prior = [], [], {}
    for table, fields, rows in (("indicators.csv", ind_f, ind), ("countries.csv", cty_f, cty)):
        atable = "Inputs" if table == "indicators.csv" else "Country Profile"
        for r in rows:
            cols = ([c for c in fields if c not in ("id", "pillar", "indicator", "unit")] if table == "indicators.csv"
                    else [c for c in fields if c != "country"])
            for col in cols:
                key, country = (r["id"], col) if table == "indicators.csv" else (col, r["country"])
                cell = (atable, str(key), country)
                if cell in applied:
                    fs = feed.get(cell)
                    label, source, vint = "live", (f"vintage {vintage_id} ({upload_label}); feed: {fs['source']}" if fs
                                                   else f"vintage {vintage_id} ({upload_label})"), vintage_id
                    gstat, reason = applied[cell].get("status", "ok"), applied[cell]["why"]
                else:
                    label, source, vint = _base_label(audit.get(cell), r[col], table)
                    gstat, reason = "", ""
                    if cell in touched:          # held / missing: the value in place stays, labelled seed (M2)
                        gstat, reason = touched[cell]["status"], touched[cell]["reason"]
                        if label == "live":
                            source = (f"seed: value in place before vintage {vintage_id} (applied earlier from {source}); "
                                      f"kept because the new pull is {gstat}")
                            kept_prior[cell] = source
                            label, vint = "seed", ""
                    elif not str(r[col]).strip():
                        gstat, reason = "blank", source
                if label == "live":
                    a = audit.get(cell) or {}
                    fs = feed.get(cell) if vint == vintage_id else None
                    if vint == vintage_id and fs is None:
                        raise MvpError(f"{cell}: applied full-fetch cell without a feed source (EQ-A-0130)")
                    live_prov.append({"table": atable, "key": key, "country": country, "value": r[col],
                                      "source": (f"{fs['source']} (full fetch on Sam's Mac, vintage {vintage_id}, "
                                                 f"{upload_label}; feed named by {fs['how'].replace('_', ' ')}"
                                                 f"{': ' + fs['evidence'] if fs['evidence'] and fs['how'] != 'traced' else ''})"
                                                 if fs else a.get("source", "")),
                                      "series": fs["series"] if fs else a.get("series", ""),
                                      "retrieved": as_of if vint == vintage_id else a.get("retrieved", vint)})
                prov.append({"table": table, "key": key, "country": country, "value": r[col], "label": label,
                             "source": source, "vintage": vint, "gate_status": gstat, "reason": reason})
    tables = {"indicators.csv": (ind_f, ind), "countries.csv": (cty_f, cty)}
    return tables, prov, gate_rows, list(review_out.values()), live_prov, kept_prior


def _restricted_evidence(data_dir: Path, mvp_data: Path) -> list[dict]:
    """Records in the shared folder (live/provenance.csv, every vintage's provenance.csv, audit_trail.csv) that tie an
    MVP cell's value to a restricted source (Yahoo, a barred licence). The MVP rewrites its own provenance, so without
    this a restricted value carried over from data/ would look like a plain seed. Returned as provenance rows."""
    from .audit import restricted_source_cells
    with tempfile.TemporaryDirectory(prefix="econquest-mvp-restricted-") as td:
        e = Path(td)
        for rel in OVERLAID:
            shutil.copyfile(mvp_data / rel, e / rel)
        if (data_dir / "audit_trail.csv").is_file():
            shutil.copyfile(data_dir / "audit_trail.csv", e / "audit_trail.csv")
        (e / "live").mkdir()
        if (data_dir / "live" / "provenance.csv").is_file():
            shutil.copyfile(data_dir / "live" / "provenance.csv", e / "live" / "provenance.csv")
        vroot = data_dir / "live" / "vintages"
        if vroot.is_dir():
            for v in sorted(p for p in vroot.iterdir() if p.is_dir() and (p / "provenance.csv").is_file()):
                (e / "live" / "vintages" / v.name).mkdir(parents=True)
                shutil.copyfile(v / "provenance.csv", e / "live" / "vintages" / v.name / "provenance.csv")
        bad = restricted_source_cells(e)
    return [{"table": r["table"], "key": str(r["key"]), "country": r["country"], "value": r["value"],
             "source": r["source"], "series": r.get("series", ""), "retrieved": r.get("retrieved", "")}
            for r in bad.to_dict("records")]


def crag_held_candidates(data_dir: Path, as_of: str = AS_OF) -> list[dict]:
    """1.8 CRAG count cells (EQ-A-0083, indicator-rules 16): held as a Tier 1 batch, or not served (JPN, KOR, SGP)."""
    from ..rules.hazard import EventRuleError
    from .crag_count import CragCountError, mvp_held_cells
    try:                                              # fails loudly when the CRAG files are missing (no silent skip)
        return mvp_held_cells(data_dir, as_of)
    except (OSError, ValueError, KeyError, EventRuleError, CragCountError) as e:
        raise MvpError(f"1.8 CRAG cells could not be built ({e}); pass --no-crag to build without them") from e


# ---- build / verify --------------------------------------------------------------------------------------------------

def build(root: Path = ROOT, out: Path | None = None, review: Path | None = None, held_candidates: list[dict] | None = None,
          now: dt.datetime | None = None, *, vintage_id: str | None = None, decisions=None,
          releases: str = "none (no verified review ledger)", upload_files: dict | None = None) -> dict:
    """Build data/mvp/ from the shared folder. Writes into a temporary sibling and renames, so a failure leaves the
    previous MVP dataset in place. Returns the manifest.

    ``vintage_id`` names the vintage the review comes from (default VINTAGE_ID, Sam's 13:03Z full fetch); as_of is its
    date. ``decisions``: verified review-ledger rows, the only source of hold releases (EQ-A-0114); ``releases`` says
    where they came from, for the manifest. ``upload_files``: {name: sha256} of the upload the review came with
    (macpass_landing), recorded in the manifest."""
    vintage_id = vintage_id or VINTAGE_ID
    as_of = vintage_as_of(vintage_id)
    root = Path(root)
    data_dir = root / "data"
    out = Path(out) if out else data_dir / "mvp"
    if review is None and (out / "manifest.json").is_file():   # do not fall back to the 13:03Z upload after a landing
        cur = json.loads((out / "manifest.json").read_text()).get("vintage_id", "")
        if str(cur)[:17] > VINTAGE_ID[:17]:
            raise MvpError(f"{out} is on vintage {cur} from a Mac-pass landing; rebuild it with "
                           "`python -m econquest.ingestion.macpass_landing run` (or pass --review) instead of the "
                           f"default {REVIEW_UPLOAD}")
    review = Path(review) if review else root / REVIEW_UPLOAD
    if not review.exists():
        raise MvpError(f"review upload not found: {review}")
    crag = "skipped (--no-crag)" if held_candidates == [] else "indicator-rules 16, held Tier 1"
    if held_candidates is None:
        held_candidates = crag_held_candidates(data_dir, as_of)
        crag = "indicator-rules 16, held Tier 1"
    upload_label = review.relative_to(root).as_posix() if review.is_relative_to(root) else review.name
    outcomes = review_outcome(review, vintage_id, decisions)
    feed_how: dict = {}

    def feeds_of(applied_values):
        f = feed_sources(root, data_dir, applied_values)
        feed_how.update(f)
        return f
    tables, prov, gate_rows, review_rows, live_prov, kept_prior = _cells(data_dir, outcomes, held_candidates, upload_label,
                                                                         vintage_id, as_of, feeds_of)
    from collections import Counter
    feed_summary = dict(sorted(Counter(v["how"] for v in feed_how.values()).items()))
    feed_unestablished = sorted(f"{t} {k} {c}" for (t, k, c), v in feed_how.items() if v["how"] == "unestablished")
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = Path(tempfile.mkdtemp(prefix=".mvp-build-", dir=out.parent))
    try:
        dd = tmp / "data"
        for rel in _frozen_files(data_dir):
            dst = dd / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            if rel in OVERLAID:
                fields, rows = tables[rel]
                dst.write_text(_csv_text(fields, rows), encoding="utf-8")
            else:
                shutil.copyfile(data_dir / rel, dst)
        # the MVP's own gate review and live provenance, so audit.build_audit_trail (and econquest demo's M2 probe) sees
        # the MVP values: held / missing cells on labelled seed values, live cells tied to their pull; not_a_cell rows
        # (equity_vol: no countries.csv column) stay only in gate_report.json
        (dd / "live").mkdir(parents=True, exist_ok=True)
        restricted = _restricted_evidence(data_dir, dd)
        live_prov = live_prov + restricted          # kept as evidence, so verify() refuses the dataset (never hidden)
        (dd / "live" / "review.csv").write_text(_csv_text(REVIEW_FIELDS, review_rows), encoding="utf-8")
        (dd / "live" / "provenance.csv").write_text(
            _csv_text(["table", "key", "country", "value", "source", "series", "retrieved"], live_prov), encoding="utf-8")
        from .audit import build_audit_trail
        trail = build_audit_trail(dd)
        for i, r in trail.iterrows():                # say where a kept value came from (not an analyst estimate)
            src = kept_prior.get((r["table"], str(r["key"]), r["country"]))
            if src:
                trail.at[i, "origin"] = "seed kept (value from an earlier vintage; the new pull is held or missing)"
                trail.at[i, "source"] = src
        trail.to_csv(dd / "audit_trail.csv", index=False)
        pfields = ["table", "key", "country", "value", "label", "source", "vintage", "gate_status", "reason"]
        (tmp / "provenance.csv").write_text(_csv_text(pfields, prov), encoding="utf-8")
        report = gate_report(gate_rows, prov)
        (tmp / "gate_report.json").write_text(json.dumps(report, indent=1, sort_keys=True) + "\n", encoding="utf-8")
        files = {}
        for p in sorted(tmp.rglob("*")):
            if p.is_file():
                files[p.relative_to(tmp).as_posix()] = _sha(p)
        counts = {}
        for r in prov:
            c = counts.setdefault(r["table"], {"cells": 0, "live": 0, "seed": 0})
            c["cells"] += 1
            c[r["label"]] += 1
        inputs = {REVIEW_UPLOAD.as_posix() if upload_label == REVIEW_UPLOAD.as_posix() else upload_label: _sha(review)}
        for rel in ("indicators.csv", "countries.csv", "audit_trail.csv"):
            inputs[f"data/{rel}"] = _sha(data_dir / rel)
        for rel in TRACE_PULLS:
            if (root / rel).is_file() and any(v["how"] == "traced" for v in feed_how.values()):
                inputs[rel] = _sha(root / rel)
        pidx = data_dir / "panel" / "vintages" / "index.csv"
        panel_vintages = [r["vintage_id"] for r in _read_csv(pidx)[1]] if pidx.exists() else []
        manifest = {
            "schema": SCHEMA, "as_of": as_of, "vintage_id": vintage_id, "review_upload": upload_label,
            "releases": releases, "upload_files": dict(sorted((upload_files or {}).items())),
            "panel_vintages": panel_vintages, "crag_1_8": crag, "restricted_cells_at_build": len(restricted),
            "built_utc": (now or dt.datetime.now(dt.timezone.utc)).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "counts": counts, "gate": report["summary"], "inputs_sha256": inputs, "files": files,
            "dataset_sha256": hashlib.sha256("".join(f"{k}\0{v}\n" for k, v in files.items()).encode()).hexdigest(),
            "excluded": {"dirs": list(EXCLUDE_DIRS), "files": list(EXCLUDE_FILES)},
            "feed_source": {"counts": feed_summary, "unestablished": feed_unestablished},
        }
        (tmp / "manifest.json").write_text(json.dumps(manifest, indent=1, sort_keys=True) + "\n", encoding="utf-8")
        for p in tmp.rglob("*"):
            if p.is_file():
                os.chmod(p, 0o444)
        old = None
        if out.exists():
            old = out.parent / f".mvp-old-{os.getpid()}"
            _rmtree(old)
            out.rename(old)
        tmp.rename(out)
        if old is not None:
            _rmtree(old)
    except BaseException:
        _rmtree(tmp)
        raise
    return manifest


def _rmtree(p: Path) -> None:
    if not p.exists():
        return

    def onerr(func, path, _exc):
        os.chmod(path, 0o755 if os.path.isdir(path) else 0o644)
        func(path)
    for q in p.rglob("*"):
        try:
            os.chmod(q, 0o755 if q.is_dir() else 0o644)
        except OSError:
            pass
    shutil.rmtree(p, onerror=onerr)


def gate_report(gate_rows: list[dict], prov: list[dict]) -> dict:
    """Every review cell and every blank cell with its outcome and an explicit reason; ``unexplained`` counts the
    held / missing / blank cells without a reason (must be 0)."""
    from collections import Counter
    blanks = [{"table": r["table"], "key": r["key"], "country": r["country"], "outcome": "blank_seed",
               "reason": r["reason"]} for r in prov if r["gate_status"] == "blank"]
    unexplained = [g for g in gate_rows + blanks if g["outcome"] != "live" and not str(g["reason"]).strip()]
    summary = {"review_cells": sum(1 for g in gate_rows), "outcomes": dict(sorted(Counter(g["outcome"] for g in gate_rows).items())),
               "blank_seed_cells": len(blanks), "unexplained": len(unexplained)}
    return {"summary": summary, "cells": gate_rows, "blank_seed": blanks}


def mvp_dir(root: Path = ROOT) -> Path:
    return Path(root) / "data" / "mvp"


def verify(mvp: Path | None = None, load: bool = True) -> dict:
    """Check the frozen dataset: every manifest file present with its sha256 and no extra file, provenance labels
    valid, gate report has 0 unexplained cells (recounted from its cells), no cell's value comes from a restricted
    source (audit.restricted_source_cells, e.g. Yahoo fx3m), and (load=True) load_universe validates. Raises MvpError.
    Never falls back to data/."""
    mvp = Path(mvp) if mvp else mvp_dir()
    mpath = mvp / "manifest.json"
    if not mpath.exists():
        raise MvpError(f"no MVP dataset at {mvp} (run: python -m econquest.ingestion.mvp_dataset build)")
    m = json.loads(mpath.read_text())
    if m.get("schema") != SCHEMA:
        raise MvpError(f"unknown manifest schema {m.get('schema')!r}")
    problems = []
    present = {p.relative_to(mvp).as_posix() for p in mvp.rglob("*") if p.is_file()} - {"manifest.json"}
    for rel, sha in m["files"].items():
        if rel not in present:
            problems.append(f"missing file {rel}")
        elif _sha(mvp / rel) != sha:
            problems.append(f"sha256 mismatch {rel}")
    extra = sorted(present - set(m["files"]))
    problems += [f"file not in manifest {rel}" for rel in extra if "__pycache__" not in rel]
    if problems:
        raise MvpError("MVP dataset failed verification: " + "; ".join(problems[:20]))
    _, prov = _read_csv(mvp / "provenance.csv")
    bad = [r for r in prov if r["label"] not in LABELS or not r["source"].strip()]
    if bad:
        raise MvpError(f"{len(bad)} provenance rows without a valid label/source, e.g. {bad[0]}")
    rep = json.loads((mvp / "gate_report.json").read_text())
    unexplained = [g for g in rep.get("cells", []) + rep.get("blank_seed", [])
                   if g.get("outcome") != "live" and not str(g.get("reason", "")).strip()]
    if rep["summary"]["unexplained"] or unexplained:         # recounted, not only the stored summary (ARCH-A-PI10)
        raise MvpError(f"gate report has {max(rep['summary']['unexplained'], len(unexplained))} unexplained cells")
    from .audit import restricted_source_cells     # no Yahoo / barred-licence value may reach the MVP (M6), on every
    bad = restricted_source_cells(mvp / "data")    # path: load_mvp_universe / mvp_data_dir / materialize use load=False
    if len(bad):
        raise MvpError(f"{len(bad)} restricted-source cells in the MVP data, e.g. "
                       f"{bad.iloc[0]['table']} {bad.iloc[0]['key']} {bad.iloc[0]['country']}: {bad.iloc[0]['reason']}")
    out = {"ok": True, "as_of": m["as_of"], "vintage_id": m["vintage_id"], "files": len(m["files"]),
           "dataset_sha256": m["dataset_sha256"], "counts": m["counts"], "gate": rep["summary"], "restricted_cells": 0}
    if load:
        from .loaders import load_universe
        try:
            u = load_universe(mvp / "data")
        except (OSError, ValueError, KeyError) as e:
            raise MvpError(f"MVP data directory does not load: {e}") from e
        out["countries"] = len(u.names)
        out["indicators"] = int(len(u.indicators))
    return out


def mvp_data_dir(root: Path = ROOT, verified: bool = True) -> Path:
    """The MVP data directory (``data/mvp/data``), verified first. Read-only: run with ``--out`` elsewhere, or use
    ``materialize`` for a writable copy."""
    mvp = mvp_dir(root)
    if verified:
        verify(mvp, load=False)
    return mvp / "data"


def load_mvp_universe(root: Path = ROOT):
    """``Universe`` loaded from the verified MVP dataset; provenance["mvp"] names its manifest. For Team C's demo."""
    from .loaders import load_universe
    mvp = mvp_dir(root)
    v = verify(mvp, load=False)
    u = load_universe(mvp / "data")
    u.provenance["mvp"] = {k: v[k] for k in ("as_of", "vintage_id", "dataset_sha256", "counts")}
    return u


def materialize(dest: Path, root: Path = ROOT) -> Path:
    """Copy the verified MVP data directory to ``dest`` (writable), for a scratch run. ``dest`` must not exist and
    must not be inside the shared data folder."""
    dest = Path(dest).resolve()
    src = mvp_data_dir(root)
    if dest.exists():
        raise MvpError(f"{dest} exists")
    if dest.is_relative_to((Path(root) / "data").resolve()):
        raise MvpError("materialize target may not be inside data/")
    shutil.copytree(src, dest)
    for p in dest.rglob("*"):
        os.chmod(p, 0o755 if p.is_dir() else 0o644)
    return dest


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.mvp_dataset", description=__doc__.split("\n")[0])
    ap.add_argument("--root", default=str(ROOT), help="econquest folder (default: %(default)s)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("build", help="build data/mvp/ from the shared folder")
    b.add_argument("--review", help=f"review upload (default: {REVIEW_UPLOAD})")
    b.add_argument("--out", help="output folder (default: data/mvp)")
    b.add_argument("--no-crag", action="store_true", help="leave out the 1.8 CRAG cells (EQ-A-0083)")
    v = sub.add_parser("verify", help="verify data/mvp/ (hashes, labels, gate report, universe loads)")
    v.add_argument("--mvp", help="MVP folder (default: data/mvp)")
    mt = sub.add_parser("materialize", help="copy the verified MVP data directory to a writable folder")
    mt.add_argument("dest")
    a = ap.parse_args(argv)
    root = Path(a.root)
    try:
        if a.cmd == "build":
            m = build(root, out=Path(a.out) if a.out else None, review=Path(a.review) if a.review else None,
                      held_candidates=[] if a.no_crag else None)
            print(json.dumps({"as_of": m["as_of"], "vintage_id": m["vintage_id"], "files": len(m["files"]),
                              "dataset_sha256": m["dataset_sha256"], "counts": m["counts"], "gate": m["gate"]}, indent=1))
        elif a.cmd == "verify":
            print(json.dumps(verify(Path(a.mvp) if a.mvp else mvp_dir(root)), indent=1))
        else:
            print(materialize(Path(a.dest), root))
    except MvpError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
