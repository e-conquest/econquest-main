"""GDELT 2.0 Events adapter: daily per-country event counts, Goldstein scale and tone (EQ-A-0023).

Feeds indicator 6.9 (political violence trend, interim proxy with UCDP) and supplies protest evidence for 4.1.
Spike and licence notes: docs/runbooks/A-spike-event-feeds.md.

Route
-----
Raw GDELT 2.0 event export files, no credentials. GDELT 2.0 publishes one zip every 15 minutes
(``<YYYYMMDDHHMMSS>.export.CSV.zip``, 96 a day), listed in ``masterfilelist.txt`` (every file since 2015-02-18,
one ``<bytes> <md5> <url>`` line each) and ``lastupdate.txt`` (latest three files) under
``data.gdeltproject.org/gdeltv2/``. The index lists http:// URLs; this module rewrites them to https:// and refuses
plain http unless ``allow_http=True``. Whether data.gdeltproject.org serves https with a valid certificate was
NOT verified from this environment (the cloud cannot reach GDELT): if it fails on the Mac, re-run with
``--allow-http`` and the md5/size from the index still check every file. *(unverified)*

Alternative (not implemented): Google BigQuery public tables ``gdelt-bq.gdeltv2.events`` (and
``events_partitioned``) carry the same 61 columns; one SQL query per year replaces the download, but needs a
Google Cloud project with billing and a credential on the Mac. A BigQuery fetcher can be plugged in by
producing staged day files in the same layout (``STAGE_COLUMNS``).

Columns used (0-based index in the 61-column tab-delimited export, no header row; GDELT 2.0 Event Codebook)
----------------------------------------------------------------------------------------------------
 0 GLOBALEVENTID        dedupe key (an event appears once in the export stream; duplicates are dropped, first
                        file wins)
 1 SQLDATE              YYYYMMDD date of the event as reported (may be days or weeks before publication)
25 IsRootEvent          1 when the event comes from the article's lead paragraphs; root events only by default
28 EventRootCode        CAMEO root code: 14 = PROTEST *(verify against CAMEO manual)*
29 QuadClass            1 verbal coop, 2 material coop, 3 verbal conflict, 4 material conflict
30 GoldsteinScale       -10..+10 theoretical impact of the event type
31 NumMentions          mentions in the first 15 minutes of coverage
34 AvgTone              mean tone of documents mentioning the event (-100..+100, usually -10..+10)
53 ActionGeo_CountryCode FIPS 10-4 two-letter code, NOT ISO (Nigeria = NI, Niger = NG, Singapore = SN,
                        Senegal = SG, Zambia = ZA, South Africa = SF)
59 DATEADDED            YYYYMMDDHHMMSS UTC when GDELT added the event

Country codes
-------------
``FIPS_TO_ISO3`` is an explicit table for the desk's 18 countries (data/countries.csv), checked against FIPS
10-4. An override CSV (``fips,iso``) adds or replaces entries. Rows whose code is blank or not in the map are
dropped and counted per code in the report; nothing is guessed.

Point in time
-------------
Default ``date_basis="file"``: an event belongs to the UTC date of the 15-minute file that published it, so a day's
snapshot is fixed once its files are out and never revised by late reports. ``date_basis="event"`` uses SQLDATE
instead (revisable: later files add events to past days). Counts only reflect what the news media covered and
GDELT machine-coded: volume follows media attention, so compare a country with its own history or use shares.

Metrics (freq "D", one row per iso, staged day and metric; counts are 0 on a fully staged day with no events,
means are omitted when there are no events)
    events_total, events_material_conflict (QuadClass 4), events_verbal_conflict (QuadClass 3),
    events_protest (EventRootCode 14), goldstein_mean, tone_mean, mentions_total
    with ``categories=True`` / ``--categories`` (EQ-A-0139) also cat_<category> per econquest event category
    (events.taxonomy: CAMEO root -> category, plus cat_uncategorised; they add up to events_total). Off by default so
    existing vintages and the pull pack keep their shape. The FIPS reference table: events.fips_reference.

Staging (resumable; a year is ~35,000 files)
--------------------------------------------
``<stage_dir>/days/<YYYYMMDD>.csv`` holds the mapped rows of one day (``STAGE_COLUMNS``, all mapped countries,
root and non-root) and ``<stage_dir>/manifest.json`` records per day the source files (url, md5, bytes), sha256 of
the staged file, rows, unmapped counts and retrieval time. A day is skipped when it is staged ``ok``, its file
sha256 matches, its file list equals the index's and the FIPS map and parser version are unchanged. Raw zips are
not kept.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import io
import json
import os
import re
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import zipfile
from pathlib import Path
from typing import Callable, Iterable

import pandas as pd

from . import base as _base
from .base import EVENT_COLUMNS, EventAdapter, is_enabled, load_event_config, save_event_vintage

SOURCE = "gdelt"
LICENCE = ("GDELT Project: unlimited and unrestricted use for any academic, commercial or governmental use "
           "without fee; every use or redistribution must cite the GDELT Project and link to "
           "https://www.gdeltproject.org/ (terms: https://www.gdeltproject.org/about.html#termsofuse) "
           "[unverified: read 2026-10-23 in the spike, not re-checked]")
BASE_URL = "https://data.gdeltproject.org/gdeltv2/"
ALLOWED_HOSTS = frozenset({"data.gdeltproject.org"})
PARSER_VERSION = "gdelt-v2-export-61/1"
N_COLUMNS = 61
COLUMNS_USED = {0: "global_event_id", 1: "sqldate", 25: "is_root", 28: "event_root_code", 29: "quad_class",
                30: "goldstein", 31: "num_mentions", 34: "avg_tone", 53: "fips", 59: "dateadded"}
STAGE_COLUMNS = ["global_event_id", "file_ts", "dateadded", "sqldate", "fips", "iso", "is_root",
                 "event_root_code", "quad_class", "goldstein", "avg_tone", "num_mentions"]
COUNT_METRICS = ["events_total", "events_material_conflict", "events_verbal_conflict", "events_protest",
                 "mentions_total"]
MEAN_METRICS = ["goldstein_mean", "tone_mean"]
METRICS = COUNT_METRICS[:4] + MEAN_METRICS + ["mentions_total"]
PROTEST_ROOT = 14

MAX_ZIP_BYTES = 20 * 2**20            # one 15-minute export zip is ~0.1-1 MB (estimate); cap well above
MAX_CSV_BYTES = 200 * 2**20           # decompressed member cap (zip-bomb guard)
MAX_INDEX_BYTES = 1024 * 2**20        # masterfilelist.txt is ~100-200 MB in 2026 (estimate)
TIMEOUT = 60

# FIPS 10-4 -> ISO3 for the desk's 18 countries (data/countries.csv). Checked by hand against FIPS 10-4.
FIPS_TO_ISO3 = {
    "VM": "VNM", "RP": "PHL", "CH": "CHN", "MY": "MYS", "SN": "SGP", "JA": "JPN", "KS": "KOR", "IN": "IND",
    "PK": "PAK", "BH": "BLZ", "BR": "BRA", "AR": "ARG", "CO": "COL", "VE": "VEN", "NI": "NGA", "SG": "SEN",
    "ZA": "ZMB", "ZI": "ZWE",
}
_FIPS_RE = re.compile(r"[A-Z]{2}")
_ISO_RE = re.compile(r"[A-Z]{3}")
_EXPORT_RE = re.compile(r"(\d{14})\.export\.CSV\.zip")
_DAY_RE = re.compile(r"\d{8}")
_UNMAPPED_KEY_RE = re.compile(r"[A-Z0-9]{0,2}")    # codes kept as-is in unmapped counts; anything else -> "other"

Fetcher = Callable[..., bytes]     # base contract: fetcher(url, headers, data=None) -> bytes


class GdeltError(RuntimeError):
    pass


class GdeltNotFound(GdeltError):
    """The server answered 404 (a constructed URL for a slot GDELT never published)."""


class GdeltFormatError(GdeltError):
    pass


class IncompleteFetchError(GdeltError):
    def __init__(self, msg: str, report: dict):
        super().__init__(msg)
        self.report = report


# ----------------------------------------------------------------------------------------------- helpers

def _utc_now() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0)


def _stamp(t: dt.datetime) -> str:
    return t.strftime("%Y-%m-%dT%H:%M:%SZ")


def _as_date(x) -> dt.date:
    if isinstance(x, dt.datetime):
        return x.date()
    if isinstance(x, dt.date):
        return x
    return dt.date.fromisoformat(str(x)[:10])


def _atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        os.replace(tmp, path)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def check_url(url: str, allow_http: bool = False) -> str:
    """Return the URL to fetch: http:// on an allowed host is upgraded to https:// unless allow_http; any other
    scheme or host is refused."""
    p = urllib.parse.urlsplit(url)
    if p.hostname not in ALLOWED_HOSTS or p.username or p.password or p.port not in (None, 80, 443):
        raise GdeltError(f"refusing URL outside {sorted(ALLOWED_HOSTS)}: {url!r}")
    if p.scheme == "https":
        return urllib.parse.urlunsplit(("https", p.hostname, p.path, p.query, ""))
    if p.scheme == "http":
        scheme = "http" if allow_http else "https"
        return urllib.parse.urlunsplit((scheme, p.hostname, p.path, p.query, ""))
    raise GdeltError(f"refusing URL scheme {p.scheme!r}: {url!r}")


def make_url_fetcher(max_bytes: int = MAX_INDEX_BYTES, timeout: float = TIMEOUT, allow_http: bool = False) -> Fetcher:
    """Default fetcher (base contract signature): urllib GET of an allowed GDELT URL, streamed with a byte cap.
    404 -> GdeltNotFound. http is upgraded to https unless allow_http. Redirects are refused (GdeltError naming host and
    path) and the response must come from the requested scheme and host (SEC-A-002), so check_url's allow-list cannot
    be bypassed by a 3xx."""
    def fetch(url: str, headers: dict | None = None, data: bytes | None = None) -> bytes:
        if data is not None:
            raise GdeltError("GDELT raw files are GET only")
        url = check_url(url, allow_http)
        parts = urllib.parse.urlsplit(url)
        safe = f"{parts.hostname}{parts.path}"
        hdrs = {"User-Agent": "econquest/0.1 (+GDELT raw export reader)", **(headers or {})}
        req = _base.build_request(url, hdrs)
        try:
            # scheme and host were checked by check_url above; the opener refuses redirects
            with _base.build_no_redirect_opener().open(req, timeout=timeout) as r:  # nosec B310
                _base.check_final_url(r, parts.scheme, parts.hostname or "", safe, GdeltError)
                length = r.headers.get("Content-Length")
                if length and length.isdigit() and int(length) > max_bytes:
                    raise GdeltError(f"{url}: Content-Length {length} over cap {max_bytes}")
                buf = io.BytesIO()
                while True:
                    block = r.read(1 << 20)
                    if not block:
                        break
                    buf.write(block)
                    if buf.tell() > max_bytes:
                        raise GdeltError(f"{url}: more than {max_bytes} bytes, stopped")
                return buf.getvalue()
        except urllib.error.HTTPError as e:
            e.close()
            if e.code == 404:
                raise GdeltNotFound(url) from None
            if 300 <= e.code < 400:
                raise GdeltError(f"HTTP {e.code} redirect from {safe}; not followed") from None
            raise GdeltError(f"HTTP {e.code} from {safe}") from None
    return fetch


def load_fips_map(override_csv: str | Path | None = None, base: dict[str, str] | None = None) -> dict[str, str]:
    """FIPS 10-4 -> ISO3. Starts from the explicit desk table; an override CSV with columns fips,iso adds or
    replaces entries (an empty iso removes one). Codes are validated, never inferred."""
    m = dict(FIPS_TO_ISO3 if base is None else base)
    if override_csv:
        df = pd.read_csv(override_csv, dtype=str, keep_default_na=False)
        if not {"fips", "iso"} <= set(df.columns):
            raise GdeltFormatError(f"{override_csv}: needs columns fips,iso")
        for fips, iso in zip(df["fips"].str.strip().str.upper(), df["iso"].str.strip().str.upper()):
            if not _FIPS_RE.fullmatch(fips) or (iso and not _ISO_RE.fullmatch(iso)):
                raise GdeltFormatError(f"{override_csv}: bad row fips={fips!r} iso={iso!r}")
            if iso:
                m[fips] = iso
            else:
                m.pop(fips, None)
    return m


def _map_sha(m: dict[str, str]) -> str:
    return _sha256(json.dumps(sorted(m.items())).encode())[:16]


# ----------------------------------------------------------------------------------------------- index

def parse_masterfilelist(text: str, start: dt.date, end: dt.date) -> dict[str, list[dict]]:
    """Export files in [start, end] by file timestamp date, grouped by day 'YYYYMMDD'. Each entry
    {ts, url, md5, bytes}. Lines for mentions/gkg files and malformed lines are skipped."""
    days: dict[str, list[dict]] = {}
    lo, hi = start.strftime("%Y%m%d"), end.strftime("%Y%m%d")
    for line in text.splitlines():
        parts = line.split()
        if len(parts) != 3:
            continue
        size, md5, url = parts
        m = _EXPORT_RE.search(url)
        if not m or not url.endswith(m.group(0)) or not size.isdigit() or not re.fullmatch(r"[0-9a-f]{32}", md5):
            continue
        ts = m.group(1)
        if lo <= ts[:8] <= hi:
            days.setdefault(ts[:8], []).append({"ts": ts, "url": url, "md5": md5, "bytes": int(size)})
    for v in days.values():
        v.sort(key=lambda e: e["ts"])
    return days


def constructed_index(start: dt.date, end: dt.date, base_url: str = BASE_URL) -> dict[str, list[dict]]:
    """All 96 quarter-hour slots per day without the master list (no md5/size check; missing slots are allowed)."""
    days: dict[str, list[dict]] = {}
    d = start
    while d <= end:
        key = d.strftime("%Y%m%d")
        days[key] = [{"ts": f"{key}{h:02d}{q:02d}00", "url": f"{base_url}{key}{h:02d}{q:02d}00.export.CSV.zip",
                      "md5": "", "bytes": 0} for h in range(24) for q in (0, 15, 30, 45)]
        d += dt.timedelta(days=1)
    return days


# ----------------------------------------------------------------------------------------------- parsing

def unzip_export(data: bytes, max_csv_bytes: int = MAX_CSV_BYTES) -> bytes:
    """The single .CSV member of an export zip, refusing members over the cap (checked before and while reading)."""
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        members = [i for i in z.infolist() if not i.is_dir()]
        if len(members) != 1 or not members[0].filename.upper().endswith(".CSV"):
            raise GdeltFormatError(f"expected one .CSV member, got {[i.filename for i in members]}")
        info = members[0]
        if info.file_size > max_csv_bytes:
            raise GdeltError(f"zip member {info.filename} is {info.file_size} bytes, over cap {max_csv_bytes}")
        with z.open(info) as f:
            out = f.read(max_csv_bytes + 1)
        if len(out) > max_csv_bytes:
            raise GdeltError(f"zip member {info.filename} decompresses past cap {max_csv_bytes}")
        return out


def parse_export(raw: bytes, file_ts: str = "") -> pd.DataFrame:
    """Parse one 61-column tab-delimited GDELT 2.0 event export (no header) into the used columns, typed.
    Raises GdeltFormatError when a row does not have 61 fields."""
    cols = list(COLUMNS_USED.values())
    if not raw.strip():
        return pd.DataFrame(columns=cols + ["file_ts"])
    text = raw.decode("utf-8", errors="replace")
    rows = []
    for n, line in enumerate(text.splitlines(), 1):
        if not line:
            continue
        f = line.split("\t")
        if len(f) != N_COLUMNS:
            raise GdeltFormatError(f"{file_ts or 'export'} line {n}: {len(f)} fields, expected {N_COLUMNS}")
        rows.append([f[i] for i in COLUMNS_USED])
    df = pd.DataFrame(rows, columns=cols)
    df["fips"] = df["fips"].str.strip().str.upper()
    for c in ("is_root", "event_root_code", "quad_class", "num_mentions"):
        df[c] = pd.to_numeric(df[c], errors="coerce").astype("Int64")
    for c in ("goldstein", "avg_tone"):
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df["file_ts"] = file_ts
    return df


def map_countries(df: pd.DataFrame, fips_map: dict[str, str]) -> tuple[pd.DataFrame, dict[str, int]]:
    """Attach iso from ActionGeo_CountryCode; return (mapped rows, {code: dropped count}) where blank codes count
    under ''."""
    iso = df["fips"].map(fips_map)
    codes = df.loc[iso.isna(), "fips"].fillna("").astype(str)
    # raw feed text goes into manifests and reports: keep only short code-like keys, group the rest as "other"
    codes = codes.where(codes.str.fullmatch(_UNMAPPED_KEY_RE), "other")
    unmapped = codes.value_counts().to_dict()
    out = df.loc[iso.notna()].copy()
    out["iso"] = iso[iso.notna()]
    return out, {str(k): int(v) for k, v in unmapped.items()}


def dedupe(df: pd.DataFrame) -> tuple[pd.DataFrame, int]:
    """Drop repeated GlobalEventIDs, keeping the earliest file."""
    s = df.sort_values(["file_ts", "global_event_id"], kind="stable")
    out = s.drop_duplicates("global_event_id", keep="first")
    return out, len(df) - len(out)


def aggregate(staged: pd.DataFrame, isos: Iterable[str], days: Iterable[str], root_only: bool = True,
              date_basis: str = "file") -> pd.DataFrame:
    """Daily metrics per iso (wide: iso, period + METRICS). Every (iso, day) for the given staged days gets a row;
    with date_basis='event', event dates outside ``days`` are dropped (they belong to unstaged days)."""
    isos = list(isos)
    days = sorted(days)
    df = staged.copy()
    if root_only:
        df = df[df["is_root"] == 1]
    if date_basis == "file":
        df["day"] = df["file_ts"].astype(str).str[:8]
    elif date_basis == "event":
        df["day"] = df["sqldate"].astype(str).str[:8]
    else:
        raise ValueError("date_basis must be 'file' or 'event'")
    df = df[df["iso"].isin(isos) & df["day"].isin(days)]
    g = df.groupby(["iso", "day"])
    agg = pd.DataFrame({
        "events_total": g.size(),
        "events_material_conflict": g["quad_class"].apply(lambda s: int((s == 4).sum())),
        "events_verbal_conflict": g["quad_class"].apply(lambda s: int((s == 3).sum())),
        "events_protest": g["event_root_code"].apply(lambda s: int((s == PROTEST_ROOT).sum())),
        "goldstein_mean": g["goldstein"].mean(),
        "tone_mean": g["avg_tone"].mean(),
        "mentions_total": g["num_mentions"].sum(min_count=1).astype("float"),
    }) if len(df) else pd.DataFrame(columns=METRICS)
    full = pd.MultiIndex.from_product([isos, days], names=["iso", "day"])
    agg = agg.reindex(full)
    for c in COUNT_METRICS:
        agg[c] = agg[c].fillna(0).astype(float)
    agg = agg.reset_index()
    agg["period"] = pd.to_datetime(agg["day"], format="%Y%m%d").dt.strftime("%Y-%m-%d")
    return agg[["iso", "period"] + METRICS]


def to_long(wide: pd.DataFrame, retrieved: dict[str, str], licence: str = LICENCE) -> pd.DataFrame:
    """Wide daily metrics -> EVENT_COLUMNS long rows; means with no events are omitted."""
    long = wide.melt(id_vars=["iso", "period"], value_vars=METRICS, var_name="metric", value_name="value")
    long = long.dropna(subset=["value"])
    long["freq"] = "D"
    long["source"] = SOURCE
    long["vintage_id"] = ""
    long["retrieved_utc"] = long["period"].str.replace("-", "").map(retrieved).fillna("")
    long["licence"] = licence
    long["value"] = long["value"].astype(float)
    order = {m: i for i, m in enumerate(METRICS)}
    long = long.sort_values(["period", "iso", "metric"], key=lambda s: s.map(order) if s.name == "metric" else s)
    return long[EVENT_COLUMNS].reset_index(drop=True)


def category_rows(staged: pd.DataFrame, isos: Iterable[str], days: Iterable[str], retrieved: dict[str, str],
                  root_only: bool = True, date_basis: str = "file", licence: str = LICENCE) -> pd.DataFrame:
    """EQ-A-0139: daily cat_<category> counts (events.taxonomy, CAMEO root -> econquest category) as EVENT_COLUMNS
    rows, zero-filled for every (iso, staged day); same root/date-basis selection as aggregate()."""
    from .taxonomy import gdelt_category_counts
    wide = gdelt_category_counts(staged, isos, days, root_only, date_basis)
    long = wide.melt(id_vars=["iso", "period"], var_name="metric", value_name="value")
    long["freq"], long["source"], long["vintage_id"], long["licence"] = "D", SOURCE, "", licence
    long["retrieved_utc"] = long["period"].str.replace("-", "").map(retrieved).fillna("")
    long["value"] = long["value"].astype(float)
    return long.sort_values(["period", "iso", "metric"])[EVENT_COLUMNS].reset_index(drop=True)


def _taxonomy_version() -> str:
    from .taxonomy import TAXONOMY_VERSION
    return TAXONOMY_VERSION


# ----------------------------------------------------------------------------------------------- adapter

class GdeltAdapter(EventAdapter):
    """GDELT 2.0 raw export files -> daily per-country metrics (see module docstring)."""

    source = SOURCE
    licence = LICENCE

    def __init__(self, stage_dir: str | Path | None = None, *, fips_map: dict[str, str] | None = None,
                 fips_map_csv: str | Path | None = None, root_only: bool = True, date_basis: str = "file",
                 index: str = "masterfilelist", base_url: str = BASE_URL, allow_http: bool = False,
                 max_zip_bytes: int = MAX_ZIP_BYTES, max_csv_bytes: int = MAX_CSV_BYTES,
                 max_index_bytes: int = MAX_INDEX_BYTES, retries: int = 3, backoff: float = 2.0,
                 sleep: Callable[[float], None] = time.sleep, now: Callable[[], dt.datetime] = _utc_now,
                 log: Callable[[str], None] | None = None, enabled: bool = True, categories: bool = False):
        super().__init__()
        self.categories = bool(categories)         # EQ-A-0139: add cat_<category> counts (events.taxonomy)
        self.enabled = enabled
        if index not in ("masterfilelist", "constructed"):
            raise ValueError("index must be 'masterfilelist' or 'constructed'")
        if date_basis not in ("file", "event"):
            raise ValueError("date_basis must be 'file' or 'event'")
        self.stage_dir = Path(stage_dir) if stage_dir else Path(tempfile.mkdtemp(prefix="gdelt-stage-"))
        self.fips_map = load_fips_map(fips_map_csv, fips_map)
        self.root_only, self.date_basis, self.index = root_only, date_basis, index
        self.base_url = check_url(base_url, allow_http)
        self.allow_http = allow_http
        self.max_zip_bytes, self.max_csv_bytes, self.max_index_bytes = max_zip_bytes, max_csv_bytes, max_index_bytes
        self.retries, self.backoff, self.sleep, self.now = retries, backoff, sleep, now
        self.log = log or (lambda msg: None)
        self.report: dict = {}

    # -- fetching with retries and checks
    def _get(self, fetcher: Fetcher, url: str, cap: int, md5: str = "", size: int = 0) -> bytes:
        url = check_url(url, self.allow_http)
        last: Exception | None = None
        for attempt in range(self.retries + 1):
            if attempt:
                self.sleep(self.backoff * 2 ** (attempt - 1))
            try:
                try:
                    data = fetcher(url, {}, None)
                except RuntimeError as e:      # base.http_fetch reports a 404 as RuntimeError("HTTP 404 ...")
                    if str(e).startswith("HTTP 404"):
                        raise GdeltNotFound(url) from e
                    raise
                if len(data) > cap:
                    raise GdeltError(f"{url}: {len(data)} bytes, over cap {cap}")
                if size and len(data) != size:
                    raise GdeltError(f"{url}: {len(data)} bytes, index says {size}")
                if md5 and hashlib.md5(data, usedforsecurity=False).hexdigest() != md5:
                    raise GdeltError(f"{url}: md5 does not match the index")
                return data
            except GdeltNotFound:
                raise
            except Exception as e:  # network errors, truncation, checksum: retry
                last = e
                self.log(f"attempt {attempt + 1} failed for {url}: {e}")
        raise GdeltError(f"{url}: failed after {self.retries + 1} attempts: {last}")

    def _index(self, fetcher: Fetcher, start: dt.date, end: dt.date) -> dict[str, list[dict]]:
        """Day -> files. `fetcher` is used only for masterfilelist.txt (index cap)."""
        if self.index == "constructed":
            return constructed_index(start, end, self.base_url)
        cached = self.stage_dir / "masterfilelist.txt"
        text = cached.read_text() if cached.is_file() else ""
        last_day = end.strftime("%Y%m%d")
        if not text or not any(e["ts"].endswith("234500") for e in parse_masterfilelist(text, end, end).get(last_day, [])):
            text = self._get(fetcher, self.base_url + "masterfilelist.txt", self.max_index_bytes).decode("utf-8", "replace")
            _atomic_write(cached, text.encode())
            self.log(f"fetched masterfilelist.txt ({len(text)} bytes)")
        return parse_masterfilelist(text, start, end)

    def _manifest_path(self) -> Path:
        return self.stage_dir / "manifest.json"

    def _load_manifest(self) -> dict:
        p = self._manifest_path()
        m = json.loads(p.read_text()) if p.is_file() else {}
        m.setdefault("days", {})
        return m

    def _save_manifest(self, m: dict) -> None:
        _atomic_write(self._manifest_path(), json.dumps(m, indent=1, sort_keys=True).encode())

    def _day_is_current(self, rec: dict | None, files: list[dict]) -> bool:
        if not rec or rec.get("status") != "ok":
            return False
        f = self.stage_dir / "days" / f"{rec.get('day', '')}.csv"
        return (f.is_file() and _sha256(f.read_bytes()) == rec.get("sha256")
                and rec.get("files") == [e["url"] for e in files]
                and rec.get("map_sha") == _map_sha(self.fips_map) and rec.get("parser") == PARSER_VERSION)

    def stage_day(self, day: str, files: list[dict], fetcher: Fetcher) -> dict:
        """Download, check, parse, map and dedupe one day's export files; write days/<day>.csv. Returns the record."""
        if not _DAY_RE.fullmatch(day):
            raise GdeltError(f"bad day key {day!r}")
        parts, unmapped, absent, failed = [], {}, [], {}
        rows_in = 0
        for e in files:
            try:
                data = self._get(fetcher, e["url"], self.max_zip_bytes, e.get("md5", ""), e.get("bytes", 0))
                df = parse_export(unzip_export(data, self.max_csv_bytes), e["ts"])
            except GdeltNotFound:
                if self.index == "constructed":
                    absent.append(e["ts"])
                    continue
                failed[e["ts"]] = "404 for a file listed in masterfilelist"
                continue
            except GdeltError as err:
                failed[e["ts"]] = str(err)
                continue
            rows_in += len(df)
            mapped, um = map_countries(df, self.fips_map)
            for k, v in um.items():
                unmapped[k] = unmapped.get(k, 0) + v
            parts.append(mapped)
        staged = pd.concat(parts, ignore_index=True) if parts else pd.DataFrame(columns=STAGE_COLUMNS)
        staged, dupes = dedupe(staged) if len(staged) else (staged, 0)
        staged = staged[STAGE_COLUMNS]
        data = staged.to_csv(index=False, lineterminator="\n").encode()
        rec = {"day": day, "status": "failed" if failed else "ok", "files": [e["url"] for e in files],
               "absent": absent, "failed": failed, "rows_in": rows_in, "rows_mapped": len(staged),
               "duplicates_dropped": dupes, "unmapped": dict(sorted(unmapped.items())),
               "map_sha": _map_sha(self.fips_map), "parser": PARSER_VERSION, "retrieved_utc": _stamp(self.now())}
        if not failed:
            _atomic_write(self.stage_dir / "days" / f"{day}.csv", data)
            rec["sha256"] = _sha256(data)
        return rec

    def stage(self, start, end, fetcher: Fetcher | None = None) -> dict:
        """Stage every day in [start, end] (by file timestamp), skipping days already staged and current.
        Returns the report; raises IncompleteFetchError (after staging what it could) if any day failed."""
        start, end = _as_date(start), _as_date(end)
        if end < start:
            raise ValueError("end before start")
        # default fetchers: one per request kind so each download is capped at its own size while streaming
        # (index 1 GiB, export zip 20 MiB), not at the larger of the two
        index_fetcher = fetcher or make_url_fetcher(self.max_index_bytes, allow_http=self.allow_http)
        fetcher = fetcher or make_url_fetcher(self.max_zip_bytes, allow_http=self.allow_http)
        self.stage_dir.mkdir(parents=True, exist_ok=True)
        index = self._index(index_fetcher, start, end)
        manifest = self._load_manifest()
        report = {"start": start.isoformat(), "end": end.isoformat(), "staged": [], "skipped": [], "failed": {},
                  "no_files": [], "unmapped": {}, "duplicates_dropped": 0, "rows_mapped": 0}
        d = start
        while d <= end:
            day = d.strftime("%Y%m%d")
            d += dt.timedelta(days=1)
            files = index.get(day, [])
            if not files:
                report["no_files"].append(day)
                continue
            if self._day_is_current(manifest["days"].get(day), files):
                report["skipped"].append(day)
                rec = manifest["days"][day]
            else:
                rec = self.stage_day(day, files, fetcher)
                manifest["days"][day] = rec
                self._save_manifest(manifest)
                (report["failed"].__setitem__(day, rec["failed"]) if rec["status"] != "ok" else report["staged"].append(day))
                self.log(f"{day}: {rec['status']} rows={rec['rows_mapped']} files={len(files)}")
            for k, v in rec.get("unmapped", {}).items():
                report["unmapped"][k] = report["unmapped"].get(k, 0) + v
            report["duplicates_dropped"] += rec.get("duplicates_dropped", 0)
            report["rows_mapped"] += rec.get("rows_mapped", 0)
        report["unmapped_total"] = sum(report["unmapped"].values())
        self.report = report
        if report["failed"]:
            raise IncompleteFetchError(f"{len(report['failed'])} day(s) incomplete: {sorted(report['failed'])}; "
                                       "re-run to resume", report)
        return report

    def load_staged(self, start, end) -> tuple[pd.DataFrame, list[str], dict[str, str]]:
        """Staged rows, the ok days and their retrieval times for [start, end]."""
        start, end = _as_date(start), _as_date(end)
        manifest = self._load_manifest()
        lo, hi = start.strftime("%Y%m%d"), end.strftime("%Y%m%d")
        days, frames, retrieved = [], [], {}
        for day, rec in sorted(manifest["days"].items()):
            if not (lo <= day <= hi) or rec.get("status") != "ok":
                continue
            f = self.stage_dir / "days" / f"{day}.csv"
            data = f.read_bytes() if f.is_file() else b""
            if _sha256(data) != rec.get("sha256"):
                raise GdeltError(f"staged {f} missing or changed since staging (sha256 mismatch)")
            frames.append(pd.read_csv(io.BytesIO(data), dtype={"global_event_id": str, "file_ts": str,
                                                              "dateadded": str, "sqldate": str, "fips": str,
                                                              "iso": str}, keep_default_na=False,
                                      na_values={c: [""] for c in ("goldstein", "avg_tone", "num_mentions",
                                                                    "is_root", "quad_class", "event_root_code")}))
            days.append(day)
            retrieved[day] = rec.get("retrieved_utc", "")
        staged = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame(columns=STAGE_COLUMNS)
        if len(staged):
            staged, _ = dedupe(staged)
        return staged, days, retrieved

    def provenance(self) -> dict:
        """Manifest fields for save_event_vintage: route, options, per-day staging hashes and the last report."""
        man = self._load_manifest() if self._manifest_path().is_file() else {"days": {}}
        r = self.report
        days = {d: {"sha256": rec.get("sha256", ""), "files": len(rec.get("files", [])), "absent": len(rec.get("absent", [])),
                    "rows_mapped": rec.get("rows_mapped", 0), "retrieved_utc": rec.get("retrieved_utc", "")}
                for d, rec in man["days"].items() if r.get("start", "9") <= f"{d[:4]}-{d[4:6]}-{d[6:]}" <= r.get("end", "0")}
        return {"route": f"raw export files {self.base_url} (index: {self.index})", "parser": PARSER_VERSION,
                "root_only": self.root_only, "date_basis": self.date_basis, "fips_map": dict(sorted(self.fips_map.items())),
                "fips_map_sha": _map_sha(self.fips_map), "unmapped": r.get("unmapped", {}),
                "unmapped_total": r.get("unmapped_total", 0), "duplicates_dropped": r.get("duplicates_dropped", 0),
                "no_files": r.get("no_files", []), "isos_without_fips": r.get("isos_without_fips", []), "days": days,
                **({"taxonomy": _taxonomy_version()} if self.categories else {})}

    def fetch(self, isos, start, end, fetcher: Fetcher | None = None) -> pd.DataFrame:
        """Stage [start, end] (resumable) and return daily metrics as EVENT_COLUMNS rows (vintage_id blank;
        save_event_vintage assigns it). Requested isos must be ISO3; isos with no FIPS mapping are reported."""
        isos = [str(i).strip().upper() for i in isos]
        bad = [i for i in isos if not _ISO_RE.fullmatch(i)]
        if bad:
            raise ValueError(f"not ISO3: {bad}")
        self.stage(start, end, fetcher)
        staged, days, retrieved = self.load_staged(start, end)
        self.report["isos_without_fips"] = sorted(set(isos) - set(self.fips_map.values()))
        wide = aggregate(staged, isos, days, self.root_only, self.date_basis)
        out = to_long(wide, retrieved, self.licence)
        if self.categories:
            out = pd.concat([out, category_rows(staged, isos, days, retrieved, self.root_only, self.date_basis,
                                                self.licence)], ignore_index=True)
        self.validate(out)
        return out


# ----------------------------------------------------------------------------------------------- CLI

def _desk_isos(data_dir: Path) -> list[str]:
    return pd.read_csv(data_dir / "countries.csv", dtype=str)["iso"].str.strip().tolist()


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.events.gdelt",
                                 description="Stage GDELT 2.0 raw event exports (resumable) and build daily metrics.")
    ap.add_argument("--start", required=True, help="first day YYYY-MM-DD (UTC file date)")
    ap.add_argument("--end", required=True, help="last day YYYY-MM-DD")
    ap.add_argument("--data-dir", default="data")
    ap.add_argument("--stage-dir", default=None, help="default <data-dir>/live/events/gdelt/staging")
    ap.add_argument("--isos", default="", help="comma-separated ISO3 (default: data/countries.csv)")
    ap.add_argument("--fips-map", default=None, help="override CSV fips,iso")
    ap.add_argument("--index", choices=("masterfilelist", "constructed"), default="masterfilelist")
    ap.add_argument("--include-non-root", action="store_true")
    ap.add_argument("--date-basis", choices=("file", "event"), default="file")
    ap.add_argument("--allow-http", action="store_true", help="only if https to data.gdeltproject.org fails")
    ap.add_argument("--retries", type=int, default=3)
    ap.add_argument("--backoff", type=float, default=2.0)
    ap.add_argument("--categories", action="store_true",
                    help="also store cat_<category> counts (econquest event taxonomy, EQ-A-0139)")
    ap.add_argument("--save", action="store_true", help="save the result as an event vintage")
    ap.add_argument("--out", default=None, help="also write the long CSV here")
    a = ap.parse_args(argv)
    data_dir = Path(a.data_dir)
    if not is_enabled(load_event_config(data_dir).get(SOURCE, {}), default=True):
        print("gdelt is disabled in data/live/events/feeds.json", file=sys.stderr)
        return 2
    stage = Path(a.stage_dir) if a.stage_dir else data_dir / "live" / "events" / "gdelt" / "staging"
    isos = [s for s in a.isos.split(",") if s] or _desk_isos(data_dir)
    ad = GdeltAdapter(stage, fips_map_csv=a.fips_map, root_only=not a.include_non_root, date_basis=a.date_basis,
                      index=a.index, allow_http=a.allow_http, retries=a.retries, backoff=a.backoff,
                      log=lambda m: print(m, file=sys.stderr, flush=True), categories=a.categories)
    try:
        df = ad.fetch(isos, a.start, a.end)
    except IncompleteFetchError as e:
        print(json.dumps(e.report, indent=1), file=sys.stderr)
        print(f"INCOMPLETE: {e}", file=sys.stderr)
        return 1
    print(json.dumps({k: v for k, v in ad.report.items() if k not in ("staged", "skipped")}, indent=1))
    print(f"staged {len(ad.report['staged'])} day(s), skipped {len(ad.report['skipped'])}, rows {len(df)}")
    if a.out:
        _atomic_write(Path(a.out), df.to_csv(index=False, lineterminator="\n").encode())
    if a.save:
        print(f"saved vintage {save_event_vintage(data_dir, df, SOURCE, provenance=ad.provenance())}")
        from .export import write_event_exports      # keep the consumer exports current (EQ-A-0028)
        ex = write_event_exports(data_dir)
        print(f"exports {ex['long']} ({ex['long_rows']} rows), {ex['weekly']} ({ex['weekly_rows']} rows)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
