"""Country-mapping QA for the event feeds (EQ-A-0052): events whose country name or code does not map to an ISO3 code
of the country universe.

Every event row is classified by its source's country key (UCDP: Gleditsch-Ward country_id and country name;
GDELT: FIPS 10-4 ActionGeo_CountryCode):

    mapped            the adapter's map gives an ISO3 that is in the universe
    outside_universe  the key resolves to an ISO3 that is not in the universe (the adapter's map, or for GDELT the
                      optional FIPS reference table): a legitimate event elsewhere, left out of the share
    unmapped          nothing resolves the key, or the reference resolves it to a universe country the adapter's map
                      lacks (iso3 then says which; add it to the override CSV). Counted per name / code.

unmapped_share = unmapped events / (mapped + unmapped events). The report breaches when the share is above
`threshold` (default DEFAULT_THRESHOLD); the CLI then exits 2. `universe_without_mapping` lists universe countries the
adapter's map cannot produce at all (their events are dropped, or for UCDP cannot be requested).

The universe is data/panel/universe_proposal.csv (iso3; the 88-country proposal) when present, else the desk's
data/countries.csv. Nothing is guessed: names and codes are matched exactly (names case-insensitively) against the
adapter maps and the optional reference table.

GDELT: the adapter's FIPS map (gdelt.FIPS_TO_ISO3 plus its override CSV) covers the desk only, and the staging
manifest keeps unmapped codes without saying which country they are. Without a full FIPS -> ISO3 reference every
code outside the map would count as unmapped. So while data/live/events/gdelt/fips_reference.csv (columns
fips,iso; from GDELT's or another authoritative FIPS 10-4 list, sourced on Sam's Mac, never typed from memory) is
absent, those codes are reported as "outside known map (reference table missing)" (status outside_known_map), left
out of the share, and the report carries a WARN line; only codes the adapter's map produces count against the
threshold (AGENT-08 2026-10-24). With the reference the full rule above applies. Unmapped counts come from the staging manifest per day and are raw rows (before GlobalEventID dedupe); mapped
counts are the staged rows (after dedupe).
UCDP: requests are filtered by Gleditsch-Ward id, so every returned event should map; the adapter refuses a pull with
any unmapped event (UnmappedCountryError). The QA is run on the raw events of the pull (`UcdpAdapter.raw_events`), or
offline on saved API pages:

    python -m econquest.ingestion.events.mapping_qa gdelt --start 2026-10-01 --end 2026-10-23 [--json]
    python -m econquest.ingestion.events.mapping_qa ucdp --pages page0.json page1.json [--json]

Exit: 0 share at or below the threshold, 2 above it, 1 bad input.
"""
from __future__ import annotations

import argparse
import datetime as dt
import io
import json
import sys
from pathlib import Path

import pandas as pd

QA_COLUMNS = ["source", "code", "name", "iso3", "status", "events"]
STATUSES = ("mapped", "outside_universe", "outside_known_map", "unmapped")
OUTSIDE_KNOWN_MAP = "outside known map (reference table missing)"
DEFAULT_THRESHOLD = 0.02
EXIT_OK, EXIT_ERROR, EXIT_BREACH = 0, 1, 2
FIPS_REFERENCE = Path("live") / "events" / "gdelt" / "fips_reference.csv"     # relative to the data folder
GDELT_STAGE = Path("live") / "events" / "gdelt" / "staging"


def universe_isos(data_dir: str | Path = "data") -> tuple[set[str], str]:
    """(ISO3 codes of the universe, where they came from): universe_proposal.csv, else countries.csv."""
    d = Path(data_dir)
    p = d / "panel" / "universe_proposal.csv"
    if p.is_file():
        df = pd.read_csv(p, dtype=str, keep_default_na=False)
        if "iso3" in df.columns:
            return {s.strip().upper() for s in df["iso3"] if s.strip()}, str(p)
    df = pd.read_csv(d / "countries.csv", dtype=str, keep_default_na=False)
    return {s.strip().upper() for s in df["iso"] if s.strip()}, str(d / "countries.csv")


def classify(records: pd.DataFrame, universe: set[str], reference: dict[str, str] | None = None,
             reference_missing: bool = False) -> pd.DataFrame:
    """records: source, code, name, iso3 (from the adapter's map, '' when none), events -> QA_COLUMNS with status.
    `reference` (code -> ISO3) only classifies keys the adapter did not map. With `reference_missing` (GDELT without
    fips_reference.csv) a key the adapter did not map is `outside_known_map`, left out of the share (AGENT-08
    2026-10-24): only what the adapter's map produces counts against the threshold."""
    ref = reference or {}
    out = records.copy()
    for c in ("code", "name", "iso3"):
        out[c] = out[c].fillna("").astype(str)
    out["events"] = pd.to_numeric(out["events"], errors="coerce").fillna(0).astype(int)
    status = []
    for r in out.itertuples(index=False):
        if r.iso3:
            status.append("mapped" if r.iso3 in universe else "outside_universe")
            continue
        if reference_missing:
            status.append("outside_known_map")
            continue
        hint = ref.get(r.code.upper(), "")
        status.append("outside_universe" if hint and hint not in universe else "unmapped")
    out["status"] = status
    hinted = (out["status"] == "unmapped") & (out["iso3"] == "")
    out.loc[hinted, "iso3"] = out.loc[hinted, "code"].str.upper().map(ref).fillna("")
    out = out.groupby(["source", "code", "name", "iso3", "status"], as_index=False)["events"].sum()
    return out[QA_COLUMNS].sort_values(["status", "events", "code", "name"], ascending=[True, False, True, True],
                                        ignore_index=True)


def qa_report(table: pd.DataFrame, universe: set[str], mapped_isos: set[str], threshold: float = DEFAULT_THRESHOLD,
              source: str = "", universe_source: str = "", notes: list[str] | None = None,
              warn: list[str] | None = None) -> dict:
    """Summary of a classify() table. mapped_isos: every ISO3 the adapter's map can produce."""
    n = {s: int(table.loc[table["status"] == s, "events"].sum()) for s in STATUSES}
    scope = n["mapped"] + n["unmapped"]
    share = n["unmapped"] / scope if scope else 0.0
    un = table[table["status"] == "unmapped"]
    return {"source": source, "threshold": threshold, "events_mapped": n["mapped"],
            "events_outside_universe": n["outside_universe"], "events_unmapped": n["unmapped"],
            "events_outside_known_map": n["outside_known_map"],
            "outside_known_map": [{"code": r.code, "name": r.name, "events": int(r.events), "status": OUTSIDE_KNOWN_MAP}
                                  for r in table[table["status"] == "outside_known_map"].itertuples(index=False)],
            "warn": list(warn or []),
            "unmapped_share": round(share, 6), "breach": share > threshold,
            "unmapped": [{"code": r.code, "name": r.name, "iso3_hint": r.iso3, "events": int(r.events)}
                         for r in un.itertuples(index=False)],
            "universe": universe_source, "universe_size": len(universe),
            "universe_without_mapping": sorted(universe - mapped_isos), "notes": list(notes or [])}


# ------------------------------------------------------------------------------------------------ UCDP

def ucdp_records(events: list[dict], by_id: dict[int, str], by_name: dict[str, str]) -> pd.DataFrame:
    """Raw UCDP events -> records (source, code = country_id, name = country, iso3, events). Same lookup as
    ucdp.map_countries (id first, then name); an id/name conflict is left unmapped (iso3 '') so it is counted."""
    counts: dict = {}
    for e in events:
        cid, name = e.get("country_id"), str(e.get("country") or "").strip()
        iso_id = by_id.get(int(cid)) if str(cid).strip().lstrip("-").isdigit() else None
        iso_nm = by_name.get(name.lower()) if name else None
        iso = "" if (iso_id and iso_nm and iso_id != iso_nm) else (iso_id or iso_nm or "")
        k = (str(cid if cid is not None else ""), name, iso)
        counts[k] = counts.get(k, 0) + 1
    return pd.DataFrame([{"source": "ucdp", "code": c, "name": n, "iso3": i, "events": v}
                         for (c, n, i), v in counts.items()], columns=["source", "code", "name", "iso3", "events"])


def ucdp_qa(events: list[dict], data_dir: str | Path = "data", threshold: float = DEFAULT_THRESHOLD,
            country_map_csv: Path | None = None) -> tuple[dict, pd.DataFrame]:
    from .ucdp import load_country_map
    d = Path(data_dir)
    if country_map_csv is None:
        country_map_csv = d / "live" / "events" / "ucdp" / "country_map.csv"
    by_id, by_name = load_country_map(country_map_csv)
    universe, usrc = universe_isos(d)
    table = classify(ucdp_records(events, by_id, by_name), universe)
    rep = qa_report(table, universe, set(by_id.values()) | set(by_name.values()), threshold, "ucdp", usrc)
    return rep, table


# ------------------------------------------------------------------------------------------------ GDELT

def load_fips_reference(path: str | Path | None) -> dict[str, str]:
    """FIPS -> ISO3 reference for QA only (columns fips,iso). {} when the file is absent."""
    if not path or not Path(path).is_file():
        return {}
    from .gdelt import load_fips_map
    return load_fips_map(path, base={})


def gdelt_records(stage_dir: str | Path, start=None, end=None) -> tuple[pd.DataFrame, list[str]]:
    """Records from a GDELT staging folder for the ok days in [start, end] (all days when None): mapped rows per
    (fips, iso) from days/<day>.csv, unmapped rows per code from manifest.json. Returns (records, days used)."""
    stage = Path(stage_dir)
    man_p = stage / "manifest.json"
    if not man_p.is_file():
        raise FileNotFoundError(f"{man_p} not found: no GDELT staging to check")
    man = json.loads(man_p.read_text()).get("days", {})
    lo = pd.Timestamp(start).strftime("%Y%m%d") if start is not None else "00000000"
    hi = pd.Timestamp(end).strftime("%Y%m%d") if end is not None else "99999999"
    counts: dict = {}
    days = []
    for day, rec in sorted(man.items()):
        if not (lo <= day <= hi) or rec.get("status") != "ok":
            continue
        days.append(day)
        for code, n in (rec.get("unmapped") or {}).items():
            k = (str(code), "")
            counts[k] = counts.get(k, 0) + int(n)
        f = stage / "days" / f"{day}.csv"
        if f.is_file():
            df = pd.read_csv(io.BytesIO(f.read_bytes()), dtype=str, keep_default_na=False, usecols=["fips", "iso"])
            for (fips, iso), n in df.groupby(["fips", "iso"]).size().items():
                k = (fips, iso)
                counts[k] = counts.get(k, 0) + int(n)
    rows = [{"source": "gdelt", "code": c, "name": "", "iso3": i, "events": v} for (c, i), v in counts.items()]
    return pd.DataFrame(rows, columns=["source", "code", "name", "iso3", "events"]), days


def gdelt_qa(data_dir: str | Path = "data", start=None, end=None, stage_dir: str | Path | None = None,
             threshold: float = DEFAULT_THRESHOLD, fips_map_csv: str | Path | None = None,
             fips_reference: str | Path | None = None) -> tuple[dict, pd.DataFrame]:
    from .gdelt import load_fips_map
    d = Path(data_dir)
    stage = Path(stage_dir) if stage_dir else d / GDELT_STAGE
    ref_path = Path(fips_reference) if fips_reference else d / FIPS_REFERENCE
    ref = load_fips_reference(ref_path)
    fmap = load_fips_map(fips_map_csv)
    universe, usrc = universe_isos(d)
    recs, days = gdelt_records(stage, start, end)
    table = classify(recs, universe, ref, reference_missing=not ref)
    notes = [f"days checked: {len(days)} ({days[0]}..{days[-1]})" if days else "no staged ok day in the range"]
    warn = []
    if not ref:
        n_out = int(table.loc[table["status"] == "outside_known_map", "events"].sum())
        warn.append(f"no FIPS reference at {ref_path}: {n_out} events with codes outside the adapter's FIPS map are "
                    f"reported as '{OUTSIDE_KNOWN_MAP}' and not counted; only codes the map produces are checked "
                    "against the threshold. Source the reference from GDELT's or another authoritative FIPS 10-4 "
                    "list on Sam's Mac (docs/runbooks/A-data-ops.md)")
    rep = qa_report(table, universe, set(fmap.values()), threshold, "gdelt", usrc, notes, warn)
    return rep, table


# ------------------------------------------------------------------------------------------------ CLI

def format_report(rep: dict, limit: int = 30) -> str:
    lines = [f"WARN: {w}" for w in rep.get("warn", [])]
    lines += [f"{rep['source']} mapping QA: {rep['events_unmapped']} unmapped of "
             f"{rep['events_mapped'] + rep['events_unmapped']} in-scope events (share {rep['unmapped_share']:.2%}, "
             f"threshold {rep['threshold']:.2%}) -> {'BREACH' if rep['breach'] else 'ok'}; "
             f"{rep['events_outside_universe']} events outside the universe"
             + (f", {rep['events_outside_known_map']} {OUTSIDE_KNOWN_MAP}" if rep.get("events_outside_known_map") else "")]
    for u in rep["unmapped"][:limit]:
        hint = f" (reference: {u['iso3_hint']})" if u["iso3_hint"] else ""
        lines.append(f"  unmapped {u['code'] or '-'} {u['name'] or ''}{hint}: {u['events']}")
    if len(rep["unmapped"]) > limit:
        lines.append(f"  ... and {len(rep['unmapped']) - limit} more")
    miss = rep["universe_without_mapping"]
    lines.append(f"  universe ({rep['universe_size']} from {rep['universe']}): {len(miss)} countries without a "
                 f"mapping{': ' + ', '.join(miss[:40]) if miss else ''}{' ...' if len(miss) > 40 else ''}")
    lines += [f"  note: {n}" for n in rep["notes"]]
    return "\n".join(lines)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.events.mapping_qa",
                                 description="Country-mapping QA for event feeds (EQ-A-0052); exit 2 when the "
                                             "unmapped share is above the threshold")
    sub = ap.add_subparsers(dest="cmd", required=True)
    g = sub.add_parser("gdelt", help="QA of the GDELT staging (manifest + staged days)")
    g.add_argument("--start", default=None, help="first day YYYY-MM-DD (default: every staged day)")
    g.add_argument("--end", default=None, help="last day YYYY-MM-DD")
    g.add_argument("--stage-dir", default=None, help="default <data>/live/events/gdelt/staging")
    g.add_argument("--fips-map", default=None, help="the adapter's override CSV fips,iso (as given to the pull)")
    g.add_argument("--fips-reference", default=None, help=f"full FIPS -> ISO3 reference (default <data>/{FIPS_REFERENCE})")
    u = sub.add_parser("ucdp", help="QA of saved UCDP API pages (JSON with a Result list)")
    u.add_argument("--pages", nargs="+", required=True, help="saved API page JSON files")
    u.add_argument("--country-map", default=None, help="override CSV (default <data>/live/events/ucdp/country_map.csv)")
    for p in (g, u):
        p.add_argument("--data", default="data", help="econquest data folder (default: data)")
        p.add_argument("--threshold", type=float, default=DEFAULT_THRESHOLD, help="maximum unmapped share (0-1)")
        p.add_argument("--json", action="store_true")
    a = ap.parse_args(argv)
    if not 0 <= a.threshold <= 1:
        print("--threshold must be between 0 and 1", file=sys.stderr)
        return EXIT_ERROR
    try:
        if a.cmd == "gdelt":
            rep, _ = gdelt_qa(a.data, a.start, a.end, a.stage_dir, a.threshold, a.fips_map, a.fips_reference)
        else:
            events = []
            for p in a.pages:
                doc = json.loads(Path(p).read_text())
                if not isinstance(doc, dict) or not isinstance(doc.get("Result"), list):
                    raise ValueError(f"{p}: no 'Result' list")
                events += doc["Result"]
            rep, _ = ucdp_qa(events, a.data, a.threshold, Path(a.country_map) if a.country_map else None)
    except (FileNotFoundError, ValueError, OSError) as e:
        print(f"mapping QA: {e}", file=sys.stderr)
        return EXIT_ERROR
    rep["checked_utc"] = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    print(json.dumps(rep, indent=1) if a.json else format_report(rep))
    return EXIT_BREACH if rep["breach"] else EXIT_OK


if __name__ == "__main__":
    sys.exit(main())
