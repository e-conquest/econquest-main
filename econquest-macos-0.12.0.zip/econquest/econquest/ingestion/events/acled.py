"""ACLED adapter (EQ-A-0024): built, but DISABLED until Sam decides on a corporate licence.

Licence (docs/runbooks/A-spike-event-feeds.md, ACLED EULA read 2026-10-23): commercial entities may not use ACLED
content without a corporate licence (EULA §1.2); the free tier is non-commercial. Shared material must be
transformative and must not let the data be rebuilt (§3.1). So:
- fetch() refuses (AcledDisabledError, before any credential is read or request sent) unless the config has
  "enabled": true (the JSON boolean; "true"/"false" strings do not count) AND a licence string
  (data/live/events/feeds.json, key "acled"). Expected licence form: a short label naming the signed corporate
  licence, e.g. "ACLED corporate licence <agreement ref>, signed <YYYY-MM-DD>". Empty, "none", "pending", "null",
  "no", a non-string, or a string starting with = + - @ TAB/CR (formula injection) or holding control characters is
  refused. Credential variable names (token_env, username_env, password_env) must start with ACLED_.
- Raw ACLED rows stay on the Mac. save_acled_vintage writes only monthly aggregates by default; raw rows are written
  only with include_raw=True, and then only inside data/live/events/acled/vintages/<id>/raw_acled.csv. Do not upload,
  publish or commit that folder.
- The configured licence string is stored on every row and in the manifest.

API *(from ACLED's getting-started page as read for the spike; parameter names marked verify were not confirmed)*:
- Token: POST https://acleddata.com/oauth/token, form fields username, password, grant_type=password,
  client_id=acled; JSON reply with access_token (24 h). Credentials only from env ACLED_USERNAME / ACLED_PASSWORD,
  or a ready token in ACLED_ACCESS_TOKEN (env names are ours, configurable).
- Data: GET https://acleddata.com/api/acled/read?iso=<numeric>&event_date=<A>|<B>&event_date_where=BETWEEN
  &limit=5000&page=<n> with header Authorization: Bearer <token>. Reply JSON with a `data` list *(verify: key name,
  `iso` filter, page numbering from 1, end of pages when a page has fewer than `limit` rows)*.
- Fields used: event_date (YYYY-MM-DD), event_type, sub_event_type, iso (ISO 3166-1 numeric), country, fatalities.

Monthly metrics (freq "M"): events_protest (Protests), events_riot (Riots), events_violence_civilians (Violence
against civilians), events_battles (Battles), events_explosions_remote (Explosions/Remote violence),
events_abductions (sub-event Abduction/forced disappearance), events_looting_property (sub-event Looting/property
destruction), events_total, fatalities.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import urllib.parse
from pathlib import Path

import pandas as pd

from econquest.ingestion.events.base import (
    EVENT_COLUMNS, ISO3_RE, EventAdapter, EventDataError, RequestBudget, check_env_name, env_secret, fetch_with_retries,
    http_fetch, is_enabled, licence_problem, load_event_config, month_start, save_event_vintage, utc_stamp,
)

TOKEN_URL = "https://acleddata.com/oauth/token"
READ_URL = "https://acleddata.com/api/acled/read"
ALLOWED_HOST = "acleddata.com"
DEFAULT_LIMIT = 5000
DISABLED_LICENCES = {"", "none", "null", "no", "pending"}
DEFAULT_DAILY_LIMIT = 2000
REDISTRIBUTION_NOTE = ("ACLED EULA: raw rows may not be redistributed or published; only transformative aggregates "
                       "leave the Mac. Raw rows, when kept, stay under data/live/events/acled/ only.")

EVENT_TYPE_METRIC = {"Protests": "events_protest", "Riots": "events_riot",
                     "Violence against civilians": "events_violence_civilians", "Battles": "events_battles",
                     "Explosions/Remote violence": "events_explosions_remote"}
SUB_EVENT_METRIC = {"Abduction/forced disappearance": "events_abductions",
                    "Looting/property destruction": "events_looting_property"}
METRICS = sorted(set(EVENT_TYPE_METRIC.values()) | set(SUB_EVENT_METRIC.values()) | {"events_total", "fatalities"})

# ISO 3166-1 numeric -> alpha-3 for the desk's 18 countries (ACLED's `iso` field is the numeric code).
ISO_NUM_TO_ISO3 = {
    704: "VNM", 608: "PHL", 156: "CHN", 458: "MYS", 702: "SGP", 392: "JPN", 410: "KOR", 356: "IND", 586: "PAK",
    84: "BLZ", 76: "BRA", 32: "ARG", 170: "COL", 862: "VEN", 566: "NGA", 686: "SEN", 894: "ZMB", 716: "ZWE",
}


class AcledDisabledError(RuntimeError):
    """ACLED is off (not enabled, or no licence configured). No credential is read and no request is sent."""


class UnmappedAcledCountryError(EventDataError):
    pass


def acled_ready(cfg: dict) -> tuple[bool, str]:
    """(ready, reason). Ready only when enabled is the JSON boolean true and licence is a usable non-empty string."""
    if not is_enabled(cfg, default=False):
        return False, "ACLED is disabled (data/live/events/feeds.json: acled.enabled is not the JSON boolean true)"
    raw = cfg.get("licence")
    lic = raw.strip() if isinstance(raw, str) else ""
    if lic.lower() in DISABLED_LICENCES:
        return False, ("ACLED has no licence configured (acled.licence); the free tier does not cover a commercial "
                       "desk (EULA §1.2). Sam must record the corporate licence first")
    why = licence_problem(raw)                                   # unstripped: a leading TAB/CR is refused too
    if why:
        return False, f"ACLED licence string refused ({why}); use a plain label such as 'ACLED corporate licence <ref>'"
    return True, ""


def aggregate_monthly(rows: list[dict], isos: list[str], start: dt.date, end: dt.date, retrieved_utc: str,
                      licence: str, iso_map: dict[int, str] | None = None) -> pd.DataFrame:
    """Raw ACLED rows -> monthly counts per iso and metric. Months are zero-filled from the later of `start` and the
    country's first returned event month up to `end`, so a country's pre-coverage years are never reported as 0."""
    iso_map = iso_map or ISO_NUM_TO_ISO3
    recs, missing = [], set()
    for r in rows:
        raw_iso = str(r.get("iso", "")).strip()
        iso = iso_map.get(int(raw_iso)) if raw_iso.isdigit() else None
        if not iso:
            missing.add((raw_iso, r.get("country")))
            continue
        try:
            fat = float(r.get("fatalities") or 0)
        except ValueError:
            raise EventDataError(f"ACLED row {r.get('event_id_cnty')}: fatalities {r.get('fatalities')!r}") from None
        recs.append({"iso": iso, "period": month_start(str(r["event_date"])[:10]), "event_type": r.get("event_type", ""),
                     "sub_event_type": r.get("sub_event_type", ""), "fatalities": fat})
    if missing:
        raise UnmappedAcledCountryError(f"ACLED iso codes not in the map: {sorted(missing, key=str)}")
    ev = pd.DataFrame(recs, columns=["iso", "period", "event_type", "sub_event_type", "fatalities"])
    lo_all, hi = month_start(start), month_start(end)
    ev = ev[(ev["period"] >= lo_all) & (ev["period"] <= hi) & ev["iso"].isin(isos)]
    parts = []
    for iso in sorted(set(isos)):
        sub = ev[ev["iso"] == iso]
        if sub.empty:
            continue                                   # no events at all: coverage unknown, emit nothing rather than 0
        months = [p.start_time.date() for p in pd.period_range(max(lo_all, sub["period"].min()), hi, freq="M")]
        g = pd.DataFrame(index=pd.Index(months, name="period"))
        for et, m in EVENT_TYPE_METRIC.items():
            g[m] = sub[sub["event_type"] == et].groupby("period").size().reindex(g.index, fill_value=0)
        for se, m in SUB_EVENT_METRIC.items():
            g[m] = sub[sub["sub_event_type"] == se].groupby("period").size().reindex(g.index, fill_value=0)
        g["events_total"] = sub.groupby("period").size().reindex(g.index, fill_value=0)
        g["fatalities"] = sub.groupby("period")["fatalities"].sum().reindex(g.index, fill_value=0.0)
        g = g.astype(float).reset_index()
        g.insert(0, "iso", iso)
        parts.append(g)
    if not parts:
        return pd.DataFrame(columns=EVENT_COLUMNS)
    wide = pd.concat(parts, ignore_index=True)
    long = wide.melt(id_vars=["iso", "period"], var_name="metric", value_name="value")
    long["period"] = long["period"].map(lambda d: d.isoformat())
    long["freq"], long["source"], long["vintage_id"] = "M", "acled", ""
    long["retrieved_utc"], long["licence"] = retrieved_utc, licence
    return long[EVENT_COLUMNS].sort_values(["iso", "period", "metric"]).reset_index(drop=True)


class AcledAdapter(EventAdapter):
    source = "acled"

    def __init__(self, data_dir: Path | None = None, config: dict | None = None, limit: int = DEFAULT_LIMIT,
                 budget: RequestBudget | None = None, retries: int = 3, backoff: float = 2.0, sleep=None,
                 max_pages: int = 200, now: dt.datetime | None = None):
        cfg = dict(config if config is not None else load_event_config(data_dir).get("acled", {}) if data_dir
                   else {"enabled": False, "licence": "none"})
        self.cfg = cfg
        self.enabled = is_enabled(cfg, default=False)              # only JSON true enables; "false" does not
        lic = self._licence_cfg = cfg.get("licence")                  # as configured; checked by acled_ready
        self.licence = lic.strip() if isinstance(lic, str) and lic.strip() else "none"
        self.username_env = check_env_name(cfg.get("username_env", "ACLED_USERNAME"), "acled.username_env", "ACLED_")
        self.password_env = check_env_name(cfg.get("password_env", "ACLED_PASSWORD"), "acled.password_env", "ACLED_")
        self.token_env = check_env_name(cfg.get("token_env", "ACLED_ACCESS_TOKEN"), "acled.token_env", "ACLED_")
        self.limit = int(limit)
        # persisted like UCDP so a restart does not reset the day's count
        self.budget = budget or RequestBudget(int(cfg.get("daily_request_limit", DEFAULT_DAILY_LIMIT)),
                                              (Path(data_dir) / "live" / "events" / "acled" / "request_budget.json")
                                              if data_dir else None)
        self.retries, self.backoff, self.sleep, self.max_pages, self.now = retries, backoff, sleep, max_pages, now
        self.raw_rows: list[dict] = []
        self._prov: dict = {}

    def _get(self, fetcher, url, headers, data=None) -> bytes:
        host = urllib.parse.urlsplit(url).hostname
        if not url.startswith("https://") or host != ALLOWED_HOST:
            raise RuntimeError("ACLED requests go only to https://" + ALLOWED_HOST)
        return fetch_with_retries(fetcher, url, headers, data, retries=self.retries, backoff=self.backoff,
                                  budget=self.budget, **({"sleep": self.sleep} if self.sleep else {}))

    def _token(self, fetcher) -> str:
        tok = env_secret(self.token_env)
        if tok:
            return tok
        user, pw = env_secret(self.username_env), env_secret(self.password_env)
        if not (user and pw):
            raise RuntimeError(f"ACLED credentials missing: set {self.token_env}, or {self.username_env} and "
                               f"{self.password_env}, in the environment (never on the command line or in a file)")
        form = urllib.parse.urlencode({"username": user, "password": pw, "grant_type": "password",
                                       "client_id": "acled"}).encode()
        body = self._get(fetcher, TOKEN_URL, {"Content-Type": "application/x-www-form-urlencoded"}, form)
        try:
            tok = json.loads(body).get("access_token")
        except (ValueError, AttributeError):
            tok = None
        if not tok:
            raise RuntimeError("ACLED OAuth reply had no access_token")
        return str(tok)

    def fetch(self, isos, start, end, fetcher=None) -> pd.DataFrame:
        ok, why = acled_ready({"enabled": self.enabled, "licence": self._licence_cfg})
        if not ok:
            raise AcledDisabledError(why)
        isos = sorted({str(i).upper() for i in isos})
        if any(not ISO3_RE.fullmatch(i) for i in isos):
            raise ValueError(f"not ISO3: {isos}")
        rev = {v: k for k, v in ISO_NUM_TO_ISO3.items()}
        missing = [i for i in isos if i not in rev]
        if missing:
            raise UnmappedAcledCountryError(f"no ACLED numeric iso for {missing}")
        start, end = pd.Timestamp(start).date(), pd.Timestamp(end).date()
        fetcher = fetcher or http_fetch
        headers = {"Authorization": f"Bearer {self._token(fetcher)}", "Accept": "application/json"}
        retrieved = utc_stamp(self.now)
        rows, pages = [], {}
        for iso in isos:
            page = 1
            while True:
                q = urllib.parse.urlencode({"iso": rev[iso], "event_date": f"{start.isoformat()}|{end.isoformat()}",
                                            "event_date_where": "BETWEEN", "limit": self.limit, "page": page})
                body = self._get(fetcher, f"{READ_URL}?{q}", headers)
                try:
                    data = json.loads(body).get("data")
                except (ValueError, AttributeError):
                    data = None
                if not isinstance(data, list):
                    raise EventDataError(f"ACLED {iso} page {page}: reply has no 'data' list")
                rows.extend(data)
                if len(data) < self.limit:
                    break
                page += 1
                if page > self.max_pages:
                    raise EventDataError(f"ACLED {iso}: more than {self.max_pages} pages")
            pages[iso] = page
        self.raw_rows = rows
        self._prov = {"licence": self.licence, "endpoint": READ_URL, "auth": "OAuth bearer (token not stored)",
                      "start": start.isoformat(), "end": end.isoformat(), "isos": isos, "pages": pages,
                      "raw_rows": len(rows), "redistribution": REDISTRIBUTION_NOTE}
        return self.validate(aggregate_monthly(rows, isos, start, end, retrieved, self.licence))

    def provenance(self) -> dict:
        return dict(self._prov)


def save_acled_vintage(data_dir: Path, df: pd.DataFrame, adapter: AcledAdapter | None = None,
                       include_raw: bool = False, now: dt.datetime | None = None) -> Path:
    """Save ACLED aggregates as an append-only vintage under data/live/events/acled/. Raw rows are added (as
    raw_acled.csv in the same folder) only with include_raw=True; the EULA forbids redistributing them."""
    prov = dict(adapter.provenance()) if adapter else {}
    prov["raw_included"] = bool(include_raw)
    prov.setdefault("redistribution", REDISTRIBUTION_NOTE)
    extra = None
    if include_raw:
        if adapter is None:
            raise ValueError("include_raw needs the adapter that holds the raw rows")
        extra = {"raw_acled.csv": pd.DataFrame(adapter.raw_rows).to_csv(index=False).encode()}
    return save_event_vintage(data_dir, df, "acled", now=now, provenance=prov, extra_files=extra)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.events.acled",
                                 description="Pull ACLED (only when enabled and licensed in data/live/events/feeds.json)")
    ap.add_argument("--data-dir", default="data")
    ap.add_argument("--start", required=True)
    ap.add_argument("--end", required=True)
    ap.add_argument("--isos", default="")
    ap.add_argument("--include-raw", action="store_true", help="also keep raw rows in the vintage (stays on the Mac)")
    a = ap.parse_args(argv)
    d = Path(a.data_dir)
    isos = [i.strip() for i in a.isos.split(",") if i.strip()] or sorted(
        pd.read_csv(d / "countries.csv", dtype=str)["iso"].str.upper())
    ad = AcledAdapter(data_dir=d)
    df = ad.fetch(isos, a.start, a.end)
    print(f"saved {save_acled_vintage(d, df, ad, include_raw=a.include_raw)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
