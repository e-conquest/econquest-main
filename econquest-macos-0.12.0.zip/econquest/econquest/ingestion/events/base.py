"""Shared contract for event-data adapters (UCDP, GDELT, ACLED): EQ-A-0022 / EQ-A-0023 / EQ-A-0024.

Every adapter returns a long table with exactly EVENT_COLUMNS:

    iso            ISO 3166-1 alpha-3 (e.g. "NGA")
    period         ISO date of the period start, "YYYY-MM-DD" (a month starts on day 01, a year on 01-01)
    freq           "D" | "M" | "Y"
    source         "ucdp" | "gdelt" | "acled"
    metric         snake_case, e.g. events_state_based, fatalities_best, events_protest, goldstein_mean, tone_mean,
                   events_total
    value          float (finite)
    vintage_id     the vintage folder the row was saved in ("" before save_event_vintage)
    retrieved_utc  "YYYY-MM-DDTHH:MM:SSZ" when the adapter fetched the data
    licence        licence string of the source ("CC BY 4.0" for UCDP, ...)

Storage: save_event_vintage writes data/live/events/<source>/vintages/<UTC ts>-<hash8>/events.csv plus manifest.json,
read-only (0444), never overwritten (exist_ok=False), and appends a row to data/live/events/<source>/vintages/index.csv
with ledger.locked_append. latest_events / list_event_vintages read them back. Live pulls run on Sam's Mac only.

Config: data/live/events/feeds.json (EVENT_CONFIG_PATH relative to data_dir), read by load_event_config with
DEFAULT_EVENT_CONFIG for anything missing. Secrets never live in the config: tokens and passwords come only from the
environment variables the config names (token_env and similar); a secret-looking key in the file is refused
(SECRET_KEY_RE, at any depth, lists included; only keys ending in _env are exempt), and every *_env value must name a
variable matching ENV_NAME_RE (UCDP_... or ACLED_...), so the config cannot point a feed at an unrelated secret.

Fetcher: adapters take an injectable `fetcher(url, headers, data=None) -> bytes` (GET when data is None, POST
otherwise). `http_fetch` is the default: https only, timeout, response size cap, redirects refused (FetchError), headers sent as
unredirected headers and the final URL checked to be https on the requested host (SEC-A-002). `fetch_with_retries` adds retries with
exponential backoff for TransientFetchError, and `RequestBudget` guards a daily request quota.
"""
from __future__ import annotations

import abc
import copy
import datetime as dt
import hashlib
import io
import json
import math
import os
import re
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Callable

import pandas as pd

from econquest.ingestion.ledger import locked_append

EVENT_COLUMNS = ["iso", "period", "freq", "source", "metric", "value", "vintage_id", "retrieved_utc", "licence"]
EVENT_SOURCES = ("ucdp", "gdelt", "acled")
EVENT_FREQS = ("D", "M", "Y")
EVENT_CONFIG_PATH = Path("live") / "events" / "feeds.json"          # relative to data_dir (data/)
DEFAULT_EVENT_CONFIG = {
    "ucdp": {"enabled": True, "token_env": "UCDP_API_TOKEN"},
    "gdelt": {"enabled": True},
    "acled": {"enabled": False, "licence": "none"},
}
INDEX_COLUMNS = ["vintage_id", "retrieved_utc", "sha256", "rows", "licence"]
DEFAULT_MAX_BYTES = 50 * 1024 * 1024                                # response size cap per request
DEFAULT_TIMEOUT = 60

ISO3_RE = re.compile(r"^[A-Z]{3}$")
METRIC_RE = re.compile(r"^[a-z][a-z0-9_]*$")
SOURCE_RE = re.compile(r"^[a-z][a-z0-9_]{0,31}$")
PERIOD_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
RETRIEVED_RE = re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z")
VINTAGE_ID_RE = re.compile(r"[0-9TZ-]+-[0-9a-f]{8}")
# config keys that look like a credential (substring, case-insensitive); keys ending in _env name a variable instead
SECRET_KEY_RE = re.compile(r"token|secret|passw|bearer|authori|api_?key", re.IGNORECASE)
_SECRET_KEYS = {"key", "apikey", "credentials", "creds"}           # exact names refused as well
ENV_NAME_RE = re.compile(r"(UCDP|ACLED)_[A-Z0-9_]+")              # allowed environment variable names for secrets
# a licence string must not start like a spreadsheet formula (CSV/formula injection) or contain control characters
_LICENCE_BAD_LEAD = ("=", "+", "-", "@", "\t", "\r")

Fetcher = Callable[..., bytes]


class EventDataError(ValueError):
    """An event table breaks the contract (columns, codes, values, duplicates)."""


class TransientFetchError(RuntimeError):
    """A request failed in a way worth retrying (timeout, connection error, HTTP 429 or 5xx)."""


class FetchError(RuntimeError):
    """A request failed for good (HTTP 4xx, a redirect, a response from an unexpected URL). The message names only the
    host and path, never query strings or header values."""


class BudgetExceededError(RuntimeError):
    """The daily request budget for a source is used up; nothing more is sent today."""


# ---------------------------------------------------------------------------------------------------------- config

def event_config_path(data_dir: Path) -> Path:
    return Path(data_dir) / EVENT_CONFIG_PATH


def _check_no_secrets(obj, where: str) -> None:
    """Refuse secret-looking keys at any depth (dicts and lists); a key ending in _env must name an allowed variable."""
    if isinstance(obj, dict):
        for k, v in obj.items():
            key = str(k)
            if key.lower().endswith("_env"):
                check_env_name(v, f"{where}: {key}")
                continue
            if SECRET_KEY_RE.search(key) or key.lower() in _SECRET_KEYS:
                raise ValueError(f"{where}: key {key!r} looks like a secret; credentials come only from environment "
                                 f"variables (name the variable with token_env / *_env instead)")
            _check_no_secrets(v, where)
    elif isinstance(obj, (list, tuple)):
        for v in obj:
            _check_no_secrets(v, where)


def check_env_name(name, where: str = "env", prefix: str | None = None) -> str:
    """An environment variable name allowed to carry a feed credential: ENV_NAME_RE, and `prefix` (e.g. "UCDP_")
    when given. Anything else (AWS_SECRET_ACCESS_KEY, HOME, ...) is refused so the config cannot redirect a token."""
    if not isinstance(name, str) or not ENV_NAME_RE.fullmatch(name) or (prefix and not name.startswith(prefix)):
        raise ValueError(f"{where}: environment variable name {name!r} is not allowed; use "
                         f"{prefix or 'UCDP_ or ACLED_'}<NAME> (upper case, digits, underscores)")
    return name


def is_enabled(cfg: dict, default: bool = False) -> bool:
    """True only when cfg['enabled'] is the JSON boolean true (strings such as "false" or "yes" do not enable)."""
    return cfg.get("enabled", default) is True


def load_event_config(data_dir: Path) -> dict:
    """Config per source: DEFAULT_EVENT_CONFIG overlaid with data/live/events/feeds.json when it exists."""
    cfg = copy.deepcopy(DEFAULT_EVENT_CONFIG)
    p = event_config_path(data_dir)
    if p.exists():
        raw = json.loads(p.read_text())
        if not isinstance(raw, dict):
            raise ValueError(f"{p}: expected a JSON object keyed by source")
        _check_no_secrets(raw, str(p))
        for src, opts in raw.items():
            if not isinstance(opts, dict):
                raise ValueError(f"{p}: entry {src!r} must be an object")
            cfg.setdefault(src, {}).update(opts)
    return cfg


def env_secret(name: str) -> str | None:
    """Read a credential from the environment only. Returns None when unset or blank."""
    v = os.environ.get(name or "", "")
    return v.strip() or None


# ---------------------------------------------------------------------------------------------------------- http

class NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    """Refuses every redirect: the 3xx surfaces as HTTPError, so no request (and no credential) goes to a second URL.
    The vendor APIs and GDELT do not need redirects (SEC-A-002)."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def build_no_redirect_opener(*handlers) -> urllib.request.OpenerDirector:
    """urllib opener with NoRedirectHandler (tests may pass stub handlers that replace the http/https handlers)."""
    return urllib.request.build_opener(NoRedirectHandler, *handlers)


def build_request(url: str, headers: dict | None = None, data: bytes | None = None) -> urllib.request.Request:
    """Request whose headers are all unredirected headers: even if a redirect were followed they are not copied."""
    req = urllib.request.Request(url, data=data, method="POST" if data is not None else "GET")
    for k, v in (headers or {}).items():
        req.add_unredirected_header(k, v)
    return req


def check_final_url(resp, scheme: str, host: str, safe: str, exc=None) -> None:
    """The response must come from `scheme`://`host` (the URL requested); otherwise raise exc (FetchError)."""
    fin = urllib.parse.urlsplit(resp.geturl() or "")
    if fin.scheme != scheme or (fin.hostname or "") != host:
        raise (exc or FetchError)(f"response for {safe} came from {fin.scheme}://{fin.hostname}{fin.path}; refused")


def http_fetch(url: str, headers: dict | None = None, data: bytes | None = None, *, timeout: float = DEFAULT_TIMEOUT,
               max_bytes: int = DEFAULT_MAX_BYTES) -> bytes:
    """Default fetcher: https only, timeout, body capped at max_bytes, redirects refused. HTTP 429/5xx, timeouts and
    connection errors raise TransientFetchError (retryable); a redirect, other HTTP errors or a response from another
    URL raise FetchError. Headers go as unredirected headers. Header values (tokens) and query strings are never put
    in error messages."""
    parts = urllib.parse.urlsplit(url)
    if parts.scheme != "https" or not parts.hostname:
        raise ValueError(f"refusing non-https URL: {parts.scheme}://{parts.hostname}{parts.path}")
    req = build_request(url, headers, data)
    safe = f"{parts.hostname}{parts.path}"
    try:
        # the scheme was checked to be https above, so B310 (file:/custom schemes) does not apply
        with build_no_redirect_opener().open(req, timeout=timeout) as resp:  # nosec B310
            check_final_url(resp, "https", parts.hostname, safe)
            body = resp.read(max_bytes + 1)
    except urllib.error.HTTPError as e:
        e.close()
        if 300 <= e.code < 400:
            raise FetchError(f"HTTP {e.code} redirect from {safe}; not followed") from None
        if e.code == 429 or e.code >= 500:
            raise TransientFetchError(f"HTTP {e.code} from {safe}") from None
        raise FetchError(f"HTTP {e.code} from {safe}") from None
    except (urllib.error.URLError, TimeoutError, ConnectionError) as e:
        raise TransientFetchError(f"connection error for {safe}: {type(e).__name__}") from None
    if len(body) > max_bytes:
        raise FetchError(f"response from {safe} exceeds the {max_bytes}-byte cap")
    return body


class RequestBudget:
    """Daily request counter (UTC day). Every attempt counts, errors included (UCDP counts errors against its quota).
    With state_path the count survives restarts (small JSON file, written atomically)."""

    def __init__(self, limit: int, state_path: Path | None = None, today: Callable[[], dt.date] | None = None):
        self.limit = int(limit)
        self.state_path = Path(state_path) if state_path else None
        self._today = today or (lambda: dt.datetime.now(dt.timezone.utc).date())
        self._counts: dict[str, int] = {}
        if self.state_path and self.state_path.exists():
            try:
                self._counts = {str(k): int(v) for k, v in json.loads(self.state_path.read_text()).items()}
            except (ValueError, AttributeError):
                self._counts = {}

    def used(self) -> int:
        return self._counts.get(self._today().isoformat(), 0)

    def remaining(self) -> int:
        return max(self.limit - self.used(), 0)

    def spend(self, n: int = 1) -> None:
        day = self._today().isoformat()
        if self._counts.get(day, 0) + n > self.limit:
            raise BudgetExceededError(f"daily request budget of {self.limit} used up for {day} (UTC); try tomorrow")
        self._counts = {day: self._counts.get(day, 0) + n}          # keep only today
        if self.state_path:
            self.state_path.parent.mkdir(parents=True, exist_ok=True)
            fd, tmp = tempfile.mkstemp(dir=self.state_path.parent, prefix=".budget.", suffix=".tmp")
            with os.fdopen(fd, "w") as f:
                json.dump(self._counts, f)
            os.replace(tmp, self.state_path)


def fetch_with_retries(fetcher: Fetcher, url: str, headers: dict | None = None, data: bytes | None = None, *,
                       retries: int = 3, backoff: float = 2.0, budget: RequestBudget | None = None,
                       sleep: Callable[[float], None] = time.sleep) -> bytes:
    """Call fetcher(url, headers, data) with up to `retries` retries on TransientFetchError, waiting backoff * 2**i.
    Each attempt is charged to `budget` first, so a budget stop happens before a request is sent."""
    for attempt in range(retries + 1):
        if budget is not None:
            budget.spend()
        try:
            return fetcher(url, headers or {}, data)
        except TransientFetchError:
            if attempt == retries:
                raise
            sleep(backoff * (2 ** attempt))
    raise AssertionError("unreachable")


# ---------------------------------------------------------------------------------------------------------- validate

def validate_events(df: pd.DataFrame, source: str | None = None) -> pd.DataFrame:
    """Check the contract and return df[EVENT_COLUMNS] (value as float). Raises EventDataError listing problems."""
    if not isinstance(df, pd.DataFrame):
        raise EventDataError("events must be a pandas DataFrame")
    missing = [c for c in EVENT_COLUMNS if c not in df.columns]
    if missing:
        raise EventDataError(f"missing columns: {missing}")
    out = df[EVENT_COLUMNS].copy()
    problems = []
    for col in ("iso", "period", "freq", "source", "metric", "vintage_id", "retrieved_utc", "licence"):
        out[col] = out[col].fillna("").astype(str)
    bad = sorted(set(out.loc[~out["iso"].str.fullmatch(ISO3_RE), "iso"]))
    if bad:
        problems.append(f"iso not ISO3: {bad[:10]}")
    bad = sorted(set(out.loc[~out["freq"].isin(EVENT_FREQS), "freq"]))
    if bad:
        problems.append(f"freq not in {EVENT_FREQS}: {bad[:10]}")
    bad = sorted(set(out.loc[~out["source"].isin(EVENT_SOURCES), "source"]))
    if bad:
        problems.append(f"source not in {EVENT_SOURCES}: {bad[:10]}")
    if source is not None and len(out) and (out["source"] != source).any():
        problems.append(f"rows from a source other than {source!r}")
    bad = sorted(set(out.loc[~out["metric"].str.fullmatch(METRIC_RE), "metric"]))
    if bad:
        problems.append(f"metric not snake_case: {bad[:10]}")
    bad = sorted(set(out.loc[(out["retrieved_utc"] != "") & ~out["retrieved_utc"].str.fullmatch(RETRIEVED_RE),
                             "retrieved_utc"]))
    if bad:
        problems.append(f"retrieved_utc not YYYY-MM-DDTHH:MM:SSZ: {bad[:10]}")
    bad = sorted({lic for lic in set(out["licence"]) if licence_problem(lic)})
    if bad:
        problems.append(f"licence unsafe (starts with = + - @ TAB CR, or has control characters): {bad[:5]!r}")
    per_ok = out["period"].str.fullmatch(PERIOD_RE) & pd.to_datetime(out["period"], format="%Y-%m-%d", errors="coerce").notna()
    if (~per_ok).any():
        problems.append(f"period not YYYY-MM-DD: {sorted(set(out.loc[~per_ok, 'period']))[:10]}")
    else:
        d = pd.to_datetime(out["period"], format="%Y-%m-%d")
        not_start = ((out["freq"] == "M") & (d.dt.day != 1)) | ((out["freq"] == "Y") & ((d.dt.day != 1) | (d.dt.month != 1)))
        if not_start.any():
            problems.append(f"period is not the start of its M/Y period: {sorted(set(out.loc[not_start, 'period']))[:10]}")
    vals = pd.to_numeric(out["value"], errors="coerce")
    if vals.isna().any() or not vals.astype(float).map(math.isfinite).all():
        problems.append("value has missing, non-numeric or non-finite entries")
    out["value"] = vals.astype(float)
    dup = out.duplicated(["iso", "period", "freq", "metric"], keep=False)
    if dup.any():
        problems.append(f"duplicate (iso, period, freq, metric): {out.loc[dup, ['iso', 'period', 'freq', 'metric']].head(5).values.tolist()}")
    if problems:
        raise EventDataError("; ".join(problems))
    return out.reset_index(drop=True)


def licence_problem(lic) -> str:
    """'' when a licence string is safe to store and to put in a spreadsheet, else the reason. Refused rather than
    escaped: a licence is a fixed label, so a formula-like or multi-line one means a bad config."""
    if not isinstance(lic, str):
        return "not a string"
    if lic.startswith(_LICENCE_BAD_LEAD):
        return "starts with a formula character"
    if any(ord(c) < 32 or ord(c) == 127 for c in lic):
        return "contains control characters"
    return ""


class EventAdapter(abc.ABC):
    """Base for event adapters. Subclasses set `source` and `licence`, and implement fetch()."""

    source: str = ""
    licence: str = ""
    enabled: bool = True

    @abc.abstractmethod
    def fetch(self, isos, start, end, fetcher: Fetcher | None = None) -> pd.DataFrame:
        """Return a DataFrame with EVENT_COLUMNS for the ISO3 codes `isos` between dates start and end (inclusive).
        `fetcher(url, headers, data=None) -> bytes` is injectable for tests; None means http_fetch."""

    def validate(self, df: pd.DataFrame) -> pd.DataFrame:
        return validate_events(df, source=self.source or None)

    def provenance(self) -> dict:
        """Extra manifest fields from the last fetch (endpoints, dataset versions ...). Subclasses fill it."""
        return {}


# ---------------------------------------------------------------------------------------------------------- vintages

def utc_stamp(now: dt.datetime | None = None) -> str:
    return _utc(now).strftime("%Y-%m-%dT%H:%M:%SZ")


def _utc(now: dt.datetime | None) -> dt.datetime:
    now = now or dt.datetime.now(dt.timezone.utc)
    return now.astimezone(dt.timezone.utc) if now.tzinfo else now.replace(tzinfo=dt.timezone.utc)


def _source_ok(source: str) -> str:
    if not isinstance(source, str) or not SOURCE_RE.fullmatch(source):
        raise ValueError(f"bad source name {source!r}")
    return source


def event_vintage_root(data_dir: Path, source: str) -> Path:
    return Path(data_dir) / "live" / "events" / _source_ok(source) / "vintages"


def save_event_vintage(data_dir: Path, df: pd.DataFrame, source: str, now: dt.datetime | None = None, *,
                       provenance: dict | None = None, extra_files: dict[str, bytes] | None = None) -> Path:
    """Append-only vintage: data/live/events/<source>/vintages/<YYYY-MM-DDTHHMMSSZ>-<hash8>/events.csv + manifest.json.

    hash8 is the first 8 hex digits of the SHA-256 of events.csv written with an empty vintage_id column; the file
    actually stored carries vintage_id = the folder name, and manifest.json records that file's own sha256, the row
    count, licence(s), retrieved time and `provenance` (endpoints, dataset versions). `extra_files` (name -> bytes,
    plain file names only) are stored beside it; used by ACLED raw rows only with an explicit flag. Files are 0444,
    the folder is created with exist_ok=False (FileExistsError, never overwritten), and a row is appended to
    vintages/index.csv under ledger.locked_append."""
    source = _source_ok(source)
    ev = validate_events(df, source=source)
    now = _utc(now)
    if (ev["retrieved_utc"] == "").any():
        ev.loc[ev["retrieved_utc"] == "", "retrieved_utc"] = utc_stamp(now)
    ev = ev.sort_values(["iso", "freq", "period", "metric"]).reset_index(drop=True)
    ev["vintage_id"] = ""
    digest = hashlib.sha256(ev.to_csv(index=False).encode()).hexdigest()
    root = event_vintage_root(data_dir, source)
    root.mkdir(parents=True, exist_ok=True)
    vid = f"{now.strftime('%Y-%m-%dT%H%M%SZ')}-{digest[:8]}"
    v = root / vid
    v.mkdir(exist_ok=False)
    ev["vintage_id"] = vid
    body = ev.to_csv(index=False).encode()
    files = {"events.csv": body}
    for name, data in (extra_files or {}).items():
        if not re.fullmatch(r"[A-Za-z0-9_][A-Za-z0-9_.-]{0,80}", name) or name in ("events.csv", "manifest.json"):
            raise ValueError(f"bad extra file name {name!r}")
        files[name] = bytes(data)
    licences = sorted(set(ev["licence"])) or [""]
    manifest = {"vintage_id": vid, "source": source, "saved_utc": utc_stamp(now), "rows": int(len(ev)),
                "sha256": hashlib.sha256(body).hexdigest(), "content_hash": digest,
                "licence": licences[0] if len(licences) == 1 else licences,
                "retrieved_utc": sorted(set(ev["retrieved_utc"])),
                "files": {n: hashlib.sha256(b).hexdigest() for n, b in sorted(files.items())},
                "provenance": provenance or {}}
    files["manifest.json"] = json.dumps(manifest, indent=1, sort_keys=True, default=str).encode()
    for name in sorted(files):
        (v / name).write_bytes(files[name])
        os.chmod(v / name, 0o444)
    with locked_append(root / "index.csv", INDEX_COLUMNS) as (w, _f, new):
        if new:
            w.writeheader()
        w.writerow({"vintage_id": vid, "retrieved_utc": utc_stamp(now), "sha256": manifest["sha256"],
                    "rows": len(ev), "licence": "|".join(licences)})
    return v


def list_event_vintages(data_dir: Path, source: str) -> list[str]:
    """Vintage ids for a source in save order (from index.csv), only those whose folder exists. A vintage folder, or
    its events.csv / manifest.json, that is a symbolic link is skipped: save_event_vintage never writes links, so a
    link points outside the append-only store (SEC-A-016 U-I3, same class as SEC-A-004 I2)."""
    root = event_vintage_root(data_dir, source)
    idx = root / "index.csv"
    if not idx.exists():
        return []
    ids = pd.read_csv(idx, dtype=str)["vintage_id"].dropna().tolist()
    return [i for i in ids if VINTAGE_ID_RE.fullmatch(i) and _plain_vintage(root / i)]


def _plain_vintage(v: Path) -> bool:
    """True when the vintage folder and its files are real (not symbolic links) and events.csv exists."""
    if v.is_symlink() or not v.is_dir():
        return False
    ev, man = v / "events.csv", v / "manifest.json"
    return ev.is_file() and not ev.is_symlink() and not man.is_symlink()


def read_event_vintage(data_dir: Path, source: str, vintage_id: str, verify: bool = True) -> pd.DataFrame:
    root = event_vintage_root(data_dir, source)
    if not VINTAGE_ID_RE.fullmatch(str(vintage_id)):
        raise ValueError(f"bad vintage id {vintage_id!r}")
    body = (root / vintage_id / "events.csv").read_bytes()
    if verify:
        man = json.loads((root / vintage_id / "manifest.json").read_text())
        if hashlib.sha256(body).hexdigest() != man.get("sha256"):
            raise EventDataError(f"{source} vintage {vintage_id}: events.csv does not match its manifest sha256")
    df = pd.read_csv(io.BytesIO(body), dtype={c: str for c in EVENT_COLUMNS if c != "value"}, keep_default_na=False)
    return validate_events(df, source=source)


def latest_events(data_dir: Path, source: str) -> pd.DataFrame:
    """Events of the most recent vintage of `source`. Raises FileNotFoundError when there is none (never falls back)."""
    ids = list_event_vintages(data_dir, source)
    if not ids:
        raise FileNotFoundError(f"no {source} event vintage under {event_vintage_root(data_dir, source)}; "
                                f"run the pull on the Mac (docs/runbooks/A-event-feeds.md)")
    return read_event_vintage(data_dir, source, ids[-1])


def month_start(d) -> dt.date:
    d = pd.Timestamp(d)
    return dt.date(d.year, d.month, 1)
