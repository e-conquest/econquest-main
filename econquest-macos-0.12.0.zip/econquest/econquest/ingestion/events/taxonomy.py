"""econquest event taxonomy shared by GDELT and UCDP (EQ-A-0139, taxonomy v1). Doc: docs/runbooks/A-event-taxonomy.md.

One small category set; every source code maps to exactly one category or to none (never guessed):

    category                    GDELT CAMEO root (EventRootCode)              UCDP type_of_violence
    armed_conflict              19 Fight, 20 Unconventional mass violence      1 state-based, 2 non-state
    violence_against_civilians  18 Assault                                     3 one-sided
    coercion                    15 Force posture, 16 Reduce relations,        -
                                17 Coerce
    protest                     14 Protest                                     -
    verbal_conflict             09 Investigate .. 13 Threaten (QuadClass 3)   -
    cooperation                 01 Statement .. 08 Yield (QuadClass 1-2)      -

CAMEO root names and the QuadClass split follow the GDELT 2.0 Event Codebook / CAMEO manual as already used in
gdelt.py and export.py (*verify against the CAMEO manual*: same caveat as gdelt.py). A root outside 1..20 or blank is
`uncategorised` and counted, never assigned. Measures: `events` (both sources) and `fatalities` (UCDP only; GDELT has
no fatality count). The two sources measure different things: UCDP codes fatal organised violence only, GDELT counts
media-reported, machine-coded events. A category is shared; a value is never summed across sources (unified.py).

Stored vintages carry adapter metrics, not raw events, so METRIC_MAP says which stored metric feeds which category:
UCDP's per-type metrics map one to one; GDELT's legacy metrics give only protest (root 14) and verbal_conflict
(QuadClass 3). GDELT vintages saved with `--categories` (gdelt.GdeltAdapter(categories=True)) carry one
`cat_<category>` count per category, computed here from the staged event rows; when a vintage has them, the legacy
metrics of that vintage are not used (they would double count protest and verbal_conflict).
"""
from __future__ import annotations

from typing import Iterable

import pandas as pd

TAXONOMY_VERSION = "eq-events-taxonomy/1"
CATEGORIES = ("armed_conflict", "violence_against_civilians", "coercion", "protest", "verbal_conflict", "cooperation")
UNCATEGORISED = "uncategorised"
MEASURES = ("events", "fatalities")

CAMEO_ROOT_NAMES = {
    1: "Make public statement", 2: "Appeal", 3: "Express intent to cooperate", 4: "Consult",
    5: "Engage in diplomatic cooperation", 6: "Engage in material cooperation", 7: "Provide aid", 8: "Yield",
    9: "Investigate", 10: "Demand", 11: "Disapprove", 12: "Reject", 13: "Threaten", 14: "Protest",
    15: "Exhibit force posture", 16: "Reduce relations", 17: "Coerce", 18: "Assault", 19: "Fight",
    20: "Use unconventional mass violence",
}
CAMEO_ROOT_TO_CATEGORY = {
    **{r: "cooperation" for r in range(1, 9)},
    **{r: "verbal_conflict" for r in range(9, 14)},
    14: "protest",
    15: "coercion", 16: "coercion", 17: "coercion",
    18: "violence_against_civilians",
    19: "armed_conflict", 20: "armed_conflict",
}
UCDP_TYPE_TO_CATEGORY = {1: "armed_conflict", 2: "armed_conflict", 3: "violence_against_civilians"}
UCDP_TYPE_NAMES = {1: "state_based", 2: "non_state", 3: "one_sided"}

# Which source is primary for a category when both report it (unified.py combine="primary"). Fixed per category,
# never per cell, so a primary series never switches source (and scale) from month to month.
PRIMARY_SOURCE = {"armed_conflict": "ucdp", "violence_against_civilians": "ucdp", "coercion": "gdelt",
                  "protest": "gdelt", "verbal_conflict": "gdelt", "cooperation": "gdelt"}

GDELT_CATEGORY_METRICS = {f"cat_{c}": c for c in CATEGORIES}
GDELT_UNCATEGORISED_METRIC = f"cat_{UNCATEGORISED}"
# stored metric -> (category, measure) per source. Several metrics may feed one category (they are summed within a
# source and vintage: UCDP state-based + non-state = armed_conflict).
METRIC_MAP = {
    "ucdp": {
        "events_state_based": ("armed_conflict", "events"), "events_non_state": ("armed_conflict", "events"),
        "events_one_sided": ("violence_against_civilians", "events"),
        "fatalities_state_based": ("armed_conflict", "fatalities"),
        "fatalities_non_state": ("armed_conflict", "fatalities"),
        "fatalities_one_sided": ("violence_against_civilians", "fatalities"),
    },
    "gdelt": {m: (c, "events") for m, c in GDELT_CATEGORY_METRICS.items()},
}
GDELT_LEGACY_MAP = {"events_protest": ("protest", "events"), "events_verbal_conflict": ("verbal_conflict", "events")}


def category_of_cameo(root) -> str:
    """Category of a CAMEO root code (int, integral float such as 19.0 from a column with blanks, or numeric string,
    '014' ok); UNCATEGORISED when blank, fractional or unknown."""
    try:
        f = float(str(root).strip())
    except (TypeError, ValueError):
        return UNCATEGORISED
    if f != f or f != int(f):                     # NaN / NA, or 14.5
        return UNCATEGORISED
    return CAMEO_ROOT_TO_CATEGORY.get(int(f), UNCATEGORISED)


def category_of_ucdp(type_of_violence) -> str:
    try:
        return UCDP_TYPE_TO_CATEGORY.get(int(type_of_violence), UNCATEGORISED)
    except (TypeError, ValueError):
        return UNCATEGORISED


def gdelt_category_counts(staged: pd.DataFrame, isos: Iterable[str], days: Iterable[str], root_only: bool = True,
                          date_basis: str = "file") -> pd.DataFrame:
    """Staged GDELT rows (gdelt.STAGE_COLUMNS) -> wide (iso, period) x cat_<category> event counts, zero-filled for
    every (iso, staged day), with the same root/date-basis selection as gdelt.aggregate. Includes
    cat_uncategorised (roots outside 1..20 or blank) so the categories always add up to events_total."""
    isos, days = list(isos), sorted(days)
    cols = list(GDELT_CATEGORY_METRICS) + [GDELT_UNCATEGORISED_METRIC]
    df = staged.copy()
    if root_only:
        df = df[pd.to_numeric(df["is_root"], errors="coerce") == 1]
    if date_basis == "file":
        df["day"] = df["file_ts"].astype(str).str[:8]
    elif date_basis == "event":
        df["day"] = df["sqldate"].astype(str).str[:8]
    else:
        raise ValueError("date_basis must be 'file' or 'event'")
    df = df[df["iso"].isin(isos) & df["day"].isin(days)]
    df["metric"] = "cat_" + df["event_root_code"].map(category_of_cameo)
    full = pd.MultiIndex.from_product([isos, days], names=["iso", "day"])
    if len(df):
        wide = df.groupby(["iso", "day", "metric"]).size().unstack("metric")
    else:
        wide = pd.DataFrame(index=full)
    wide = wide.reindex(index=full, columns=cols).fillna(0).astype(float).reset_index()
    wide["period"] = pd.to_datetime(wide["day"], format="%Y%m%d").dt.strftime("%Y-%m-%d")
    return wide[["iso", "period"] + cols]


def taxonomy_table() -> pd.DataFrame:
    """One row per source code: source, code, name, category (for the doc and for Team B)."""
    rows = [{"source": "gdelt", "code": f"{r:02d}", "name": CAMEO_ROOT_NAMES[r], "category": c}
            for r, c in sorted(CAMEO_ROOT_TO_CATEGORY.items())]
    rows += [{"source": "ucdp", "code": str(t), "name": UCDP_TYPE_NAMES[t], "category": c}
             for t, c in sorted(UCDP_TYPE_TO_CATEGORY.items())]
    return pd.DataFrame(rows, columns=["source", "code", "name", "category"])
