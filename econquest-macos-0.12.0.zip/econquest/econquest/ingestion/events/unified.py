"""Unified event API for Team B (EQ-A-0139 -> EQ-B-0142): GDELT and UCDP on one category set, point in time.

    from econquest.ingestion.events.unified import unified_events, coverage_report
    df = unified_events("data", as_of="2026-10-24", freq="M")            # by_source, all categories
    df.attrs["dedup"]                                                      # dedup statistics of this call

Reads only stored vintages (data/live/events/<source>/vintages/, the store of record; never a live pull) and maps
their metrics to econquest categories (events.taxonomy, docs/runbooks/A-event-taxonomy.md).

UNIFIED_COLUMNS
    iso            ISO3
    period         YYYY-MM-DD start of the day (freq D) or month (freq M)
    freq           "D" (GDELT only: UCDP is monthly) | "M"
    source         "gdelt" | "ucdp"
    category       one of taxonomy.CATEGORIES
    measure        "events" | "fatalities" (fatalities: UCDP only)
    value          float; counts are explicit zeros where the source covered the cell and saw nothing
    days_covered   GDELT at freq M: staged days summed into the month (a partial month is < days in month);
                   blank for UCDP (its vintages are zero-filled inside the dataset coverage, see ucdp.py)
    primary        True when `source` is taxonomy.PRIMARY_SOURCE[category] (UCDP for armed_conflict and
                   violence_against_civilians, GDELT for the rest); fixed per category, never per cell
    available_utc  when the row entered the store: saved_utc of the vintage it came from (the newest such vintage
                   available at as_of)
    vintage_id     that vintage
    provenance     source, dataset/scope, taxonomy version and licence (starts with the source name, so the
                   licence register's gdelt / ucdp rows apply)

Point in time (as_of): a row is used only when its vintage was saved at or before as_of (a date means the end of that
UTC day) and its period starts on or before as_of. The same call with the same as_of always returns the same table,
whatever was saved later.

De-duplication
    1. events (GDELT, inside the adapter): a GlobalEventID seen in more than one 15-minute file or staged day is
       kept once (gdelt.dedupe, first file wins). Unchanged here.
    2. across days / vintages: incremental and pull-pack vintages overlap (the recorded pulls 2026-10-17..23 and
       2026-10-18..24 share six days). For each (source, iso, freq, period, category, measure) only the newest vintage
       available at as_of is used; older copies are dropped and counted (dropped_overlap).
    3. across sources: GDELT and UCDP both report armed_conflict and violence_against_civilians. Values are never
       summed across sources. combine="by_source" (default) returns both, with `primary` marking the one to use;
       combine="primary" keeps only primary rows, so each (iso, period, category, measure) appears once. Cells that
       both sources report are counted (cross_source_cells) and, with "primary", the non-primary copy is dropped
       (dropped_cross_source). Non-primary rows with no primary counterpart are also left out by "primary"; they
       are not duplicates and are counted apart (dropped_non_primary), never in the dedup rate.
    Not possible from stored aggregates: matching one real-world event that GDELT codes under several GlobalEventIDs
    (re-reports), or one GDELT event to one UCDP event. That needs event-level records; see the doc, section 4.

dedup_rate = (dropped_overlap + dropped_cross_source) / rows_in, where rows_in counts category cells after the
as_of filter and before steps 2-3.

    python -m econquest.ingestion.events.unified events --as-of 2026-10-24 [--freq M] [--combine primary] [--out F]
    python -m econquest.ingestion.events.unified coverage [--as-of D] [--pull-report team/inbox/pull-*/report.json]
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
from pathlib import Path
from typing import Iterable

import pandas as pd

from econquest.ingestion.events.base import list_event_vintages, read_event_vintage, event_vintage_root
from econquest.ingestion.events.taxonomy import (
    CATEGORIES, GDELT_CATEGORY_METRICS, GDELT_LEGACY_MAP, METRIC_MAP, PRIMARY_SOURCE, TAXONOMY_VERSION,
)

UNIFIED_COLUMNS = ["iso", "period", "freq", "source", "category", "measure", "value", "days_covered", "primary",
                   "available_utc", "vintage_id", "provenance"]
CELL = ["source", "iso", "freq", "period", "category", "measure"]
SOURCES = ("gdelt", "ucdp")
COMBINE = ("by_source", "primary")
API_VERSION = "eq-unified-events/1"


# ------------------------------------------------------------------------------------------------ helpers

def as_of_stamp(as_of) -> str | None:
    """'YYYY-MM-DDTHH:MM:SSZ' for as_of (None -> None). A plain date means the end of that UTC day."""
    if as_of is None:
        return None
    if isinstance(as_of, dt.datetime):
        t = as_of.astimezone(dt.timezone.utc) if as_of.tzinfo else as_of
        return t.strftime("%Y-%m-%dT%H:%M:%SZ")
    s = str(as_of).strip()
    if len(s) == 10:
        dt.date.fromisoformat(s)
        return f"{s}T23:59:59Z"
    t = pd.Timestamp(s)
    t = t.tz_convert("UTC") if t.tzinfo else t
    return t.strftime("%Y-%m-%dT%H:%M:%SZ")


def _manifest(data_dir: Path, source: str, vid: str) -> dict:
    p = event_vintage_root(data_dir, source) / vid / "manifest.json"
    return json.loads(p.read_text()) if p.is_file() else {}


def load_vintage_rows(data_dir: str | Path, sources: Iterable[str] = SOURCES) -> tuple[pd.DataFrame, dict]:
    """Every stored vintage of `sources` (EVENT_COLUMNS + _order, saved_utc), oldest first, and the manifests by
    (source, vintage id). Empty frame when there is none."""
    data_dir = Path(data_dir)
    frames, mans = [], {}
    for source in sources:
        for order, vid in enumerate(list_event_vintages(data_dir, source)):
            ev = read_event_vintage(data_dir, source, vid)
            man = _manifest(data_dir, source, vid)
            mans[(source, vid)] = man
            saved = str(man.get("saved_utc") or "") or (max(ev["retrieved_utc"]) if len(ev) else "")
            frames.append(ev.assign(_order=order, saved_utc=saved))
    if not frames:
        return pd.DataFrame(columns=["iso", "period", "freq", "source", "metric", "value", "vintage_id",
                                     "retrieved_utc", "licence", "_order", "saved_utc"]), mans
    return pd.concat(frames, ignore_index=True), mans


def _provenance(source: str, man: dict, licence: str) -> str:
    p = man.get("provenance") or {}
    if source == "gdelt":
        root = "root events" if p.get("root_only", True) else "root and non-root events"
        scope = f"GDELT 2.0 events, cite gdeltproject.org; {root}, date basis {p.get('date_basis', 'file')}"
    else:
        ds = ", ".join(f"{d.get('dataset')} {d.get('version')}" for d in p.get("datasets") or []) or "GED/Candidate"
        scope = f"UCDP {ds}"
    return f"{scope}; {TAXONOMY_VERSION}; licence {licence}"


def _categorise(rows: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Stored metrics -> category cells, summed within (source, vintage, iso, freq, period, category, measure).
    GDELT vintages with cat_* metrics use them; older GDELT vintages use the legacy protest / verbal_conflict
    metrics only. Returns (cells, resolution per gdelt vintage)."""
    parts, resolution = [], {}
    for (source, vid), g in rows.groupby(["source", "vintage_id"], sort=False):
        if source == "gdelt":
            has_cat = g["metric"].isin(list(GDELT_CATEGORY_METRICS)).any()
            mmap = METRIC_MAP["gdelt"] if has_cat else GDELT_LEGACY_MAP
            resolution[vid] = "category" if has_cat else "legacy"
        else:
            mmap = METRIC_MAP.get(source, {})
        g = g[g["metric"].isin(list(mmap))]
        if g.empty:
            continue
        cm = g["metric"].map(mmap)
        parts.append(g.assign(category=cm.str[0], measure=cm.str[1]))
    if not parts:
        return pd.DataFrame(columns=CELL + ["value", "vintage_id", "saved_utc", "_order", "licence"]), resolution
    c = pd.concat(parts, ignore_index=True)
    c = c.groupby(CELL + ["vintage_id", "saved_utc", "_order", "licence"], as_index=False)["value"].sum()
    return c, resolution


# ------------------------------------------------------------------------------------------------ core

def unify(rows: pd.DataFrame, as_of=None, *, freq: str = "M", isos: Iterable[str] | None = None,
          categories: Iterable[str] | None = None, combine: str = "by_source",
          manifests: dict | None = None) -> tuple[pd.DataFrame, dict]:
    """Stored vintage rows (load_vintage_rows) -> (UNIFIED_COLUMNS table, dedup statistics). See module doc."""
    if freq not in ("D", "M"):
        raise ValueError("freq must be 'D' or 'M'")
    if combine not in COMBINE:
        raise ValueError(f"combine must be one of {COMBINE}")
    cats = list(categories) if categories is not None else list(CATEGORIES)
    bad = sorted(set(cats) - set(CATEGORIES))
    if bad:
        raise ValueError(f"unknown categories {bad}; taxonomy: {list(CATEGORIES)}")
    manifests = manifests or {}
    stamp = as_of_stamp(as_of)
    r = rows.copy()
    if stamp is not None:
        r = r[(r["saved_utc"].astype(str) <= stamp) & (r["period"].astype(str) <= stamp[:10])]
    if isos is not None:
        want = {str(i).strip().upper() for i in isos}
        r = r[r["iso"].isin(want)]
    cells, resolution = _categorise(r)
    cells = cells[cells["category"].isin(cats)]
    rows_in = len(cells)
    # 2. across days / vintages: newest vintage available at as_of wins per cell
    cells = cells.sort_values(CELL + ["saved_utc", "_order"], kind="mergesort")
    kept = cells.drop_duplicates(CELL, keep="last")
    dropped_overlap = rows_in - len(kept)
    # frequency
    if freq == "D":
        out = kept[kept["freq"] == "D"].assign(days_covered=float("nan"))
    else:
        daily = kept[kept["freq"] == "D"].copy()
        monthly = kept[kept["freq"] == "M"].assign(days_covered=float("nan"))
        if len(daily):
            daily["period"] = pd.to_datetime(daily["period"]).dt.to_period("M").dt.start_time.dt.strftime("%Y-%m-%d")
            daily = daily.sort_values("saved_utc", kind="mergesort")
            daily = daily.groupby(["source", "iso", "period", "category", "measure"], as_index=False).agg(
                value=("value", "sum"), days_covered=("value", "size"), saved_utc=("saved_utc", "last"),
                vintage_id=("vintage_id", lambda s: "|".join(dict.fromkeys(s))), licence=("licence", "last"))
            daily["freq"] = "M"
        out = pd.concat([x for x in (monthly, daily) if len(x)], ignore_index=True) if (len(monthly) or len(daily)) \
            else monthly
    if out.empty:
        out = pd.DataFrame(columns=UNIFIED_COLUMNS)
        stats = _stats(as_of, stamp, freq, combine, rows_in, dropped_overlap, 0, 0, out, resolution)
        return out, stats
    out = out.copy()
    out["primary"] = out["source"] == out["category"].map(PRIMARY_SOURCE)
    key = ["iso", "freq", "period", "category", "measure"]
    n_src = out.groupby(key)["source"].transform("nunique")
    cross_cells = int(out.loc[n_src > 1, key].drop_duplicates().shape[0])
    dropped_cross = dropped_non_primary = 0
    if combine == "primary":
        dropped_cross = int(((n_src > 1) & ~out["primary"]).sum())            # the other source's copy of a cell
        dropped_non_primary = int(((n_src == 1) & ~out["primary"]).sum())     # policy, not a duplicate
        out = out[out["primary"]]
    out["available_utc"] = out["saved_utc"]
    out["provenance"] = [
        _provenance(s, manifests.get((s, v.split("|")[-1]), {}), lic)
        + (f"; {int(d)} staged day(s)" if s == "gdelt" and freq == "M" and pd.notna(d) else "")
        for s, v, lic, d in zip(out["source"], out["vintage_id"], out["licence"], out["days_covered"])]
    out = out.sort_values(["iso", "period", "category", "measure", "source"], kind="mergesort")
    out = out[UNIFIED_COLUMNS].reset_index(drop=True)
    stats = _stats(as_of, stamp, freq, combine, rows_in, dropped_overlap, cross_cells, dropped_cross, out, resolution)
    stats["dropped_non_primary"] = dropped_non_primary
    return out, stats


def _stats(as_of, stamp, freq, combine, rows_in, dropped_overlap, cross_cells, dropped_cross, out, resolution) -> dict:
    return {"api": API_VERSION, "taxonomy": TAXONOMY_VERSION, "as_of": None if as_of is None else str(as_of),
            "as_of_utc": stamp, "freq": freq, "combine": combine, "rows_in": int(rows_in),
            "dropped_overlap": int(dropped_overlap), "cross_source_cells": int(cross_cells),
            "dropped_cross_source": int(dropped_cross), "dropped_non_primary": 0, "rows_out": int(len(out)),
            "dedup_rate": round((dropped_overlap + dropped_cross) / rows_in, 6) if rows_in else 0.0,
            "gdelt_resolution": dict(resolution)}


def unified_events(data_dir: str | Path = "data", as_of=None, *, freq: str = "M", isos: Iterable[str] | None = None,
                   categories: Iterable[str] | None = None, combine: str = "by_source",
                   sources: Iterable[str] = SOURCES) -> pd.DataFrame:
    """Team B's entry point: the unified, point-in-time event table (UNIFIED_COLUMNS) from the stored vintages.
    df.attrs["dedup"] holds the statistics. Empty table (columns only) when nothing is stored."""
    rows, mans = load_vintage_rows(data_dir, sources)
    df, stats = unify(rows, as_of, freq=freq, isos=isos, categories=categories, combine=combine, manifests=mans)
    df.attrs["dedup"] = stats
    return df


# ------------------------------------------------------------------------------------------------ coverage

def pull_report_counts(path: str | Path) -> list[dict]:
    """GDELT / UCDP step counts recorded in a Mac pull-pack report.json (status, counts, vintage)."""
    rep = json.loads(Path(path).read_text())
    out = []
    for s in rep.get("steps", []):
        if s.get("id") in ("gdelt", "ucdp"):
            out.append({"report": str(path), "step": s.get("id"), "status": s.get("status"),
                        "reason": s.get("reason", ""), "counts": s.get("counts") or {},
                        "vintage": (s.get("vintages") or {}).get(f"{s.get('id')}_vintage", "")})
    return out


def coverage_report(data_dir: str | Path = "data", as_of=None, *, isos: Iterable[str] | None = None,
                    pull_reports: Iterable[str | Path] = ()) -> dict:
    """Per-country coverage on recorded data only: the stored vintages (unified, by_source, monthly) and, when given,
    the counts recorded in Mac pull-pack reports. Never fills a gap."""
    from econquest.ingestion.events.mapping_qa import universe_isos
    d = Path(data_dir)
    universe, usrc = universe_isos(d)
    desk = set(pd.read_csv(d / "countries.csv", dtype=str)["iso"].str.strip().str.upper()) \
        if (d / "countries.csv").is_file() else set()
    rows, mans = load_vintage_rows(d, SOURCES)
    df, stats = unify(rows, as_of, freq="M", isos=isos, manifests=mans)
    per = []
    if len(df):
        g = df.groupby(["iso", "source", "category", "measure"])
        per = g.agg(first_period=("period", "min"), last_period=("period", "max"), months=("period", "nunique"),
                    months_nonzero=("value", lambda v: int((v > 0).sum())), total=("value", "sum"),
                    staged_days=("days_covered", "sum")).reset_index()
        per["staged_days"] = per["staged_days"].where(per["source"] == "gdelt")
        per = per.to_dict("records")
    covered = set(df["iso"]) if len(df) else set()
    scope = set(isos) if isos is not None else (universe | desk)
    gd = []
    for (src, vid), man in sorted(mans.items()):
        if src != "gdelt":
            continue
        p = man.get("provenance") or {}
        top = [[k, v] for k, v in sorted((p.get("unmapped") or {}).items(), key=lambda kv: -kv[1])[:20]]
        gd.append({"vintage": vid, "saved_utc": man.get("saved_utc"), "unmapped_total": p.get("unmapped_total"),
                   "unmapped_top": top, "isos_without_fips": p.get("isos_without_fips", []),
                   "taxonomy": p.get("taxonomy", "legacy")})
    return {"api": API_VERSION, "as_of": stats["as_of_utc"], "universe": usrc, "universe_size": len(universe),
            "stored_vintages": {s: len(list_event_vintages(d, s)) for s in SOURCES},
            "per_country": per, "countries_with_rows": sorted(covered),
            "countries_without_rows": sorted(scope - covered), "dedup": stats, "gdelt_mapping": gd,
            "pull_reports": [c for p in pull_reports for c in pull_report_counts(p)]}


def format_coverage(rep: dict) -> str:
    sv = rep["stored_vintages"]
    lines = [f"event coverage ({rep['api']}, as of {rep['as_of'] or 'latest'}): stored vintages gdelt {sv['gdelt']}, "
             f"ucdp {sv['ucdp']}; countries with rows {len(rep['countries_with_rows'])}, without "
             f"{len(rep['countries_without_rows'])} (universe {rep['universe_size']} from {rep['universe']})"]
    for r in rep["per_country"]:
        sd = f", {int(r['staged_days'])} staged days" if pd.notna(r.get("staged_days")) else ""
        lines.append(f"  {r['iso']} {r['source']} {r['category']} {r['measure']}: {r['first_period']}..{r['last_period']}"
                     f" {r['months']} month(s), {r['months_nonzero']} non-zero, total {r['total']:g}{sd}")
    d = rep["dedup"]
    lines.append(f"  dedup: rows_in {d['rows_in']}, dropped_overlap {d['dropped_overlap']}, cross_source_cells "
                 f"{d['cross_source_cells']}, rate {d['dedup_rate']:.2%}")
    for g in rep["gdelt_mapping"]:
        lines.append(f"  gdelt {g['vintage']}: unmapped_total {g['unmapped_total']}, taxonomy {g['taxonomy']}")
    for p in rep["pull_reports"]:
        lines.append(f"  pull report {p['report']} {p['step']} {p['status']}: {json.dumps(p['counts'])}"
                     + (f" ({p['reason'][:80]})" if p["reason"] else ""))
    return "\n".join(lines)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.events.unified",
                                 description="Unified GDELT + UCDP event table and coverage report (EQ-A-0139)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    e = sub.add_parser("events", help="the unified table (CSV to --out, else a summary)")
    e.add_argument("--as-of", default=None, help="YYYY-MM-DD (end of UTC day) or a UTC timestamp")
    e.add_argument("--freq", choices=("D", "M"), default="M")
    e.add_argument("--combine", choices=COMBINE, default="by_source")
    e.add_argument("--isos", default="", help="comma-separated ISO3")
    e.add_argument("--categories", default="", help=f"comma-separated, of {','.join(CATEGORIES)}")
    e.add_argument("--out", default=None, help="write the CSV here (an existing folder)")
    c = sub.add_parser("coverage", help="per-country coverage on recorded data")
    c.add_argument("--as-of", default=None)
    c.add_argument("--pull-report", nargs="*", default=[], help="Mac pull-pack report.json files to include")
    c.add_argument("--json", action="store_true")
    for p in (e, c):
        p.add_argument("--data", default="data")
    a = ap.parse_args(argv)
    try:
        if a.cmd == "events":
            df = unified_events(a.data, a.as_of, freq=a.freq, combine=a.combine,
                                isos=[s for s in a.isos.split(",") if s] or None,
                                categories=[s for s in a.categories.split(",") if s] or None)
            if a.out:
                out = Path(a.out)
                if not out.parent.is_dir():
                    raise FileNotFoundError(f"{out.parent} does not exist (no folder is created)")
                out.write_text(df.to_csv(index=False, lineterminator="\n"))
            print(json.dumps(df.attrs["dedup"], indent=1))
        else:
            rep = coverage_report(a.data, a.as_of, pull_reports=a.pull_report)
            print(json.dumps(rep, indent=1, default=str) if a.json else format_coverage(rep))
    except (ValueError, FileNotFoundError) as err:
        print(f"unified events: {err}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
