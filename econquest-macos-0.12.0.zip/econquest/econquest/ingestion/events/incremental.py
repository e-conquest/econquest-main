"""Daily incremental UCDP / GDELT pulls (EQ-A-0052): resume from the last stored date, pull only the new days, save a
vintage only when something changed, and run the country-mapping QA (events.mapping_qa) on what was pulled.

Resume point (from the stored vintages of the source, all of them, not only the latest):
  ucdp   the last day covered by any vintage (manifest provenance.coverage, else the month end of the latest period).
         UCDP counts are monthly, so the pull restarts at the first day of the month after it, or at the start of
         that month when the coverage ended mid-month (the whole month is pulled again; a partial month is never
         stacked on another). End: today (UTC). The Candidate dataset is monthly, so most daily runs find nothing
         new and save nothing.
  gdelt  the last day with an events_total row (a fully staged day, file-date basis). The pull starts the next day and
         ends yesterday (UTC): today's 15-minute files are not all out. Staging (gdelt.GdeltAdapter) resumes per day.
Bounded: at most `max_days` days per run (DEFAULT_MAX_DAYS: ucdp 366, gdelt 7); the rest is left for the next run and
reported as remaining_days. No stored vintage: the run refuses (status no_history) unless an explicit `start` is given;
the first pull is the Mac pull pack (pullpack steps 5a/5b, docs/runbooks/A-mac-pull-pack.md).
Idempotent: a run whose pull equals what is stored (same iso, period, freq, metric and value) saves nothing (status
no_new_data); a second run on the same day finds the plan empty or the same data. A per-source lock
(data/live/events/<source>/incremental.lock, flock) stops two runs overlapping (status busy).

Each run appends one row to data/live/events/<source>/incremental_log.csv (LOG_COLUMNS) and, when a vintage was saved,
refreshes the consumer exports (export.write_event_exports). Vintages hold only the pulled window; consumers that need
the full history read every vintage: export.build_events_long does, and indicators.stored_events uses merged_events.

    python -m econquest.ingestion.events.incremental plan --source all
    python -m econquest.ingestion.events.incremental run --source gdelt [--max-days 7] [--qa-threshold 0.02] [--json]

Exit: 0 ok / up to date / no new data; 2 the mapping QA breached its threshold (UCDP: an unmapped country, the pull
is refused and nothing saved; GDELT: the vintage is saved and the breach reported); 1 an error (token missing,
incomplete GDELT day, lock busy, no history). With --source all the worst code wins (1 over 2 over 0).
UCDP needs its token in the environment variable named in data/live/events/feeds.json (default UCDP_API_TOKEN).
"""
from __future__ import annotations

import argparse
import contextlib
import datetime as dt
import json
import sys
from pathlib import Path
from typing import Callable

import pandas as pd

from econquest.ingestion.events.base import (
    EVENT_COLUMNS, event_vintage_root, list_event_vintages, month_start, read_event_vintage, save_event_vintage,
    utc_stamp,
)
from econquest.ingestion.events.mapping_qa import DEFAULT_THRESHOLD
from econquest.ingestion.ledger import locked_append

try:                                     # POSIX only
    import fcntl
except ImportError:                      # pragma: no cover
    fcntl = None

SOURCES = ("ucdp", "gdelt")
DEFAULT_MAX_DAYS = {"ucdp": 366, "gdelt": 7}
# SEC-A-007 L5: hard ceiling on --max-days for GDELT (raw files ~15 GB a year; the pull pack refuses more than 366
# days too, pullpack.PackOptions.gdelt_max_days). UCDP is one small API page set per month.
MAX_DAYS_CEILING = {"ucdp": 3660, "gdelt": 366}
KEY = ["iso", "period", "freq", "metric"]
LOG_COLUMNS = ["run_utc", "source", "last_stored", "start", "end", "status", "vintage_id", "rows", "new_rows",
               "remaining_days", "unmapped_share", "qa_breach", "message"]
EXIT_OK, EXIT_ERROR, EXIT_BREACH = 0, 1, 2
OK_STATUSES = ("saved", "no_new_data", "up_to_date")


class IncrementalBusy(RuntimeError):
    """Another incremental run of the same source holds the lock."""


def _source_dir(data_dir: Path, source: str) -> Path:
    return event_vintage_root(data_dir, source).parent


def merged_events(data_dir: str | Path, source: str) -> pd.DataFrame:
    """Every stored vintage of `source`, oldest first, merged: for each (iso, period, freq, metric) the row of the
    newest vintage that has it. Empty (EVENT_COLUMNS) when there is no vintage."""
    frames = [read_event_vintage(data_dir, source, v) for v in list_event_vintages(data_dir, source)]
    if not frames:
        return pd.DataFrame(columns=EVENT_COLUMNS)
    allv = pd.concat(frames, ignore_index=True)
    return allv.drop_duplicates(KEY, keep="last").sort_values(KEY, ignore_index=True)[EVENT_COLUMNS]


def _manifest(data_dir: Path, source: str, vid: str) -> dict:
    p = event_vintage_root(data_dir, source) / vid / "manifest.json"
    try:
        return json.loads(p.read_text()) if p.is_file() else {}
    except ValueError:
        return {}


def last_stored_date(data_dir: str | Path, source: str) -> dt.date | None:
    """The last day the stored vintages of `source` cover (see the module docstring), or None without a vintage."""
    d = Path(data_dir)
    vids = list_event_vintages(d, source)
    if not vids:
        return None
    best = None
    if source == "ucdp":
        for v in vids:
            for pair in (_manifest(d, source, v).get("provenance") or {}).get("coverage") or []:
                try:
                    e = dt.date.fromisoformat(str(pair[1])[:10])
                except (ValueError, IndexError, TypeError):
                    continue
                best = e if best is None or e > best else best
        if best is not None:
            return best
    ev = merged_events(d, source)
    if source == "gdelt":
        ev = ev[ev["metric"] == "events_total"]
    if ev.empty:
        return None
    last = pd.Timestamp(ev["period"].max())
    if source == "ucdp":
        return (last + pd.offsets.MonthEnd(0)).date()
    return last.date()


def plan_incremental(data_dir: str | Path, source: str, today: dt.date | None = None, max_days: int | None = None,
                     start=None, end=None) -> dict:
    """What a run would pull: {source, last_stored, start, end, days, remaining_days, action} with action pull,
    up_to_date or no_history. `start` / `end` override the resume point / the default end."""
    if source not in SOURCES:
        raise ValueError(f"source must be one of {SOURCES}")
    today = today or dt.datetime.now(dt.timezone.utc).date()
    max_days = int(max_days or DEFAULT_MAX_DAYS[source])
    if max_days < 1:
        raise ValueError("max_days must be at least 1")
    if max_days > MAX_DAYS_CEILING[source]:
        raise ValueError(f"max_days {max_days} is over the {source} ceiling of {MAX_DAYS_CEILING[source]} days "
                         "(disk-bound); pull in bounded pieces, each run resumes")
    last = last_stored_date(data_dir, source)
    out = {"source": source, "last_stored": last.isoformat() if last else "", "max_days": max_days,
           "start": "", "end": "", "days": 0, "remaining_days": 0}
    if start is not None:
        lo = pd.Timestamp(start).date()
    elif last is None:
        return {**out, "action": "no_history",
                "message": f"no stored {source} vintage: run the first pull (pull pack step "
                           f"{'5a' if source == 'ucdp' else '5b'}) or pass an explicit start"}
    else:
        lo = last + dt.timedelta(days=1)
    if source == "ucdp":
        lo = month_start(lo)                  # monthly counts: never stack a partial month
    hi = pd.Timestamp(end).date() if end is not None else (today if source == "ucdp" else today - dt.timedelta(days=1))
    if lo > hi:
        return {**out, "action": "up_to_date", "message": f"{source} stored through {out['last_stored']}; nothing to pull"}
    capped = min(hi, lo + dt.timedelta(days=max_days - 1))
    return {**out, "action": "pull", "start": lo.isoformat(), "end": capped.isoformat(),
            "days": (capped - lo).days + 1, "remaining_days": (hi - capped).days, "message": ""}


@contextlib.contextmanager
def _run_lock(data_dir: Path, source: str):
    p = _source_dir(data_dir, source) / "incremental.lock"
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "a") as f:
        if fcntl is not None:
            try:
                fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except OSError:
                raise IncrementalBusy(f"another incremental {source} run holds {p}") from None
        try:
            yield
        finally:
            if fcntl is not None:
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)


def new_rows(pulled: pd.DataFrame, stored: pd.DataFrame) -> pd.DataFrame:
    """Rows of `pulled` whose key is not stored or whose value differs from the stored one."""
    if pulled.empty:
        return pulled
    if stored.empty:
        return pulled
    m = pulled.merge(stored[KEY + ["value"]], on=KEY, how="left", suffixes=("", "_stored"), indicator=True)
    changed = (m["_merge"] == "left_only") | ((m["value"] - m["value_stored"]).abs() > 1e-9)
    return pulled[changed.to_numpy()]


def _desk_isos(data_dir: Path) -> list[str]:
    return sorted(pd.read_csv(data_dir / "countries.csv", dtype=str, keep_default_na=False)["iso"].str.strip().str.upper())


def _log(data_dir: Path, row: dict) -> None:
    with locked_append(_source_dir(data_dir, row["source"]) / "incremental_log.csv", LOG_COLUMNS) as (w, _f, new):
        if new:
            w.writeheader()
        w.writerow({c: row.get(c, "") for c in LOG_COLUMNS})


def _pull_ucdp(d: Path, plan: dict, isos, fetcher, now, threshold, adapter_kwargs) -> tuple[pd.DataFrame | None, object, dict]:
    from econquest.ingestion.events.mapping_qa import ucdp_qa
    from econquest.ingestion.events.ucdp import UcdpAdapter, UnmappedCountryError
    ad = UcdpAdapter(data_dir=d, now=now, **(adapter_kwargs or {}))
    try:
        df = ad.fetch(isos, plan["start"], plan["end"], fetcher=fetcher)
    except UnmappedCountryError:
        qa, _ = ucdp_qa(ad.raw_events, d, threshold)
        qa["breach"] = True                                   # the adapter refuses any unmapped event
        return None, ad, qa
    qa, _ = ucdp_qa(ad.raw_events, d, threshold)
    return df, ad, qa


def _pull_gdelt(d: Path, plan: dict, isos, fetcher, now, threshold, adapter_kwargs, stage_dir) -> tuple[pd.DataFrame, object, dict]:
    from econquest.ingestion.events.gdelt import GdeltAdapter
    from econquest.ingestion.events.mapping_qa import gdelt_qa
    kw = dict(adapter_kwargs or {})
    if now is not None:
        kw.setdefault("now", lambda: now)
    kw.setdefault("categories", True)      # EQ-A-0138 (for A-0139): incremental vintages carry cat_<category> counts too
    stage = Path(stage_dir) if stage_dir else d / "live" / "events" / "gdelt" / "staging"
    ad = GdeltAdapter(stage, **kw)
    df = ad.fetch(isos, plan["start"], plan["end"], fetcher=fetcher)
    qa, _ = gdelt_qa(d, plan["start"], plan["end"], stage_dir=stage, threshold=threshold,
                     fips_map_csv=kw.get("fips_map_csv"))
    return df, ad, qa


def run_incremental(data_dir: str | Path, source: str, *, today: dt.date | None = None, max_days: int | None = None,
                    start=None, end=None, isos=None, fetcher=None, now: dt.datetime | None = None,
                    threshold: float = DEFAULT_THRESHOLD, stage_dir: str | Path | None = None,
                    adapter_kwargs: dict | None = None, export: bool = True,
                    log: Callable[[str], None] = lambda m: None) -> dict:
    """One incremental run of `source` (see the module docstring). Returns the report dict: the plan plus status
    (saved, no_new_data, up_to_date, no_history, mapping_failed, incomplete, busy, error), vintage_id, rows, new_rows,
    qa (mapping_qa report or None) and exit (0, 1 or 2). Never raises for an expected failure; it is in the report."""
    d = Path(data_dir)
    now = now or dt.datetime.now(dt.timezone.utc)
    today = today or now.date()
    rep: dict = {"source": source, "status": "", "vintage_id": "", "rows": 0, "new_rows": 0, "qa": None, "exit": EXIT_OK}
    try:
        with _run_lock(d, source):
            plan = plan_incremental(d, source, today, max_days, start, end)
            rep.update(plan)
            if plan["action"] != "pull":
                rep["status"] = plan["action"]
                rep["exit"] = EXIT_OK if plan["action"] == "up_to_date" else EXIT_ERROR
                return _finish(d, rep, now, log)
            isos = [str(i).strip().upper() for i in (isos or _desk_isos(d))]
            log(f"{source}: pulling {plan['start']}..{plan['end']} ({plan['days']} days; "
                f"{plan['remaining_days']} days left after this run)")
            from econquest.ingestion.events.gdelt import IncompleteFetchError
            try:
                if source == "ucdp":
                    df, ad, qa = _pull_ucdp(d, plan, isos, fetcher, now, threshold, adapter_kwargs)
                else:
                    df, ad, qa = _pull_gdelt(d, plan, isos, fetcher, now, threshold, adapter_kwargs, stage_dir)
            except IncompleteFetchError as e:
                rep.update(status="incomplete", message=f"{e}; rerun to resume", exit=EXIT_ERROR)
                return _finish(d, rep, now, log)
            rep["qa"] = qa
            if df is None:
                rep.update(status="mapping_failed", exit=EXIT_BREACH,
                           message="UCDP events with countries outside the map: nothing saved; add them to "
                                   "data/live/events/ucdp/country_map.csv")
                return _finish(d, rep, now, log)
            fresh = new_rows(df, merged_events(d, source))
            rep.update(rows=int(len(df)), new_rows=int(len(fresh)))
            if fresh.empty:
                rep["status"] = "no_new_data"
            else:
                prov = dict(ad.provenance())
                prov["incremental"] = {k: plan[k] for k in ("last_stored", "start", "end", "days", "remaining_days")}
                v = save_event_vintage(d, df, source, now=now, provenance=prov)
                rep.update(status="saved", vintage_id=v.name)
                if export:
                    from econquest.ingestion.events.export import write_event_exports
                    ex = write_event_exports(d, now=now)
                    rep["exports"] = {k: ex.get(k) for k in ("long_rows", "weekly_rows")}
            rep["exit"] = EXIT_BREACH if qa and qa.get("breach") else EXIT_OK
            return _finish(d, rep, now, log)
    except IncrementalBusy as e:
        rep.update(status="busy", message=str(e), exit=EXIT_ERROR)
        return rep                                            # not logged: the other run logs itself
    except (RuntimeError, ValueError, OSError) as e:
        rep.update(status="error", message=f"{type(e).__name__}: {e}", exit=EXIT_ERROR)
        return _finish(d, rep, now, log)


def _finish(d: Path, rep: dict, now: dt.datetime, log) -> dict:
    qa = rep.get("qa") or {}
    _log(d, {**{k: rep.get(k, "") for k in LOG_COLUMNS}, "run_utc": utc_stamp(now),
             "unmapped_share": qa.get("unmapped_share", ""), "qa_breach": qa.get("breach", ""),
             "message": str(rep.get("message", ""))[:300]})
    log(f"{rep['source']}: {rep['status']} {rep.get('vintage_id', '')} {rep.get('message', '')}".rstrip())
    return rep


def combined_exit(codes) -> int:
    codes = list(codes)
    return EXIT_ERROR if EXIT_ERROR in codes else (EXIT_BREACH if EXIT_BREACH in codes else EXIT_OK)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.events.incremental",
                                 description="Daily incremental UCDP / GDELT pull with country-mapping QA (EQ-A-0052)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name, hlp in (("plan", "show what a run would pull (no network, writes nothing)"),
                      ("run", "pull the new days, save a vintage when something changed, run the mapping QA")):
        p = sub.add_parser(name, help=hlp)
        p.add_argument("--source", choices=SOURCES + ("all",), default="all")
        p.add_argument("--data", default="data", help="econquest data folder (default: data)")
        p.add_argument("--max-days", type=int, default=None, help="days per run (default ucdp 366, gdelt 7)")
        p.add_argument("--start", default=None, help="override the resume point (first pull without history)")
        p.add_argument("--end", default=None, help="override the end (default: ucdp today, gdelt yesterday, UTC)")
        p.add_argument("--json", action="store_true")
        if name == "run":
            p.add_argument("--qa-threshold", type=float, default=DEFAULT_THRESHOLD, help="maximum unmapped share")
            p.add_argument("--isos", default="", help="comma-separated ISO3 (default: data/countries.csv)")
            p.add_argument("--gdelt-allow-http", action="store_true", help="only if https to data.gdeltproject.org fails")
            p.add_argument("--no-export", action="store_true", help="do not refresh the consumer exports")
    a = ap.parse_args(argv)
    sources = SOURCES if a.source == "all" else (a.source,)
    d = Path(a.data)
    if a.cmd == "plan":
        plans = [plan_incremental(d, s, max_days=a.max_days, start=a.start, end=a.end) for s in sources]
        if a.json:
            print(json.dumps(plans, indent=1))
        else:
            for p in plans:
                print(f"{p['source']}: {p['action']} last stored {p['last_stored'] or '-'}"
                      + (f"; pull {p['start']}..{p['end']} ({p['days']} days, {p['remaining_days']} left)"
                         if p["action"] == "pull" else f"; {p['message']}"))
        return EXIT_OK
    isos = [s for s in a.isos.split(",") if s.strip()] or None
    reps = []
    for s in sources:
        kw = {"allow_http": True} if (s == "gdelt" and a.gdelt_allow_http) else None
        reps.append(run_incremental(d, s, max_days=a.max_days, start=a.start, end=a.end, isos=isos,
                                    threshold=a.qa_threshold, adapter_kwargs=kw, export=not a.no_export,
                                    log=lambda m: print(m, file=sys.stderr, flush=True)))
    if a.json:
        print(json.dumps(reps, indent=1, default=str))
    else:
        from econquest.ingestion.events.mapping_qa import format_report
        for r in reps:
            print(f"{r['source']}: {r['status']}" + (f" vintage {r['vintage_id']}" if r["vintage_id"] else "")
                  + (f" rows {r['rows']} new {r['new_rows']}" if r["rows"] else "")
                  + (f" ({r.get('message')})" if r.get("message") else ""))
            if r.get("qa"):
                print(format_report(r["qa"], limit=15))
    return combined_exit(r["exit"] for r in reps)


if __name__ == "__main__":
    raise SystemExit(main())
