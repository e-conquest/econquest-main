"""Candidate values for scorecard indicators 6.9, 4.1 and 6.4 from stored event vintages (EQ-A-0022..0024, GOV-014).

event_indicators(events, as_of, isos) -> one row per (iso, indicator) with columns
    iso, indicator, value, suggested_level, basis, sources, vintage_ids

These are CANDIDATES for the analyst and for model-risk change control (docs/runbooks/A-spike-event-feeds.md,
"What Sam must decide" 4-5). Nothing here writes indicators.csv: levels 0-4 for 4.1 and 6.4 stay analyst-set.

Point in time: only rows with period <= as_of are used (pass `as_of_retrieval=True` to also drop rows retrieved after
as_of, i.e. reproduce what a vintage held then). Windows end at the last complete month on or before as_of, or at the
latest month the source covers for that country if earlier. A window with a month the source does not cover gives no
value (basis says so); UCDP and ACLED vintages are zero-filled inside their coverage, GDELT daily rows are summed to
months.

6.9 Political violence trend (ratio, rulebook thresholds 0.8 / 1.0 / 1.5 / 2.0 / 3.0):
    indicator-rules section 7 (EQ-A-0118; section 19.2 replaced the old floor of 1): N12 = events in the last 12
    months, B = mean annual events over the previous 60 months; B >= 5: N12 / B; B < 5 and N12 < 5: 0.8; B < 5 and
    N12 >= 5: N12 / 5; cap 10; data end more than 92 days before as_of: stale, no suggested level.
    ACLED when present: Battles + Explosions/Remote violence + Violence against civilians.
    Otherwise UCDP events_total, labelled a PROXY (fatal organised violence only, reads low in protest-led unrest).
    suggested_level = number of thresholds the ratio reaches (0-5), a band, not a rulebook score.
4.1 Street pressure (level 0-4, analyst): value = protest ratio.
    ACLED: Protests + Riots over the last 3 months / mean 3-month count over the previous 60 months (floor 1).
    Else GDELT: protest share of all GDELT events (EventRootCode 14 / total) over 3 months / the same share over the
    previous 60 months (controls for media volume).
    suggested_level only when `adjustment` (iso -> fiscal adjustment, % of GDP, indicator 1.6 side) is given:
    0 if ratio <= 1.0; 2 if adjustment >= 1.5 and ratio >= 1.5; else 1. Never above 2: 3-4 (reversal, deaths,
    government fall) are analyst judgements.
6.4 Attacks on business and staff (level 0-4, analyst): ACLED only. value = abductions + looting/property destruction
    events over 12 months, with the 5-year annual mean in basis; suggested_level empty (per-country thresholds not
    set). Without ACLED the row says there is no feed evidence (UCDP and GDELT cannot support 6.4).
"""
from __future__ import annotations

import datetime as dt
import math
from pathlib import Path

import pandas as pd

from econquest.ingestion.events.base import EVENT_COLUMNS, load_event_config, validate_events
from econquest.rules.research import violence_trend_ratio

OUT_COLUMNS = ["iso", "indicator", "value", "suggested_level", "basis", "sources", "vintage_ids"]
THRESHOLDS_69 = (0.8, 1.0, 1.5, 2.0, 3.0)
ACLED_PV = ["events_battles", "events_explosions_remote", "events_violence_civilians"]
ACLED_PROTEST = ["events_protest", "events_riot"]
ACLED_ATTACKS = ["events_abductions", "events_looting_property"]
BASE_MONTHS = 60


def _last_complete_month(as_of: dt.date) -> pd.Period:
    p = pd.Period(as_of, freq="M")
    return p if as_of == p.end_time.date() else p - 1


def _monthly(ev: pd.DataFrame, source: str, metrics: list[str]) -> pd.DataFrame:
    """Rows of one source -> wide monthly table (iso, month) x metric, summing daily rows into months."""
    sub = ev[(ev["source"] == source) & ev["metric"].isin(metrics) & ev["freq"].isin(["D", "M"])]
    if sub.empty:
        return pd.DataFrame(columns=metrics)
    sub = sub.assign(month=pd.to_datetime(sub["period"]).dt.to_period("M"))
    return sub.pivot_table(index=["iso", "month"], columns="metric", values="value", aggfunc="sum")


def _windows(anchor: pd.Period, recent: int):
    rec = pd.period_range(anchor - recent + 1, anchor, freq="M")
    base = pd.period_range(anchor - recent - BASE_MONTHS + 1, anchor - recent, freq="M")
    return rec, base


def _series(wide: pd.DataFrame, iso: str, metrics: list[str]) -> pd.Series | None:
    if wide.empty or iso not in wide.index.get_level_values(0):
        return None
    w = wide.xs(iso, level=0)
    if any(m not in w.columns for m in metrics):
        return None
    w = w[metrics]
    w = w[w.notna().all(axis=1)]                     # a month counts as covered only when every metric is present
    return w.sum(axis=1) if len(w) else None


def _vids(ev: pd.DataFrame, source: str, iso: str) -> str:
    v = ev[(ev["source"] == source) & (ev["iso"] == iso)]["vintage_id"]
    return "|".join(sorted({x for x in v if x}))


def _ratio(s: pd.Series, as_of: dt.date, recent: int, per: int):
    """recent-window total / (base total / (BASE_MONTHS / per)), base floored at 1 per `per` months."""
    anchor = min(_last_complete_month(as_of), s.index.max())
    rec, base = _windows(anchor, recent)
    miss = [p for p in list(base) + list(rec) if p not in s.index]
    if miss:
        return None, (f"insufficient coverage: {len(miss)} of {len(base) + len(rec)} months missing "
                      f"({miss[0]}..{miss[-1]}) for {rec[0]}..{rec[-1]} vs {base[0]}..{base[-1]}")
    r_tot, b_tot = float(s[rec].sum()), float(s[base].sum())
    b_mean = b_tot / (BASE_MONTHS / per)
    floored = b_mean < 1.0
    val = r_tot / max(b_mean, 1.0)
    unit = "year" if per == 12 else f"{per} months"
    basis = (f"{r_tot:g} in {rec[0]}..{rec[-1]} vs mean {b_mean:.2f} per {unit} in {base[0]}..{base[-1]}"
             + (" (base floored at 1)" if floored else ""))
    return val, basis


# 6.9 by indicator-rules section 7 (section 19.2): Team B's one implementation, C15 (HO-20261026-A-B-004, EQ-A-0129).
# The local copy is gone; _ratio_69 stays one release as an alias (rule 5) for Team B's parity test.
_ratio_69 = violence_trend_ratio


def _share_ratio(prot: pd.Series, tot: pd.Series, as_of: dt.date, recent: int):
    idx = prot.index.intersection(tot.index)
    if not len(idx):
        return None, "no GDELT months"
    anchor = min(_last_complete_month(as_of), idx.max())
    rec, base = _windows(anchor, recent)
    miss = [p for p in list(base) + list(rec) if p not in idx]
    if miss:
        return None, f"insufficient GDELT coverage: {len(miss)} of {len(base) + len(rec)} months missing"
    rt, bt = float(tot[rec].sum()), float(tot[base].sum())
    if rt <= 0 or bt <= 0:
        return None, "no GDELT events in a window"
    rs, bs = float(prot[rec].sum()) / rt, float(prot[base].sum()) / bt
    if bs <= 0:
        return None, "no GDELT protest events in the base window"
    return rs / bs, (f"protest share {rs:.4f} in {rec[0]}..{rec[-1]} vs {bs:.4f} in {base[0]}..{base[-1]} "
                     "(GDELT root 14 / all events)")


def band(value: float, thresholds=THRESHOLDS_69) -> int:
    return int(sum(value >= t for t in thresholds))


def event_indicators(events: pd.DataFrame, as_of, isos, adjustment: dict | None = None,
                     thresholds_69=THRESHOLDS_69, as_of_retrieval: bool = False) -> pd.DataFrame:
    """Candidate values and evidence for 6.9, 4.1 and 6.4 per country (see module docstring)."""
    as_of = pd.Timestamp(as_of).date()
    ev = validate_events(events) if len(events) else pd.DataFrame(columns=EVENT_COLUMNS)
    ev = ev[pd.to_datetime(ev["period"]).dt.date <= as_of] if len(ev) else ev
    if as_of_retrieval and len(ev):
        cutoff = pd.Timestamp(as_of, tz="UTC") + pd.Timedelta(days=1)
        ev = ev[pd.to_datetime(ev["retrieved_utc"], utc=True, errors="coerce") < cutoff]
    has = {s: bool(len(ev)) and (ev["source"] == s).any() for s in ("ucdp", "gdelt", "acled")}
    acled_pv = _monthly(ev, "acled", ACLED_PV) if has["acled"] else pd.DataFrame()
    acled_pr = _monthly(ev, "acled", ACLED_PROTEST) if has["acled"] else pd.DataFrame()
    acled_at = _monthly(ev, "acled", ACLED_ATTACKS) if has["acled"] else pd.DataFrame()
    ucdp = _monthly(ev, "ucdp", ["events_total"]) if has["ucdp"] else pd.DataFrame()
    gd = _monthly(ev, "gdelt", ["events_protest", "events_total"]) if has["gdelt"] else pd.DataFrame()
    adjustment = adjustment or {}
    rows = []
    for iso in sorted({str(i).upper() for i in isos}):
        # ---- 6.9
        u = _series(ucdp, iso, ["events_total"])
        u_val, u_basis, u_stale = violence_trend_ratio(u, as_of) if u is not None else (None, "no UCDP rows", False)
        a = _series(acled_pv, iso, ACLED_PV)
        stale = False
        if a is not None:
            val, basis, stale = violence_trend_ratio(a, as_of)
            basis = f"ACLED political-violence events: {basis}; UCDP cross-check: " + (
                f"{u_val:.2f}" if u_val is not None else u_basis)
            src, vids = "acled" + ("+ucdp" if u is not None else ""), "|".join(
                x for x in (_vids(ev, "acled", iso), _vids(ev, "ucdp", iso)) if x)
        elif u is not None:
            val, basis, stale = u_val, f"PROXY (UCDP fatal organised violence only; reads low in protest-led unrest): {u_basis}", u_stale
            src, vids = "ucdp (proxy)", _vids(ev, "ucdp", iso)
        else:
            val, basis, src, vids = None, "no UCDP or ACLED rows", "", ""
        rows.append({"iso": iso, "indicator": "6.9", "value": val, "suggested_level": band(val, thresholds_69)
                     if val is not None and not stale else None, "basis": basis + "; suggested_level = thresholds reached "
                     f"{'/'.join(map(str, thresholds_69))}", "sources": src, "vintage_ids": vids})
        # ---- 4.1
        p = _series(acled_pr, iso, ACLED_PROTEST)
        if p is not None:
            val, basis = _ratio(p, as_of, 3, 3)
            basis, src, vids = f"ACLED protests+riots: {basis}", "acled", _vids(ev, "acled", iso)
        else:
            gp, gt = _series(gd, iso, ["events_protest"]), _series(gd, iso, ["events_total"])
            if gp is not None and gt is not None:
                val, basis = _share_ratio(gp, gt, as_of, 3)
                basis, src, vids = f"PROXY (GDELT media-coded): {basis}", "gdelt (proxy)", _vids(ev, "gdelt", iso)
            else:
                val, basis, src, vids = None, "no ACLED or GDELT protest rows", "", ""
        lvl = None
        adj = adjustment.get(iso)
        if val is not None and adj is not None and not (isinstance(adj, float) and math.isnan(adj)):
            lvl = 0 if val <= 1.0 else (2 if adj >= 1.5 and val >= 1.5 else 1)
            basis += f"; adjustment {adj:g}% GDP"
        rows.append({"iso": iso, "indicator": "4.1", "value": val, "suggested_level": lvl,
                     "basis": basis + "; evidence only, analyst sets the level (suggestion capped at 2)",
                     "sources": src, "vintage_ids": vids})
        # ---- 6.4
        t = _series(acled_at, iso, ACLED_ATTACKS)
        if t is not None:
            val, b = _ratio(t, as_of, 12, 12)
            anchor = min(_last_complete_month(as_of), t.index.max())
            cnt = float(t[_windows(anchor, 12)[0]].sum()) if val is not None else None
            basis = (f"ACLED abductions + looting/property destruction: {b}; ratio {val:.2f}" if val is not None
                     else f"ACLED: {b}")
            rows.append({"iso": iso, "indicator": "6.4", "value": cnt, "suggested_level": None,
                         "basis": basis + "; no keyword filter for business targets yet; analyst sets the level",
                         "sources": "acled", "vintage_ids": _vids(ev, "acled", iso)})
        else:
            rows.append({"iso": iso, "indicator": "6.4", "value": None, "suggested_level": None,
                         "basis": "no ACLED rows (ACLED not enabled/licensed); UCDP and GDELT cannot support 6.4; "
                                  "analyst sets the level from press", "sources": "", "vintage_ids": ""})
    out = pd.DataFrame(rows, columns=OUT_COLUMNS)
    out["value"] = pd.to_numeric(out["value"], errors="coerce").astype(float)
    out["suggested_level"] = pd.to_numeric(out["suggested_level"], errors="coerce").astype("Int64")
    return out


def stored_events(data_dir: Path) -> pd.DataFrame:
    """Stored events of every source that has a vintage; ACLED only when enabled and licensed in the config.
    EQ-A-0052: all vintages merged (incremental.merged_events: per iso, period, freq and metric the newest vintage's
    row), because a daily incremental vintage holds only the days it pulled. With one full-range vintage this is that
    vintage, as before."""
    from econquest.ingestion.events.acled import acled_ready
    from econquest.ingestion.events.incremental import merged_events
    cfg = load_event_config(data_dir)
    frames = []
    for s in ("ucdp", "gdelt", "acled"):
        if s == "acled" and not acled_ready(cfg.get("acled", {}))[0]:
            continue
        ev = merged_events(data_dir, s)
        if len(ev):
            frames.append(ev)
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame(columns=EVENT_COLUMNS)
