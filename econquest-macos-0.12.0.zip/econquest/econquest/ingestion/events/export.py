"""Consumer exports of the stored event vintages (EQ-A-0028): Team B's long table and Team C's weekly table.

Our contract (`base.EVENT_COLUMNS`, one table per source vintage) stays the store of record. This module derives the
two formats other teams asked for from the stored vintages only (never from a live pull):

    data/live/events/events_long.csv   Team B, HO-20261023-B-A-004 (event stress index, engine/event_index.py)
    data/live/events_weekly.csv        Team C, HO-20261023-C-A-007 (presentation/events_view.py EVENT_SCHEMA)

Vintage folders are read-only and append-only, so a copy of each export is NOT put inside them. Instead every
write_event_exports() call that changes either file also archives both files, read-only (0444), under
data/live/events/exports/<YYYY-MM-DDTHHMMSSZ>-<hash8>/ with a manifest.json (sha256, rows, the source vintages
used, problems) and a row in data/live/events/exports/index.csv. An export identical to the newest archived one is
not archived again.

Team B long table (LONG_COLUMNS, one row per iso, source, series, freq, period, vintage)
-------------------------------------------------------------------------------------
Built from ALL stored vintages of ucdp and gdelt, not only the latest. Mapping (SERIES_MAP):

    ucdp  events_total             -> events       (all three UCDP violence types; fatal events only)
    ucdp  fatalities_best          -> fatalities   (UCDP best estimate)
    gdelt events_material_conflict -> events       (conflict-relevant count: QuadClass 4 = material conflict,
                                                    CAMEO roots 14-20 per the GDELT codebook; root events only
                                                    and file-date basis, as recorded in the vintage manifest)
    gdelt goldstein_mean           -> goldstein_mean (event-weighted daily mean over ALL root events of the day,
    gdelt tone_mean                -> tone_mean       not only conflict events: the adapter stores only that mean)

UCDP source: a UCDP vintage holds monthly rows from two datasets. Each row is labelled `ucdp_ged` or
`ucdp_candidate` by the dataset windows in the vintage manifest (provenance.datasets: dataset GED|Candidate,
version, start, end); a row outside every window is dropped and reported (never guessed).

vintage = the date the row became available to the desk: the UTC date of the row's retrieved_utc (the snapshot
time; for GDELT the time that day was staged), or `release_date` of the GED/Candidate dataset entry in the manifest
when one is recorded. Point in time: a row is written for a new vintage only when its value differs from the value
of the same (iso, source, series, freq, period) in the previous vintage (or the key is new), so "latest vintage on or
before as_of" reproduces each snapshot. Two snapshots on the same date: the later save wins.

Explicit zeros: UCDP vintages are zero-filled for every requested country and month inside the dataset coverage
and GDELT vintages carry 0 counts for every requested country on a fully staged day, so `events` / `fatalities`
rows with value 0 are kept; GDELT goldstein/tone rows are absent on a day with no events (as the adapter stores them).

Team C weekly table (WEEKLY_COLUMNS == events_view.EVENT_SCHEMA)
--------------------------------------------------------------
GDELT only: UCDP vintages hold monthly totals, which cannot be split into ISO weeks without inventing a daily profile
(a follow-up would need the UCDP adapter to store daily or weekly counts). For each (iso, day) the most recent GDELT
vintage that covers the day (has an events_total row) supplies all of that day's metrics. Days are bucketed to the
ISO week starting Monday (UTC). Per country and week: one total row (event_type blank, event_count = sum of
events_total, goldstein_mean / tone_mean = means weighted by the daily events_total over days that have a mean) and
breakdown rows event_type material_conflict / verbal_conflict / protest (counts only). fatalities is blank for GDELT.
A week only partly staged is summed over the staged days (events_view drops a week that is not complete at its
reference date). retrieved = the latest retrieved_utc of the week's rows.

Reader for the engine: load_events_long(data_dir) (the lead wires it into loaders.Universe.events, EQ-A-0028).
"""
from __future__ import annotations

import datetime as dt
import hashlib
import io
import json
import logging
import os
import tempfile
from pathlib import Path

import pandas as pd

from econquest.ingestion.events.base import (
    EventDataError, event_vintage_root, list_event_vintages, month_start, read_event_vintage, utc_stamp,
)
from econquest.ingestion.ledger import locked_append

log = logging.getLogger(__name__)

LONG_COLUMNS = ["iso", "source", "series", "freq", "period", "value", "vintage", "provenance"]
LONG_KEY = ["iso", "source", "series", "freq", "period"]
WEEKLY_COLUMNS = ["iso3", "country", "week_start", "source", "event_type", "event_count", "fatalities",
                  "goldstein_mean", "tone_mean", "retrieved"]
LONG_PATH = Path("live") / "events" / "events_long.csv"          # relative to data_dir (data/)
WEEKLY_PATH = Path("live") / "events_weekly.csv"
EXPORTS_DIR = Path("live") / "events" / "exports"
EXPORT_INDEX_COLUMNS = ["export_id", "created_utc", "long_rows", "long_sha256", "weekly_rows", "weekly_sha256"]

SERIES_MAP = {
    "ucdp": {"events_total": "events", "fatalities_best": "fatalities"},
    "gdelt": {"events_material_conflict": "events", "goldstein_mean": "goldstein_mean", "tone_mean": "tone_mean"},
}
UCDP_DATASETS = {"GED": "ucdp_ged", "Candidate": "ucdp_candidate"}
GDELT_FILTER = "events = QuadClass 4 (material conflict); goldstein_mean/tone_mean = mean over all {scope}"
WEEKLY_SOURCE = "GDELT"
WEEKLY_TYPES = {"events_material_conflict": "material_conflict", "events_verbal_conflict": "verbal_conflict",
                "events_protest": "protest"}


# ---------------------------------------------------------------------------------------------------------- read

def _manifest(data_dir: Path, source: str, vid: str) -> dict:
    p = event_vintage_root(data_dir, source) / vid / "manifest.json"
    return json.loads(p.read_text()) if p.exists() else {}


def _vintages(data_dir: Path, source: str):
    """(save order, vintage id, validated events, manifest) for every stored vintage of `source`, oldest first."""
    for i, vid in enumerate(list_event_vintages(data_dir, source)):
        yield i, vid, read_event_vintage(data_dir, source, vid), _manifest(data_dir, source, vid)


def _avail_date(retrieved: pd.Series, fallback: str) -> pd.Series:
    """UTC date (YYYY-MM-DD) of retrieved_utc, or of `fallback` (the manifest's saved_utc) when blank."""
    r = retrieved.where(retrieved.astype(str).str.len() >= 10, fallback)
    return r.astype(str).str[:10]


def _ucdp_windows(man: dict) -> list[tuple[dt.date, dt.date, str, str, str | None]]:
    """(first month, last day, source label, provenance, release date) per dataset recorded in the manifest."""
    out = []
    prov = man.get("provenance") or {}
    for d in prov.get("datasets") or []:
        label = UCDP_DATASETS.get(str(d.get("dataset")))
        if not label or not d.get("start") or not d.get("end"):
            continue
        rel = str(d.get("release_date") or "")[:10] or None
        out.append((month_start(d["start"]), pd.Timestamp(d["end"]).date(), label,
                    f"UCDP {d.get('dataset')} {d.get('version', '?')}", rel))
    return out


def _ucdp_rows(vid: str, ev: pd.DataFrame, man: dict, problems: list[str]) -> pd.DataFrame:
    ev = ev[ev["metric"].isin(SERIES_MAP["ucdp"])].copy()
    if ev.empty:
        return ev
    wins = _ucdp_windows(man)
    per = pd.to_datetime(ev["period"], format="%Y-%m-%d").dt.date
    ev["source"], ev["prov"], ev["rel"] = "", "", None
    for lo, hi, label, prov, rel in wins:
        m = (ev["source"] == "") & (per >= lo) & (per <= hi)
        ev.loc[m, "source"], ev.loc[m, "prov"], ev.loc[m, "rel"] = label, prov, rel
    miss = ev["source"] == ""
    if miss.any():
        problems.append(f"ucdp vintage {vid}: {int(miss.sum())} row(s) outside the GED/Candidate windows of its manifest "
                        f"(periods {sorted(set(ev.loc[miss, 'period']))[:3]}...) dropped")
        ev = ev[~miss]
    avail = _avail_date(ev["retrieved_utc"], str(man.get("saved_utc", "")))
    ev["vintage"] = ev["rel"].where(ev["rel"].notna(), avail)
    ev["provenance"] = ev["prov"] + " (" + ev["licence"] + "); vintage ucdp/" + vid
    ev["series"] = ev["metric"].map(SERIES_MAP["ucdp"])
    return ev


def _gdelt_scope(man: dict) -> str:
    p = man.get("provenance") or {}
    root = "root events" if p.get("root_only", True) else "events (root and non-root)"
    return f"{root}, date basis {p.get('date_basis', 'file')}"


def _gdelt_rows(vid: str, ev: pd.DataFrame, man: dict) -> pd.DataFrame:
    ev = ev[ev["metric"].isin(SERIES_MAP["gdelt"])].copy()
    if ev.empty:
        return ev
    scope = _gdelt_scope(man)
    ev["source"] = "gdelt"
    ev["vintage"] = _avail_date(ev["retrieved_utc"], str(man.get("saved_utc", "")))
    ev["provenance"] = (f"GDELT 2.0 events, cite gdeltproject.org; {scope}; "
                        + GDELT_FILTER.format(scope=scope.split(',')[0]) + f"; vintage gdelt/{vid}")
    ev["series"] = ev["metric"].map(SERIES_MAP["gdelt"])
    return ev


def _build_long(data_dir: Path) -> tuple[pd.DataFrame, list[str], dict[str, list[str]]]:
    data_dir = Path(data_dir)
    frames, problems, used = [], [], {"ucdp": [], "gdelt": []}
    for source in ("ucdp", "gdelt"):
        for order, vid, ev, man in _vintages(data_dir, source):
            rows = _ucdp_rows(vid, ev, man, problems) if source == "ucdp" else _gdelt_rows(vid, ev, man)
            used[source].append(vid)
            if len(rows):
                rows = rows.assign(_order=order)
                frames.append(rows[LONG_COLUMNS + ["_order"]])
    if not frames:
        return pd.DataFrame(columns=LONG_COLUMNS), problems, used
    df = pd.concat(frames, ignore_index=True)
    df["freq"] = df["freq"].replace({"Y": "A"})                       # Team B calls annual "A"
    df = df.sort_values(LONG_KEY + ["vintage", "_order"], kind="mergesort")
    df = df.drop_duplicates(LONG_KEY + ["vintage"], keep="last")   # same-day snapshots: the later save wins
    prev = df.groupby(LONG_KEY, sort=False)["value"].shift()
    df = df[prev.isna() | (df["value"] != prev)]                    # keep a row only when new or revised
    return df[LONG_COLUMNS].reset_index(drop=True), problems, used


def build_events_long(data_dir: Path) -> pd.DataFrame:
    """Team B's long table (LONG_COLUMNS) from every stored ucdp and gdelt vintage. Problems (rows that could not be
    labelled) are logged and dropped, never guessed; see the module docstring for the mapping."""
    df, problems, _ = _build_long(data_dir)
    for p in problems:
        log.warning(p)
    return df


def _country_names(data_dir: Path) -> dict[str, str]:
    p = Path(data_dir) / "countries.csv"
    if not p.exists():
        return {}
    c = pd.read_csv(p, dtype=str, keep_default_na=False, usecols=lambda x: x in ("country", "iso"))
    if not {"country", "iso"} <= set(c.columns):
        return {}
    return dict(zip(c["iso"].str.strip().str.upper(), c["country"].str.strip()))


def _weekly_from_daily(daily: pd.DataFrame, names: dict[str, str]) -> pd.DataFrame:
    """Daily GDELT rows (EVENT_COLUMNS, one vintage per (iso, day) already chosen) -> WEEKLY_COLUMNS."""
    w = daily.pivot_table(index=["iso", "period"], columns="metric", values="value", aggfunc="last")
    w = w.reindex(columns=sorted(set(w.columns) | {"events_total", "goldstein_mean", "tone_mean", *WEEKLY_TYPES}))
    ret = daily.groupby(["iso", "period"])["retrieved_utc"].max()
    w = w.join(ret).reset_index()
    d = pd.to_datetime(w["period"], format="%Y-%m-%d")
    w["week_start"] = (d - pd.to_timedelta(d.dt.weekday, unit="D")).dt.strftime("%Y-%m-%d")
    n = w["events_total"].fillna(0.0)
    w["_gw"] = (w["goldstein_mean"] * n).where(w["goldstein_mean"].notna(), 0.0)
    w["_gn"] = n.where(w["goldstein_mean"].notna(), 0.0)
    w["_tw"] = (w["tone_mean"] * n).where(w["tone_mean"].notna(), 0.0)
    w["_tn"] = n.where(w["tone_mean"].notna(), 0.0)
    agg = {"events_total": "sum", "_gw": "sum", "_gn": "sum", "_tw": "sum", "_tn": "sum", "retrieved_utc": "max",
           **{m: "sum" for m in WEEKLY_TYPES}}
    g = w.groupby(["iso", "week_start"], as_index=False).agg(agg)
    base = pd.DataFrame({"iso3": g["iso"], "country": g["iso"].map(names).fillna(""), "week_start": g["week_start"],
                         "source": WEEKLY_SOURCE, "fatalities": float("nan"), "retrieved": g["retrieved_utc"]})
    tot = base.assign(event_type="", event_count=g["events_total"].round().astype(int),
                      goldstein_mean=(g["_gw"] / g["_gn"]).where(g["_gn"] > 0).round(6),
                      tone_mean=(g["_tw"] / g["_tn"]).where(g["_tn"] > 0).round(6))
    parts = [tot] + [base.assign(event_type=label, event_count=g[m].round().astype(int), goldstein_mean=float("nan"),
                                 tone_mean=float("nan")) for m, label in WEEKLY_TYPES.items()]
    out = pd.concat(parts, ignore_index=True)
    out = out.sort_values(["week_start", "iso3", "source", "event_type"], kind="mergesort")
    return out[WEEKLY_COLUMNS].reset_index(drop=True)


def build_events_weekly(data_dir: Path) -> pd.DataFrame:
    """Team C's weekly table (WEEKLY_COLUMNS = events_view.EVENT_SCHEMA) from the GDELT vintages: for each country and
    day the newest vintage covering it, bucketed to ISO weeks starting Monday. Empty (columns only) without GDELT."""
    data_dir = Path(data_dir)
    days = []
    for order, _vid, ev, _man in _vintages(data_dir, "gdelt"):
        ev = ev[ev["freq"] == "D"]
        if len(ev):
            days.append(ev.assign(_order=order))
    if not days:
        return pd.DataFrame(columns=WEEKLY_COLUMNS)
    allrows = pd.concat(days, ignore_index=True)
    cover = allrows[allrows["metric"] == "events_total"].groupby(["iso", "period"])["_order"].max().rename("_pick")
    allrows = allrows.join(cover, on=["iso", "period"])
    daily = allrows[allrows["_order"] == allrows["_pick"]]
    return _weekly_from_daily(daily, _country_names(data_dir))


# ---------------------------------------------------------------------------------------------------------- write

def _csv_bytes(df: pd.DataFrame) -> bytes:
    return df.to_csv(index=False, lineterminator="\n").encode()


def _atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(tmp, 0o644)
        os.replace(tmp, path)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


def _last_export(index: Path) -> dict | None:
    if not index.exists():
        return None
    t = pd.read_csv(index, dtype=str, keep_default_na=False)
    return t.iloc[-1].to_dict() if len(t) else None


def write_event_exports(data_dir: Path, now: dt.datetime | None = None) -> dict:
    """Rebuild both exports from the stored vintages and write them atomically:
    data/live/events/events_long.csv (Team B) and data/live/events_weekly.csv (Team C). When either changed since the
    newest archived export, also archive both read-only under data/live/events/exports/<ts>-<hash8>/ (+ manifest.json,
    index.csv row). Raises FileNotFoundError when no ucdp or gdelt vintage exists (never writes an empty feed)."""
    data_dir = Path(data_dir)
    long_df, problems, used = _build_long(data_dir)
    if not any(used.values()):
        raise FileNotFoundError(f"no ucdp or gdelt event vintage under {data_dir / 'live' / 'events'}; nothing to export "
                                f"(run the pulls on the Mac, docs/runbooks/A-event-feeds.md)")
    for p in problems:
        log.warning(p)
    weekly_df = build_events_weekly(data_dir)
    lb, wb = _csv_bytes(long_df), _csv_bytes(weekly_df)
    lp, wp = data_dir / LONG_PATH, data_dir / WEEKLY_PATH
    _atomic_write(lp, lb)
    _atomic_write(wp, wb)
    lsha, wsha = hashlib.sha256(lb).hexdigest(), hashlib.sha256(wb).hexdigest()
    out = {"long": lp, "weekly": wp, "long_rows": len(long_df), "weekly_rows": len(weekly_df), "archive": None,
           "problems": problems}
    root = data_dir / EXPORTS_DIR
    last = _last_export(root / "index.csv")
    if last and last.get("long_sha256") == lsha and last.get("weekly_sha256") == wsha:
        out["archive"] = root / last["export_id"]
        return out
    stamp = utc_stamp(now)
    eid = f"{stamp.replace(':', '')}-{hashlib.sha256((lsha + wsha).encode()).hexdigest()[:8]}"
    v = root / eid
    v.mkdir(parents=True, exist_ok=False)
    manifest = {"export_id": eid, "created_utc": stamp, "ticket": "EQ-A-0028",
                "files": {"events_long.csv": {"sha256": lsha, "rows": len(long_df), "live_path": str(LONG_PATH),
                                              "consumer": "Team B, HO-20261023-B-A-004"},
                          "events_weekly.csv": {"sha256": wsha, "rows": len(weekly_df), "live_path": str(WEEKLY_PATH),
                                                "consumer": "Team C, HO-20261023-C-A-007"}},
                "source_vintages": used, "series_map": SERIES_MAP, "problems": problems}
    files = {"events_long.csv": lb, "events_weekly.csv": wb,
             "manifest.json": json.dumps(manifest, indent=1, sort_keys=True).encode()}
    for name in sorted(files):
        (v / name).write_bytes(files[name])
        os.chmod(v / name, 0o444)
    with locked_append(root / "index.csv", EXPORT_INDEX_COLUMNS) as (w, _f, new):
        if new:
            w.writeheader()
        w.writerow({"export_id": eid, "created_utc": stamp, "long_rows": len(long_df), "long_sha256": lsha,
                    "weekly_rows": len(weekly_df), "weekly_sha256": wsha})
    out["archive"] = v
    return out


# ---------------------------------------------------------------------------------------------------------- load

def load_events_long(data_dir: Path) -> pd.DataFrame | None:
    """data/live/events/events_long.csv as a DataFrame (LONG_COLUMNS; iso/source/series/freq/provenance str, value
    float, period and vintage datetime64) or None when the file does not exist. Raises EventDataError when it lacks a
    column or has an unparsable date. For loaders.Universe.events (wired by the lead under EQ-A-0028)."""
    p = Path(data_dir) / LONG_PATH
    if not p.exists():
        return None
    t = pd.read_csv(io.BytesIO(p.read_bytes()), dtype=str, keep_default_na=False)
    missing = [c for c in LONG_COLUMNS if c not in t.columns]
    if missing:
        raise EventDataError(f"{p}: missing columns {missing}")
    t = t[LONG_COLUMNS].copy()
    t["value"] = pd.to_numeric(t["value"], errors="coerce").astype(float)
    for c in ("period", "vintage"):
        d = pd.to_datetime(t[c], format="%Y-%m-%d", errors="coerce")
        if d.isna().any():
            raise EventDataError(f"{p}: {c} not YYYY-MM-DD in {int(d.isna().sum())} row(s)")
        t[c] = d
    return t
