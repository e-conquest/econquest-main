"""GDELT FIPS 10-4 -> ISO 3166-1 alpha-3 reference table (EQ-A-0139).

GDELT 2.0 codes ActionGeo_CountryCode in FIPS 10-4, not ISO. The adapter's map (`gdelt.FIPS_TO_ISO3`) covers the
desk's 18 countries only, so every event elsewhere is dropped and counted as unmapped: the Mac pull pack recorded
unmapped_total 612,127 rows for 2026-10-17..23 (team/inbox/pull-20261024T183257Z/report.json, step 5b) and 614,172
for 2026-10-18..24 (pull-20261025T013150Z and pull-20261025T121034Z). Where it happens: gdelt.map_countries (rows
whose code is not in the map are dropped and counted per code into the staging manifest, then into the vintage
manifest's provenance.unmapped). The per-code breakdown lives only in those manifests on Sam's Mac; it is not on this
disk.

Source and derivation
---------------------
No authoritative FIPS 10-4 file is on disk (searched: the repo's data/, tests/, team/, docs/, the shipped zips and
installed packages; there is no pycountry or similar). The table is therefore derived, not typed from memory:

    resolved rows   = gdelt.FIPS_TO_ISO3, verbatim (EQ-A-0023, AGENT-06 2026-10-23: "checked by hand against FIPS
                      10-4"); its trap cases (NI Nigeria vs NG Niger, SN Singapore vs SG Senegal, ZA Zambia vs SF
                      South Africa) are pinned in tests/test_events_gdelt.py. Names come from data/countries.csv.
    unresolved rows = every ISO3 of the country universe (data/panel/universe_proposal.csv, else data/countries.csv)
                      that no resolved row produces. Their FIPS code is left blank: an ISO2 code is NOT a FIPS code
                      (NG is Nigeria in ISO but Niger in FIPS), so nothing is inferred from ISO2 or names.

A row moves from unresolved to resolved only with an authoritative list sourced on Sam's Mac (GDELT's own country
lookup or the FIPS 10-4 publication), recorded with its URL and retrieval date in `SOURCE` and the doc
(docs/runbooks/A-event-taxonomy.md section 2). Until then mapping_qa keeps reporting other codes as "outside known
map (reference table missing)": this table is deliberately not written to data/live/events/gdelt/fips_reference.csv,
because mapping_qa treats a file there as a complete reference and would count every non-desk code as unmapped.

Licence: the table is econquest's own derivation from its code; no third-party file is copied, so no licence-register
row is added (the GDELT row in data/licences.csv covers the event data itself).

    python -m econquest.ingestion.events.fips_reference [--data data] [--csv OUT] [--json]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import pandas as pd

from econquest.ingestion.events.gdelt import FIPS_TO_ISO3

REFERENCE_VERSION = "fips-iso3-ref/1 (EQ-A-0139, 2026-10-26)"
REFERENCE_COLUMNS = ["fips", "iso3", "name", "status", "source"]
SOURCE = {
    "resolved": "econquest code econquest/ingestion/events/gdelt.py FIPS_TO_ISO3 (EQ-A-0023, AGENT-06, "
                "2026-10-23, checked by hand against FIPS 10-4); copied verbatim",
    "unresolved": "country universe ISO3 without a FIPS row; no authoritative FIPS 10-4 list on disk, left blank",
    "authoritative_list": None,          # set with URL + retrieval date when one is sourced on the Mac
    "licence": "econquest derivation from its own code; no third-party file copied",
}
# Recorded GDELT unmapped totals (Mac pull pack report.json, step 5b gdelt, counts.unmapped_total)
RECORDED_UNMAPPED = (
    {"pull": "pull-20261024T183257Z", "vintage": "2026-10-24T185014Z-5a8eb4f1", "start": "2026-10-17",
     "end": "2026-10-23", "unmapped_total": 612127, "rows": 882},
    {"pull": "pull-20261025T013150Z", "vintage": "2026-10-25T014301Z-101935a0", "start": "2026-10-18",
     "end": "2026-10-24", "unmapped_total": 614172, "rows": 882},
    {"pull": "pull-20261025T121034Z", "vintage": "2026-10-25T122156Z-57287fc7", "start": "2026-10-18",
     "end": "2026-10-24", "unmapped_total": 614172, "rows": 882},
)


def resolved_map() -> dict[str, str]:
    """FIPS -> ISO3 for the resolved rows (a copy of gdelt.FIPS_TO_ISO3)."""
    return dict(sorted(FIPS_TO_ISO3.items()))


def _names(data_dir: Path) -> dict[str, str]:
    names = {}
    p = Path(data_dir) / "panel" / "universe_proposal.csv"
    if p.is_file():
        u = pd.read_csv(p, dtype=str, keep_default_na=False)
        if {"iso3", "name"} <= set(u.columns):
            names.update(zip(u["iso3"].str.strip().str.upper(), u["name"].str.strip()))
    c = Path(data_dir) / "countries.csv"
    if c.is_file():
        d = pd.read_csv(c, dtype=str, keep_default_na=False)
        names.update(zip(d["iso"].str.strip().str.upper(), d["country"].str.strip()))
    return names


def reference_table(data_dir: str | Path = "data") -> pd.DataFrame:
    """REFERENCE_COLUMNS: resolved rows (fips set) then unresolved universe countries (fips blank)."""
    from econquest.ingestion.events.mapping_qa import universe_isos
    d = Path(data_dir)
    names = _names(d)
    universe, _src = universe_isos(d)
    rows = [{"fips": f, "iso3": i, "name": names.get(i, ""), "status": "resolved", "source": SOURCE["resolved"]}
            for f, i in resolved_map().items()]
    have = set(FIPS_TO_ISO3.values())
    rows += [{"fips": "", "iso3": i, "name": names.get(i, ""), "status": "unresolved", "source": SOURCE["unresolved"]}
             for i in sorted(universe - have)]
    return pd.DataFrame(rows, columns=REFERENCE_COLUMNS)


def summary(data_dir: str | Path = "data") -> dict:
    from econquest.ingestion.events.mapping_qa import universe_isos
    t = reference_table(data_dir)
    universe, src = universe_isos(Path(data_dir))
    res, unres = t[t["status"] == "resolved"], t[t["status"] == "unresolved"]
    return {"version": REFERENCE_VERSION, "universe": src, "universe_size": len(universe),
            "fips_codes_resolved": len(res), "universe_isos_resolved": int(res["iso3"].isin(universe).sum()),
            "universe_isos_unresolved": unres["iso3"].tolist(), "source": SOURCE,
            "recorded_unmapped": list(RECORDED_UNMAPPED),
            "note": "the per-code breakdown of the recorded unmapped rows is in the vintage manifests on Sam's Mac "
                    "(provenance.unmapped); it is not on this disk, so no code behind them is resolved here"}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.events.fips_reference",
                                 description="GDELT FIPS 10-4 -> ISO3 reference table (EQ-A-0139)")
    ap.add_argument("--data", default="data")
    ap.add_argument("--csv", default=None, help="write the table here (CSV)")
    ap.add_argument("--json", action="store_true", help="print the summary as JSON")
    a = ap.parse_args(argv)
    t = reference_table(a.data)
    if a.csv:
        Path(a.csv).write_text(t.to_csv(index=False, lineterminator="\n"))
    s = summary(a.data)
    if a.json:
        print(json.dumps(s, indent=1))
    else:
        print(f"{REFERENCE_VERSION}: {s['fips_codes_resolved']} FIPS codes resolved; universe {s['universe_size']} "
              f"({s['universe']}): {s['universe_isos_resolved']} resolved, {len(s['universe_isos_unresolved'])} "
              f"unresolved: {', '.join(s['universe_isos_unresolved'])}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
