"""Standalone verifier for an econquest validator data room (EQ-A-0041). Standard library only.

This file is copied into every data room as `verify.py`, so a validator can check the room without econquest:

    python -I verify.py                 # verify the folder this script is in
    python -I verify.py /path/to/room   # or another room
    python -I verify.py --json          # machine-readable report

It checks, in order:
1. MANIFEST.json: every listed path is a plain relative path inside the room; every listed file is present with
   the recorded size and sha256 (missing / changed); no file is present that the manifest does not list (extra).
2. The top hash: `manifest_sha256` equals SHA-256 over the canonical JSON of the manifest without the keys
   `manifest_sha256` and `build` (build time and machine details are deliberately outside the hash), and
   `content_sha256` equals SHA-256 over "<path>=<sha256>;" for every listed file in path order.
3. Integrity anchors inside the room (the same checks econquest runs on its own stores):
   live and panel vintages against their index.csv content hash, market snapshots, event vintages and event
   export archives against their manifest.json and index.csv, frozen replay snapshots against their manifest and
   snapshots/index.csv, and the change-approval log's hash chain. A folder with no anchor row is reported as
   `unanchored` (a warning: legacy folders made before the index existed), a mismatch as `failed`.
   A live vintage must have every index.csv row for its id agree (index.csv is append-only; SEC-A-004 L1).
4. Altered files (EQ-A-0044). A file the build withheld (a licence that bars passing it on, e.g. raw_yahoo.csv) or
   whose e-mail addresses it replaced by `[redacted-email]` is listed in the hashed manifest under `withheld` or
   `redactions` with its original sha256 and size. Anchors that compare a sha256 (market and event manifests and
   index rows, replay manifests) use that original sha256. A live or panel vintage content hash covers the original
   bytes and cannot be recomputed from the room, so such a folder is reported as `altered` (a warning) when the
   room's index.csv row matches the hash and file count the build verified on the source (manifest
   `altered_anchors`), and as `failed` otherwise. An altered approvals log is reported the same way.

5. Hostile rooms (SEC-A-006 L2/L3). A symlink anywhere in the room, or a listed path with a symlinked parent, is
   reported as `unsafe` and never followed (the build never writes one); withheld and redacted paths must be plain
   relative paths too. MANIFEST.json larger than MAX_MANIFEST_BYTES is refused; a malformed or too deeply nested
   manifest, or a malformed manifest.json inside the room, gives a FAILED report, never a traceback. Every file is
   hashed in chunks.

6. Labelled rooms and the MVP dataset (EQ-A-0125). A room built with a licence baseline label carries it in the hashed
   manifest (`licence_baseline`; only DEMO exists, never the owner's approval) and every report prints it. A room
   holding the frozen MVP dataset (`data/mvp`, hashed `mvp` record) is checked against data/mvp/manifest.json: every
   listed file, no unlisted one, dataset_sha256 recomputed, and the record's dataset_sha256 and build-time "ok".

Exit status 0 when the room verifies (no missing, extra or changed file, both hashes match, no failed anchor),
1 otherwise. `verify_room(path)` returns the same report as a dict; econquest.ingestion.dataroom.verify_data_room
calls it, so the library and the copy in the room run exactly the same code."""
from __future__ import annotations

import csv
import hashlib
import json
import os
import sys
from pathlib import Path, PurePosixPath

MANIFEST_NAME = "MANIFEST.json"
SCHEMA = "econquest.dataroom/1"
UNHASHED_KEYS = ("manifest_sha256", "build")
GENESIS = "0" * 64
MAX_MANIFEST_BYTES = 64 * 1024 * 1024        # SEC-A-006 L3: a real MANIFEST.json is well under 1 MB
MAX_JSON_BYTES = 64 * 1024 * 1024            # the same cap for manifest.json files inside the room
MALFORMED = (RecursionError, TypeError, AttributeError, KeyError, ValueError, UnicodeDecodeError)


def _plain_file(p: Path) -> bool:
    """A regular file that is not a symlink (verify.py never follows a link, SEC-A-006 L2)."""
    return not p.is_symlink() and p.is_file()


def _plain_dir(p: Path) -> bool:
    return not p.is_symlink() and p.is_dir()


def _read_json(path: Path, cap: int = MAX_JSON_BYTES):
    """json.loads of a plain file no larger than `cap`; ValueError for a symlink, an oversized file, bad JSON or one
    nested too deeply (RecursionError)."""
    if not _plain_file(path):
        raise ValueError(f"{path.name} is not a plain file")
    size = path.stat().st_size
    if size > cap:
        raise ValueError(f"{path.name} is {size} bytes, over the {cap}-byte cap")
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except RecursionError:
        raise ValueError(f"{path.name} is nested too deeply") from None


def sha256_file(path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def canonical_json(obj) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("ascii")


def manifest_hash(manifest: dict) -> str:
    """SHA-256 over the canonical JSON of the manifest without manifest_sha256 and build."""
    return hashlib.sha256(canonical_json({k: v for k, v in manifest.items() if k not in UNHASHED_KEYS})).hexdigest()


def content_hash(files: list) -> str:
    """SHA-256 over '<path>=<sha256>;' for every file entry, in path order: a content address of the room's files."""
    h = hashlib.sha256()
    for e in sorted(files, key=lambda e: e["path"]):
        h.update(f"{e['path']}={e['sha256']};".encode())
    return h.hexdigest()


def safe_rel(rel) -> bool:
    """A manifest path must be a plain relative POSIX path that stays inside the room."""
    if not isinstance(rel, str) or not rel or "\\" in rel or "\0" in rel:
        return False
    p = PurePosixPath(rel)
    return not p.is_absolute() and all(part not in ("", ".", "..") for part in p.parts) and rel == p.as_posix()


def _rows(path: Path) -> list[dict]:
    if path.is_symlink():
        raise ValueError(f"{path.name} is a symlink (not followed)")
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def _last_row(rows: list[dict], col: str, value: str) -> dict | None:
    hit = [r for r in rows if r.get(col) == value]
    return hit[-1] if hit else None


def _vintage_row(rows: list[dict], vid: str) -> tuple[dict | None, bool]:
    """(first index row of a live vintage, True when every row for the id carries the same hash and file count).
    index.csv is append-only, so the first row is the one written at save time (SEC-A-004 L1)."""
    hit = [r for r in rows if r.get("vintage_id") == vid]
    if not hit:
        return None, True
    return hit[0], len({(r.get("hash"), str(r.get("n_files"))) for r in hit}) == 1


def chain_problem(text: str) -> tuple[str, int]:
    """('' or the first problem, rows) for a change-approval log: every row's prev_hash and row_hash from genesis."""
    prev, n = GENESIS, 0
    for line in text.splitlines():
        if not line.strip():
            continue
        n += 1
        try:
            row = json.loads(line)
        except (ValueError, RecursionError):
            return f"line {n} is not JSON", n
        if not isinstance(row, dict):
            return f"line {n} is not a JSON object", n
        body = json.dumps({k: v for k, v in row.items() if k != "row_hash"}, sort_keys=True, separators=(",", ":"),
                          ensure_ascii=False)
        if row.get("prev_hash") != prev or hashlib.sha256((prev + body).encode("utf-8")).hexdigest() != row.get("row_hash"):
            return f"hash chain broken at row {n} (seq {row.get('seq')})", n
        prev = row["row_hash"]
    return "", n


def _entries(value) -> list:
    return value if isinstance(value, list) else []


def altered_map(manifest: dict) -> dict:
    """Room path -> {"action": "withheld" | "redacted", "original_sha256", "original_size", ...} from the manifest.
    Only entries whose path is a plain relative path (safe_rel) count; verify_room reports the others as unsafe."""
    out = {}
    for e in _entries(manifest.get("withheld")):
        if isinstance(e, dict) and safe_rel(e.get("path")):
            out[e["path"]] = {"action": "withheld", "original_sha256": e.get("sha256"), "original_size": e.get("size"),
                              "reason": e.get("reason", "")}
    for e in _entries(manifest.get("redactions")):
        if isinstance(e, dict) and safe_rel(e.get("path")):
            out[e["path"]] = {"action": "redacted", "original_sha256": e.get("original_sha256"),
                              "original_size": e.get("original_size"), "replacements": e.get("replacements"),
                              "restricted_cells": e.get("restricted_cells")}
    return out


def folder_content_hash(folder: Path) -> tuple[str, int]:
    """Live and panel vintage content hash: SHA-256 over (name, NUL, bytes, NUL) of the folder's files in name order.
    Symlinks are not followed and not counted (SEC-A-006 L2); files are hashed in chunks (L3)."""
    h = hashlib.sha256()
    names = sorted(p.name for p in folder.iterdir() if _plain_file(p))
    for name in names:
        h.update(name.encode() + b"\0")
        with open(folder / name, "rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                h.update(chunk)
        h.update(b"\0")
    return h.hexdigest(), len(names)


def _manifest_files_ok(folder: Path, sha_of=None) -> list[str]:
    """Problems with a folder's own manifest.json 'files' (name -> sha256 or {sha256}) and top-level sha256.
    sha_of(path) gives a file's sha256 as the anchor saw it (the original for an altered file) or None if absent."""
    sha_of = sha_of or (lambda p: sha256_file(p) if _plain_file(p) else None)
    mp = folder / "manifest.json"
    if not mp.is_file() and not mp.is_symlink():
        return []
    try:
        m = _read_json(mp)
    except (OSError, ValueError) as e:
        return [f"unreadable manifest.json: {e}"]
    if not isinstance(m, dict):
        return ["malformed manifest.json: not a JSON object"]
    out = []
    files = m.get("files")
    if isinstance(files, dict):
        for name, v in sorted(files.items()):
            sha = v.get("sha256") if isinstance(v, dict) else v
            if not isinstance(sha, str) or not safe_rel(name):
                continue
            got = sha_of(folder / name)
            if got is None:
                out.append(f"manifest.json lists {name}, not present")
            elif got != sha:
                out.append(f"{name} does not match manifest.json sha256")
    for body in ("quotes.csv", "events.csv"):
        got = sha_of(folder / body)
        if isinstance(m.get("sha256"), str) and got is not None and got != m["sha256"]:
            out.append(f"{body} does not match manifest.json sha256")
    return out


def _check(kind: str, folder: Path, root: Path, status: str, detail: str = "") -> dict:
    return {"kind": kind, "path": folder.relative_to(root).as_posix(), "status": status, "detail": detail}


def _anchor_checks(root: Path, altered: dict | None = None, altered_anchors: dict | None = None,
                   mvp_rec: dict | None = None) -> list[dict]:
    """Integrity anchors of the room. `altered` (altered_map of the manifest) and `altered_anchors` (manifest
    `altered_anchors`: what the build verified on the source for a folder or file it altered) cover withheld and
    redacted files (EQ-A-0044). `mvp_rec` is the manifest's `mvp` record (EQ-A-0125)."""
    out = []
    data = root / "data"
    altered = altered or {}
    altered_anchors = altered_anchors or {}

    def rel(p: Path) -> str:
        return p.relative_to(root).as_posix()

    def sha_of(p: Path):
        a = altered.get(rel(p))
        if a is not None:
            return a.get("original_sha256")
        return sha256_file(p) if _plain_file(p) else None

    def index_of(parent: Path) -> list[dict]:
        return _rows(parent / "index.csv") if _plain_file(parent / "index.csv") else []

    def folders(parent: Path):
        return sorted(p for p in parent.iterdir() if _plain_dir(p)) if _plain_dir(parent) else []

    def anchor_rec(key: str) -> dict:
        rec = altered_anchors.get(key)
        return rec if isinstance(rec, dict) else {}

    for kind, parent in (("live_vintage", data / "live" / "vintages"), ("panel_vintage", data / "panel" / "vintages")):
        rows = index_of(parent)
        for f in folders(parent):
            digest, n = folder_content_hash(f)
            if kind == "live_vintage":
                row, agree = _vintage_row(rows, f.name)
            else:
                row, agree = _last_row(rows, "vintage_id", f.name), True
            prefix = rel(f) + "/"
            changed = sorted(k[len(prefix):] + f" ({a['action']})" for k, a in altered.items()
                             if k.startswith(prefix) and "/" not in k[len(prefix):])
            if row is None:
                out.append(_check(kind, f, root, "unanchored", "no row in index.csv"
                                  + (f"; altered in the room: {', '.join(changed)}" if changed else "")))
            elif not agree:
                out.append(_check(kind, f, root, "failed", "index.csv rows for this id disagree on hash or file count"))
            elif changed:
                n_withheld = sum(1 for c in changed if c.endswith("(withheld)"))
                rec = anchor_rec(rel(f))
                probs = []
                if str(row.get("n_files")) != str(n + n_withheld):
                    probs.append(f"{n} files present + {n_withheld} withheld != index.csv {row.get('n_files')}")
                if rec.get("index_hash") != row.get("hash"):
                    probs.append("index.csv hash differs from the hash the build verified")
                if rec.get("verified_at_build") != "ok":
                    probs.append(f"build-time verification: {rec.get('verified_at_build') or 'not recorded'}")
                out.append(_check(kind, f, root, "failed" if probs else "altered", "; ".join(probs) or (
                    f"content hash not recomputable in the room ({', '.join(changed)}); the build verified the source "
                    f"folder against index.csv hash {str(row.get('hash'))[:12]}; originals' sha256 in MANIFEST.json")))
            elif row.get("hash") != digest or str(row.get("n_files")) != str(n):
                out.append(_check(kind, f, root, "failed", f"content hash {digest[:12]} / {n} files != index.csv"))
            else:
                out.append(_check(kind, f, root, "ok", f"content hash {digest[:12]} matches index.csv"))
    parent = data / "live" / "market" / "snapshots"
    rows = index_of(parent)
    for f in folders(parent):
        probs = _manifest_files_ok(f, sha_of)
        row = _last_row(rows, "snapshot_id", f.name)
        q = f / "quotes.csv"
        if sha_of(q) is not None and row is not None and row.get("sha256") != sha_of(q):
            probs.append("quotes.csv does not match index.csv sha256")
        out.append(_check("market_snapshot", f, root, "failed" if probs else ("unanchored" if row is None else "ok"),
                          "; ".join(probs) or ("no row in index.csv" if row is None else "manifest and index.csv match")))
    ev_root = data / "live" / "events"
    for parent in sorted(p for p in ev_root.glob("*/vintages") if _plain_dir(p) and _plain_dir(p.parent)) \
            if _plain_dir(ev_root) else []:
        rows = index_of(parent)
        for f in folders(parent):
            probs = _manifest_files_ok(f, sha_of)
            row = _last_row(rows, "vintage_id", f.name)
            ev = f / "events.csv"
            if sha_of(ev) is not None and row is not None and row.get("sha256") != sha_of(ev):
                probs.append("events.csv does not match index.csv sha256")
            out.append(_check("event_vintage", f, root, "failed" if probs else ("unanchored" if row is None else "ok"),
                              "; ".join(probs) or ("no row in index.csv" if row is None else "manifest and index.csv match")))
    parent = data / "live" / "events" / "exports"
    rows = index_of(parent)
    for f in folders(parent):
        probs = _manifest_files_ok(f, sha_of)
        row = _last_row(rows, "export_id", f.name)
        if row is not None:
            for name, col in (("events_long.csv", "long_sha256"), ("events_weekly.csv", "weekly_sha256")):
                if sha_of(f / name) is not None and row.get(col) != sha_of(f / name):
                    probs.append(f"{name} does not match index.csv {col}")
        out.append(_check("event_export", f, root, "failed" if probs else ("unanchored" if row is None else "ok"),
                          "; ".join(probs) or ("no row in index.csv" if row is None else "manifest and index.csv match")))
    parent = data / "live" / "snapshots"
    rows = index_of(parent)
    for f in folders(parent):
        if "-pre-apply" in f.name:
            out.append(_check("pre_apply_snapshot", f, root, "unanchored", "pre-apply backups have no index row"))
            continue
        probs = []
        try:
            m = _read_json(f / "manifest.json")
        except (OSError, ValueError) as e:
            out.append(_check("replay_snapshot", f, root, "failed", f"unreadable manifest.json: {e}"))
            continue
        files = m.get("files") if isinstance(m, dict) else None
        if not isinstance(files, dict) or not all(isinstance(k, str) and isinstance(v, str) for k, v in files.items()):
            out.append(_check("replay_snapshot", f, root, "failed",
                              "malformed manifest.json: 'files' must map file names to sha256 strings"))
            continue
        for name, sha in sorted(files.items()):
            got = sha_of(f / name) if safe_rel(name) else None
            if got is None:
                probs.append(f"missing {name}")
            elif got != sha:
                probs.append(f"hash mismatch {name}")
        h = hashlib.sha256()
        for name in sorted(files):
            h.update(f"{name}={files[name]};".encode())
        if h.hexdigest() != m.get("inputs_hash"):
            probs.append("inputs_hash does not match the manifest file list")
        row = _last_row(rows, "snapshot", f.name)
        if row is not None and row.get("inputs_hash") != m.get("inputs_hash"):
            probs.append("inputs_hash differs from snapshots/index.csv")
        out.append(_check("replay_snapshot", f, root, "failed" if probs else ("unanchored" if row is None else "ok"),
                          "; ".join(probs) or ("no row in index.csv" if row is None else "manifest and index.csv match")))
    log = data / "approvals" / "log.jsonl"
    if _plain_file(log):
        a = altered.get(rel(log))
        if a is not None:                      # redacted: the chain covers the original bytes, verified at build
            built = anchor_rec(rel(log)).get("verified_at_build")
            status, detail = ("altered", f"{a['action']} in the room; the build verified the original chain: {built}") \
                if built == "ok" else ("failed", f"{a['action']} in the room; build-time chain check: {built or 'not recorded'}")
        else:
            problem, n = chain_problem(log.read_text(encoding="utf-8"))
            status, detail = ("failed", problem) if problem else ("ok", f"{n} rows chain from genesis")
        out.append({"kind": "approvals_chain", "path": rel(log), "status": status, "detail": detail})
    mvp = data / "mvp"
    if isinstance(mvp_rec, dict):              # a room built with include_mvp (an include_current copy has no record)
        out.append(_mvp_check(root, mvp, sha_of, altered, mvp_rec))
    return out


def _mvp_check(root: Path, mvp: Path, sha_of, altered: dict, rec) -> dict:
    """EQ-A-0125: the frozen MVP dataset (data/mvp): every file its manifest.json lists matches (the original sha256
    for a withheld or redacted file), no unlisted file, dataset_sha256 recomputed from the list (SHA-256 over
    "<path>\\0<sha256>\\n" in path order, as mvp_dataset builds it), and the same dataset_sha256 and a build-time "ok"
    in the room manifest's hashed `mvp` record."""
    def chk(status, detail):
        return {"kind": "mvp_dataset", "path": "data/mvp", "status": status, "detail": detail}
    rec = rec if isinstance(rec, dict) else {}
    try:
        m = _read_json(mvp / "manifest.json")
    except (OSError, ValueError) as e:
        return chk("failed", f"unreadable manifest.json: {e}")
    files = m.get("files") if isinstance(m, dict) else None
    if not isinstance(files, dict) or not all(isinstance(k, str) and isinstance(v, str) for k, v in files.items()):
        return chk("failed", "malformed manifest.json: 'files' must map paths to sha256 strings")
    probs = []
    for name, sha in sorted(files.items()):
        got = sha_of(mvp / name) if safe_rel(name) else None
        if got is None:
            probs.append(f"missing {name}")
        elif got != sha:
            probs.append(f"hash mismatch {name}")
    prefix = "data/mvp/"
    listed = {prefix + k for k in files} | {prefix + "manifest.json"}
    in_room = {p for p in _present(root) if p.startswith(prefix)} | {k for k in altered if k.startswith(prefix)}
    probs += [f"not in manifest.json: {p[len(prefix):]}" for p in sorted(in_room - listed)]
    digest = hashlib.sha256("".join(f"{k}\0{v}\n" for k, v in files.items()).encode()).hexdigest()
    if digest != m.get("dataset_sha256"):
        probs.append("dataset_sha256 does not match the manifest file list")
    if rec.get("dataset_sha256") != m.get("dataset_sha256"):
        probs.append("dataset_sha256 differs from the room manifest's mvp record")
    if rec.get("verified_at_build") != "ok":
        probs.append(f"build-time verification: {rec.get('verified_at_build') or 'not recorded'}")
    if probs:
        return chk("failed", "; ".join(probs[:10]))
    n_alt = sum(1 for k in altered if k.startswith(prefix))
    return chk("altered" if n_alt else "ok",
               f"dataset_sha256 {digest[:16]} recomputed; {len(files)} files match manifest.json"
               + (f" ({n_alt} withheld or redacted in the room, checked by their original sha256)" if n_alt else ""))


def _symlinks(root: Path) -> list[str]:
    """Every symlink in the room (files and folders), never followed (SEC-A-006 L2)."""
    out = []
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        for name in dirnames + filenames:
            p = Path(dirpath) / name
            if p.is_symlink():
                out.append(p.relative_to(root).as_posix())
    return sorted(out)


def _present(root: Path) -> set:
    out = set()
    for dirpath, _dirnames, filenames in os.walk(root, followlinks=False):
        for name in filenames:
            out.add((Path(dirpath) / name).relative_to(root).as_posix())
    return out


def _linked_parent(root: Path, rel: str) -> bool:
    """True when `rel` or any folder on its way from the room root is a symlink (os.lstat on each part)."""
    p = root
    for part in PurePosixPath(rel).parts:
        p = p / part
        if p.is_symlink():
            return True
    return False


def verify_room(path, expect_manifest_sha256: str | None = None) -> dict:
    """Verify a data room folder. Returns {ok, manifest_sha256, recomputed_manifest_sha256, manifest_hash_ok,
    content_sha256_ok, files, missing, extra, changed, unsafe, withheld, redacted, anchors, anchor_failures,
    anchor_warnings, warnings}. Never raises on a malformed or hostile room: the problem is reported (SEC-A-006 L3).

    expect_manifest_sha256 (SEC-A-014 P3-L1, EQ-A-0125): the manifest_sha256 received separately from the exporter.
    When given, the room passes only if the recomputed hash equals it, so a room fully re-hashed after an edit (for
    example with its DEMO label stripped) fails. A value that is not 64 hex characters fails too."""
    root = Path(path)
    rep = {"room": str(root), "ok": False, "files": 0, "missing": [], "extra": [], "changed": [], "unsafe": [],
           "withheld": [], "redacted": [],
           "manifest_sha256": None, "recomputed_manifest_sha256": None, "manifest_hash_ok": False,
           "content_sha256_ok": False, "anchors": [], "anchor_failures": 0, "anchor_warnings": 0, "warnings": [],
           "error": ""}
    exp = None
    if expect_manifest_sha256 is not None:
        exp = str(expect_manifest_sha256).strip().lower()
        rep["expected_manifest_sha256"] = exp
        rep["expected_manifest_ok"] = False
        if len(exp) != 64 or any(c not in "0123456789abcdef" for c in exp):
            rep["error"] = "--expect-manifest-sha256 must be 64 hex characters (the manifest_sha256 sent to you)"
            return rep
    try:
        m = _read_json(root / MANIFEST_NAME, MAX_MANIFEST_BYTES)
        if not isinstance(m, dict) or not isinstance(m.get("files"), list):
            raise ValueError("no 'files' list")
    except (OSError, ValueError) as e:
        rep["error"] = f"cannot read {MANIFEST_NAME}: {e}"
        return rep
    try:
        _verify(root, m, rep)
    except (OSError, csv.Error, *MALFORMED) as e:     # malformed manifest content: a FAILED report, not a traceback
        rep["error"] = f"malformed {MANIFEST_NAME} or room: {type(e).__name__}: {str(e)[:200]}"
        rep["ok"] = False
    if exp is not None:
        rep["expected_manifest_ok"] = exp == rep["recomputed_manifest_sha256"] == rep["manifest_sha256"]
        rep["ok"] = rep["ok"] and rep["expected_manifest_ok"]
    base = rep.get("licence_baseline")              # a labelled room's folder name should say so (warning only)
    if isinstance(base, dict) and base.get("label"):
        name = root.resolve().name
        if not name.endswith(f"-{base['label']}"):
            rep["warnings"].append(f"the room is labelled {base['label']} but its folder name {name!r} does not end "
                                   f"in -{base['label']}")
    return rep


def _verify(root: Path, m: dict, rep: dict) -> None:
    files = []
    for e in m["files"]:
        if (isinstance(e, dict) and isinstance(e.get("path"), str) and isinstance(e.get("sha256"), str)
                and isinstance(e.get("size"), int) and not isinstance(e.get("size"), bool)):
            files.append(e)
        else:
            rep["unsafe"].append(f"malformed file entry: {str(e)[:80]}")
    rep["files"] = len(files)
    listed = set()
    for link in _symlinks(root):                # the build never writes a symlink: any link is tampering
        rep["unsafe"].append(f"{link} (symlink, not followed)")
    for e in sorted(files, key=lambda e: e["path"]):
        rel = e["path"]
        if not safe_rel(rel) or rel == MANIFEST_NAME:
            rep["unsafe"].append(rel)
            continue
        listed.add(rel)
        p = root / rel
        if _linked_parent(root, rel):
            continue                            # reported above; never read through a link
        if not p.is_file():
            rep["missing"].append(rel)
            continue
        why = []
        if p.stat().st_size != e["size"]:
            why.append("size")
        if sha256_file(p) != e["sha256"]:
            why.append("sha256")
        if why:
            rep["changed"].append({"path": rel, "differs": why})
    rep["extra"] = sorted(_present(root) - listed - {MANIFEST_NAME})
    rep["manifest_sha256"] = m.get("manifest_sha256")
    rep["recomputed_manifest_sha256"] = manifest_hash(m)
    rep["manifest_hash_ok"] = rep["manifest_sha256"] == rep["recomputed_manifest_sha256"]
    try:
        rep["content_sha256_ok"] = m.get("content_sha256") == content_hash(files)
    except (KeyError, TypeError):
        rep["content_sha256_ok"] = False
    for key in ("withheld", "redactions"):      # SEC-A-006 L3: these paths must be plain relative paths too
        val = m.get(key)
        if val is not None and not isinstance(val, list):
            rep["unsafe"].append(f"{key}: not a list")
        for e in _entries(val):
            if not isinstance(e, dict) or not safe_rel(e.get("path")):
                rep["unsafe"].append(f"{key} entry {str(e.get('path') if isinstance(e, dict) else e)[:80]} (not a plain "
                                     "relative path)")
    altered = altered_map(m)
    rep["withheld"] = sorted(k for k, a in altered.items() if a["action"] == "withheld")
    rep["redacted"] = sorted(k for k, a in altered.items() if a["action"] == "redacted")
    for k in rep["withheld"]:                  # a withheld file must not be in the room, or listed as a file
        if k in listed or (root / k).exists() or (root / k).is_symlink():
            rep["unsafe"].append(f"{k} (listed as withheld but present)")
    try:
        anchors = m.get("altered_anchors") if isinstance(m.get("altered_anchors"), dict) else {}
        rep["anchors"] = _anchor_checks(root, altered, anchors, m.get("mvp"))
    except (OSError, csv.Error, *MALFORMED) as e:
        rep["anchors"] = [{"kind": "anchors", "path": "", "status": "failed",
                           "detail": f"anchor checks stopped: {type(e).__name__}: {str(e)[:200]}"}]
    rep["anchor_failures"] = sum(a["status"] == "failed" for a in rep["anchors"])
    rep["anchor_warnings"] = sum(a["status"] in ("unanchored", "altered") for a in rep["anchors"])
    rep["ok"] = (not rep["missing"] and not rep["extra"] and not rep["changed"] and not rep["unsafe"]
                 and rep["manifest_hash_ok"] and rep["content_sha256_ok"] and rep["anchor_failures"] == 0)
    base = m.get("licence_baseline")                # EQ-A-0125: a labelled room says so in every report
    if isinstance(base, dict):
        rep["licence_baseline"] = {k: base.get(k) for k in ("label", "banner", "register_sha256", "register_rows")}


def format_report(rep: dict) -> str:
    lines = [f"data room: {rep['room']}"]
    base = rep.get("licence_baseline")
    if isinstance(base, dict):
        lines.append(f"licence baseline: {base.get('label')} ({base.get('banner')}; register sha256 "
                     f"{str(base.get('register_sha256'))[:16]}, {base.get('register_rows')} rows)")
    if rep.get("error"):
        return "\n".join(lines + [f"FAILED: {rep['error']}", "RESULT: FAILED"])
    lines.append(f"files listed: {rep['files']}; missing {len(rep['missing'])}, extra {len(rep['extra'])}, "
                 f"changed {len(rep['changed'])}, unsafe paths {len(rep['unsafe'])}")
    for k in ("missing", "extra", "unsafe"):
        lines += [f"  {k}: {p}" for p in rep[k]]
    lines += [f"  changed: {c['path']} ({', '.join(c['differs'])})" for c in rep["changed"]]
    lines.append(f"manifest_sha256: {'ok' if rep['manifest_hash_ok'] else 'MISMATCH'} "
                 f"(stated {rep['manifest_sha256']}, recomputed {rep['recomputed_manifest_sha256']})")
    lines.append(f"content_sha256: {'ok' if rep['content_sha256_ok'] else 'MISMATCH'}")
    if "expected_manifest_sha256" in rep:
        lines.append(f"expected manifest_sha256: {'ok' if rep.get('expected_manifest_ok') else 'MISMATCH'} "
                     f"(expected {rep['expected_manifest_sha256']}, recomputed {rep['recomputed_manifest_sha256']})")
    else:
        lines.append("expected manifest_sha256: not given (compare manifest_sha256 with the value sent to you, or "
                     "rerun with --expect-manifest-sha256 HEX)")
    lines += [f"warning: {w}" for w in rep.get("warnings", [])]
    if rep.get("withheld") or rep.get("redacted"):
        lines.append(f"altered by the build (listed in MANIFEST.json with original sha256): {len(rep.get('withheld', []))} "
                     f"withheld, {len(rep.get('redacted', []))} redacted (e-mail addresses, or values from a restricted source "
                 "blanked)")
    lines.append(f"integrity anchors: {len(rep['anchors'])} checked, {rep['anchor_failures']} failed, "
                 f"{rep['anchor_warnings']} unanchored or altered")
    lines += [f"  {a['status']}: {a['kind']} {a['path']} - {a['detail']}" for a in rep["anchors"] if a["status"] != "ok"]
    lines.append("RESULT: " + ("VERIFIED" if rep["ok"] else "FAILED"))
    return "\n".join(lines)


def main(argv=None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    usage = "usage: python -I verify.py [ROOM_DIR] [--json] [--expect-manifest-sha256 HEX]"
    as_json = "--json" in args
    args = [a for a in args if a != "--json"]
    expect = None                                  # SEC-A-014 P3-L1: the manifest_sha256 sent separately
    rest = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--expect-manifest-sha256":
            if i + 1 >= len(args):
                print(usage)
                return 2
            expect, i = args[i + 1], i + 2
            continue
        if a.startswith("--expect-manifest-sha256="):
            expect = a.split("=", 1)[1]
        else:
            rest.append(a)
        i += 1
    args = rest
    if any(a in ("-h", "--help") for a in args) or len(args) > 1:
        print(usage)
        return 0 if args and args[0] in ("-h", "--help") else 2
    room = Path(args[0]) if args else Path(__file__).resolve().parent
    rep = verify_room(room, expect)
    print(json.dumps(rep, indent=1, sort_keys=True) if as_json else format_report(rep))
    return 0 if rep["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
