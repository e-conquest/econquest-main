"""Coverage to 60%, part 3 (EQ-A-0062): the gap matrix of feed-eligible cells for the desk countries.

Target (Sam 2026-10-24 12:41Z, EQ-A-0055): 60% of the feed-eligible cells per country, i.e. 30 of the 50 indicators
that universe.feed_eligible_ids returns. This module lists, for every desk country (data_dir/countries.csv) and every
feed-eligible id, the state of the cell after parts 1 (EQ-A-0049) and 2 (EQ-A-0050) and part 3's WDI fallbacks
(official/wdi_extra.py), and the expected share once every built adapter is verified.

States (one per cell; the first that applies):
    live                  finite in live/live_inputs.csv and not held (universe.missing_cell_report)
    adapter_unverified    an adapter is built AND configured with series codes; it will serve the cell once the codes
                          are confirmed on a live pull (and, where noted, Team B approves the method)
    adapter_unconfigured  a transform is built but its series codes are unknown (IMF SDMX specs with filters=None,
                          OECD / Eurostat specs): needs the Mac structure check before it can serve anything
    held_research         the rule exists and the research feed builds the cell, but every value is held for review
                          until Sam's sign-off at first values (6.10: indicator-rules 3 and 13.4; EQ-A-0096, was
                          blocked_team_b)
    feed_no_value         a verified feed serves this id for other countries; the source has nothing for this one
    not_applicable        the concept does not exist for this country (Singapore has no policy interest rate)
    no_adapter            no adapter, with the documented reason (no free source, file only, licence, token, ...)
The brief's three states map as: live; built-but-unverified = adapter_unverified (+ adapter_unconfigured, which is
built but cannot serve yet); no adapter = the rest.

expected = live + adapter_unverified (what the built, configured adapters give once verified); upper = expected +
adapter_unconfigured + held_research. Every count is from this folder's latest pull plus the adapters' own
registries (imf.IMF_SPECS, worldbank.WB_EXTRA_IDS, wdi_extra.WDI_EXTRA_IDS, central_banks.CB_REGISTRY); which
countries a not-yet-pulled series covers is UNVERIFIED and assumed, as stated in each row's reason.

Projection and ranking (EQ-A-0078, `rank`): three cases per desk country on top of the gap matrix, each a rule on the
cell's state (project()), and the residual gaps of one case ranked by model weight x countries missing (rank()). A
cell counts live in a case only when a named source serves it under that case's stated assumption (CASE_ASSUMPTIONS);
docs/runbooks/A-coverage-60.md has the numbers and the plan.

Command line:
    python -m econquest.ingestion.coverage_gaps build [--data D] [--out CSV] [--summary CSV]
    python -m econquest.ingestion.coverage_gaps rank [--data D] [--case a|b|c] [--report report.json]
                                                     [--projection CSV] [--out CSV] [--top N]
"""
from __future__ import annotations

import argparse
import json
import re
from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd

from . import universe as U
from .feeds import WB_SOURCE_SERIES, WEO_SOURCE_SERIES
from .official.central_banks import CB_REGISTRY, CONCEPT_CELLS
from .official.imf import IMF_COMPONENTS, IMF_NOT_SERVED, IMF_SPECS
from .official.oecd import OECD_SPECS
from .official.wdi_extra import METHOD_APPROVED, WDI_EXTRA_COMPONENTS, WDI_EXTRA_IDS
from .official.worldbank import WB_EXTRA_IDS, WB_NOT_SERVED

DEFAULT_DATA = U.DEFAULT_DATA
DEFAULT_OUT = DEFAULT_DATA / "panel" / "coverage_gaps_part3.csv"
COLUMNS = ["iso3", "id", "state", "candidate_source", "reason", "action"]
STATES = ("live", "adapter_unverified", "adapter_unconfigured", "held_research", "feed_no_value", "not_applicable",
          "no_adapter")
EXPECTED_STATES = ("live", "adapter_unverified")
UPPER_STATES = EXPECTED_STATES + ("adapter_unconfigured", "held_research")
# OECD and EU members of the 88-country universe, as listed in docs/runbooks/A-coverage-plan.md section 4 (1.5 only)
OECD_MEMBERS = frozenset("USA DEU GBR FRA ITA CAN AUS JPN KOR MEX CHL COL CRI TUR POL HUN ISR".split())
EU_MEMBERS = frozenset("DEU FRA ITA POL HUN ROU".split())
IDS_DEPENDENT = {"2.9", "2.2"}           # IDS-based: low- and middle-income economies that report to the DRS
IDS_PROBE = "2.10"                       # IDS series that is live today: evidence the country is in IDS
BIS_IDS = {"2.12", "5.9", "5.13"}
MAC_CHECK = "confirm the codes on a live pull on Sam's Mac (A-fetch-on-mac.md), then set verified=yes in coverage_source_map.csv"

# Documented reasons for ids with no adapter (section 10 of docs/runbooks/A-coverage-plan.md). (reason, action)
_RESEARCH = "research dataset (free, not official): needs Sam's decision on research sources and their licences"
DOCUMENTED = {
    "1.1": ("rulebook source is the IMF Article IV DSA tables (manual); econquest dsa (Team B) writes a proxy to "
            "outputs/dsa_scorecard_feeds.csv with an analyst average-maturity input (derived_from mixed), and domestic "
            "amortisation has no free cross-country API",
            "stays manual / dsa; never a live cell while maturity is an analyst input"),
    "1.4": ("rulebook source is the IMF Fiscal Monitor GFN table (manual); the Fiscal Monitor dataflow on the new IMF "
            "portal is UNVERIFIED, and a WEO deficit + IDS external amortisation proxy leaves out domestic amortisation, "
            "the larger part of GFN for most desk names",
            "stays manual; candidate: IMF FM dataflow once the Mac structure check confirms one (then Team B sign-off)"),
    "1.5": ("no confident free API outside OECD / EU members: World Bank QPSD reports debt by currency for a subset, "
            "but its database id and series codes are UNVERIFIED here",
            "stays manual (national debt office bulletins); re-check QPSD on the Mac"),
    "1.8": ("Bank of Canada / Bank of England CRAG sovereign default database is a file download, not an API",
            "file import under EQ-A-0008 / EQ-A-0016 (Blocked on the Mac pull)"),
    "2.1": ("IMF ARA metric is an annual IMF file, no SDMX series; econquest dsa computes 2.1 with analyst components "
            "(derived_from mixed)",
            "stays dsa / manual"),
    "5.4": ("World Bank Pink Sheet is a monthly Excel file (no API series known here); private-credit codes for the IMF "
            "ODC survey are unconfigured; Team B has not set the window or the rule for non-commodity exporters",
            "stays manual until Team B sets the rule; then a file import"),
    "5.7": ("World Bank Bank Regulation and Supervision Survey is a periodic survey file (waves years apart), question "
            "id UNVERIFIED, no API",
            "stays manual (survey file; the staleness rule would hold most values)"),
    "3.6": ("V-Dem annual file (v2x_jucon, v2xlg_legcon), not an API; " + _RESEARCH, "Sam: research-dataset decision"),
    "3.7": ("WJP Rule of Law Index annual file, licence UNVERIFIED (possible non-commercial terms); " + _RESEARCH,
            "Sam: research-dataset and licence decision"),
    "4.3": ("V-Dem annual file and a Team B level mapping; " + _RESEARCH, "Sam: research-dataset decision; Team B mapping"),
    "4.4": ("Powell-Thyne coups file, terms UNVERIFIED; " + _RESEARCH, "Sam: research-dataset decision"),
    "6.1": ("UCDP GED API needs an access token (x-ucdp-access-token); " + _RESEARCH,
            "Sam: research-dataset decision and token request"),
    "6.7": ("Global Organized Crime Index biennial file, terms UNVERIFIED; " + _RESEARCH, "Sam: research-dataset decision"),
    "6.9": ("rulebook names ACLED (licensed); UCDP proxy needs a token and a Team B zero-base rule; " + _RESEARCH,
            "Sam: research-dataset decision and token request"),
    "6.11": ("IPC API key and terms UNVERIFIED; IPC analyses only food-crisis countries; " + _RESEARCH,
             "Sam: research-dataset decision; Team B blank-vs-0 rule"),
    "6.12": ("UCDP (token) for neighbours plus UNHCR refugee statistics, Team B mapping; " + _RESEARCH,
             "Sam: research-dataset decision"),
    "6.13": ("Global Terrorism Index annual file, IEP terms UNVERIFIED (possible non-commercial); " + _RESEARCH,
             "Sam: research-dataset and licence decision"),
    "7.1": ("UNDRR GAR risk data is a one-off static file, terms UNVERIFIED; " + _RESEARCH, "Sam: research-dataset decision"),
    "7.2": ("UNDRR GAR probable maximum loss is a one-off static file, terms UNVERIFIED; " + _RESEARCH,
            "Sam: research-dataset decision"),
    "7.8": ("CIESIN LECZ static file (SEDAC); " + _RESEARCH, "Sam: research-dataset decision"),
    "7.11": ("ND-GAIN annual file, terms UNVERIFIED; " + _RESEARCH, "Sam: research-dataset decision"),
    "7.12": ("WRI Aqueduct static file; Team B level mapping; " + _RESEARCH, "Sam: research-dataset decision"),
}


@dataclass
class GapMatrix:
    cells: pd.DataFrame                  # COLUMNS, one row per desk country x feed-eligible id
    countries: pd.DataFrame              # one row per country: counts per state, expected / upper share, meets
    summary: dict = field(default_factory=dict)


def _map(data_dir: Path) -> pd.DataFrame:
    p = data_dir / U.COVERAGE_MAP
    if not p.is_file():
        p = DEFAULT_DATA / U.COVERAGE_MAP
    return pd.read_csv(p, dtype=str, keep_default_na=False).set_index("id")


_CODE = re.compile(r"\b[A-Z][A-Z0-9_]*(?:\.[A-Z0-9_]+)*\b")
_RAW = {"weo": ("raw_weo.csv", WEO_SOURCE_SERIES), "worldbank": ("raw_worldbank.csv", WB_SOURCE_SERIES)}


def raw_evidence(data_dir: Path) -> dict:
    """{(feed, iso, series): latest period} from the pull's raw WEO / World Bank tables (empty when absent)."""
    out = {}
    for feed, (name, _) in _RAW.items():
        p = data_dir / "live" / name
        if p.is_file():
            r = pd.read_csv(p, usecols=["iso", "series", "period"], dtype={"iso": str, "series": str})
            r["period"] = pd.to_numeric(r["period"], errors="coerce")
            for (iso, ser), v in r.groupby(["iso", "series"])["period"].max().items():
                out[(feed, iso, ser)] = v
    return out


def _evidence(ev: dict, feed: str, key: str, iso: str) -> str:
    """'raw_weo.csv: GGXWDG_NGDP latest 2025; NGDP absent' for the series an existing feed reads for `key`."""
    if feed not in _RAW or key not in _RAW[feed][1]:
        return ""
    codes = [c for c in dict.fromkeys(_CODE.findall(_RAW[feed][1][key])) if any(k[2] == c for k in ev)]
    bits = [f"{c} latest {int(ev[(feed, iso, c)])}" if (feed, iso, c) in ev else f"{c} absent" for c in codes]
    return f"{_RAW[feed][0]} for {iso}: " + "; ".join(bits) if bits else ""


def _imf_configured(key: str) -> bool:
    return all(IMF_SPECS[c].configured for c in IMF_COMPONENTS.get(key, ()))


def _cb_machine(iso: str, key: str) -> str | None:
    """'<source> <series_key>' of a machine-readable national series serving `key` for `iso`, else None."""
    for concept, cells in CONCEPT_CELLS.items():
        if ("Inputs", key) in cells:
            s = CB_REGISTRY.get(iso, {}).get(concept)
            if s is not None and s.machine:
                return f"{s.source} {s.series_key}"
    return None


def _not_applicable(iso: str, key: str) -> str | None:
    for concept, cells in CONCEPT_CELLS.items():
        if ("Inputs", key) in cells:
            s = CB_REGISTRY.get(iso, {}).get(concept)
            if s is not None and s.note.startswith("not applicable"):
                return s.note
    return None


def classify(iso: str, key: str, live: bool, pull_reason: str, m: pd.DataFrame, live_ids_anywhere: set,
             ids_live: bool, ev: dict | None = None) -> tuple[str, str, str, str]:
    """(state, candidate_source, reason, action) for one cell."""
    row = m.loc[key] if key in m.index else pd.Series(dtype=str)
    cand = str(row.get("candidate_source", ""))
    verified = str(row.get("verified", "")).strip().lower() == "yes"
    if live:
        return "live", cand, "finite in live/live_inputs.csv and not held", "none"
    na = _not_applicable(iso, key)
    if na:
        return "not_applicable", cand, na, "none: no source can serve it; the cell stays seed/analyst"
    cb = _cb_machine(iso, key)
    # BIS indicators: BIS returned nothing for this country; fallbacks in precedence order
    if key in BIS_IDS:
        fb = []
        if key in IMF_COMPONENTS and _imf_configured(key):
            fb.append("IMF SDMX " + "/".join(IMF_COMPONENTS[key]))
        if key in WDI_EXTRA_IDS:
            fb.append("WDI " + "/".join(WDI_EXTRA_COMPONENTS[key]) + " (EQ-A-0062)")
        if cb:
            fb.append(f"national {cb}")
        if fb:
            extra = "" if key in METHOD_APPROVED or key not in WDI_EXTRA_IDS else ("; WDI method approved by Team B with "
                                                                                    "changes (built EQ-A-0084), awaits Sam's "
                                                                                    "Tier 1 sign-off (METHOD_APPROVED)")
            return ("adapter_unverified", f"BIS (no series for this country) then {' then '.join(fb)}",
                    f"{pull_reason}; fallback built, codes UNVERIFIED, country coverage of the fallback UNVERIFIED{extra}",
                    MAC_CHECK)
        return "no_adapter", cand, f"{pull_reason}; no fallback source built", "see section 10"
    # IDS-based ids: only countries that IDS serves (2.10 live today is the evidence)
    if key in IDS_DEPENDENT and not ids_live:
        return ("no_adapter", cand, "IDS covers low- and middle-income economies that report to the DRS; IDS returned "
                "no 2.10 value for this country on the latest pull, so no IDS-based value is expected",
                "stays manual (no free cross-country source for this country)")
    if key in WB_NOT_SERVED:
        return "held_research", cand, WB_NOT_SERVED[key], "Sam: sign-off at first values (research feed, EQ-A-0095)"
    if key in WB_EXTRA_IDS:
        return ("adapter_unverified", cand, "World Bank addition built (EQ-A-0049, official/worldbank.py); not yet "
                "pulled; codes UNVERIFIED" + ("; IDS US$ components need the counterpart fix (section 10)"
                                              if key == "2.2" else ""), MAC_CHECK)
    if key in IMF_NOT_SERVED:
        r, a = DOCUMENTED.get(key, (IMF_NOT_SERVED[key], "see section 10"))
        return "no_adapter", cand, r, a
    if key in IMF_COMPONENTS:
        if _imf_configured(key):
            return "adapter_unverified", cand, "IMF SDMX series configured, codes UNVERIFIED", MAC_CHECK
        unconf = [c for c in IMF_COMPONENTS[key] if not IMF_SPECS[c].configured]
        extra = (" (econquest dsa also computes 1.2 from IDS DT.TDS.DPPG.CD projections: ingesting "
                 "dsa_scorecard_feeds.csv rows with derived_from=live is a Team A follow-up)") if key == "1.2" else ""
        return ("adapter_unconfigured", cand, f"IMF transform built; series codes unknown: {', '.join(unconf)}{extra}",
                "run `python -m econquest.ingestion.official.imf structure <FLOW>` on the Mac, set IMF_SPECS, then verify")
    if key == "1.5":
        if iso in OECD_MEMBERS or iso in EU_MEMBERS:
            feeds = [f for f, mem in (("Eurostat", EU_MEMBERS), ("OECD", OECD_MEMBERS)) if iso in mem]
            unk = ", ".join(n for n, s in OECD_SPECS.items() if not s.configured)
            return ("adapter_unconfigured", cand, f"{' / '.join(feeds)} transform built; dataset and keys unknown ({unk})",
                    "OECD / Eurostat structure check on the Mac, then verify")
        r, a = DOCUMENTED["1.5"]
        return "no_adapter", cand, r, a
    if key in DOCUMENTED:
        r, a = DOCUMENTED[key]
        return "no_adapter", cand, r, a
    # an existing feed id (WEO / World Bank)
    if key in live_ids_anywhere or verified:
        feed = pull_reason.split(" ")[0] if pull_reason else ""
        seen = _evidence(ev or {}, feed, key, iso)
        return ("feed_no_value", cand, f"{pull_reason} (the feed serves this id for other desk countries)"
                + (f"; {seen}" if seen else ""),
                "none: re-check on the next vintage" + (f"; national {cb} fills it once verified" if cb else ""))
    return ("adapter_unverified", cand, f"{pull_reason}: no desk country had a value; code fix built after the pull "
            "(EQ-A-0027 / EQ-A-0036), UNVERIFIED", MAC_CHECK)


def build(data_dir: str | Path = DEFAULT_DATA, target: float = U.LIVE_TARGET) -> GapMatrix:
    d = Path(data_dir)
    rep = U.missing_cell_report(d, target)
    eligible = sorted(U.feed_eligible_ids(d if (d / U.COVERAGE_MAP).is_file() else DEFAULT_DATA), key=U._idkey)
    cty = pd.read_csv(d / "countries.csv", dtype=str, keep_default_na=False)[["country", "iso"]]
    m = _map(d)
    missing = {(r.key, r.country): r.reason for r in rep.cells.itertuples(index=False)}
    names = list(cty["country"])
    live_ids_anywhere = {i for i in eligible if any((i, n) not in missing for n in names)}
    ev = raw_evidence(d)
    rows = []
    for n, iso in zip(cty["country"], cty["iso"]):
        ids_live = (IDS_PROBE, n) not in missing
        for i in eligible:
            st, cand, why, act = classify(iso, i, (i, n) not in missing, missing.get((i, n), ""), m,
                                          live_ids_anywhere, ids_live, ev)
            rows.append({"iso3": iso, "id": i, "state": st, "candidate_source": cand, "reason": why, "action": act})
    cells = pd.DataFrame(rows, columns=COLUMNS)
    n_elig = len(eligible)
    need = int(-(-round(target * n_elig, 9) // 1))
    counts = cells.pivot_table(index="iso3", columns="state", values="id", aggfunc="count", fill_value=0)
    counts = counts.reindex(index=list(cty["iso"]), columns=list(STATES), fill_value=0)
    out = counts.reset_index()
    out["n_eligible"] = n_elig
    out["expected"] = counts[list(EXPECTED_STATES)].sum(axis=1).to_numpy()
    out["upper"] = counts[list(UPPER_STATES)].sum(axis=1).to_numpy()
    out["pct_live"] = (out["live"] / n_elig).round(4)
    out["pct_expected"] = (out["expected"] / n_elig).round(4)
    out["pct_upper"] = (out["upper"] / n_elig).round(4)
    out["target_cells"] = need
    out["meets_target_expected"] = out["expected"] >= need
    out["meets_target_upper"] = out["upper"] >= need
    out["short_of_target_expected"] = (need - out["expected"]).clip(lower=0)
    summary = {"n_countries": len(out), "n_feed_eligible": n_elig, "target_cells_per_country": need,
               "denominator": U.target_denominator(target, n_elig),
               "live_cells": int(out["live"].sum()), "expected_cells": int(out["expected"].sum()),
               "upper_cells": int(out["upper"].sum()), "total_cells": n_elig * len(out),
               "pct_live_overall": round(out["live"].sum() / (n_elig * len(out)), 4) if len(out) else 0.0,
               "pct_expected_overall": round(out["expected"].sum() / (n_elig * len(out)), 4) if len(out) else 0.0,
               "pct_upper_overall": round(out["upper"].sum() / (n_elig * len(out)), 4) if len(out) else 0.0,
               "countries_meeting_target_expected": int(out["meets_target_expected"].sum()),
               "countries_meeting_target_upper": int(out["meets_target_upper"].sum()),
               "missing_target_even_when_verified": [str(x) for x in out.loc[~out["meets_target_expected"], "iso3"]],
               "cells_by_state": cells["state"].value_counts().reindex(list(STATES), fill_value=0).to_dict()}
    return GapMatrix(cells, out, summary)


# ----------------------------------------------------------------------------------------------
# EQ-A-0078: projection to the 60% target and residual gaps ranked by model weight
# ----------------------------------------------------------------------------------------------
RESEARCH_SOURCE = "research dataset (free, not official)"
CASES = ("a", "b", "b_upper", "c", "c_strict", "d")
CASE_ASSUMPTIONS = {
    "a": "today's shared data: finite in <data>/live/live_inputs.csv and not held (state live); nothing else",
    "b": "after the 0.4.2 Mac rerun: (a) plus every adapter_unverified cell (adapter built and configured; the rerun "
         "confirms its codes and the coverage map row is set verified=yes, otherwise the gate holds the value), which "
         "includes 2.2 for the IDS countries through the EQ-A-0068 World counterpart; minus WDI-only fallbacks whose "
         "method Team B has not approved (wdi_extra.METHOD_APPROVED) and minus BIS fallbacks that the --report pull shows "
         "failing (B_EVIDENCE). The EQ-A-0068 WEO-route and PV.EST fixes feed the panel history and the layer-1 hazard "
         "panel, not Inputs cells: they add 0 cells here",
    "b_upper": "(b) without its two exclusions: every adapter_unverified cell (the part-3 'expected' column)",
    "c": "after EQ-A-0067: (b) plus every no_adapter cell of a research-dataset id (coverage map candidate_source) and "
         "6.10 (EPR with the WDI Gini already fetched), each dataset serving every desk country (country coverage "
         "UNVERIFIED)",
    "c_strict": "(c) minus the cells that also need a Team B rule, a token Sam does not hold yet, or lie outside the "
                "dataset's documented coverage (C_GATES), and minus the ids whose every research.REGISTRY entry "
                "(EQ-A-0067, when importable) is blocked or deferred",
    "d": "plan bracket, not a forecast: (c) plus the cells of every indicator whose NEXT_STEPS entry is an adapter of "
         "effort S whose cell is adapter_unconfigured or no_adapter (IMF codes set on the Mac, the CRAG 1.8 count), each "
         "serving every desk country (coverage UNVERIFIED; the FSI encouraged set is sparse)",
}
# Reasons in a pullpack report (step 'universe', counts.by_reason) showing that a built BIS fallback did not serve.
# The report has counts only, not countries, so case b drops the fallback for every desk country it would fill.
B_EVIDENCE = {"5.13": r"no observation for policy_rate", "2.12": r"no PX\.REX\.REER value"}
# Cells case c serves only once something besides the dataset exists (case c_strict leaves them out)
C_GATES = {
    "4.3": "Team B level mapping from V-Dem v2x_regime / v2cacamps (the level guide has no numeric cut-offs)",
    "4.4": "Team B level mapping from coup attempt / success counts and their recency (A-research-datasets.md)",
    "6.1": "UCDP API token (Sam has requested it; not held on 2026-10-25)",
    "6.9": "UCDP API token, and a Team B zero-base rule for the 12m vs 5y ratio",
    "6.10": "rule set (indicator-rules 3, 13.4); held for Sam's sign-off at first values, and EPR without ACD2EPR",
    "6.11": "IPC analyses food-crisis countries only; Team B blank-vs-0 rule for the others",
    "6.12": "UCDP API token, and a Team B level mapping (neighbours in conflict, refugees > 1% of population)",
    "7.12": "Team B level mapping from the Aqueduct risk categories",
}
# Read from the engine, not edited (EQ-A-0078 brief). engine/layer1_hazard.build_features reads these indicator ids;
# every pillar-4 id moves pitf_instability through the pillar-4 aggregate.
LAYER1_IDS = {"1.3": "debt_gdp", "1.6": "primary_deficit_gap", "2.9": "stfx_debt_reserves",
              "2.8": "current_account (fitted mode)", "5.5": "inflation_log (fitted mode)", "5.6": "real_growth (fitted mode)"}
LAYER1_PILLAR = "4"
# scorecard/readiness.REQUIRED_INDICATORS keys (tests/test_coverage_gaps_rank.py keeps the two in step; ingestion does
# not import the scorecard layer)
REQUIRED_IDS = frozenset("1.3 1.4 1.5 1.6 1.7 2.1 2.7 2.8 2.9 2.11 4.10 5.5 5.6 5.12 6.1 7.2".split())

_IMF_LIC = ("IMF terms: free reuse with attribution, commercial reuse needs IMF permission; client-restricted like the "
            "other IMF cells")
_WB_LIC = "World Bank: CC BY 4.0 for most datasets (per-dataset licence UNVERIFIED)"
_MAC = "Team A (AGENT-06) builds; Sam's Mac run confirms"
# One next step per residual-gap indicator: kind is adapter | manual | accept. (kind, step, source, licence, effort, who)
NEXT_STEPS = {
    "1.1": ("manual", "documented manual cell: econquest dsa (Team B) proxy with the analyst average-maturity input; "
            "never live while maturity is an analyst input (domestic amortisation has no free cross-country API)",
            "IMF Article IV DSA tables, budget documents", _IMF_LIC, "none (dsa exists)",
            "Team B analyst via data/dsa_inputs.csv, after each Article IV and each WEO (April, October)"),
    "1.2": ("adapter", "configure irfcl_drains_12m after `python -m econquest.ingestion.official.imf structure` on the "
            "Mac, then verify; alternative: ingest dsa_scorecard_feeds.csv 1.2 rows with derived_from=live once IDS "
            "serves the World counterpart", "IMF SDMX IRFCL section II (predetermined drains)", _IMF_LIC,
            "S (transform built; one spec and a Mac check); reporter coverage UNVERIFIED", _MAC),
    "1.4": ("manual", "documented manual cell from the Fiscal Monitor GFN statistical table; an adapter only if the Mac "
            "structure check finds a Fiscal Monitor dataflow", "IMF Fiscal Monitor (GFN table)", _IMF_LIC,
            "18 cells twice a year", "Team A analyst at each Fiscal Monitor (April, October), attested like fx_manual.csv"),
    "1.5": ("adapter", "probe World Bank QPSD (public debt by currency) for the non-OECD names; configure OECD for JPN, "
            "KOR and COL on the Mac; debt office bulletins by hand where neither serves",
            "World Bank QPSD (database id UNVERIFIED); OECD", _WB_LIC + "; OECD terms UNVERIFIED",
            "M (new series, coverage UNVERIFIED) + S (OECD keys)", _MAC),
    "1.8": ("adapter", "count default or restructuring episodes in the past 20 years from "
            "data/panel/sovereign_defaults_crag.csv (imported under EQ-A-0008, updater EQ-A-0069) into 1.8, as of the "
            "run date (never the wall clock); Team B confirms the counting rule",
            "Bank of Canada / Bank of England CRAG database (file)", "UNVERIFIED (EQ-A-0069 tag; EQ-A-0076 register)",
            "S (file already imported; one transform and tests)", "Team A (AGENT-06); refresh with each CRAG update (annual)"),
    "2.1": ("adapter", "file import of the IMF ARA emerging-market dataset; advanced economies (JPN, KOR, SGP) have no "
            "ARA metric and stay with econquest dsa", "IMF Assessing Reserve Adequacy data (annual file)", _IMF_LIC,
            "M (file format UNVERIFIED; EM names only)", "Team A; annual, when the IMF updates ARA"),
    "2.2": ("adapter", "short-term external debt for the non-IDS names from QEDS (SDDS subscribers: SGP, JPN, KOR, MYS); "
            "VEN does not report and stays seed", "World Bank Quarterly External Debt Statistics (database id UNVERIFIED)",
            _WB_LIC, "M (one new database in WorldBankFeed; also serves 2.9 and 2.10)", _MAC),
    "2.3": ("adapter", "configure iip_portfolio_debt_liab on the Mac, then verify", "IMF SDMX BOP/IIP", _IMF_LIC,
            "S (transform built)", _MAC),
    "2.4": ("adapter", "configure fsi_fx_liab_pct on the Mac, then verify", "IMF SDMX FSI (encouraged set)", _IMF_LIC,
            "S (transform built); encouraged-set coverage is sparse, UNVERIFIED", _MAC),
    "2.9": ("adapter", "QEDS short-term external debt / reserves for SGP, JPN, KOR, MYS (same adapter as 2.2); VEN stays seed",
            "World Bank QEDS (database id UNVERIFIED)", _WB_LIC, "M (shared with 2.2)", _MAC),
    "2.10": ("adapter", "QEDS gross external debt / WDI exports for SGP, JPN, KOR, MYS (same adapter as 2.2); VEN stays seed",
             "World Bank QEDS (database id UNVERIFIED)", _WB_LIC, "M (shared with 2.2)", _MAC),
    "2.12": ("adapter", "built: confirm the IMF reer_index code on the Mac; WDI PX.REX.REER method approved by Team B (2-year "
             "stale hold built, EQ-A-0084), awaits Sam's Tier 1 sign-off (METHOD_APPROVED)",
             "IMF SDMX REER, then WDI PX.REX.REER", _IMF_LIC, "S (code built; Mac check and Sam sign-off)", _MAC + "; Sam Tier 1"),
    "5.1": ("adapter", "configure odc_claims_cg / odc_total_assets on the Mac, then verify", "IMF SDMX MFS ODC", _IMF_LIC,
            "S (transform built)", _MAC),
    "5.2": ("adapter", "configure fsi_fx_loans_pct on the Mac, then verify", "IMF SDMX FSI (encouraged set)", _IMF_LIC,
            "S (transform built); coverage sparse, UNVERIFIED", _MAC),
    "5.4": ("accept", "no rule: Team B has not set the window or the rule for non-commodity exporters, and the Pink "
            "Sheet is a monthly Excel file; re-open when Team B sets the rule", "World Bank Pink Sheet + IMF ODC credit",
            _WB_LIC, "", "Team B rule first"),
    "5.7": ("accept", "the Bank Regulation and Supervision Survey comes in waves years apart, so the staleness rule would "
            "hold any value; the seed stands", "World Bank BRSS (survey file)", _WB_LIC, "", ""),
    "5.9": ("adapter", "built: Team B approved the WDI one-sided HP gap with 5 changes, built under EQ-A-0084 (break and "
            "2-year stale holds, IMF restriction, label, BIS comparison); run `wdi_extra compare` on the Mac, then "
            "Sam's Tier 1 sign-off adds it to METHOD_APPROVED; the 15-year rule refused 7 of 88 on the 0.4.2 pull",
            "WDI FS.AST.PRVT.GD.ZS (IMF IFS via WDI)", _IMF_LIC, "none in code (Mac comparison, Sam sign-off)",
            "AGENT-08 to Sam (Tier 1)"),
    "5.11": ("adapter", "configure odc_deposits on the Mac, then verify", "IMF SDMX MFS ODC + CPI", _IMF_LIC,
             "S (transform built)", _MAC),
    "5.13": ("adapter", "national policy rates for the non-BIS names through official/central_banks.py CB_REGISTRY "
             "(the IMF fallback returned no observation for 57 of 88 on 2026-10-24); SGP has no policy rate (accept)",
             "central banks (machine-readable series)", "per central bank, UNVERIFIED", "M (one series per bank)", _MAC),
    "6.10": ("adapter", "held, research: Gini (already fetched) + EPR level per indicator-rules 3 / 13.4, wired in "
             "EQ-A-0095; released by Sam's sign-off at first values",
             "WDI SI.POV.GINI + ETH Zurich EPR", _WB_LIC + "; EPR terms UNVERIFIED (EQ-A-0067)",
             "none in code (Sam's sign-off)", "Sam via AGENT-08"),
}
_RESEARCH_EFFORT = {"6.1": "M (token API)", "6.9": "M (token API)", "6.12": "M (token API + UNHCR API)",
                    "6.11": "M (API key UNVERIFIED)"}
_FEED_GAP = ("accept", "the existing feed has no value for this country (evidence in the gap matrix reason); re-check each "
             "vintage; a latest-actual fallback would be a Team B rule", "", "", "", "")
RANK_COLUMNS = ["rank", "id", "indicator", "pillar", "indicator_weight", "pillar_weight", "model_weight", "n_missing",
                "score", "countries", "states", "closed_in_c", "closed_in_c_strict", "closed_in_d", "layer1", "required", "kind", "step",
                "source", "licence", "effort", "who"]


def read_matrix(path: str | Path) -> pd.DataFrame:
    """A CSV this module wrote (gap matrix, projection, rank) with every column as text, so ids such as 2.1 and 2.10
    stay distinct (read as numbers they collide)."""
    return pd.read_csv(path, dtype=str, keep_default_na=False)


def pull_evidence(report: str | Path | None) -> dict:
    """{'exclude': {id: note}, 'facts': {...}} from a pullpack report.json (the universe step's counts). Empty when
    `report` is None. Only the reasons in B_EVIDENCE are read; the counts are of the staged universe's countries."""
    if not report:
        return {"exclude": {}, "facts": {}}
    r = json.loads(Path(report).read_text())
    step = next((s for s in r.get("steps", []) if s.get("id") == "universe"), {})
    c = step.get("counts", {})
    by = c.get("by_reason", {})
    n = c.get("n_countries")
    exclude = {}
    for key, pat in B_EVIDENCE.items():
        hits = {k: v for k, v in by.items() if re.search(pat, k)}
        if hits:
            exclude[key] = (f"{sum(hits.values())} of {n} countries had no {key} value on the {r.get('generated_utc')} "
                            f"staged pull ({'; '.join(hits)}); per-country rows are not in the report")
    facts = {k: c[k] for k in ("n_countries", "pct_live_eligible_overall", "pct_live_overall", "countries_meeting_target")
             if k in c}
    facts.update({"generated_utc": r.get("generated_utc"), "econquest_version": r.get("econquest_version"),
                  "held_by_quality_gate": by.get("held by quality gate", 0)})
    return {"exclude": exclude, "facts": facts}


def research_status() -> dict:
    """{indicator id: (status, why)} from econquest.ingestion.research.REGISTRY (EQ-A-0067): the best status of the
    entries serving the id (built / existing beat deferred / blocked). Empty only when the package is not installed
    (ImportError); any other error while importing it propagates."""
    try:
        from .research import REGISTRY
    except ImportError:  # package absent: case c_strict then uses C_GATES only. Any other error (a bad SPEC) is a
        return {}        # defect and must not silently change the c_strict numbers (AGENT-05 review, EQ-A-0078)
    rank_ = {"built": 0, "existing": 0, "deferred": 1, "blocked": 2}
    out: dict = {}
    for key, e in REGISTRY.items():
        for i in e.indicators:
            cur = out.get(i)
            if cur is None or rank_.get(e.status, 3) < rank_.get(cur[0], 3):
                out[i] = (e.status, f"{key}: {e.why}" if e.why else key)
    return out


def _wdi_only(cand: str) -> bool:
    return "WDI" in cand and "IMF SDMX" not in cand and "national" not in cand


def case_flags(g: GapMatrix, data_dir: str | Path = DEFAULT_DATA, report: str | Path | None = None) -> pd.DataFrame:
    """g.cells plus one boolean column per case in CASES (True = counts live in that case) and `note`, the reason a
    cell changes from case a or is held back. Rules in CASE_ASSUMPTIONS; nothing here reads a value."""
    m = _map(Path(data_dir))
    research = set(m.index[m["candidate_source"].str.strip() == RESEARCH_SOURCE])
    ev = pull_evidence(report)["exclude"]
    c = g.cells.copy()
    st, key, cand = c["state"], c["id"], c["candidate_source"].fillna("")
    unv = st == "adapter_unverified"
    wdi = unv & key.isin(WDI_EXTRA_IDS - METHOD_APPROVED) & cand.map(_wdi_only)
    bad = unv & key.isin(set(ev)) & cand.str.startswith("BIS (no series")
    c["a"] = st == "live"
    c["b"] = c["a"] | (unv & ~wdi & ~bad)
    c["b_upper"] = c["a"] | unv
    res = ((st == "no_adapter") & key.isin(research)) | ((st == "held_research") & (key == "6.10"))
    c["c"] = c["b"] | res
    reg = research_status()
    stuck = {i for i, (status, _) in reg.items() if status in ("blocked", "deferred")}
    c["c_strict"] = c["b"] | (res & ~key.isin(set(C_GATES) | stuck))
    quick = {k for k, v in NEXT_STEPS.items() if v[0] == "adapter" and v[4].startswith("S ")}
    nxt = st.isin(["adapter_unconfigured", "no_adapter"]) & key.isin(quick)
    c["d"] = c["c"] | nxt
    note = pd.Series("", index=c.index)
    note[unv] = "b: built adapter, served once its codes are verified on the rerun"
    note[unv & (key == "2.2")] = "b: IDS World counterpart (EQ-A-0068), served once verified"
    note[wdi] = ("b_upper only: WDI method approved by Team B with changes and built (EQ-A-0084); not in "
                 "wdi_extra.METHOD_APPROVED until Sam signs off (Tier 1)")
    for k, why in ev.items():
        note[bad & (key == k)] = f"b_upper only: {why}"
    note[res] = "c: research dataset (EQ-A-0067)"
    for k, why in C_GATES.items():
        note[res & (key == k)] = f"c only, not c_strict: {why}"
    for k in stuck:
        note[res & (key == k)] = f"c only, not c_strict: research.REGISTRY {reg[k][0]} ({reg[k][1]})"
    note[nxt & ~c["c"]] = "d: next S-effort adapter (NEXT_STEPS)"
    c["note"] = note
    return c


def project(flags: pd.DataFrame, target: float = U.LIVE_TARGET) -> tuple[pd.DataFrame, dict]:
    """Per desk country: live cells and share in each case, whether it reaches the target and how far short."""
    n = int(flags.groupby("iso3").size().max()) if len(flags) else 0
    need = int(-(-round(target * n, 9) // 1))
    order = list(dict.fromkeys(flags["iso3"]))
    out = flags.groupby("iso3", sort=False)[list(CASES)].sum().reindex(order).astype(int)
    for k in CASES:
        out[f"pct_{k}"] = (out[k] / n).round(4) if n else 0.0
        out[f"meets_{k}"] = out[k] >= need
    out.insert(0, "n_eligible", n)
    out.insert(1, "target_cells", need)
    out["short_c"] = (need - out["c"]).clip(lower=0)
    out = out.reset_index()
    tot = n * len(out)
    summary = {"n_countries": len(out), "n_feed_eligible": n, "target_cells_per_country": need,
               "denominator": U.target_denominator(target, n), "total_cells": tot,
               "cells": {k: int(out[k].sum()) for k in CASES},
               "pct": {k: round(out[k].sum() / tot, 4) if tot else 0.0 for k in CASES},
               "countries_meeting_target": {k: int(out[f"meets_{k}"].sum()) for k in CASES},
               "assumptions": CASE_ASSUMPTIONS}
    return out, summary


def model_weights(data_dir: str | Path = DEFAULT_DATA) -> pd.DataFrame:
    """Per indicator id: pillar, rulebook weight within the pillar, standard pillar weight (assumptions.json
    scorecard.pillar_weights) and model_weight = their product, the indicator's share of the composite through the
    pillar's weighted average (scorecard/scoring.py; the worst-indicator blend and floors are not linear and are left out)."""
    d = Path(data_dir)
    rb = pd.read_csv(d / "rulebook.csv", dtype={"id": str}).set_index("id")
    pw = json.loads((d / "assumptions.json").read_text())["scorecard"]["pillar_weights"]
    w = pd.DataFrame({"indicator": rb["indicator"], "pillar": rb["pillar"].astype(str),
                      "indicator_weight": rb["weight"].astype(float)})
    w["pillar_weight"] = w["pillar"].map(lambda p: float(pw[p]))
    w["model_weight"] = (w["indicator_weight"] * w["pillar_weight"]).round(6)
    return w


def next_step(key: str, states: set, m: pd.DataFrame) -> tuple[str, str, str, str, str, str]:
    """(kind, step, source, licence, effort, who) for a residual-gap indicator."""
    if key in NEXT_STEPS:
        return NEXT_STEPS[key]
    row = m.loc[key] if key in m.index else pd.Series(dtype=str)
    if str(row.get("candidate_source", "")).strip() == RESEARCH_SOURCE:
        lic = str(row.get("licence_terms", "")).split(" http")[0].strip()
        gate = f"; also needs: {C_GATES[key]}" if key in C_GATES else ""
        reg = research_status().get(key)
        if reg:
            gate += f"; research.REGISTRY: {reg[0]}" + (f" ({reg[1]})" if reg[0] in ("blocked", "deferred") else "")
        return ("adapter", f"EQ-A-0067 research adapter (Sam approved research datasets; non-commercial terms are "
                f"internal-only){gate}", str(row.get("dataset_or_flow", "")), lic,
                _RESEARCH_EFFORT.get(key, "S (annual or static file)"), "Team A (AGENT-01, EQ-A-0067)")
    if states <= {"feed_no_value", "not_applicable"}:
        return _FEED_GAP
    if states <= {"adapter_unverified"}:
        return ("adapter", "built and configured: confirm the codes on the Mac rerun, then set verified=yes in "
                "coverage_source_map.csv", str(row.get("candidate_source", "")),
                str(row.get("licence_terms", "")).split(" http")[0].strip(), "S (Mac check only)", _MAC)
    return ("accept", "no next step recorded: add one to coverage_gaps.NEXT_STEPS", "", "", "", "")


def rank(flags: pd.DataFrame, data_dir: str | Path = DEFAULT_DATA, case: str = "b") -> pd.DataFrame:
    """Residual gaps of `case` (cells not live in it), one row per indicator, ordered by score = model_weight x
    n_missing (ties: id order)."""
    if case not in CASES:
        raise ValueError(f"case must be one of {CASES}")
    w = model_weights(data_dir)
    m = _map(Path(data_dir))
    rows = []
    for key, grp in flags[~flags[case]].groupby("id", sort=False):
        ww = w.loc[key]
        states = grp["state"].value_counts()
        kind, step, src, lic, eff, who = next_step(key, set(states.index), m)
        l1 = LAYER1_IDS.get(key, "pitf_instability (pillar 4 aggregate)" if ww["pillar"] == LAYER1_PILLAR else "")
        rows.append({"id": key, "indicator": ww["indicator"], "pillar": ww["pillar"],
                     "indicator_weight": ww["indicator_weight"], "pillar_weight": ww["pillar_weight"],
                     "model_weight": ww["model_weight"], "n_missing": len(grp),
                     "score": round(ww["model_weight"] * len(grp), 6), "countries": " ".join(grp["iso3"]),
                     "states": ", ".join(f"{s} {v}" for s, v in states.items()),
                     "closed_in_c": int(grp["c"].sum()), "closed_in_c_strict": int(grp["c_strict"].sum()),
                     "closed_in_d": int(grp["d"].sum()),
                     "layer1": l1, "required": "Y" if key in REQUIRED_IDS else "", "kind": kind, "step": step,
                     "source": src, "licence": lic, "effort": eff, "who": who})
    out = pd.DataFrame(rows, columns=[c for c in RANK_COLUMNS if c != "rank"])
    if len(out):
        out["_k"] = out["id"].map(U._idkey)
        out = out.sort_values(["score", "_k"], ascending=[False, True], kind="mergesort").drop(columns="_k")
    out.insert(0, "rank", range(1, len(out) + 1))
    return out.reset_index(drop=True)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.coverage_gaps", description=__doc__.split("\n\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("build")
    p.add_argument("--data", default=str(DEFAULT_DATA))
    p.add_argument("--out", default=None, help=f"gap matrix CSV (default {DEFAULT_OUT.relative_to(U.ROOT)} under --data)")
    p.add_argument("--summary", default=None, help="per-country expected-share CSV (optional)")
    p.add_argument("--target", type=float, default=U.LIVE_TARGET)
    r = sub.add_parser("rank", help="EQ-A-0078: cases a/b/c per desk country and residual gaps ranked by model weight")
    r.add_argument("--data", default=str(DEFAULT_DATA))
    r.add_argument("--case", default="b", choices=CASES, help="case whose residual gaps are ranked (default b)")
    r.add_argument("--report", default=None, help="pullpack report.json: drops BIS fallbacks it shows failing from b")
    r.add_argument("--projection", default=None, help="per-country projection CSV (optional; nothing written otherwise)")
    r.add_argument("--out", default=None, help="ranked residual-gap CSV (optional; nothing written otherwise)")
    r.add_argument("--top", type=int, default=0, help="print only the first N ranked rows (0 = all)")
    r.add_argument("--target", type=float, default=U.LIVE_TARGET)
    a = ap.parse_args(argv)
    if a.cmd == "rank":
        g = build(a.data, a.target)
        flags = case_flags(g, a.data, a.report)
        proj, summ = project(flags, a.target)
        ranked = rank(flags, a.data, a.case)
        for path, df in ((a.projection, proj), (a.out, ranked)):
            if path:
                Path(path).parent.mkdir(parents=True, exist_ok=True)
                df.to_csv(path, index=False)
        print(proj[["iso3", *CASES, "meets_c", "short_c"]].to_string(index=False))
        print(json.dumps({k: v for k, v in summ.items() if k != "assumptions"}, indent=1))
        if a.report:
            print(json.dumps(pull_evidence(a.report), indent=1))
        shown = ranked.head(a.top) if a.top else ranked
        print(shown[["rank", "id", "model_weight", "n_missing", "score", "closed_in_c", "closed_in_d", "kind", "required",
                     "layer1"]].to_string(index=False))
        print(f"target: {summ['denominator']}; ranked case {a.case}; order: model_weight x n_missing")
        return 0
    g = build(a.data, a.target)
    out = Path(a.out) if a.out else Path(a.data) / "panel" / DEFAULT_OUT.name
    out.parent.mkdir(parents=True, exist_ok=True)
    g.cells.to_csv(out, index=False)
    if a.summary:
        g.countries.to_csv(a.summary, index=False)
    print(g.countries[["iso3", "live", "adapter_unverified", "adapter_unconfigured", "expected", "pct_expected",
                       "upper", "pct_upper", "meets_target_expected"]].to_string(index=False))
    print(json.dumps(g.summary, indent=1, default=str))
    print(f"target: {g.summary['denominator']}; wrote {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
