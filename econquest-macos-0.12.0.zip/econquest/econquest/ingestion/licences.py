"""Per-dataset licence register (EQ-A-0076): one machine-readable row per source or dataset in data/licences.csv.

Before this register, licence knowledge sat in tag constants (official.IMF_LICENCE, official.theratesapi.THERATES_LICENCE,
market_history.GOOGLEFINANCE_LICENCE ...), in data/panel/cb_series_verified.csv (licence_ok), in the reason logic of
audit.restricted_reason / audit.client_output_reason / dataroom.restricted_reason, and in the EXC entries of
docs/governance/issues-log.md. The register collects it; contract and column meanings: docs/runbooks/A-licence-register.md.

Columns (REGISTER_COLUMNS):
    source_id        stable id (lower case, [a-z0-9_])
    name             what the source / dataset is
    match_source     regex (case-insensitive, re.search) on a provenance `source` text      } a row matches a record
    match_licence    regex on a licence tag (licence column, licence constant)               } when ANY non-empty
    match_series     regex on a provenance `series` text (derived values)                    } matcher matches its
    match_path       regex on a data-dir relative path, '/' separated (files)                } field
    licence_text     the terms as the repo records them (never invented; UNVERIFIED where not read)
    url              terms page, when the repo records one
    terms_verified   yes | no | UNVERIFIED
    commercial       yes | no | unknown        (commercial use, as the recorded terms say)
    internal_use     yes | no                  (no: barred from desk numbers, audit.restricted_reason)
    client_output    allowed | restricted | barred
    validator_nda    allowed | UNVERIFIED | barred   (the independent validator's data room under NDA; UNVERIFIED:
                     no licence stated and Sam has not decided, withheld from the room until he does)
    exc_id           governance exception (EXC-nnn) when one applies
    attribution_text required citation, when the repo records one
    notes            decisions, tickets, code constants the row mirrors

Optional evidence columns (EVIDENCE_COLUMNS, EQ-A-0093): read and validated when the header has them, '' otherwise.
    terms_url        the terms page actually read (https)
    terms_read_utc   the date it was read, YYYY-MM-DD (or YYYY-MM-DDTHH:MM:SSZ); requires terms_url
    clause           the clauses read, quoted, one line ('[topic] "quote" ... "quote"'); UNVERIFIED rows say why

Several rows can match one record (a BIS policy rate whose series names a WEO input matches `bis` and `imf_derived`).
`licence_for` and `cell_licence` return the MOST RESTRICTIVE matching row (internal_use, then client_output, then
validator_nda); ties go to the row matched on more fields, then to the earlier row in the file.

The register only ever adds restrictions in the hooks (audit.restricted_reason, audit.client_output_reason,
dataroom.restricted_reason): a row saying "allowed", or no row, falls back to the existing rules unchanged.

    python -m econquest.ingestion.licences report --data data       # per source: cells, files, most restrictive tag
    python -m econquest.ingestion.licences check                    # validate the register (exit 1 on a problem)
"""
from __future__ import annotations

import argparse
import contextlib
import contextvars
import csv
import os
import re
import sys
from pathlib import Path
from typing import Iterable, Mapping

REQUIRED_COLUMNS = ["source_id", "name", "match_source", "match_licence", "match_series", "match_path", "licence_text",
                    "url", "terms_verified", "commercial", "internal_use", "client_output", "validator_nda", "exc_id",
                    "attribution_text", "notes"]
# EQ-A-0093: evidence of the terms read. Optional, so a register without them (older copies, other teams' fixtures)
# still loads; Team C's reader (presentation/licences.py) reads REGISTER_COLUMNS only and ignores them.
EVIDENCE_COLUMNS = ["terms_url", "terms_read_utc", "clause"]
REGISTER_COLUMNS = REQUIRED_COLUMNS + EVIDENCE_COLUMNS      # what the shipped register has; a file needs REQUIRED_COLUMNS
READ_DATE_RE = re.compile(r"\d{4}-\d{2}-\d{2}(T\d{2}:\d{2}:\d{2}Z)?")
MAX_CLAUSE = 8000
_EVIDENCE_CTRL = re.compile("[\x00-\x1f\x7f\x85\u2028\u2029]")
MATCH_FIELDS = {"match_source": "source", "match_licence": "licence", "match_series": "series", "match_path": "path"}
VOCAB = {"terms_verified": ("yes", "no", "UNVERIFIED"), "commercial": ("yes", "no", "unknown"),
         "internal_use": ("yes", "no"), "client_output": ("allowed", "restricted", "barred"),
         "validator_nda": ("allowed", "UNVERIFIED", "barred")}
# restrictiveness ranks (higher = more restrictive)
CLIENT_RANK = {"allowed": 0, "restricted": 1, "barred": 2}
VALIDATOR_RANK = {"allowed": 0, "UNVERIFIED": 1, "barred": 2}   # UNVERIFIED: Sam has not decided; withheld
INTERNAL_RANK = {"yes": 0, "no": 1}
SOURCE_ID_RE = re.compile(r"[a-z0-9_]{1,40}")
EXC_RE = re.compile(r"(EXC-\d{3})?")
REGISTER_NAME = "licences.csv"
DEFAULT_REGISTER = Path(__file__).resolve().parents[2] / "data" / REGISTER_NAME
REGISTER_ENV = "ECONQUEST_LICENCE_REGISTER"     # optional override of the register path (tests, a Mac copy)
UNMATCHED = "(no register row)"
TICKET = "EQ-A-0076"


class RegisterError(ValueError):
    """data/licences.csv is missing a column, has a bad value, a duplicate id or a regex that does not compile."""


# EQ-A-0111 (HO-20261025-C-A-004): the register of the data folder in use, set per call by use_register(). A
# ContextVar, so concurrent requests / asyncio tasks each keep their own; a new thread starts without it (pass the
# context with contextvars.copy_context().run, or enter use_register in the thread).
_ACTIVE_REGISTER: contextvars.ContextVar = contextvars.ContextVar("econquest_licence_register", default=None)


def data_dir_register(data_dir: str | Path) -> Path | None:
    """The register that governs `data_dir`: the approved version when `econquest change` has one (Team C's
    ops.licence_gov.state(data_dir)["approved_path"], hash-checked there, also while data_dir/licences.csv has drifted),
    else data_dir/licences.csv when it is a regular file, else None (the caller falls back to the default)."""
    d = Path(data_dir)
    try:
        from ..ops import licence_gov
        approved = licence_gov.state(d).get("approved_path")    # never raises (documented); guarded anyway below
    except Exception:                                           # noqa: BLE001 - no governance module or state: own file
        approved = None
    if approved:
        return Path(approved)
    own = d / REGISTER_NAME
    return own if own.is_file() and not own.is_symlink() else None


def register_path(path: str | Path | None = None, data_dir: str | Path | None = None) -> Path:
    """The register file, first of: `path`; the register of `data_dir` (data_dir_register); the register set by an
    enclosing use_register(); $ECONQUEST_LICENCE_REGISTER; the package's data/licences.csv. With no argument and no
    use_register() this is the old rule (env, then package file)."""
    if path:
        return Path(path)
    if data_dir is not None:
        own = data_dir_register(data_dir)
        if own is not None:
            return own
    active = _ACTIVE_REGISTER.get()
    if active is not None:
        return active
    env = os.environ.get(REGISTER_ENV, "").strip()
    return Path(env) if env else DEFAULT_REGISTER


@contextlib.contextmanager
def use_register(path: str | Path | None = None, data_dir: str | Path | None = None):
    """Within the block every hook that resolves the register without a path (licence_for, cell_licence,
    file_licence, safe_register, register_problem, require_register, invalid_reason, audit / dataroom hooks) reads
    `path`, or the register of `data_dir` (approved version first, see data_dir_register). No environment variable
    is changed. Resolved once on entry; nests (the inner block wins, the outer one is restored on exit). A data_dir
    with neither an approved version nor its own licences.csv leaves the current resolution unchanged. Yields the path
    in force."""
    if path:
        target = Path(path)
    elif data_dir is not None:
        target = data_dir_register(data_dir)
    else:
        target = None
    token = _ACTIVE_REGISTER.set(target if target is not None else _ACTIVE_REGISTER.get())
    try:
        yield register_path()
    finally:
        _ACTIVE_REGISTER.reset(token)


def validate_register(rows: list[dict], where: str = "licence register") -> list[dict]:
    """Check register rows (dicts with REGISTER_COLUMNS, str values): source_id form and uniqueness, the value sets in
    VOCAB, internal_use=no only with client_output=barred, exc_id form, at least one match rule, and every match
    regex compiles and cannot match the empty string. Returns the rows; raises RegisterError naming every problem.
    Public for other teams' readers (Team C presentation/licences.py)."""
    return _validate(rows, where)


def _validate(rows: list[dict], where: str) -> list[dict]:
    problems, seen = [], set()
    for i, r in enumerate(rows, start=2):
        sid = r["source_id"]
        if not SOURCE_ID_RE.fullmatch(sid):
            problems.append(f"line {i}: source_id {sid!r} is not [a-z0-9_]{{1,40}}")
        if sid in seen:
            problems.append(f"line {i}: duplicate source_id {sid!r}")
        seen.add(sid)
        for col, ok in VOCAB.items():
            if r[col] not in ok:
                problems.append(f"line {i} ({sid}): {col}={r[col]!r} not one of {'/'.join(ok)}")
        if r["internal_use"] == "no" and r["client_output"] != "barred":
            problems.append(f"line {i} ({sid}): internal_use=no needs client_output=barred")
        if not EXC_RE.fullmatch(r["exc_id"]):
            problems.append(f"line {i} ({sid}): exc_id {r['exc_id']!r} is not EXC-nnn")
        url, read, clause = (r.get(c, "") or "" for c in EVIDENCE_COLUMNS)
        if url and not url.startswith("https://"):
            problems.append(f"line {i} ({sid}): terms_url {url[:60]!r} is not https://")
        if read and not READ_DATE_RE.fullmatch(read):
            problems.append(f"line {i} ({sid}): terms_read_utc {read!r} is not YYYY-MM-DD[THH:MM:SSZ]")
        if read and not url:
            problems.append(f"line {i} ({sid}): terms_read_utc needs terms_url")
        if len(clause) > MAX_CLAUSE or _EVIDENCE_CTRL.search(url + read + clause):
            problems.append(f"line {i} ({sid}): evidence columns hold a control character or a clause over {MAX_CLAUSE}")
        if not any(r[m] for m in MATCH_FIELDS):
            problems.append(f"line {i} ({sid}): no match rule (match_source / match_licence / match_series / match_path)")
        for m in MATCH_FIELDS:
            if r[m]:
                try:
                    rx = re.compile(r[m], re.IGNORECASE)
                except re.error as e:
                    problems.append(f"line {i} ({sid}): {m} does not compile ({e})")
                    continue
                if rx.search("") is not None:          # e.g. '.*', 'x?', '^': would match every record or file
                    problems.append(f"line {i} ({sid}): {m} {r[m]!r} matches the empty string")
    if problems:
        raise RegisterError(f"{where}: " + "; ".join(problems))
    return rows


_CACHE: dict = {}


def _cached_rows(path: str | Path | None = None) -> list[dict]:
    """Validated register rows with compiled matchers (`_re`), cached on path, size and mtime. Not copied: internal."""
    p = register_path(path)
    try:
        st = p.stat()
    except OSError:
        return []
    key = (str(p.resolve()), st.st_size, st.st_mtime_ns)
    if key not in _CACHE:
        try:
            with p.open(newline="", encoding="utf-8") as fh:
                rd = csv.DictReader(fh)
                missing = [c for c in REQUIRED_COLUMNS if c not in (rd.fieldnames or [])]
                if missing:
                    raise RegisterError(f"{p}: missing columns {missing}")
                rows = [{c: (r.get(c) or "").strip() for c in REGISTER_COLUMNS} for r in rd]
            _validate(rows, str(p))
            for r in rows:
                r["_re"] = {m: re.compile(r[m], re.IGNORECASE) for m in MATCH_FIELDS if r[m]}
        except (OSError, UnicodeDecodeError, csv.Error) as e:
            rows = RegisterError(f"{p}: {type(e).__name__}: {e}")
        except RegisterError as e:
            rows = e
        _CACHE.clear()
        _CACHE[key] = rows                             # an error is cached too: hooks call this per record
    if isinstance(_CACHE[key], RegisterError):
        raise _CACHE[key]
    return _CACHE[key]


def load_register(path: str | Path | None = None) -> list[dict]:
    """Rows of the register as dicts (REGISTER_COLUMNS, all str), in file order, validated (RegisterError otherwise).
    [] when the file does not exist (an install without data/: callers fall back to their own rules). Cached on the
    file's path, size and mtime; each call returns fresh copies. Rows carry REGISTER_COLUMNS; the EVIDENCE_COLUMNS are
    '' when the file has none (a register with REQUIRED_COLUMNS only is still valid)."""
    return [_public(r) for r in _cached_rows(path)]


_READ_ERRORS = (RegisterError, OSError, UnicodeDecodeError, csv.Error)
_WARNED: set = set()


def register_problem(path: str | Path | None = None) -> str | None:
    """None when the register loads; 'missing: <path>' when the file does not exist (the hooks' documented fallback);
    'invalid: <error>' when it exists but cannot be read or validated (SEC-A-010 L3: builds refuse on this)."""
    p = register_path(path)
    if not p.exists():
        return f"missing: {p}"
    try:
        _cached_rows(path)
    except _READ_ERRORS as e:
        return f"invalid: {type(e).__name__}: {e}"
    return None


def invalid_reason(path: str | Path | None = None) -> str | None:
    """Fail-closed reason the audit / data-room hooks return for EVERY record and file while the register exists but
    is invalid (AGENT-05 review, SEC-A-010 L3); None when it is valid or missing (missing: the old rules alone)."""
    why = register_problem(path)
    if why and why.startswith("invalid"):
        _safe_rows(path)                                # the loud one-time warning
        return (f"licence register invalid ({register_path(path)}): every record and file is treated as restricted "
                f"until it is fixed (python -m econquest.ingestion.licences check): {why[9:][:300]}")
    return None


def require_register(path: str | Path | None = None) -> None:
    """Raise RegisterError when the register exists but is invalid (a missing register is allowed: old rules only).
    What data-room and evidence builds call before exporting anything (SEC-A-010 L3)."""
    why = register_problem(path)
    if why and why.startswith("invalid"):
        raise RegisterError(f"licence register {register_path(path)} is invalid, refusing to build: {why[9:]}")


def _safe_rows(path: str | Path | None = None) -> list[dict]:
    try:
        return _cached_rows(path)
    except _READ_ERRORS as e:
        key = (str(register_path(path)), str(e))
        if key not in _WARNED:                         # SEC-A-010 L3: loud, once per register state and process
            _WARNED.add(key)
            import warnings
            msg = (f"LICENCE REGISTER INVALID ({register_path(path)}): {e}. Restrictions held only by the register "
                   "are NOT applied; the old rules run alone. Fix it: python -m econquest.ingestion.licences check")
            warnings.warn(msg, RuntimeWarning, stacklevel=3)
            print("!" * 100 + "\n" + msg + "\n" + "!" * 100, file=sys.stderr)
        return []


def safe_register(path: str | Path | None = None) -> list[dict]:
    """load_register, or [] when the register cannot be read or is invalid: what the audit / data-room hooks use, so
    a broken register never loosens anything (the hooks then run their existing rules only). `check` and the
    consistency test report the problem."""
    return [_public(r) for r in _safe_rows(path)]


def _rank(row: Mapping) -> tuple[int, int, int]:
    return (INTERNAL_RANK.get(row.get("internal_use", ""), 0), CLIENT_RANK.get(row.get("client_output", ""), 0),
            VALIDATOR_RANK.get(row.get("validator_nda", ""), 0))


def _norm_path(p) -> str:
    s = str(p).replace("\\", "/") if p else ""
    while s.startswith("./"):
        s = s[2:]
    return s.lstrip("/")


def matches(row: Mapping, source=None, licence=None, series=None, path=None) -> int:
    """Number of the row's matchers that match the given fields (0: the row does not apply)."""
    given = {"source": source, "licence": licence, "series": series, "path": _norm_path(path)}
    rx = row.get("_re") or {m: re.compile(row[m], re.IGNORECASE) for m in MATCH_FIELDS if row.get(m)}
    n = 0
    for m, rgx in rx.items():
        text = given[MATCH_FIELDS[m]]
        if text is not None and str(text) != "" and rgx.search(str(text)):
            n += 1
    return n


def _best(cands: list[tuple[int, int, dict]]) -> dict | None:
    """Most restrictive candidate; ties: more matched fields, then earlier in the file. cands = (hits, index, row)."""
    if not cands:
        return None
    hits, idx, row = max(cands, key=lambda c: (_rank(c[2]), c[0], -c[1]))
    return _public(row)


def _public(row: Mapping | None) -> dict | None:
    return None if row is None else {k: v for k, v in row.items() if not k.startswith("_")}


def licence_for(source=None, path=None, licence=None, series=None, register: list[dict] | None = None) -> dict | None:
    """The register row for a record (source / licence / series text) or a file (data-dir relative path): the most
    restrictive matching row, or None when no row matches."""
    reg = _safe_rows() if register is None else register
    cands = []
    for i, r in enumerate(reg):
        n = matches(r, source=source, licence=licence, series=series, path=path)
        if n:
            cands.append((n, i, r))
    return _best(cands)


def most_restrictive(tags: Iterable):
    """The most restrictive of `tags`.

    * client_output tag strings ('allowed', 'restricted', 'barred'): the strictest string ('allowed' for none);
    * validator_nda strings only ('allowed', 'UNVERIFIED', 'barred'): the strictest of those;
    * register rows (dicts) or source_ids: the strictest row (internal_use, then client_output, then validator_nda;
      ties to the first given). Unknown source_ids are ignored; None when nothing is left."""
    items = [t for t in tags if t is not None]
    if items and all(isinstance(t, str) and t in CLIENT_RANK for t in items):
        return max(items, key=lambda t: CLIENT_RANK[t])
    if items and all(isinstance(t, str) and t in VALIDATOR_RANK for t in items):
        return max(items, key=lambda t: VALIDATOR_RANK[t])
    if not items:
        return None
    reg = None
    rows = []
    for t in items:
        if isinstance(t, Mapping):
            rows.append(t)
        else:
            reg = _safe_rows() if reg is None else reg
            hit = next((r for r in reg if r["source_id"] == str(t)), None)
            if hit is not None:
                rows.append(hit)
    if not rows:
        return None
    best = rows[0]
    for r in rows[1:]:
        if _rank(r) > _rank(best):
            best = r
    return _public(best)


def cell_licence(provenance_row: Mapping, register: list[dict] | None = None) -> dict | None:
    """Register row for one provenance / audit-trail record (keys source, series, and licence / license if present)."""
    get = provenance_row.get
    lic = next((get(k) for k in ("licence", "license", "licences", "licenses") if get(k) not in (None, "")), None)
    return licence_for(source=get("source"), licence=lic, series=get("series"), register=register)


def file_licence(rel_path, register: list[dict] | None = None) -> dict | None:
    """Register row for a data-dir file by its relative path (match_path only), or None."""
    return licence_for(path=rel_path, register=register)


SIDECAR_SUFFIX = ".provenance.json"


def column_licences(csv_path, register: list[dict] | None = None) -> dict:
    """Column-level tags for a CSV that has a provenance sidecar (<name>.provenance.json next to it, as
    market_history.prices.csv and its builds: `series` {column: {source, licence}} and `exceptions`
    {EXC-nnn: {columns, licence}}): {column: register row or None}. Each column gets the most restrictive of its
    series row and any exception naming it (HO-20261025-B-A-001 item 2: EXC-005 covers only the theratesapi columns of
    prices.csv). {} when there is no sidecar or it cannot be read. file_licence stays the whole-file tag (the most
    restrictive column), which is what the data room uses."""
    import json
    p = Path(csv_path)
    side = p.with_name((p.name[:-4] if p.name.endswith(".csv") else p.name) + SIDECAR_SUFFIX)
    try:
        meta = json.loads(side.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    if not isinstance(meta, dict):
        return {}
    reg = _safe_rows() if register is None else register
    series = meta.get("series") if isinstance(meta.get("series"), dict) else {}
    cols = [c for c in (meta.get("columns") or list(series)) if isinstance(c, str)]
    exc_rows: dict[str, list] = {}
    for exc, e in (meta.get("exceptions") or {}).items():
        if not isinstance(e, dict):
            continue
        row = licence_for(licence=f"{exc} {e.get('licence', '')}", register=reg)
        for c in e.get("columns") or []:
            exc_rows.setdefault(c, []).append(row)
    out = {}
    for c in cols:
        s = series.get(c) if isinstance(series.get(c), dict) else {}
        rows = [licence_for(source=s.get("source"), licence=s.get("licence"), register=reg) if s else None]
        rows += exc_rows.get(c, [])
        out[c] = most_restrictive([r for r in rows if r is not None])
    return out


def register_reason(row: Mapping, use: str) -> str:
    """Reason text for a restriction the register adds where the existing rules gave none."""
    room = ("withheld from the validator data room: validator_nda UNVERIFIED, Sam has not decided"
            if row.get("validator_nda") == "UNVERIFIED" else "barred from the validator data room")
    what = {"desk": "barred from desk numbers", "client": f"{row['client_output']} for client output",
            "validator": room}[use]
    exc = f", {row['exc_id']}" if row.get("exc_id") else ""
    text = (row.get("licence_text") or row.get("name") or "")[:160]
    return f"licence register {row['source_id']}: {what} ({text}{exc}; data/licences.csv, {TICKET})"


# ------------------------------------------------------------------------------------------------ report
REPORT_COLUMNS = ["source_id", "internal_use", "client_output", "validator_nda", "exc_id", "terms_verified", "cells",
                  "files", "sources"]


def _cells(d: Path) -> list[dict]:
    """Cells of the applied audit trail (audit_trail.csv) plus current-pull cells not in it (live/provenance.csv),
    one record per (table, key, country)."""
    import pandas as pd
    out: dict = {}
    for rel in ("audit_trail.csv", "live/provenance.csv"):
        p = d / rel
        if not p.is_file() or p.is_symlink():
            continue
        try:
            df = pd.read_csv(p, dtype=str, keep_default_na=False)
        except (ValueError, OSError):
            continue
        if not {"table", "key", "country", "source"} <= set(df.columns):
            continue
        for r in df.to_dict("records"):
            k = (r["table"], r["key"], r["country"])
            if k not in out:
                out[k] = dict(r, evidence=rel)
    return list(out.values())


def _files(d: Path) -> list[str]:
    out = []
    for root, dirs, files in os.walk(d, followlinks=False):
        dirs[:] = sorted(x for x in dirs if not (Path(root) / x).is_symlink())
        for f in sorted(files):
            p = Path(root) / f
            if p.is_symlink() or f.startswith("."):          # lock / hidden files
                continue
            out.append(p.relative_to(d).as_posix())
    return out


def report(data_dir: str | Path, register: list[dict] | None = None) -> dict:
    """{source_id: {row tags..., cells: n, files: [..], sources: {source text: n}}}; key UNMATCHED for cells and files
    no register row matches."""
    reg = _cached_rows() if register is None else register
    d = Path(data_dir)
    by: dict = {}

    def slot(row):
        sid = row["source_id"] if row else UNMATCHED
        if sid not in by:
            base = {c: (row or {}).get(c, "") for c in REPORT_COLUMNS[1:6]}
            by[sid] = dict(base, source_id=sid, cells=0, files=[], sources={})
        return by[sid]

    for c in _cells(d):
        s = slot(cell_licence(c, register=reg))
        s["cells"] += 1
        src = str(c.get("source", ""))[:90]
        s["sources"][src] = s["sources"].get(src, 0) + 1
    for rel in _files(d):
        row = file_licence(rel, register=reg)
        slot(row)["files"].append(rel)      # no row: working tables, config ... listed under UNMATCHED
    order = {r["source_id"]: i for i, r in enumerate(reg)}
    return dict(sorted(by.items(), key=lambda kv: (-CLIENT_RANK.get(kv[1]["client_output"], -1),
                                                    order.get(kv[0], 10 ** 6))))


def format_report(rep: dict, data_dir, limit: int = 8) -> str:
    lines = [f"Licence register report for {data_dir} (data/licences.csv, {TICKET})",
             "per source: most restrictive tag (internal_use / client_output / validator_nda), cells, files", ""]
    tot_cells = sum(v["cells"] for v in rep.values())
    tot_files = sum(len(v["files"]) for v in rep.values())
    for sid, v in rep.items():
        tag = (f"internal={v['internal_use'] or '-'} client={v['client_output'] or '-'} "
               f"validator={v['validator_nda'] or '-'}" + (f" {v['exc_id']}" if v["exc_id"] else "")
               + (f" terms={v['terms_verified']}" if v["terms_verified"] else ""))
        lines.append(f"{sid:<20} {tag}")
        lines.append(f"    cells: {v['cells']}" + ("" if not v["sources"] else "  (" + "; ".join(
            f"{s} x{n}" for s, n in sorted(v["sources"].items(), key=lambda kv: -kv[1])[:4]) + ")"))
        if v["files"]:
            shown = v["files"][:limit]
            more = f" ... and {len(v['files']) - limit} more" if len(v["files"]) > limit else ""
            lines.append(f"    files: {len(v['files'])}  " + ", ".join(shown) + more)
    un = rep.get(UNMATCHED, {"cells": 0, "files": []})
    lines += ["", f"{tot_cells} cells ({tot_cells - un['cells']} with a register row), {tot_files} files "
                  f"({tot_files - len(un['files'])} with a register row). Cells are audit_trail.csv / live/provenance.csv "
                  "records by (table, key, country), not matched to applied values (audit restricted / client do that)."]
    allowed_unverified = [s for s, v in rep.items() if v["client_output"] == "allowed" and v["terms_verified"] != "yes"
                          and v["cells"]]
    if allowed_unverified:
        lines.append("client_output=allowed with terms not verified (what the code does today, not a licence "
                     "decision; Sam decides): " + ", ".join(allowed_unverified))
    return "\n".join(lines)


def _csv_report(rep: dict) -> None:
    from .ledger import _neutralise
    w = csv.writer(sys.stdout, lineterminator="\n")
    w.writerow(REPORT_COLUMNS)
    for sid, v in rep.items():
        w.writerow([_neutralise(str(x)) for x in (sid, v["internal_use"], v["client_output"], v["validator_nda"],
                                                    v["exc_id"], v["terms_verified"], v["cells"], len(v["files"]),
                                                    "; ".join(f"{s} x{n}" for s, n in v["sources"].items()))])


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.licences",
                                 description="Per-dataset licence register (data/licences.csv, EQ-A-0076)")
    ap.add_argument("--register", help=f"register file (default: ${REGISTER_ENV} or the package data/licences.csv)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("report", help="per source: cells and files and their most restrictive tag")
    r.add_argument("--data", default="data", help="econquest data folder (default: data)")
    r.add_argument("--csv", action="store_true", help="one CSV row per source instead of text")
    r.add_argument("--limit", type=int, default=8, help="files shown per source (default 8)")
    sub.add_parser("check", help="validate the register; exit 1 on a problem")
    a = ap.parse_args(argv)
    try:
        reg = _cached_rows(a.register)
    except RegisterError as e:
        print(f"licence register invalid: {e}", file=sys.stderr)
        return 1
    if not reg:
        print(f"licence register not found: {register_path(a.register)}", file=sys.stderr)
        return 1
    if a.cmd == "check":
        print(f"{len(reg)} register rows OK ({register_path(a.register)})")
        return 0
    rep = report(a.data, register=reg)
    if a.csv:
        _csv_report(rep)
    else:
        print(format_report(rep, a.data, limit=a.limit))
    return 0


if __name__ == "__main__":
    sys.exit(main())
