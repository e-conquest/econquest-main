"""Point-in-time replay (EQ-A-0007): freeze the full set of Team-A-owned run inputs after an apply, linked to the
vintage id of the pull that was applied, and rebuild a complete data directory from that freeze later.

A vintage folder (`data/live/vintages/<id>/`) keeps only what a pull returned (live cells, raw feeds, provenance,
review). A run reads much more: the applied indicators.csv and countries.csv, market history, the panels and the
current live pull. `freeze_inputs` copies all of those to

    data/live/snapshots/<vintage_id>-inputs/          (files 0o444, never overwritten)
        manifest.json                                 sha256 per frozen file, inputs_hash, data_hash at freeze time,
                                                      sha256 of every other input ("not frozen by Team A")
        indicators.csv, countries.csv, market_history/..., panel/..., live/*.csv, live/*.json

and appends a row to data/live/snapshots/index.csv (vintage_id, snapshot, frozen_utc, inputs_hash), which is the
anchor the manifest is checked against. A second freeze of the same vintage with identical files reuses the folder;
with different files (a re-apply after review) it gets a new `-inputs-1`, `-inputs-2` ... folder and the latest wins.

`materialize_vintage` copies data_dir to out_dir with the frozen files substituted (Team A files present now but not
at freeze time are left out), verifying every hash first. Files owned by other teams (assumptions.json, rulebook.csv,
...) are copied as they are now; the result lists those that changed since the freeze under `drift`, so a replay
that cannot be exact says so instead of passing silently.

Hardening (EQ-A-0011, AGENT-09 lows R1-R4): a snapshot name read from index.csv must be a plain folder name directly
under snapshots/ and its manifest must name the requested vintage (R1); out_dir may not lie inside data_dir (R2);
materialize builds in a temporary sibling folder and renames it into place, so a failure leaves no partial out_dir
(R3); index.csv appends take the same exclusive lock as the review ledger (R4)."""
from __future__ import annotations

import csv
import datetime as dt
import hashlib
import json
import os
import shutil
import tempfile
from pathlib import Path

MANIFEST = "manifest.json"
REPLAY_MANIFEST = "replay_manifest.json"
SNAPSHOT_INDEX_COLUMNS = ["vintage_id", "snapshot", "frozen_utc", "inputs_hash"]
FROZEN_FILES = ("indicators.csv", "countries.csv")          # Team A files at the top of data_dir
FROZEN_TREES = ("market_history", "panel")                   # every file below these folders
FROZEN_LIVE_SUFFIXES = (".csv", ".json")                     # data/live/*.csv and *.json, one level (the current pull)
# Team A run inputs that load_universe reads (EQ-A-0028), listed so a change to the freeze rule cannot drop them:
# live/raw_weo.csv (Universe.weo_raw) and live/raw_worldbank_history.csv (Universe.wb_raw) are covered by the one-level
# live/*.csv rule; live/raw_bis_cbs.csv (stress contagion exposures) too; live/events/events_long.csv (Universe.events)
# sits one level deeper and is named explicitly.
TEAM_A_RUN_INPUTS = ("live/raw_weo.csv", "live/raw_worldbank_history.csv", "live/raw_bis_cbs.csv", "live/events/events_long.csv")
FROZEN_LIVE_EXTRA = ("live/events/events_long.csv",)
SKIP_DIRS = ("live/vintages", "live/snapshots",              # archives: never inputs, never copied into a replay dir
             # EQ-A-0054: raw FX history vintages, staged builds, the restricted GOOGLEFINANCE archive and research
             # copies (garch.load_prices reads top-level market_history/*.csv only)
             "market_history/vintages", "market_history/builds", "market_history/archive", "market_history/research",
             # SEC-A-007 M1: GOOGLEFINANCE-era repair tables (EQ-A-0056 inda_repair_*.csv), not engine inputs
             "market_history/repairs",
             # EQ-A-0063: staged sovereign spread history (raw vintages, builds, registry); not an engine input
             "market_history/spreads",
             # EQ-A-0077: review state of held FX history builds (fx_review.csv, holds.json); not an engine input
             "market_history/reviews",
             # SEC-A-008 M2 (EQ-A-0066): the WEO release archive is its own immutable, hash-checked store (weo_asof reads
             # it point in time), and panel_history staging runs and the WEO file cache are not engine inputs; frozen
             # into every snapshot they would copy hundreds of MB per pull
             "panel/weo_vintages", "panel/staging")


class VintageIntegrityError(ValueError):
    """A frozen input snapshot does not match its manifest or the snapshot index (tampered or incomplete)."""


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _inputs_hash(files: dict[str, str]) -> str:
    """SHA-256 over `rel=sha256;` in path order: one hash for the whole frozen set."""
    h = hashlib.sha256()
    for rel in sorted(files):
        h.update(f"{rel}={files[rel]};".encode())
    return h.hexdigest()


def _skipped(rel: str) -> bool:
    return any(rel == s or rel.startswith(s + "/") for s in SKIP_DIRS) or any(part.startswith(".") for part in rel.split("/"))


def is_team_a_input(rel: str) -> bool:
    """True for the data-dir-relative POSIX paths that freeze_inputs owns."""
    parts = rel.split("/")
    if rel in FROZEN_FILES or rel in FROZEN_LIVE_EXTRA:
        return True
    if parts[0] in FROZEN_TREES and len(parts) > 1:
        return True
    return len(parts) == 2 and parts[0] == "live" and rel.endswith(FROZEN_LIVE_SUFFIXES)


def _all_files(data_dir: Path) -> list[str]:
    d = Path(data_dir)
    out = []
    for p in d.rglob("*"):
        if p.is_file():
            rel = p.relative_to(d).as_posix()
            if not _skipped(rel):
                out.append(rel)
    return sorted(out)


def _resolve(data_dir: Path, vintage_id: str) -> str:
    from .feeds import vintage_path
    return vintage_path(data_dir, str(vintage_id)).name


def _snap_root(data_dir: Path) -> Path:
    return Path(data_dir) / "live" / "snapshots"


def _snap_dir(data_dir: Path, name: str) -> Path:
    """The snapshot folder called `name` (from index.csv), confined to the snapshots root (R1): no path separator, no
    '..', and its resolved parent must be the resolved snapshots root (so a symlinked folder pointing elsewhere fails)."""
    root = _snap_root(data_dir)
    name = str(name or "")
    if not name or name in (".", "..") or "/" in name or "\\" in name or os.sep in name or ".." in name:
        raise VintageIntegrityError(f"snapshots/index.csv names an invalid snapshot folder {name!r}")
    p = root / name
    if p.resolve().parent != root.resolve():
        raise VintageIntegrityError(f"snapshot {name!r} resolves outside {root}")
    return p


def _check_vintage(m: dict, vid: str, snap: Path) -> None:
    if str(m.get("vintage_id")) != vid:
        raise VintageIntegrityError(f"{snap}: manifest vintage_id {m.get('vintage_id')!r} is not the requested {vid!r}")


def _read_index(data_dir: Path) -> list[dict]:
    idx = _snap_root(data_dir) / "index.csv"
    if not idx.exists():
        return []
    with open(idx, newline="") as f:
        return list(csv.DictReader(f))


def _data_hash(data_dir: Path) -> str | None:
    try:
        from ..versioning import data_hash
        return data_hash(data_dir)
    except Exception:  # noqa: BLE001 - provenance only; the manifest's own hashes are what replay checks
        return None


def freeze_inputs(data_dir: str | Path, vintage_id: str, now: dt.datetime | None = None) -> Path:
    """Freeze the Team-A-owned run inputs under data/live/snapshots/<vintage_id>-inputs/ (see module docstring).
    `vintage_id` must name an existing vintage (a date means that day's latest); raises FileNotFoundError otherwise.
    Returns the snapshot folder. `now` fixes the clock (UTC) for tests."""
    from .feeds import _utc
    d = Path(data_dir)
    vid = _resolve(d, vintage_id)
    now = _utc(now)
    rels = _all_files(d)
    frozen = {rel: _sha256(d / rel) for rel in rels if is_team_a_input(rel)}
    others = {rel: _sha256(d / rel) for rel in rels if not is_team_a_input(rel)}
    ih = _inputs_hash(frozen)
    root = _snap_root(d); root.mkdir(parents=True, exist_ok=True)
    existing = [r for r in _read_index(d) if r["vintage_id"] == vid]
    if existing and existing[-1]["inputs_hash"] == ih and _snap_dir(d, existing[-1]["snapshot"]).is_dir():
        snap = _snap_dir(d, existing[-1]["snapshot"])
        _check_vintage(verify_snapshot(snap, d), vid, snap)
        return snap                                            # same files already frozen for this vintage
    manifest = {"vintage_id": vid, "frozen_utc": now.strftime("%Y-%m-%dT%H:%M:%SZ"), "inputs_hash": ih,
                "data_hash": _data_hash(d), "files": frozen, "not_frozen_by_team_a": others}
    tmp = Path(tempfile.mkdtemp(dir=root, prefix=f".{vid}-inputs."))
    try:
        for rel in frozen:
            (tmp / rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(d / rel, tmp / rel)
        for rel in frozen:                                      # re-check: a concurrent writer must not slip in
            if _sha256(tmp / rel) != frozen[rel]:
                raise VintageIntegrityError(f"{rel} changed while it was being frozen; retry")
        (tmp / MANIFEST).write_text(json.dumps(manifest, indent=1, sort_keys=True) + "\n")
        for p in tmp.rglob("*"):
            if p.is_file():
                os.chmod(p, 0o444)
        # B103: 0o755 is the snapshot directory (owner rwx, others r-x); every file in it is 0o444
        os.chmod(tmp, 0o755)  # nosec B103
        for n in range(1000):
            snap = root / (f"{vid}-inputs" if n == 0 else f"{vid}-inputs-{n}")
            if snap.exists():
                continue
            try:
                os.rename(tmp, snap); break                     # atomic; fails if a racer created it
            except OSError:
                continue
        else:
            raise FileExistsError(f"no free snapshot folder for {vid}-inputs")
    except BaseException:
        if tmp.exists():
            shutil.rmtree(tmp)                                  # files are 0o444 but the folder is writable
        raise
    from .ledger import locked_append
    with locked_append(root / "index.csv", SNAPSHOT_INDEX_COLUMNS) as (w, _f, new):   # R4: same lock as the ledger
        if new:
            w.writeheader()
        w.writerow({"vintage_id": vid, "snapshot": snap.name, "frozen_utc": manifest["frozen_utc"], "inputs_hash": ih})
    return snap


def snapshot_path(data_dir: str | Path, vintage_id: str) -> Path:
    """Latest frozen input snapshot of a vintage (by snapshots/index.csv). FileNotFoundError when the vintage was
    never frozen (pulled without apply, or applied before EQ-A-0007): replay never falls back to current files."""
    d = Path(data_dir)
    vid = _resolve(d, vintage_id)
    rows = [r for r in _read_index(d) if r["vintage_id"] == vid]
    if not rows:
        raise FileNotFoundError(f"vintage {vid!r} has no frozen input snapshot under {_snap_root(d)} "
                                "(it was pulled without --apply, or applied before input freezing existed)")
    return _snap_dir(d, rows[-1]["snapshot"])


def verify_snapshot(snap: str | Path, data_dir: str | Path | None = None) -> dict:
    """Check a frozen snapshot: every manifest file present with its sha256, no extra files, inputs_hash consistent,
    and (when data_dir is given) inputs_hash equal to the one in snapshots/index.csv. Returns the manifest; raises
    VintageIntegrityError on any mismatch."""
    snap = Path(snap)
    try:
        m = json.loads((snap / MANIFEST).read_text())
    except (OSError, ValueError) as e:
        raise VintageIntegrityError(f"{snap}: unreadable {MANIFEST}: {e}") from e
    files = m.get("files", {})
    problems = []
    present = {p.relative_to(snap).as_posix() for p in snap.rglob("*") if p.is_file()} - {MANIFEST}
    if present - set(files):
        problems.append(f"files not in manifest: {sorted(present - set(files))}")
    for rel, sha in sorted(files.items()):
        if rel not in present:
            problems.append(f"missing {rel}")
        elif _sha256(snap / rel) != sha:
            problems.append(f"hash mismatch {rel}")
    if _inputs_hash(files) != m.get("inputs_hash"):
        problems.append("manifest inputs_hash does not match its file list")
    if data_dir is not None:
        rows = [r for r in _read_index(Path(data_dir)) if r["snapshot"] == snap.name]
        if not rows:
            problems.append("snapshot not in snapshots/index.csv")
        elif rows[-1]["inputs_hash"] != m.get("inputs_hash"):
            problems.append("inputs_hash differs from snapshots/index.csv")
    if problems:
        raise VintageIntegrityError(f"{snap}: " + "; ".join(problems))
    return m


def materialize_vintage(data_dir: str | Path, vintage_id: str, out_dir: str | Path) -> dict:
    """Build a complete data directory for replaying a run at `vintage_id` in out_dir (which must not exist or be
    empty): every file of data_dir except the archives, with the Team A inputs replaced by the verified frozen copies.
    Writes out_dir/replay_manifest.json and returns it: vintage_id, snapshot, inputs_hash, frozen data_hash,
    `files` (sha256 of every file written), `not_frozen_by_team_a` (paths copied as-is) and `drift` (those whose
    content differs from the freeze) and `drift_in_data_hash` (the subset versioning.data_hash covers: when it is
    not empty the replay's data_hash will differ from the frozen run's)."""
    d = Path(data_dir); out = Path(out_dir)
    dr, outr = d.resolve(), out.resolve()
    if outr == dr or dr in outr.parents:                     # R2: a replay dir inside data_dir would be frozen next time
        raise ValueError(f"out_dir {out} must not be inside data_dir {d}")
    snap = snapshot_path(d, vintage_id)
    m = verify_snapshot(snap, d)
    _check_vintage(m, _resolve(d, vintage_id), snap)
    if out.exists() and (not out.is_dir() or any(out.iterdir())):
        raise FileExistsError(f"{out} is not empty")
    out.parent.mkdir(parents=True, exist_ok=True)
    final, out = out, Path(tempfile.mkdtemp(dir=out.parent, prefix=f".{out.name}.replay."))   # R3: build aside
    try:
        rm = _materialize_into(d, snap, m, out)
        if final.exists():
            final.rmdir()                                     # empty (checked above); rmdir fails if a racer filled it
        os.rename(out, final)
    except BaseException:
        shutil.rmtree(out, ignore_errors=True)
        raise
    return rm


def _materialize_into(d: Path, snap: Path, m: dict, out: Path) -> dict:
    written = {}
    others = [rel for rel in _all_files(d) if not is_team_a_input(rel)]
    for rel in others:
        (out / rel).parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(d / rel, out / rel); written[rel] = _sha256(out / rel)
    for rel, sha in m["files"].items():
        (out / rel).parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(snap / rel, out / rel)
        got = _sha256(out / rel)
        if got != sha:
            raise VintageIntegrityError(f"{rel}: copy hash {got[:12]} differs from manifest {sha[:12]}")
        written[rel] = got
    was = m.get("not_frozen_by_team_a", {})
    drift = sorted(rel for rel in set(was) | set(others) if was.get(rel) != written.get(rel))
    try:
        from ..versioning import data_files
        hashed = set(data_files(out))
    except Exception:  # noqa: BLE001
        hashed = set(written)
    rm = {"vintage_id": m["vintage_id"], "snapshot": snap.name, "inputs_hash": m["inputs_hash"],
          "frozen_data_hash": m.get("data_hash"), "files": dict(sorted(written.items())),
          "not_frozen_by_team_a": sorted(others), "drift": drift,
          "drift_in_data_hash": [rel for rel in drift if rel in hashed]}
    (out / REPLAY_MANIFEST).write_text(json.dumps(rm, indent=1, sort_keys=True) + "\n")
    return rm
