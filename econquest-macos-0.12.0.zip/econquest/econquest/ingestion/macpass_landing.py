"""Mac-pass landing kit (EQ-A-0116): land Sam's uploads after a Mac pass into the MVP dataset, in one command.

    python -m econquest.ingestion.macpass_landing run --inbox team/inbox/FOLDER [--vintage-id ID] [--dry-run]
    python -m econquest.ingestion.macpass_landing check --inbox team/inbox/FOLDER

Input: one inbox folder with what team/first-mac-pass.md step 15 asks Sam to upload:
    review.csv          data/live/review.csv after his review and apply              (required)
    report.json         data/live/pullpack/report.json of the pull pack              (required)
    pullpack.log        data/live/pullpack/pullpack.log                              (required)
    review_ledger.csv   data/live/review_ledger.csv: the only source of hold releases (optional; without it no
                        held cell is released, EQ-A-0114 / SEC-A-012 L3)
    worldbank_history.csv, wb_probe*/probes.json ...  World Bank panel and probe outputs (optional, checked and
                        recorded for Team B; never applied here)
    SHA256SUMS          optional `shasum -a 256` lines; every file it names must match

What `run` does, in order; any refusal leaves data/mvp exactly as it was:
1. inventory: required files present, no symbolic link, nothing outside the folder;
2. hashes: sha256 of every file; SHA256SUMS and every sha256 the pull report records for an uploaded file must match;
3. secrets: no file may match a credential pattern (dataroom.secret_reason; the report names file and line, never
   the text);
4. freshness: report.json is a pull-pack report from econquest MIN_VERSION or later with no step pending or running,
   and the vintage (``--vintage-id``, else the dsa_regate step's derived vintage) is newer than data/mvp's;
5. review: required columns, known statuses, no duplicate cell, every desk country, and every cell of the current MVP
   review still there (a truncated file is partial, not a smaller universe);
6. ledger: if uploaded, ``ledger.verify_ledger`` must pass; its rows release holds (bound to the vintage or value, the
   effective_holds rules); typed "apply" text in review.csv never does;
7. rebuild data/mvp from the new review (mvp_dataset.build into a candidate folder), verify it (hashes, labels, 0
   unexplained, 0 restricted, universe loads) and run econquest demo's M2 probe on it (0 unexplained); only then the
   candidate replaces data/mvp;
8. coverage before and after (coverage_live.measure on the old and the new MVP review);
9. "what changed": cells moved to live or to seed, live values changed, new and cleared holds, cells where the MVP now
   differs from data/ (what a reviewed apply would change in the base), Tier 1 items for Sam.

Writes only data/mvp (step 7) and the report folder (default outputs/macpass/FOLDER: landing.json and landing.md,
or refused.json and refused.md when the upload is refused). It never
writes data/ itself: moving values into data/ stays a reviewed apply on Sam's Mac. `check` stops after step 6.
Exit: 0 landed (or checked); 2 refused, partial or stale upload; 1 error (hash mismatch, secret, ledger chain broken,
or the rebuilt dataset fails verification).
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import os
import re
import shutil
import sys
import tempfile
from pathlib import Path

from . import mvp_dataset as M

SCHEMA = "econquest.macpass_landing/1"
TICKET = "EQ-A-0116"
REQUIRED = ("review.csv", "report.json", "pullpack.log")
LEDGER = "review_ledger.csv"
SUMS = "SHA256SUMS"
REPORT_SCHEMA = "econquest.pullpack.report/1"
MIN_VERSION = "0.7.0"                     # the MVP zip of the first Mac pass (team/first-mac-pass.md)
REVIEW_REQUIRED = ("table", "key", "country", "seed", "live", "status", "reason")
STATUSES = ("ok", "hold", "missing")
TIER1_KEYS = {"1.5": "1.5 first values (indicator-rules 18)", "1.8": "1.8 CRAG count (indicator-rules 16)",
              "2.11": "2.11 export concentration first values (indicator-rules 15)"}
TIER1_MARKS = {"Tier 1": "Tier 1 batch (parked for Sam's sign-off)",
               "dsa_reseed:": "dsa_reseed hold (F8): needs Sam's named decision bound to this vintage"}
MAX_SCAN_BYTES = 64 * 2 ** 20
VINTAGE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{6}Z-[0-9a-f]{8}$")
HEX_RE = re.compile(r"^[0-9a-f]{16,64}$")
DATA_FILES = ("indicators.csv", "countries.csv", "audit_trail.csv", "live/review.csv", "live/provenance.csv")


class Refused(RuntimeError):
    """The upload is partial or stale (exit 2)."""


class LandingError(RuntimeError):
    """The upload is inconsistent or unsafe, or the rebuilt dataset fails verification (exit 1)."""


def _sha(p: Path) -> str:
    return M._sha(p)


def _version(v: str) -> tuple:
    try:
        return tuple(int(x) for x in re.findall(r"\d+", str(v))[:3])
    except ValueError:
        return ()


def _vintage_time(vid: str) -> str:
    """Sortable 'YYYY-MM-DDTHHMMSS' of a vintage id (date only when no time part)."""
    m = re.match(r"^(\d{4}-\d{2}-\d{2})(T\d{6})?", str(vid or ""))
    return (m.group(1) + (m.group(2) or "T000000")) if m else ""


# ---- steps 1-3: inventory, hashes, secrets ---------------------------------------------------------------------------

def inventory(inbox: Path) -> dict:
    """{relative name: Path} of every file in the inbox (subfolders included). Refuses symbolic links and a missing
    required file."""
    inbox = Path(inbox)
    if not inbox.is_dir():
        raise Refused(f"inbox folder not found: {inbox}")
    files, links = {}, []
    for p in sorted(inbox.rglob("*")):
        rel = p.relative_to(inbox).as_posix()
        if p.is_symlink():
            links.append(rel)
        elif p.is_file() and "__pycache__" not in rel and p.name != ".DS_Store":
            files[rel] = p
    if links:
        raise LandingError(f"symbolic links in the upload: {', '.join(links[:5])} (upload the files themselves)")
    missing = [f for f in REQUIRED if f not in files]
    if missing:
        raise Refused(f"partial upload: {', '.join(missing)} missing from {inbox.name} "
                      "(team/first-mac-pass.md step 15 uploads review.csv, report.json and pullpack.log)")
    return files


def _report_hashes(doc, names: set) -> list[tuple[str, str, str]]:
    """(file name, recorded hex, where) for every sha256 the pull report records for an uploaded file name: a dict with
    a path-like value ending in that name and a *sha256 key, and verify checks named '<file> matches ... sha256'."""
    out = []

    def walk(x, where):
        if isinstance(x, dict):
            paths = [str(v) for v in x.values() if isinstance(v, str)]
            shas = [(k, str(v).lower()) for k, v in x.items() if "sha256" in str(k).lower() and isinstance(v, str)]
            for n in names:
                if any(p == n or p.endswith("/" + n) for p in paths):
                    out.extend((n, h, f"{where}.{k}") for k, h in shas if HEX_RE.match(h))
            nm, det = str(x.get("name", "")), str(x.get("detail", "")).strip().lower()
            if "sha256" in nm and HEX_RE.match(det):
                out.extend((n, det, f"{where} check '{nm}'") for n in names if nm.startswith(n + " ") or f" {n} " in f" {nm} ")
            for k, v in x.items():
                walk(v, f"{where}.{k}" if where else str(k))
        elif isinstance(x, list):
            for i, v in enumerate(x):
                walk(v, f"{where}[{i}]")
    walk(doc, "")
    return out


def verify_hashes(files: dict, report: dict) -> dict:
    """sha256 per file; SHA256SUMS and report-recorded hashes must match (LandingError otherwise)."""
    sums = {rel: _sha(p) for rel, p in files.items()}
    checked, problems = [], []
    if SUMS in files:
        for line in files[SUMS].read_text(encoding="utf-8", errors="replace").splitlines():
            m = re.match(r"^([0-9a-fA-F]{64})\s+\*?(.+)$", line.strip())
            if not m:
                continue
            h, name = m.group(1).lower(), m.group(2).strip().lstrip("./")
            hit = [r for r in sums if r == name or r.endswith("/" + name.split("/")[-1]) and name.split("/")[-1] == r.split("/")[-1]]
            if not hit:
                problems.append(f"{SUMS} names {name}, which is not in the upload")
            elif sums[hit[0]] != h:
                problems.append(f"{hit[0]}: sha256 {sums[hit[0]][:16]} is not the {SUMS} value {h[:16]}")
            else:
                checked.append(f"{hit[0]} = {SUMS}")
    by_name = {}
    for rel in sums:
        by_name.setdefault(rel.split("/")[-1], []).append(rel)
    for name, h, where in _report_hashes(report, set(by_name)):
        for rel in by_name[name]:
            if not sums[rel].startswith(h):
                problems.append(f"{rel}: sha256 {sums[rel][:16]} is not the value report.json records ({where}: {h[:16]})")
            else:
                checked.append(f"{rel} = report.json {where}")
    if problems:
        raise LandingError("hash mismatch, the upload is not what the Mac produced: " + "; ".join(problems[:10]))
    return {"sha256": dict(sorted(sums.items())), "checked": sorted(set(checked))}


def _json_secret_values(doc, path="") -> list[str]:
    """Credential-like keys holding a string value of 8+ characters (a key alone, like a 'pass' count, is not one)."""
    from .dataroom import SECRET_KEY_RE
    out = []
    if isinstance(doc, dict):
        for k, v in doc.items():
            p = f"{path}.{k}" if path else str(k)
            if SECRET_KEY_RE.fullmatch(str(k)) and isinstance(v, str) and len(v.strip()) >= 8 and " " not in v.strip():
                out.append(p)
            out += _json_secret_values(v, p)
    elif isinstance(doc, list):
        for i, v in enumerate(doc):
            out += _json_secret_values(v, f"{path}[{i}]")
    return out


def scan_secrets(files: dict) -> list[dict]:
    """[{file, reason, lines}] for files that look like credentials or contain credential-like text
    (dataroom's SECRET_FILES / SECRET_NAME_RE / SECRET_TEXT_RE, and JSON keys holding a credential-like value).
    Never the text itself."""
    from .dataroom import SECRET_FILES, SECRET_NAME_RE, SECRET_TEXT_RE
    hits = []
    for rel, p in files.items():
        name = rel.split("/")[-1]
        if p.stat().st_size > MAX_SCAN_BYTES:
            hits.append({"file": rel, "reason": f"too large to scan ({p.stat().st_size} bytes)", "lines": []})
            continue
        if name.lower() in SECRET_FILES or SECRET_NAME_RE.search(name):
            hits.append({"file": rel, "reason": "credential-like file name", "lines": []})
            continue
        text = p.read_bytes().decode("utf-8", errors="ignore")
        lines = [i for i, ln in enumerate(text.splitlines(), 1) if SECRET_TEXT_RE.search(ln)][:20]
        if lines:
            hits.append({"file": rel, "reason": "text matches a credential pattern", "lines": lines})
            continue
        if name.lower().endswith(".json"):
            try:
                keys = _json_secret_values(json.loads(text))
            except ValueError:
                keys = []
            if keys:
                hits.append({"file": rel, "reason": f"JSON keys holding credential-like values: {', '.join(keys[:5])}",
                             "lines": []})
    return hits


# ---- step 4: freshness -----------------------------------------------------------------------------------------------

def read_report(files: dict) -> dict:
    try:
        doc = json.loads(files["report.json"].read_text(encoding="utf-8"))
    except (ValueError, OSError) as e:
        raise LandingError(f"report.json is not readable JSON ({type(e).__name__}: {str(e)[:120]})") from None
    if not isinstance(doc, dict) or doc.get("schema") != REPORT_SCHEMA:
        raise LandingError(f"report.json is not a pull-pack report (schema {doc.get('schema') if isinstance(doc, dict) else '?'!r})")
    _report_shape(doc)
    return doc


def _report_shape(doc: dict) -> None:
    """EQ-A-0138: the parts of report.json the landing reads have the pull pack's shape (steps a list of objects with
    object vintages/artifacts, summary an object of counts), so a damaged file is a plain LandingError, not a crash."""
    steps = doc.get("steps", [])
    if steps is not None and not isinstance(steps, list):
        raise LandingError("report.json is damaged: 'steps' is not a list (upload the file `econquest mac-pull run` wrote)")
    for i, s in enumerate(steps or []):
        if not isinstance(s, dict):
            raise LandingError(f"report.json is damaged: step {i + 1} is not an object (upload the file the Mac wrote)")
        for k in ("vintages", "artifacts"):
            if s.get(k) is not None and not isinstance(s[k], dict):
                raise LandingError(f"report.json is damaged: step {s.get('id')!r} {k} is not an object")
    summ = doc.get("summary", {})
    if summ is not None and not isinstance(summ, dict):
        raise LandingError("report.json is damaged: 'summary' is not an object")
    for k in ("pending", "running"):
        v = (summ or {}).get(k, 0)
        if v not in (None, "") and not (isinstance(v, int) or (isinstance(v, str) and v.strip().isdigit())):
            raise LandingError(f"report.json is damaged: summary.{k} is {str(v)[:40]!r}, not a count")


def report_vintage(report: dict) -> str | None:
    """The vintage the review belongs to: the dsa_regate step's derived vintage (the latest after the full fetch)."""
    for s in report.get("steps") or []:
        if s.get("id") == "dsa_regate" and s.get("status") == "done":
            for v in ((s.get("vintages") or {}).get("dsa_vintage"), (s.get("artifacts") or {}).get("vintage_id")):
                if v and VINTAGE_RE.match(str(v)):
                    return str(v)
    return None


def freshness(report: dict, vintage_id: str | None, current: dict | None) -> dict:
    """Refused unless the report is a finished pull pack from MIN_VERSION+ and the vintage is newer than data/mvp's."""
    ver = str(report.get("econquest_version", ""))
    if _version(ver) < _version(MIN_VERSION):
        raise Refused(f"stale upload: the pull pack ran econquest {ver or '?'}; the Mac pass runs {MIN_VERSION} or later "
                      "(install the MVP zip first, team/first-mac-pass.md steps 1-2)")
    steps = report.get("steps") or []
    open_steps = [f"{s.get('id')} {s.get('status')}" for s in steps if s.get("status") in ("pending", "running")]
    summ = report.get("summary") or {}
    if open_steps or int(summ.get("pending", 0) or 0) or int(summ.get("running", 0) or 0):
        raise Refused(f"partial upload: the pull pack had not finished ({', '.join(open_steps) or summ}); "
                      "rerun `econquest mac-pull run` to the end and upload again")
    vid = vintage_id or report_vintage(report)
    if not vid:
        raise Refused("partial upload: no vintage id (report.json has no finished dsa_regate step); pass --vintage-id "
                      "with the id `econquest review` shows for the applied vintage")
    if not VINTAGE_RE.match(vid):
        raise LandingError(f"vintage id {vid!r} is not YYYY-MM-DDTHHMMSSZ-xxxxxxxx")
    gen = str(report.get("generated_utc", ""))
    if gen and gen.replace(":", "").replace("-", "")[:15] < _vintage_time(vid).replace("-", "")[:15]:
        raise LandingError(f"report.json was generated {gen}, before its own vintage {vid}")
    if current and _vintage_time(vid) <= _vintage_time(current.get("vintage_id", "")):
        raise Refused(f"stale upload: vintage {vid} is not newer than the one data/mvp is built from "
                      f"({current.get('vintage_id')})")
    return {"econquest_version": ver, "generated_utc": gen, "vintage_id": vid,
            "steps": {str(s.get("id")): str(s.get("status")) for s in steps}, "exit_code": report.get("exit_code")}


# ---- step 5-6: review and ledger -------------------------------------------------------------------------------------

def check_review(path: Path, desk: list[str], current_review: Path | None) -> dict:
    import pandas as pd
    try:
        rv = pd.read_csv(path, dtype=str, keep_default_na=False)
    except (ValueError, OSError) as e:
        raise LandingError(f"review.csv is not readable CSV ({type(e).__name__}: {str(e)[:120]})") from None
    miss = [c for c in REVIEW_REQUIRED if c not in rv.columns]
    if miss:
        raise LandingError(f"review.csv lacks column(s) {', '.join(miss)}")
    bad = sorted(set(rv["status"]) - set(STATUSES))
    if bad:
        raise LandingError(f"review.csv has unknown status value(s) {bad[:5]}")
    dup = rv[rv.duplicated(["table", "key", "country"], keep=False)]
    if len(dup):
        r = dup.iloc[0]
        raise LandingError(f"review.csv has {len(dup)} duplicate cell rows, e.g. {r['table']} {r['key']} {r['country']}")
    absent = [c for c in desk if c not in set(rv["country"])]
    if absent:
        raise Refused(f"partial upload: review.csv has no rows for {', '.join(absent)}")
    lost = []
    if current_review is not None and current_review.is_file():
        cur = pd.read_csv(current_review, dtype=str, keep_default_na=False)
        cur = cur[~cur["reason"].astype(str).str.startswith(("Tier 1", "1.8 not served"))]   # MVP's own 1.8 rows
        have = set(zip(rv["table"], rv["key"].astype(str), rv["country"]))
        lost = [f"{t} {k} {c}" for t, k, c in zip(cur["table"], cur["key"].astype(str), cur["country"]) if (t, k, c) not in have]
    if lost:
        raise Refused(f"partial upload: review.csv lacks {len(lost)} cells the current MVP review has, e.g. "
                      f"{', '.join(lost[:5])} (upload the whole data/live/review.csv)")
    return {"rows": int(len(rv)), "status": {k: int(v) for k, v in rv["status"].value_counts().items()},
            "typed_applies_on_holds": int(((rv["status"] == "hold") &
                                           (rv.get("decision", pd.Series("", index=rv.index)).astype(str).str.strip()
                                            .str.lower().str.startswith("apply"))).sum())}


def read_verified_ledger(files: dict):
    """(rows, info) from an uploaded review_ledger.csv that ledger.verify_ledger passes; (None, info) when absent."""
    from . import ledger as L
    if LEDGER not in files:
        return None, {"uploaded": False, "releases": "none (no review_ledger.csv uploaded: holds stay held)"}
    with tempfile.TemporaryDirectory(prefix="econquest-macpass-ledger-") as td:
        d = Path(td)
        (d / "live").mkdir()
        shutil.copyfile(files[LEDGER], L.ledger_path(d))
        v = L.verify_ledger(d)
        if not v.get("ok"):
            raise LandingError("review_ledger.csv fails ledger verify (hash chain): "
                               + "; ".join(str(x) for x in (v.get("problems") or [])[:5]))
        rows = L.read_ledger(d)
    sha = _sha(files[LEDGER])
    return rows, {"uploaded": True, "rows": int(len(rows)), "sha256": sha, "chained": v.get("chained"),
                  "releases": f"review_ledger.csv sha256 {sha[:16]} (ledger verify ok, {len(rows)} rows)"}


def check_wb_panel(files: dict, report: dict) -> dict | None:
    """worldbank_history.csv, when uploaded, against the wb_panel step's contract (pullpack.wb_panel_checks)."""
    rel = next((r for r in files if r.split("/")[-1] == "worldbank_history.csv"), None)
    if rel is None:
        return None
    from .pullpack import wb_panel_checks
    st = next((s for s in report.get("steps") or [] if s.get("id") == "wb_panel"), {})
    a = st.get("artifacts") or {}
    codes = list(a.get("codes") or [])
    years = str(a.get("years", ""))
    if not codes or not re.match(r"^\d{4}-\d{4}$", years):
        return {"file": rel, "checked": False, "note": "report.json has no wb_panel step with codes and years; recorded only"}
    lo, hi = (int(x) for x in years.split("-"))
    checks, counts = wb_panel_checks(files[rel], codes, lo, hi)
    failed = [c["name"] for c in checks if c.get("required", True) and not c.get("ok")]
    if failed:
        raise LandingError(f"{rel} fails the wb_panel contract: {'; '.join(failed)}")
    return {"file": rel, "checked": True, "rows": counts.get("rows"), "series": sorted(counts.get("series", {}))}


# ---- step 7-9: rebuild, coverage, what changed -----------------------------------------------------------------------

def _prov(mvp: Path) -> dict:
    p = mvp / "provenance.csv"
    if not p.is_file():
        return {}
    with open(p, newline="", encoding="utf-8") as f:
        return {(r["table"], r["key"], r["country"]): r for r in csv.DictReader(f)}


def _gate(mvp: Path) -> dict:
    p = mvp / "gate_report.json"
    if not p.is_file():
        return {}
    return {(c["table"], str(c["key"]), c["country"]): c for c in json.loads(p.read_text()).get("cells", [])}


def _base_values(data_dir: Path) -> dict:
    out = {}
    for name in ("indicators.csv", "countries.csv"):
        with open(data_dir / name, newline="", encoding="utf-8") as f:
            for r in csv.DictReader(f):
                for col, v in r.items():
                    if name == "indicators.csv" and col not in ("id", "pillar", "indicator", "unit"):
                        out[(name, r["id"], col)] = v
                    elif name == "countries.csv" and col != "country":
                        out[(name, col, r["country"])] = v
    return out


def _differs(a: str, b: str) -> bool:
    x, y = M._num(a), M._num(b)
    if x is None or y is None:
        return str(a).strip() != str(b).strip()
    return abs(x - y) > 1e-9 * max(1.0, abs(x))


def what_changed(old_mvp: dict, new_mvp: dict, old_gate: dict, new_gate: dict, base: dict) -> dict:
    to_live, to_seed, value_changed = [], [], []
    for cell, n in new_mvp.items():
        o = old_mvp.get(cell)
        if o is None:
            continue
        if o["label"] != n["label"]:
            (to_live if n["label"] == "live" else to_seed).append({"cell": "|".join(cell), "from": o["value"], "to": n["value"],
                                                                   "source": n["source"], "reason": n["reason"]})
        elif _differs(o["value"], n["value"]):
            value_changed.append({"cell": "|".join(cell), "from": o["value"], "to": n["value"], "label": n["label"]})
    held_old = {c for c, g in old_gate.items() if g.get("outcome") == "held"}
    held_new = {c for c, g in new_gate.items() if g.get("outcome") == "held"}
    new_holds = [{"cell": "|".join(c), "reason": new_gate[c]["reason"]} for c in sorted(held_new - held_old)]
    cleared = [{"cell": "|".join(c), "now": new_gate[c]["outcome"] if c in new_gate else "not in review"}
               for c in sorted(held_old - held_new)]
    diff_old = {c for c, r in old_mvp.items() if c in base and _differs(base[c], r["value"])}
    diff_new = {c for c, r in new_mvp.items() if c in base and _differs(base[c], r["value"])}
    base_touch = [{"cell": "|".join(c), "data": base[c], "mvp": new_mvp[c]["value"], "label": new_mvp[c]["label"]}
                  for c in sorted(diff_new - diff_old)]
    tier1 = []
    for c, g in sorted(new_gate.items()):
        reason = str(g.get("reason", ""))
        mark = next((t for m, t in TIER1_MARKS.items() if m in reason), None)
        mark = (TIER1_KEYS.get(c[1]) if c[0] == "Inputs" else None) or mark
        if not mark or g.get("outcome") == "not_a_cell" or (g.get("outcome") == "missing" and not reason.startswith("Tier 1")):
            continue
        state = ("released by Sam (ledger)" if g.get("outcome") == "live" and "ledger-verified" in reason
                 else "live (gate ok)" if g.get("outcome") == "live" else "held, needs Sam")
        tier1.append({"cell": "|".join(c), "state": state, "value": g.get("live", ""), "seed": g.get("seed", ""),
                      "why": TIER1_KEYS.get(c[1], mark), "reason": reason[:200]})
    return {"to_live": to_live, "to_seed": to_seed, "live_value_changed": value_changed, "new_holds": new_holds,
            "cleared_holds": cleared, "base_inputs_touched": base_touch,
            "base_inputs_differing": {"before": len(diff_old), "after": len(diff_new)}, "tier1": tier1}


def coverage(review: Path, data_dir: Path) -> dict | None:
    try:
        from . import coverage_live as C
    except ImportError:
        return None
    try:
        return C.measure(review, data_dir)
    except C.CoverageError as e:
        return {"error": str(e)[:300]}


def _coverage_summary(before, after) -> dict:
    if before is None or after is None:
        return {"note": "not measured (coverage_live not available)"}
    if "error" in before or "error" in after:
        return {"note": "not measured", "before": before.get("error"), "after": after.get("error")}
    b, a = before["desk"], after["desk"]
    gained = sorted(set(a["live_cells"]) - set(b["live_cells"]))
    lost = sorted(set(b["live_cells"]) - set(a["live_cells"]))
    return {"before": {"live": b["live"], "eligible": b["eligible_cells"], "share": b["share"],
                       "countries_at_target": b["countries_at_target"]},
            "after": {"live": a["live"], "eligible": a["eligible_cells"], "share": a["share"],
                      "countries_at_target": a["countries_at_target"]},
            "gained": gained, "lost": lost}


def _data_hashes(data_dir: Path) -> dict:
    return {rel: _sha(data_dir / rel) for rel in DATA_FILES if (data_dir / rel).is_file()}


def land(inbox: Path, root: Path = M.ROOT, out: Path | None = None, vintage_id: str | None = None,
         dry_run: bool = False, check_only: bool = False, now: dt.datetime | None = None) -> dict:
    """Run the landing; returns the report dict (also written to ``out``). Raises Refused / LandingError."""
    root, inbox = Path(root).resolve(), Path(inbox).resolve()
    data_dir = root / "data"
    mvp = M.mvp_dir(root)
    if inbox.is_relative_to(data_dir.resolve()):
        raise LandingError("the inbox may not be inside data/ (uploads land in team/inbox/)")
    out = Path(out).resolve() if out else root / "outputs" / "macpass" / inbox.name
    if out.is_relative_to(data_dir.resolve()):
        raise LandingError("the report folder may not be inside data/")
    from .pullpack import data_folder_problem
    problem = data_folder_problem(data_dir)             # EQ-A-0138: wrong --root (the ~/Downloads release copy)
    if problem:
        raise Refused(f"wrong folder: {problem}")
    rep = {"schema": SCHEMA, "ticket": TICKET, "inbox": str(inbox), "started_utc": _now(now), "status": "", "steps": {}}
    if not check_only:
        recovered = recover_interrupted_swap(data_dir, mvp)
        if recovered:
            rep["recovered"] = recovered
    files = inventory(inbox)
    with tempfile.TemporaryDirectory(prefix="econquest-macpass-") as td:
        return _land_files(private_copy(files, Path(td)), rep, root, data_dir, mvp, out, vintage_id, dry_run,
                           check_only, now)


def private_copy(files: dict, dest: Path) -> dict:
    """SEC-A-013 L1: copy the upload into a private folder once, so the bytes hashed, scanned and checked are the bytes
    the rebuild reads (team/inbox is shared and writable; a file swapped between steps must not reach data/mvp).
    A file that became a symbolic link since the inventory is refused."""
    out = {}
    for rel, p in files.items():
        if p.is_symlink() or not p.is_file():
            raise LandingError(f"{rel} changed into a link or vanished during the landing (upload the files themselves)")
        q = dest / rel
        q.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(p, q, follow_symlinks=False)
        out[rel] = q
    return out


def _land_files(files: dict, rep: dict, root: Path, data_dir: Path, mvp: Path, out: Path, vintage_id, dry_run,
                check_only, now) -> dict:
    """land() after the upload was copied to a private folder (private_copy)."""
    report = read_report(files)
    rep["steps"]["hashes"] = verify_hashes(files, report)
    secrets = scan_secrets(files)
    if secrets:
        rep["steps"]["secrets"] = secrets
        raise LandingError("credential-like content in the upload: " + "; ".join(
            f"{s['file']} ({s['reason']}{', lines ' + ','.join(map(str, s['lines'][:5])) if s['lines'] else ''})" for s in secrets)
            + ". Do not forward these files; rotate the credential and upload clean copies")
    rep["steps"]["secrets"] = "none found"
    cur_manifest = json.loads((mvp / "manifest.json").read_text()) if (mvp / "manifest.json").is_file() else None
    rep["steps"]["freshness"] = fresh = freshness(report, vintage_id, cur_manifest)
    desk = [r["country"] for r in csv.DictReader(open(data_dir / "countries.csv", newline="", encoding="utf-8"))]
    rep["steps"]["review"] = check_review(files["review.csv"], desk, mvp / "data" / "live" / "review.csv")
    decisions, linfo = read_verified_ledger(files)
    rep["steps"]["ledger"] = linfo
    rep["steps"]["wb_panel"] = check_wb_panel(files, report)
    rep["optional_files"] = sorted(r for r in files if r not in REQUIRED + (LEDGER, SUMS))
    if check_only:
        rep["status"] = "checked"
        return _write(rep, out)
    before = {"manifest": cur_manifest, "prov": _prov(mvp), "gate": _gate(mvp)}
    cov_before = coverage(mvp / "data" / "live" / "review.csv", mvp / "data") if (mvp / "data").is_dir() else None
    data_before = _data_hashes(data_dir)
    cand = data_dir / f".mvp-candidate-{fresh['vintage_id']}"
    M._rmtree(cand)
    try:
        man = M.build(root, out=cand, review=files["review.csv"], vintage_id=fresh["vintage_id"], decisions=decisions,
                      releases=linfo["releases"], upload_files={r: h for r, h in rep["steps"]["hashes"]["sha256"].items()},
                      now=now)
        try:
            v = M.verify(cand, load=True)
        except M.MvpError as e:
            raise LandingError(f"the rebuilt dataset fails verification, data/mvp kept: {e}") from None
        from ..ops.demo import probe_gate
        g = probe_gate(str(cand / "data"))
        if not g.get("ok"):
            raise LandingError(f"the rebuilt dataset fails econquest demo's M2 check, data/mvp kept: {g.get('reason')}")
        after = {"prov": _prov(cand), "gate": _gate(cand)}
        cov_after = coverage(cand / "data" / "live" / "review.csv", cand / "data")
        rep["steps"]["rebuild"] = {"dataset_sha256": man["dataset_sha256"], "previous_dataset_sha256":
                                   (cur_manifest or {}).get("dataset_sha256"), "vintage_id": man["vintage_id"],
                                   "as_of": man["as_of"], "counts": man["counts"], "gate": man["gate"],
                                   "releases": man["releases"], "verify": {k: v[k] for k in ("ok", "restricted_cells", "countries", "indicators")},
                                   "m2_probe": g.get("reason")}
        rep["coverage"] = _coverage_summary(cov_before, cov_after)
        rep["changes"] = what_changed(before["prov"], after["prov"], before["gate"], after["gate"], _base_values(data_dir))
        if _data_hashes(data_dir) != data_before:
            raise LandingError("data/ changed while landing (another session is applying?): data/mvp kept, rerun")
        if dry_run:
            rep["status"] = "dry run: data/mvp kept, candidate discarded"
        else:
            swap_in(cand, mvp, data_dir / f".mvp-old-{fresh['vintage_id']}")
            rep["status"] = "landed: data/mvp rebuilt"
    finally:
        M._rmtree(cand)
    rep["steps"]["data_unchanged"] = True
    return _write(rep, out)


def _rename(src: Path, dst: Path) -> None:
    """One rename (os.rename); its own function so the rehearsal and tests can interrupt the swap (EQ-A-0138)."""
    os.rename(src, dst)


def swap_in(cand: Path, mvp: Path, old: Path) -> None:
    """EQ-A-0138: replace data/mvp by the verified candidate with two renames, never leaving data/ without an mvp: when
    the second rename fails or is interrupted (Ctrl-C, disk error), the previous data/mvp is renamed back before the
    error goes on. A hard kill between the two renames leaves data/.mvp-old-*, which recover_interrupted_swap puts back
    at the start of the next landing."""
    M._rmtree(old)
    had = mvp.exists()
    if had:
        _rename(mvp, old)
    try:
        _rename(cand, mvp)
    except BaseException:
        if had and old.exists() and not mvp.exists():
            os.rename(old, mvp)
        raise
    M._rmtree(old)


def recover_interrupted_swap(data_dir: Path, mvp: Path) -> str | None:
    """EQ-A-0138: put back data/mvp from data/.mvp-old-* when a landing was killed between swap_in's two renames
    (data/mvp absent, exactly one previous copy present). Returns what it did, or None. Leftover candidates are removed:
    a candidate is never installed without the verify that follows its build."""
    for c in data_dir.glob(".mvp-candidate-*"):
        M._rmtree(c)
    # AGENT-09 Info (EQ-A-0141): a symlinked .mvp-old-* is never renamed into data/mvp
    olds = sorted(p for p in data_dir.glob(".mvp-old-*") if p.is_dir() and not p.is_symlink())
    if mvp.exists() or mvp.is_symlink() or len(olds) != 1:
        return None
    os.rename(olds[0], mvp)
    return f"data/mvp put back from {olds[0].name} (a landing was stopped between its two renames)"


def _now(now=None) -> str:
    return (now or dt.datetime.now(dt.timezone.utc)).strftime("%Y-%m-%dT%H:%M:%SZ")


def markdown(rep: dict) -> str:
    s = rep["steps"]
    L = [f"# Mac-pass landing: {Path(rep['inbox']).name}", "", f"Status: **{rep['status']}** ({rep.get('started_utc')})", ""]
    if "freshness" in s:
        f = s["freshness"]
        L += [f"- Pull pack: econquest {f['econquest_version']}, generated {f['generated_utc']}, vintage {f['vintage_id']}"]
    if "hashes" in s:
        L += [f"- Files: {len(s['hashes']['sha256'])}; hashes cross-checked: {len(s['hashes']['checked'])}; secrets: {s.get('secrets')}"]
    if "review" in s:
        L += [f"- Review: {s['review']['rows']} rows {s['review']['status']}; typed 'apply' on held cells (not used): "
              f"{s['review']['typed_applies_on_holds']}"]
    if "ledger" in s:
        L += [f"- Releases: {s['ledger']['releases']}"]
    if s.get("wb_panel"):
        L += [f"- worldbank_history.csv: {s['wb_panel']}"]
    rb = s.get("rebuild")
    if rb:
        L += ["", "## data/mvp", "", f"- dataset_sha256 {rb['dataset_sha256']} (was {rb['previous_dataset_sha256']})",
              f"- counts {rb['counts']}", f"- gate {rb['gate']}", f"- verify {rb['verify']}", f"- M2: {rb['m2_probe']}"]
    cov = rep.get("coverage")
    if cov:
        L += ["", "## Coverage (desk, feed-eligible cells live)", ""]
        if "before" in cov and isinstance(cov["before"], dict):
            L += [f"- before {cov['before']}", f"- after {cov['after']}",
                  f"- gained {len(cov['gained'])}: {', '.join(cov['gained'][:20])}",
                  f"- lost {len(cov['lost'])}: {', '.join(cov['lost'][:20])}"]
        else:
            L += [f"- {cov.get('note')}"]
    ch = rep.get("changes")
    if ch:
        L += ["", "## What changed", "",
              f"- moved to live: {len(ch['to_live'])}; moved to seed: {len(ch['to_seed'])}; live values changed: "
              f"{len(ch['live_value_changed'])}",
              f"- new holds: {len(ch['new_holds'])}; cleared holds: {len(ch['cleared_holds'])}",
              f"- cells where data/mvp differs from data/ (a reviewed apply would change them): "
              f"{ch['base_inputs_differing']['before']} -> {ch['base_inputs_differing']['after']}"]
        for k, title in (("to_live", "Moved to live"), ("to_seed", "Moved to seed"), ("new_holds", "New holds"),
                         ("base_inputs_touched", "Base inputs newly differing from data/")):
            if ch[k]:
                L += ["", f"### {title}", ""] + [f"- {x['cell']}: " + ", ".join(f"{a} {b}" for a, b in x.items() if a != "cell")
                                                   for x in ch[k][:60]]
        if ch["tier1"]:
            L += ["", "### Tier 1 items for Sam", "", "| Cell | State | Value | Seed | Why |", "|---|---|---|---|---|"]
            L += [f"| {t['cell']} | {t['state']} | {t['value']} | {t['seed']} | {t['why']} |" for t in ch["tier1"]]
    if rep.get("error"):
        L += ["", f"Refused / error: {rep['error']}"]
    return "\n".join(L) + "\n"


def _write(rep: dict, out: Path, stem: str = "landing") -> dict:
    """landing.json / landing.md for a landing or check; refused.json / refused.md for a refusal, so a later refusal
    (e.g. the same upload run twice) never overwrites the report of the landing that happened."""
    out.mkdir(parents=True, exist_ok=True)
    (out / f"{stem}.json").write_text(json.dumps(rep, indent=1, sort_keys=True, default=str) + "\n", encoding="utf-8")
    (out / f"{stem}.md").write_text(markdown(rep), encoding="utf-8")
    rep["out"] = str(out)
    return rep


def main(argv: list[str] | None = None, now: dt.datetime | None = None) -> int:
    """CLI. ``now`` (default: the wall clock) stamps the reports and the rebuilt manifest; tests pin it."""
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.macpass_landing", description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name, hlp in (("run", "verify the upload, rebuild data/mvp and report what changed"),
                      ("check", "verify the upload only (hashes, secrets, freshness, review, ledger)")):
        p = sub.add_parser(name, help=hlp)
        p.add_argument("--inbox", required=True, help="the upload folder, e.g. team/inbox/macpass-20261027")
        p.add_argument("--root", default=str(M.ROOT), help="econquest folder (default: %(default)s)")
        p.add_argument("--out", help="report folder (default: outputs/macpass/INBOX_NAME)")
        p.add_argument("--vintage-id", help="the applied vintage id (default: report.json's dsa_regate vintage)")
        if name == "run":
            p.add_argument("--dry-run", action="store_true", help="build and report, but keep data/mvp as it is")
    a = ap.parse_args(argv)
    root = Path(a.root).resolve()
    inbox = Path(a.inbox)
    inbox = inbox if inbox.is_absolute() else root / inbox
    out = Path(a.out) if a.out else root / "outputs" / "macpass" / inbox.name
    mvp_before = _mvp_stamp(root)
    try:
        rep = land(inbox, root, out, vintage_id=a.vintage_id, dry_run=getattr(a, "dry_run", False), check_only=a.cmd == "check",
                   now=now)
    except Refused as e:
        _fail(inbox, out, "refused", e, now)
        return 2
    except (LandingError, M.MvpError) as e:
        _fail(inbox, out, "error", e, now)
        return 1
    except KeyboardInterrupt:                            # EQ-A-0138: swap_in already put data/mvp back
        _fail(inbox, out, "interrupted", RuntimeError(f"stopped before the end; {_mvp_outcome(root, mvp_before)} "
                                                      "Rerun the same command"), now)
        return 1
    except Exception as e:  # noqa: BLE001 - EQ-A-0138: a damaged upload ends in one plain line, never a traceback
        _fail(inbox, out, "error", RuntimeError(f"the landing could not finish ({type(e).__name__}: "
                                                f"{' '.join(str(e).split())[:200]}); {_mvp_outcome(root, mvp_before)} "
                                                "Check the upload is what the Mac wrote (team/first-mac-pass.md step 15)"), now)
        return 1
    print(f"{rep['status']}; report {Path(rep['out']) / 'landing.md'}")
    rb = rep["steps"].get("rebuild")
    if rb:
        print(f"data/mvp dataset_sha256 {rb['dataset_sha256']}; {rb['m2_probe']}")
    return 0


def _mvp_stamp(root: Path) -> str | None:
    """sha256 of data/mvp/manifest.json (None when absent): tells whether a failed landing had already swapped."""
    p = M.mvp_dir(root) / "manifest.json"
    try:
        return _sha(p) if p.is_file() else None
    except OSError:
        return None


def _mvp_outcome(root: Path, before: str | None) -> str:
    """EQ-A-0138 (AGENT-09 Info): what a stopped landing left, measured, not assumed. data/ itself is never written."""
    if _mvp_stamp(root) == before:
        return "data/mvp and data/ are as they were (any half-built candidate was removed)."
    return ("data/mvp was already replaced by the verified new dataset when it stopped (data/ itself was not changed); "
            "the landing report may be missing.")


def _fail(inbox: Path, out: Path, kind: str, e: Exception, now: dt.datetime | None = None) -> None:
    print(f"{kind}: {e}", file=sys.stderr)
    try:
        _write({"schema": SCHEMA, "ticket": TICKET, "inbox": str(inbox), "status": kind, "error": str(e), "steps": {},
                "started_utc": _now(now)}, out, stem="refused")
    except OSError:
        pass


if __name__ == "__main__":
    sys.exit(main())
