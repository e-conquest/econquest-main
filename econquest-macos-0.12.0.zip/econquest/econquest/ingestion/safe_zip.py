"""Unpacked-size budget for zip containers (xlsx, xlsm, zip downloads) before anything decompresses them (SEC-A-010 L1).

A small compressed file can declare gigabytes of content (a decompression bomb, CWE-409). A cap on the compressed
size does not stop it: `ZipFile.testzip()` and `pandas.read_excel` decompress every member in full. Call
`check_zip_budget(zf)` (an open ZipFile) or `check_zip_file(path_or_bytes)` first. It reads only the central
directory (declared sizes), never member data. zipfile stops reading a member at its declared size and the CRC check
catches a header that lies, so the declared sizes are a sound budget.

Shared: crag_update.check_input and default_panel._read_frames (EQ-A-0069) use it; research/base.py
(read_excel_sheets, EQ-A-0067) can call `check_zip_file(io.BytesIO(body))` the same way.
"""
from __future__ import annotations

import io
import zipfile
from pathlib import Path

MAX_TOTAL_BYTES = 500 * 2**20          # all members, uncompressed
MAX_MEMBER_BYTES = 300 * 2**20         # any single member, uncompressed
MAX_RATIO = 200                        # uncompressed / compressed, for a member over RATIO_MIN_BYTES
RATIO_MIN_BYTES = 2**20                # small members compress far better (empty sheets, styles) and cost nothing
MAX_MEMBERS = 10_000


class ZipBudgetExceeded(ValueError):
    """The archive would unpack beyond the budget: refused before decompression."""


def check_zip_budget(zf: zipfile.ZipFile, *, max_total: int = MAX_TOTAL_BYTES, max_member: int = MAX_MEMBER_BYTES,
                     max_ratio: float = MAX_RATIO, ratio_min_bytes: int = RATIO_MIN_BYTES,
                     max_members: int = MAX_MEMBERS) -> int:
    """Raise ZipBudgetExceeded when the declared contents exceed the budget; else return the total uncompressed size."""
    infos = zf.infolist()
    if len(infos) > max_members:
        raise ZipBudgetExceeded(f"zip has {len(infos):,} members, over the {max_members:,} limit")
    total = 0
    for i in infos:
        if i.file_size > max_member:
            raise ZipBudgetExceeded(f"zip member {i.filename!r} unpacks to {i.file_size:,} bytes, over the {max_member:,}-byte limit")
        if i.file_size > ratio_min_bytes and i.file_size > max_ratio * max(i.compress_size, 1):
            raise ZipBudgetExceeded(f"zip member {i.filename!r} has compression ratio "
                                    f"{i.file_size / max(i.compress_size, 1):,.0f}:1, over {max_ratio:,.0f}:1 (decompression bomb?)")
        total += i.file_size
        if total > max_total:
            raise ZipBudgetExceeded(f"zip unpacks to more than {max_total:,} bytes in total")
    return total


def check_zip_file(src: str | Path | bytes | io.BytesIO, **limits) -> int:
    """check_zip_budget on a path, bytes or a BytesIO. zipfile.BadZipFile propagates (not a zip, or truncated)."""
    if isinstance(src, bytes):
        src = io.BytesIO(src)
    with zipfile.ZipFile(src) as zf:
        return check_zip_budget(zf, **limits)
